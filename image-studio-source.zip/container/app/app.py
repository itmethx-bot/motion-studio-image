"""Same protected image service on PC and Pod; ComfyUI is loopback-only."""
import argparse
import asyncio
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import secrets
import time
from urllib.parse import urlsplit
import zipfile
from aiohttp import web, ClientSession, ClientTimeout
from PIL import Image
from core import VERSION, atomic, validate, graph

ROOT=Path(__file__).resolve().parent
ID=re.compile(r'^[a-f0-9]{32}$')
POD=re.compile(r'^https://[a-zA-Z0-9]{8,40}-8188\.proxy\.runpod\.net/?$')
ACTIVE={'queued','running','downloading','unknown'}
PREFIX='/image-studio'

def checked_png(raw, plan):
    if len(raw)>30*1024**2: raise ValueError('ภาพผลลัพธ์ใหญ่เกิน 30 MB')
    with Image.open(io.BytesIO(raw)) as im:
        if im.format!='PNG' or im.size!=(plan['width'],plan['height']): raise ValueError('ชนิดหรือขนาดภาพผลลัพธ์ไม่ตรงงาน')
        im.load()

class Studio:
    def __init__(self,data,pod=False,engine=None):
        self.data=Path(data);self.data.mkdir(parents=True,exist_ok=True)
        self.pod=pod;self.engine=engine;self.sessions={};self.attempts=[];self.tasks={};self.lock=asyncio.Lock()
        codefile=self.data/'access-code.txt'
        if not codefile.exists():
            codefile.write_text(os.environ.get('MOTION_ACCESS_CODE') or secrets.token_urlsafe(24),encoding='utf-8')
        self.code=codefile.read_text(encoding='utf-8').strip()
        self.jobs={}
        for file in (self.data/'jobs').glob('*.json'):
            j=json.loads(file.read_text(encoding='utf-8'));self.jobs[j['id']]=j
        self.cached={}; self.cache_time=0

    def persist(self,j): atomic(self.data/'jobs'/(j['id']+'.json'),j)
    def check(self,r,mutation=False):
        bearer=r.headers.get('Authorization','')
        good_bearer=self.pod and secrets.compare_digest(bearer,'Bearer '+self.code)
        good_cookie=self.sessions.get(r.cookies.get('image_session',''),0)>time.time()
        if not (good_bearer or good_cookie): raise web.HTTPUnauthorized(text='กรุณาใส่รหัสเข้าใช้งานเดิม')
        if mutation:
            if r.headers.get('X-Requested-With')!='ImageStudio': raise web.HTTPForbidden(text='คำขอไม่ถูกต้อง')
            origin=r.headers.get('Origin')
            if origin and urlsplit(origin).netloc.lower()!=r.host.lower(): raise web.HTTPForbidden(text='ไม่อนุญาตคำขอจากเว็บไซต์อื่น')
    async def body(self,r):
        try:
            b=await r.json()
            if not isinstance(b,dict):raise ValueError()
            return b
        except (ValueError,TypeError):raise web.HTTPBadRequest(text='ข้อมูลไม่ถูกต้อง')
    async def login(self,r):
        if r.headers.get('X-Requested-With')!='ImageStudio':raise web.HTTPForbidden()
        if r.headers.get('Origin') and urlsplit(r.headers['Origin']).netloc.lower()!=r.host.lower():raise web.HTTPForbidden()
        now=time.time();self.attempts=[v for v in self.attempts if now-v<60]
        if len(self.attempts)>=10:raise web.HTTPTooManyRequests(text='รอ 1 นาทีแล้วลองใหม่')
        b=await self.body(r)
        if not isinstance(b.get('code'),str) or not secrets.compare_digest(b['code'],self.code):
            self.attempts.append(now);raise web.HTTPUnauthorized(text='รหัสไม่ถูกต้อง')
        token=secrets.token_urlsafe(32);self.sessions[token]=now+86400
        response=web.json_response({'ok':True});response.set_cookie('image_session',token,httponly=True,samesite='Strict',max_age=86400,
          secure=r.secure or r.headers.get('X-Forwarded-Proto')=='https');return response
    def settings(self):
        p=self.data/'connection.json';return json.loads(p.read_text(encoding='utf-8')) if p.exists() else None
    async def remote(self,method,path,body=None,raw=False):
        s=self.settings()
        if not s or not POD.fullmatch(s['url']):raise ValueError('ยังไม่ได้เชื่อม Pod รุ่น Text-to-Image')
        async with ClientSession(timeout=ClientTimeout(total=40)) as c:
            async with c.request(method,s['url'].rstrip('/')+PREFIX+'/api'+path,json=body,
                headers={'Authorization':'Bearer '+s['code'],'X-Requested-With':'ImageStudio'},allow_redirects=False) as r:
                if r.status!=200:
                    raise ValueError(f'Pod ตอบ HTTP {r.status} — ใช้ image รุ่น Text-to-Image และรหัสเชื่อมต่อให้ตรง')
                if raw:
                    data=bytearray()
                    async for chunk in r.content.iter_chunked(1024*1024):
                        data.extend(chunk)
                        if len(data)>30*1024**2:raise ValueError('ภาพใหญ่เกินขนาดที่รองรับ')
                    return bytes(data)
                return await r.json()
    async def status(self,r):
        self.check(r)
        local=self.engine.status() if self.engine else {'ready':False,'message':'ยังไม่ได้ติดตั้งโมเดลบน PC'}
        remote={'ready':False,'message':'เชื่อม Pod รุ่น Text-to-Image เพื่อใช้โมเดลใหญ่'}
        if not self.pod and self.settings():
            if time.time()-self.cache_time>8:
                try:
                    st=await self.remote('GET','/status')
                    self.cached=st['local'] if st.get('version')==VERSION else {'ready':False,'message':'Pod เป็นระบบรุ่นเก่า'}
                except Exception as e:self.cached={'ready':False,'message':str(e) if isinstance(e,ValueError) else 'ติดต่อ Pod ไม่ได้ ตรวจว่าเครื่องเปิดอยู่'}
                self.cache_time=time.time()
            remote=self.cached
        rows=sorted(self.jobs.values(),key=lambda j:j['created'],reverse=True)[:18]
        return web.json_response({'version':VERSION,'local':local,'runpod':remote,'pod_mode':self.pod,'jobs':rows,'busy':any(j['status'] in ACTIVE for j in self.jobs.values())})
    async def connection(self,r):
        self.check(r,True)
        if self.pod:raise web.HTTPNotFound()
        if any(j['status'] in ACTIVE for j in self.jobs.values()):raise web.HTTPConflict(text='รอรับงานเดิมหรือกู้ผลให้เสร็จก่อนเปลี่ยน Pod')
        b=await self.body(r)
        if not isinstance(b.get('url'),str) or not isinstance(b.get('code'),str):raise web.HTTPBadRequest(text='ลิงก์หรือรหัสไม่ถูกต้อง')
        url=b['url'].strip();code=b['code'].strip()
        if not POD.fullmatch(url) or not re.fullmatch(r'[A-Za-z0-9_-]{24,128}',code):raise web.HTTPBadRequest(text='ตรวจลิงก์พอร์ต 8188 และรหัสเชื่อมต่อ')
        # Verify the exact destination before saving credentials; do not accept redirects.
        async with ClientSession(timeout=ClientTimeout(total=20)) as c:
            async with c.get(url.rstrip('/')+PREFIX+'/api/status',headers={'Authorization':'Bearer '+code},allow_redirects=False) as response:
                if response.status!=200:raise web.HTTPBadRequest(text=f'เชื่อมไม่ได้ HTTP {response.status} — Pod ต้องใช้ image รุ่นสร้างภาพใหม่')
                st=await response.json()
                if st.get('version')!=VERSION or not st.get('pod_mode'):raise web.HTTPBadRequest(text='Pod ไม่ใช่ระบบ Text-to-Image รุ่นใหม่')
        atomic(self.data/'connection.json',{'url':url.rstrip('/'),'code':code});self.cache_time=0
        return web.json_response({'ok':True})
    async def template(self,r):
        self.check(r)
        if self.pod:raise web.HTTPNotFound()
        p=self.data/'template.json'
        if not p.exists():raise web.HTTPBadRequest(text='Docker image ใหม่ยังสร้างไม่เสร็จ')
        value=json.loads(p.read_text(encoding='utf-8'))
        if not value.get('image'):raise web.HTTPBadRequest(text='Docker image ใหม่ยังสร้างไม่เสร็จ')
        return web.json_response(value)
    async def submit(self,r):
        self.check(r,True);body=await self.body(r)
        try:plan=validate(body,self.pod)
        except ValueError as e:raise web.HTTPBadRequest(text=str(e))
        jid=body.get('id')
        if not isinstance(jid,str) or not ID.fullmatch(jid):raise web.HTTPBadRequest(text='รหัสงานไม่ถูกต้อง')
        async with self.lock:
            if jid in self.jobs:
                old=self.jobs[jid]
                if any(old['plan'][k]!=plan[k] for k in ('prompt','negative','target','ratio','quality')) or (body.get('seed') not in (None,'') and old['plan']['seed']!=plan['seed']):raise web.HTTPConflict(text='รหัสงานนี้ใช้กับข้อความอื่นแล้ว')
                return web.json_response(old)
            if any(j['status'] in ACTIVE for j in self.jobs.values()):raise web.HTTPConflict(text='มีงานเดิมที่ต้องรอหรือกู้ผลก่อน')
            if plan['target']=='local' or self.pod:
                if not self.engine or not self.engine.status()['ready']:raise web.HTTPConflict(text='GPU ยังไม่พร้อม กรุณารอการเตรียมโมเดล')
            else:
                s=await self.remote('GET','/status')
                if not s.get('local',{}).get('ready'):raise web.HTTPConflict(text='Pod ยังไม่พร้อม')
            j=dict(id=jid,created=time.time(),status='queued',message='กำลังส่งงาน',plan=plan)
            self.jobs[jid]=j;self.persist(j)
            self.tasks[jid]=asyncio.create_task(self.run(j))
        return web.json_response(j)
    async def run(self,j,recover=False):
        try:
            if j['plan']['target']=='runpod' and not self.pod:
                if not recover:
                    j['status']='unknown';j['message']='กำลังส่งงาน ตรวจผลก่อนส่งซ้ำ';self.persist(j)
                    await self.remote('POST','/jobs',dict(j['plan'],id=j['id']))
                for _ in range(2400):
                    try:st=await self.remote('GET','/jobs/'+j['id'])
                    except Exception:
                        j.update(status='unknown',message='ติดต่อ Pod ไม่ได้ กดกู้ผลเดิม ห้ามส่งซ้ำ');self.persist(j);return
                    if st['status']=='failed':raise ValueError(st.get('message','Pod สร้างภาพไม่สำเร็จ'))
                    if st['status']=='succeeded':
                        raw=await self.remote('GET','/jobs/'+j['id']+'/image',raw=True);break
                    j.update(status='running',message=st.get('message','GPU กำลังสร้างภาพ'));self.persist(j);await asyncio.sleep(3)
                else:raise ValueError('งานใช้เวลานานเกินกำหนด ตรวจ Pod ก่อนสร้างใหม่')
            else:
                raw=await self.engine.render(j,self.persist,recover)
            checked_png(raw,j['plan'])
            out=self.data/'outputs';out.mkdir(exist_ok=True)
            (out/(j['id']+'.png')).write_bytes(raw)
            atomic(out/(j['id']+'.json'),{'version':VERSION,'plan':j['plan'],'workflow':graph(j['plan'],j['id'])})
            j.update(status='succeeded',message='บันทึก PNG และค่าการสร้างลง PC แล้ว' if not self.pod else 'ภาพพร้อมดาวน์โหลด')
        except Exception as e:
            # A timed-out POST might have reached the GPU. Never automatically resubmit.
            unknown=j['status']=='unknown'
            j.update(status='unknown' if unknown else 'failed',message=('ผลการส่งงานยังไม่ชัดเจน กดกู้ผลเดิม ห้ามสร้างซ้ำ' if unknown else (str(e)[:600] if isinstance(e,ValueError) else 'สร้างภาพไม่สำเร็จ ตรวจ log ของระบบ')))
        finally:self.persist(j)
    async def recover(self,r):
        self.check(r,True);j=self.find(r)
        if j['status'] not in ACTIVE:return web.json_response(j)
        if j['id'] not in self.tasks or self.tasks[j['id']].done():self.tasks[j['id']]=asyncio.create_task(self.run(j,True))
        return web.json_response(j)
    def find(self,r):
        jid=r.match_info['id']
        if not ID.fullmatch(jid) or jid not in self.jobs:raise web.HTTPNotFound()
        return self.jobs[jid]
    async def job(self,r):self.check(r);return web.json_response(self.find(r))
    async def result(self,r):
        self.check(r);j=self.find(r)
        if j['status']!='succeeded':raise web.HTTPNotFound()
        return web.FileResponse(self.data/'outputs'/(j['id']+'.png'),headers={'Content-Disposition':f'inline; filename="image-{j["id"][:8]}.png"','Cache-Control':'private,no-store'})
    async def bundle(self,r):
        self.check(r);j=self.find(r)
        if j['status']!='succeeded':raise web.HTTPNotFound()
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
            for ext in ('png','json'):z.write(self.data/'outputs'/(j['id']+'.'+ext),'image.'+ext)
        return web.Response(body=buf.getvalue(),content_type='application/zip',headers={'Content-Disposition':f'attachment; filename="image-{j["id"][:8]}-for-video.zip"'})
    def app(self):
        @web.middleware
        async def errors(r, handler):
            try:return await handler(r)
            except ValueError as e:raise web.HTTPBadRequest(text=str(e)[:500])
            except (OSError,asyncio.TimeoutError):raise web.HTTPServiceUnavailable(text='ติดต่อ GPU ไม่ได้ กรุณาตรวจสถานะก่อนส่งงานซ้ำ')
        app=web.Application(client_max_size=12*1024,middlewares=[errors])
        async def home(r):return web.FileResponse(ROOT/'web/index.html',headers={'Cache-Control':'no-store'})
        async def root(r):raise web.HTTPFound(PREFIX+'/')
        for p in ('/','/motion-studio/'):app.router.add_get(p,root)
        app.router.add_get(PREFIX+'/',home)
        app.router.add_static(PREFIX+'/assets',ROOT/'web')
        for method,path,h in [('POST','/login',self.login),('GET','/status',self.status),('GET','/template',self.template),('POST','/connection',self.connection),('POST','/jobs',self.submit),('GET','/jobs/{id}',self.job),('POST','/jobs/{id}/recover',self.recover),('GET','/jobs/{id}/image',self.result),('GET','/jobs/{id}/bundle',self.bundle)]:
            app.router.add_route(method,PREFIX+'/api'+path,h)
        return app

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pod',action='store_true');parser.add_argument('--port',type=int,default=8767);parser.add_argument('--data',default=str(ROOT/'private-data'));args=parser.parse_args()
    from engine import Engine
    engine=Engine(ROOT,args.pod)
    studio=Studio(args.data,args.pod,engine)
    app=studio.app()
    async def start(app):engine.start()
    async def close(app):
        engine.close()
        for task in studio.tasks.values():task.cancel()
        for task in studio.tasks.values():
            with contextlib.suppress(asyncio.CancelledError):await task
    app.on_startup.append(start);app.on_cleanup.append(close)
    web.run_app(app,host='0.0.0.0' if args.pod else '127.0.0.1',port=args.port,print=None)

if __name__=='__main__':main()
