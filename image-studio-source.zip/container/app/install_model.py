import sys
from pathlib import Path
import time
from core import LOCAL_MODELS,POD_MODELS,model_artifacts
import download_model as d

def main():
    root=Path(__file__).resolve().parent
    comfy=root/'runtime/ComfyUI' if sys.argv[1]=='local' else Path('/workspace/ImageStudio/ComfyUI')
    target='local' if sys.argv[1]=='local' else 'runpod'
    # ระบุชื่อโมเดลเพื่อเตรียมชุดเดียวได้ ไม่ต้องดาวน์โหลดทุกชุดบน Pod
    selected=sys.argv[2:] or (list(LOCAL_MODELS) if target=='local' else ['qwen'])
    models=[item for model in selected for item in model_artifacts(model,target)]
    pending=d.pending_models(comfy/'models',models)
    d.storage_preflight(comfy,pending)
    for item in pending:
        for attempt in range(3):
            try:d.download_artifact(comfy/'models',item);break
            except d.InstallError as e:
                if not e.retryable or attempt==2:raise
                time.sleep(2*(attempt+1))
    # log ของแต่ละไฟล์แยก verified กับ checksum recorded (first download)
    print('Model installation complete; see per-file checksum status above.')
if __name__=='__main__':main()
