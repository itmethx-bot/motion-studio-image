import sys
from pathlib import Path
import time
from core import SDXL,QWEN
import download_model as d

def main():
    root=Path(__file__).resolve().parent
    comfy=root/'runtime/ComfyUI' if sys.argv[1]=='local' else Path('/workspace/ImageStudio/ComfyUI')
    pending=d.pending_models(comfy/'models',[SDXL] if sys.argv[1]=='local' else QWEN)
    d.storage_preflight(comfy,pending)
    for item in pending:
        for attempt in range(3):
            try:d.download_artifact(comfy/'models',item);break
            except d.InstallError as e:
                if not e.retryable or attempt==2:raise
                time.sleep(2*(attempt+1))
    print('All model checksums verified')
if __name__=='__main__':main()
