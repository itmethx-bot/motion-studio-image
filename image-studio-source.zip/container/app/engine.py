import asyncio
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
from aiohttp import ClientSession,ClientTimeout
from core import SDXL,QWEN,COMFY_COMMIT,graph

class Engine:
    def __init__(self,root,pod=False):
        self.root=Path(root);self.pod=pod;self.process=None;self.thread=None;self.stopped=threading.Event();self.launch_lock=threading.Lock()
        self.comfy=Path('/workspace/ImageStudio/ComfyUI') if pod else self.root/'runtime/ComfyUI'
        self.python=sys.executable if pod else str(self.root/'.venv/Scripts/python.exe')
        self.port=8199;self.base=f'http://127.0.0.1:{self.port}'
        self.state={'ready':False,'message':'กำลังตรวจระบบสร้างภาพ','model':'qwen' if pod else 'sdxl'}
    def status(self):
        if self.process and self.process.poll() is not None:self.state.update(ready=False,message='ComfyUI หยุดทำงาน ตรวจ engine.log')
        return dict(self.state)
    def start(self):
        if self.thread and self.thread.is_alive():return
        self.thread=threading.Thread(target=self.prepare,daemon=True);self.thread.start()
    def prepare(self):
        try:
            if not Path(self.python).is_file() or (not self.pod and not (self.comfy/'main.py').is_file()):
                raise ValueError('ยังไม่ได้ติดตั้งโหมด PC กรุณาเปิด setup-local.ps1')
            if not self.pod and (self.root/'private-data/setup-in-progress').exists():
                raise ValueError('กำลังติดตั้งโหมด PC ครั้งแรก รอ setup-local เสร็จแล้วเปิดเว็บใหม่')
            if self.pod and not self.comfy.exists():
                import shutil
                shutil.copytree('/opt/ComfyUI',self.comfy,ignore=shutil.ignore_patterns('.git','__pycache__'))
            # Do not reuse or take over another local service on the same port.
            import socket
            with socket.socket() as probe:
                if probe.connect_ex(('127.0.0.1',self.port))==0:raise ValueError('พอร์ต 8199 ถูกใช้งานอยู่ กรุณาปิด Image Studio รุ่นเดิมก่อน')
            check=subprocess.run([self.python,'-c','import torch; assert torch.cuda.is_available(), "CUDA unavailable"; print(torch.cuda.get_device_name(0))'],capture_output=True,text=True)
            if check.returncode:raise ValueError('ไม่พบ CUDA ที่ใช้งานได้ กรุณาตรวจการติดตั้ง PyTorch และ driver')
            self.state.update(message='กำลังตรวจ checksum และเตรียมโมเดล')
            import download_model as downloader
            models=QWEN if self.pod else [SDXL]
            pending=downloader.pending_models(self.comfy/'models',models)
            downloader.storage_preflight(self.comfy,pending)
            for item in pending:
                if self.stopped.is_set():return
                self.state.update(message='กำลังดาวน์โหลด '+item['id']+' (ไฟล์ถูกตรวจ checksum ก่อนใช้)')
                for attempt in range(3):
                    try:downloader.download_artifact(self.comfy/'models',item);break
                    except downloader.InstallError as e:
                        if not e.retryable or attempt==2:raise
                        time.sleep(2*(attempt+1))
            self.root.joinpath('logs').mkdir(exist_ok=True)
            self.log=(self.root/'logs/engine.log').open('a',encoding='utf-8')
            args=[self.python,str(self.comfy/'main.py'),'--listen','127.0.0.1','--port',str(self.port),'--disable-auto-launch','--fp32-vae']
            if not self.pod:args+=['--lowvram','--reserve-vram','1']
            with self.launch_lock:
                if self.stopped.is_set():self.log.close();return
                self.process=subprocess.Popen(args,cwd=self.comfy,stdout=self.log,stderr=subprocess.STDOUT)
            from urllib.request import urlopen
            self.state.update(message='กำลังเริ่ม GPU สร้างภาพ')
            for _ in range(180):
                if self.stopped.is_set():return
                if self.process.poll() is not None:raise ValueError('ComfyUI เริ่มไม่สำเร็จ ตรวจ logs/engine.log')
                try:
                    with urlopen(self.base+'/object_info',timeout=3) as response:schema=json.load(response)
                    from core import validate
                    plan=validate(dict(prompt='a landscape',target='runpod' if self.pod else 'local'))
                    for n in graph(plan,'a'*32).values():
                        if n['class_type'] not in schema:raise ValueError('ComfyUI ขาดโหนด '+n['class_type'])
                    self.state.update(ready=True,message='พร้อมสร้างภาพ — Qwen-Image บน RunPod' if self.pod else 'พร้อมสร้างภาพ — SDXL บน PC',gpu=check.stdout.strip())
                    return
                except ValueError:raise
                except Exception:time.sleep(2)
            raise ValueError('GPU เริ่มงานไม่ทันเวลา ตรวจ engine.log')
        except Exception as e:
            text=str(e) if isinstance(e,ValueError) or type(e).__name__=='InstallError' else type(e).__name__+': ตรวจ logs/engine.log'
            self.state.update(ready=False,message=text[:500])
    async def render(self,j,persist,recover=False):
        workflow=graph(j['plan'],j['id'])
        async with ClientSession(timeout=ClientTimeout(total=60)) as c:
            if not recover:
                async with c.get(self.base+'/queue') as r:
                    q=await r.json()
                    if q.get('queue_running') or q.get('queue_pending'):raise ValueError('GPU มีงานอื่นอยู่ รอให้เสร็จก่อน')
                j.update(status='unknown',message='กำลังส่งงานให้ GPU');persist(j)
                async with c.post(self.base+'/prompt',json={'prompt':workflow,'client_id':j['id'],'extra_data':{'image_studio_job':j['id']}}) as r:
                    result=await r.json()
                    if r.status!=200 or result.get('node_errors'):
                        j['status']='failed';raise ValueError('ComfyUI ไม่รับ workflow: '+json.dumps(result.get('node_errors',result.get('error',{})),ensure_ascii=False)[:450])
                    j['prompt_id']=result['prompt_id'];j.update(status='running',message='GPU กำลังสร้างภาพ');persist(j)
            if not j.get('prompt_id'):raise ValueError('ไม่ทราบ prompt ID — ตรวจคิวและผลบน GPU ก่อนส่งใหม่')
            for _ in range(2400):
                async with c.get(self.base+'/history/'+j['prompt_id']) as r:history=await r.json()
                row=history.get(j['prompt_id'])
                if row:
                    status=row.get('status',{})
                    errors=[msg[1] for msg in status.get('messages',[]) if msg[0] in ('execution_error','execution_interrupted')]
                    if errors:
                        err=errors[-1];raise ValueError('GPU สร้างภาพไม่สำเร็จ: '+str(err.get('exception_message',err.get('node_type','งานถูกหยุด')))[:350])
                    images=row.get('outputs',{}).get('10',{}).get('images',[])
                    if images:
                        item=images[0]
                        if item.get('type')!='output' or not re.fullmatch(r'[A-Za-z0-9_.-]+\.png',item.get('filename','')) or item.get('subfolder')!='image-studio':raise ValueError('ปลายทางภาพไม่ตรงกับงาน')
                        j.update(status='downloading',message='กำลังตรวจและบันทึกภาพ');persist(j)
                        async with c.get(self.base+'/view',params=item) as r:
                            if r.status!=200:raise ValueError('อ่านภาพผลลัพธ์ไม่ได้')
                            buf=bytearray()
                            async for chunk in r.content.iter_chunked(1024*1024):
                                buf.extend(chunk)
                                if len(buf)>30*1024**2:raise ValueError('ภาพใหญ่เกิน 30 MB')
                            return bytes(buf)
                    if status.get('completed'):raise ValueError('งานจบแต่ไม่พบ PNG ที่โหนด SaveImage')
                await asyncio.sleep(2)
            j['status']='unknown';raise ValueError('GPU ใช้เวลานาน ตรวจคิวเดิมก่อนสร้างต่อ')
    def close(self):
        self.stopped.set()
        with self.launch_lock:
            if self.process and self.process.poll() is None:
                self.process.terminate()
                try:self.process.wait(timeout=10)
                except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=5)
            if hasattr(self,'log') and not self.log.closed:self.log.close()
