import asyncio
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
from aiohttp import ClientSession,ClientTimeout
from core import SDXL,JUGGERNAUT,REALVIS,QWEN,FLUX,LOCAL_MODELS,POD_MODELS,FEATURES,COMFY_COMMIT,graph,model_artifacts

def recover_prompt_id(queue,history,job_id):
    matches=set()
    records=list(queue.get('queue_running',[]))+list(queue.get('queue_pending',[]))
    records += [row.get('prompt',[]) for row in history.values() if isinstance(row,dict)]
    for row in records:
        if isinstance(row,(list,tuple)) and len(row)>3 and isinstance(row[3],dict) and row[3].get('image_studio_job')==job_id:
            matches.add(row[1])
    if len(matches)>1:raise ValueError('พบมากกว่าหนึ่งงานที่ใช้รหัสเดียวกัน กรุณาตรวจคิวก่อนสร้างต่อ')
    return next(iter(matches),None)

class Engine:
    def __init__(self,root,pod=False):
        self.root=Path(root);self.pod=pod;self.process=None;self.thread=None;self.stopped=threading.Event();self.launch_lock=threading.Lock()
        # โหลดเฉพาะชุดที่เลือก ห้าม PC ดาวน์โหลด FLUX
        self.model_sets={'qwen':QWEN,'flux1_dev':FLUX} if pod else {'sdxl':[SDXL],'juggernaut_x':[JUGGERNAUT],'realvisxl':[REALVIS]}
        self.checked_models=set();self.model_lock=threading.Lock()
        self.comfy=Path('/workspace/ImageStudio/ComfyUI') if pod else self.root/'runtime/ComfyUI'
        self.python=sys.executable if pod else str(self.root/'.venv/Scripts/python.exe')
        self.port=8199;self.base=f'http://127.0.0.1:{self.port}'
        self.state={'ready':False,'message':'กำลังตรวจระบบสร้างภาพ','model':'qwen' if pod else 'juggernaut_x',
                    'models':list(self.model_sets),'features':FEATURES}
    def status(self):
        if self.process and self.process.poll() is not None:self.state.update(ready=False,message='ComfyUI หยุดทำงาน ตรวจ engine.log')
        return dict(self.state)
    def start(self):
        if self.thread and self.thread.is_alive():return
        self.thread=threading.Thread(target=self.prepare,daemon=True);self.thread.start()
    def install_for_model(self,model,progress=None):
        if model not in self.model_sets:raise ValueError('โมเดลไม่ตรงกับ GPU ของโหมดนี้')
        with self.model_lock:
            if model in self.checked_models:return
            import download_model as downloader
            models=model_artifacts(model,'runpod' if self.pod else 'local')
            # checksum ว่างจะบันทึกใน models/.checksums.json โดยตัวดาวน์โหลด
            first_download=any(not item.get('checksum') for item in models)
            if progress:progress('กำลังตรวจไฟล์โมเดล '+model)
            pending=downloader.pending_models(self.comfy/'models',models)
            downloader.storage_preflight(self.comfy,pending)
            for item in pending:
                if self.stopped.is_set():raise ValueError('ระบบถูกปิดก่อนเตรียมโมเดลเสร็จ')
                if progress:progress('กำลังดาวน์โหลด '+item['id']+(' และบันทึก SHA256 ครั้งแรก' if not item.get('checksum') else ' และตรวจ SHA256')+' (ครั้งแรกใช้เวลานาน)')
                for attempt in range(3):
                    try:downloader.download_artifact(self.comfy/'models',item);break
                    except downloader.InstallError as e:
                        if not e.retryable or attempt==2:raise
                        time.sleep(2*(attempt+1))
            self.checked_models.add(model)
            if progress and first_download:progress('เตรียมโมเดลแล้ว — ใช้ checksum ที่บันทึกครั้งแรกเพื่อตรวจไฟล์')
    def prepare(self):
        try:
            if not Path(self.python).is_file() or (not self.pod and not (self.comfy/'main.py').is_file()):
                raise ValueError('ยังไม่ได้ติดตั้งโหมด PC กรุณาเปิด setup-local.ps1')
            if not self.pod and (self.root/'private-data/setup-in-progress').exists():
                raise ValueError('กำลังติดตั้งโหมด PC ครั้งแรก รอ setup-local เสร็จแล้วเปิดเว็บใหม่')
            if self.pod and not self.comfy.exists():
                import shutil
                shutil.copytree('/opt/ComfyUI',self.comfy,ignore=shutil.ignore_patterns('.git','__pycache__'))
            # Do not reuse or take over another local service on the same port.
            import socket
            with socket.socket() as probe:
                if probe.connect_ex(('127.0.0.1',self.port))==0:raise ValueError('พอร์ต 8199 ถูกใช้งานอยู่ กรุณาปิด Image Studio รุ่นเดิมก่อน')
            check=subprocess.run([self.python,'-c','import json,torch; assert torch.cuda.is_available(), "CUDA unavailable"; print(json.dumps(dict(name=torch.cuda.get_device_name(0),vram_gib=torch.cuda.get_device_properties(0).total_memory/1024**3)))'],capture_output=True,text=True)
            if check.returncode:raise ValueError('ไม่พบ CUDA ที่ใช้งานได้ กรุณาตรวจการติดตั้ง PyTorch และ driver')
            self.state.update(message='กำลังตรวจ checksum และเตรียมโมเดล')
            gpu=json.loads(check.stdout.strip())
            self.state.update(gpu=gpu['name'],vram_gib=gpu['vram_gib'])
            # Pod เริ่ม ComfyUI ก่อน แล้วค่อยติดตั้ง Qwen หรือ FLUX ตามงานที่เลือก
            if not self.pod:
                for model in ('sdxl','juggernaut_x'):
                    self.install_for_model(model,lambda message:self.state.update(message=message))
            self.root.joinpath('logs').mkdir(exist_ok=True)
            self.log=(self.root/'logs/engine.log').open('a',encoding='utf-8')
            args=[self.python,str(self.comfy/'main.py'),'--listen','127.0.0.1','--port',str(self.port),'--disable-auto-launch','--fp32-vae']
            if not self.pod:args+=['--lowvram','--reserve-vram','1']
            with self.launch_lock:
                if self.stopped.is_set():self.log.close();return
                self.process=subprocess.Popen(args,cwd=self.comfy,stdout=self.log,stderr=subprocess.STDOUT)
            from urllib.request import urlopen
            self.state.update(message='กำลังเริ่ม GPU สร้างภาพ')
            for _ in range(180):
                if self.stopped.is_set():return
                if self.process.poll() is not None:raise ValueError('ComfyUI เริ่มไม่สำเร็จ ตรวจ logs/engine.log')
                try:
                    with urlopen(self.base+'/object_info',timeout=3) as response:schema=json.load(response)
                    from core import validate
                    for model in self.model_sets:
                        plan=validate(dict(prompt='a landscape',model=model,target='runpod' if self.pod else 'local'))
                        for n in graph(plan,'a'*32).values():
                            if n['class_type'] not in schema:raise ValueError('ComfyUI ขาดโหนด '+n['class_type'])
                    self.state.update(ready=True,message='พร้อมสร้างภาพ — Qwen / FLUX บน RunPod' if self.pod else 'พร้อมสร้างภาพ — SDXL / Juggernaut / RealVisXL บน PC')
                    return
                except ValueError:raise
                except Exception:time.sleep(2)
            raise ValueError('GPU เริ่มงานไม่ทันเวลา ตรวจ engine.log')
        except Exception as e:
            text=str(e) if isinstance(e,ValueError) or type(e).__name__=='InstallError' else type(e).__name__+': ตรวจ logs/engine.log'
            self.state.update(ready=False,message=text[:500])
    async def render(self,j,persist,recover=False):
        if not recover:
            if self.pod and j['plan']['model']=='flux1_dev' and self.state.get('vram_gib',0)<40:
                raise ValueError('FLUX.1-dev รุ่นเต็มควรใช้ Pod VRAM 48 GB ขึ้นไป')
            def progress(message):j.update(status='running',message=message);persist(j)
            # การดาวน์โหลดล้มเหลวไม่ทำให้งานโมเดลเดิมหรือ service ล่ม
            await asyncio.to_thread(self.install_for_model,j['plan']['model'],progress)
        workflow=graph(j['plan'],j['id'])
        async with ClientSession(timeout=ClientTimeout(total=60)) as c:
            if not recover:
                async with c.get(self.base+'/queue') as r:
                    q=await r.json()
                    if q.get('queue_running') or q.get('queue_pending'):raise ValueError('GPU มีงานอื่นอยู่ รอให้เสร็จก่อน')
                j.update(status='unknown',message='กำลังส่งงานให้ GPU');persist(j)
                async with c.post(self.base+'/prompt',json={'prompt':workflow,'client_id':j['id'],'extra_data':{'image_studio_job':j['id']}}) as r:
                    result=await r.json()
                    if r.status!=200 or result.get('node_errors'):
                        j['status']='failed';raise ValueError('ComfyUI ไม่รับ workflow: '+json.dumps(result.get('node_errors',result.get('error',{})),ensure_ascii=False)[:450])
                    j['prompt_id']=result['prompt_id'];j.update(status='running',message='GPU กำลังสร้างภาพ');persist(j)
            if recover and not j.get('prompt_id'):
                async with c.get(self.base+'/queue') as r:q=await r.json()
                async with c.get(self.base+'/history',params={'max_items':200}) as r:h=await r.json()
                found=recover_prompt_id(q,h,j['id'])
                if found:j.update(prompt_id=found,status='running',message='พบงานเดิมบน GPU กำลังกู้ผล');persist(j)
            if not j.get('prompt_id'):raise ValueError('ยังไม่พบงานเดิมในคิวหรือประวัติ GPU — ไม่ส่งงานใหม่ซ้ำ')
            for _ in range(2400):
                async with c.get(self.base+'/history/'+j['prompt_id']) as r:history=await r.json()
                row=history.get(j['prompt_id'])
                if row:
                    status=row.get('status',{})
                    errors=[msg[1] for msg in status.get('messages',[]) if msg[0] in ('execution_error','execution_interrupted')]
                    if errors:
                        err=errors[-1];raise ValueError('GPU สร้างภาพไม่สำเร็จ: '+str(err.get('exception_message',err.get('node_type','งานถูกหยุด')))[:350])
                    images=row.get('outputs',{}).get('10',{}).get('images',[])
                    if images:
                        item=images[0]
                        if item.get('type')!='output' or not re.fullmatch(r'[A-Za-z0-9_.-]+\.png',item.get('filename','')) or item.get('subfolder')!='image-studio':raise ValueError('ปลายทางภาพไม่ตรงกับงาน')
                        j.update(status='downloading',message='กำลังตรวจและบันทึกภาพ');persist(j)
                        async with c.get(self.base+'/view',params=item) as r:
                            if r.status!=200:raise ValueError('อ่านภาพผลลัพธ์ไม่ได้')
                            buf=bytearray()
                            async for chunk in r.content.iter_chunked(1024*1024):
                                buf.extend(chunk)
                                if len(buf)>30*1024**2:raise ValueError('ภาพใหญ่เกิน 30 MB')
                            return bytes(buf)
                    if status.get('completed'):raise ValueError('งานจบแต่ไม่พบ PNG ที่โหนด SaveImage')
                await asyncio.sleep(2)
            j['status']='unknown';raise ValueError('GPU ใช้เวลานาน ตรวจคิวเดิมก่อนสร้างต่อ')
    def close(self):
        self.stopped.set()
        with self.launch_lock:
            if self.process and self.process.poll() is None:
                self.process.terminate()
                try:self.process.wait(timeout=10)
                except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=5)
            if hasattr(self,'log') and not self.log.closed:self.log.close()
