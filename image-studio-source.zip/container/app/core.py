"""Text-to-image only. No video inputs, face swapping or provider lifecycle API."""
import json
import secrets
from pathlib import Path

VERSION = 'image-studio-1'
COMFY_COMMIT = 'f1072eb0350638a3390ddb6afbcaa8c6b237c6fd'
RATIOS = {'portrait': (832,1216), 'square': (1024,1024), 'landscape': (1216,832)}
LOCAL_RATIOS = {'portrait': (640,896), 'square': (768,768), 'landscape': (896,640)}
NEGATIVE = 'low quality, blurry, distorted anatomy, extra fingers, extra limbs, watermark'

def atomic(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.'+secrets.token_hex(8)+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def validate(body, pod=False):
    target='runpod' if pod else body.get('target','local')
    if target not in ('local','runpod'): raise ValueError('เลือก PC หรือ RunPod')
    prompt=body.get('prompt','')
    if not isinstance(prompt,str) or not 3<=len(prompt.strip())<=3000: raise ValueError('ใส่คำบรรยายภาพ 3–3,000 ตัวอักษร')
    negative=body.get('negative',NEGATIVE)
    if not isinstance(negative,str) or len(negative)>1000: raise ValueError('ข้อความสิ่งที่ไม่ต้องการยาวเกินไป')
    ratio=body.get('ratio','portrait')
    if ratio not in RATIOS: raise ValueError('สัดส่วนภาพไม่ถูกต้อง')
    seed=body.get('seed')
    if seed in (None,''): seed=secrets.randbelow(2**53)
    elif isinstance(seed,bool) or not isinstance(seed,int) or not 0<=seed<2**53: raise ValueError('Seed ต้องเป็นจำนวนเต็ม 0–9007199254740991')
    quality=body.get('quality','standard')
    if quality not in ('draft','standard','high'): raise ValueError('ระดับคุณภาพไม่ถูกต้อง')
    steps=({'draft':12,'standard':24,'high':32} if target=='local' else {'draft':20,'standard':32,'high':40})[quality]
    w,h=(LOCAL_RATIOS if target=='local' else RATIOS)[ratio]
    return dict(prompt=prompt.strip(),negative=negative.strip(),target=target,ratio=ratio,seed=seed,
                quality=quality,steps=steps,width=w,height=h,model='sdxl' if target=='local' else 'qwen')

def graph(plan, job_id):
    def node(cls, **inputs): return {'class_type':cls,'inputs':inputs}
    if plan['model']=='sdxl':
        g={'1':node('CheckpointLoaderSimple',ckpt_name='sd_xl_base_1.0.safetensors')}
        model=['1',0]; clip=['1',1]; vae=['1',2]; empty='EmptyLatentImage'
    else:
        g={'1':node('UNETLoader',unet_name='qwen_image_fp8_e4m3fn.safetensors',weight_dtype='default'),
           '2':node('CLIPLoader',clip_name='qwen_2.5_vl_7b_fp8_scaled.safetensors',type='qwen_image',device='default'),
           '3':node('VAELoader',vae_name='qwen_image_vae.safetensors'),
           '4':node('ModelSamplingAuraFlow',model=['1',0],shift=3.1)}
        model=['4',0];clip=['2',0];vae=['3',0];empty='EmptySD3LatentImage'
    g.update({'5':node('CLIPTextEncode',text=plan['prompt'],clip=clip),
      '6':node('CLIPTextEncode',text=plan['negative'],clip=clip),
      '7':node(empty,width=plan['width'],height=plan['height'],batch_size=1),
      '8':node('KSampler',model=model,positive=['5',0],negative=['6',0],latent_image=['7',0],
          seed=plan['seed'],steps=plan['steps'],cfg=6.0 if plan['model']=='sdxl' else 4.0,
          sampler_name='dpmpp_2m' if plan['model']=='sdxl' else 'euler',scheduler='karras' if plan['model']=='sdxl' else 'simple',denoise=1.0),
      '9':node('VAEDecode',samples=['8',0],vae=vae),
      '10':node('SaveImage',images=['9',0],filename_prefix='image-studio/'+job_id)})
    return g

SDXL={'id':'sdxl','path':'checkpoints/sd_xl_base_1.0.safetensors','bytes':6938078334,
  'checksum_algorithm':'sha256','checksum':'31e35c80fc4829d14f90153f4c74cd59c90b779f6afe05a74cd6120b893f7e5b',
  'url':'https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/f298da3c058bd8f1f1c62f3ecfa775244a243897/sd_xl_base_1.0.safetensors'}
QWEN=[{'id':'qwen','path':'diffusion_models/qwen_image_fp8_e4m3fn.safetensors','bytes':20430635136,
  'checksum_algorithm':'sha256','checksum':'98763a127701eb6fb59096f7742cb3aa7d64ed510b9f4e882d8351f8176e3ce3',
  'url':'https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/a4875863818e93fdb65f366d1d7a201581d05eeb/split_files/diffusion_models/qwen_image_fp8_e4m3fn.safetensors'},
 {'id':'qwen_text','path':'text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors','bytes':9384670680,
  'checksum_algorithm':'sha256','checksum':'cb5636d852a0ea6a9075ab1bef496c0db7aef13c02350571e388aea959c5c0b4',
  'url':'https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/1405a2b738c29b890cf6d03fc038d8d3e92eeed7/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors'},
 {'id':'qwen_vae','path':'vae/qwen_image_vae.safetensors','bytes':253806246,
  'checksum_algorithm':'sha256','checksum':'a70580f0213e67967ee9c95f05bb400e8fb08307e017a924bf3441223e023d1f',
  'url':'https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/1f12b17be14c89b026c51a91d67c32f84bb047bc/split_files/vae/qwen_image_vae.safetensors'}]
