"""Text-to-image only. No video inputs, face swapping or provider lifecycle API."""
import json
import re
import secrets
from pathlib import Path

VERSION = 'image-studio-1'
COMFY_COMMIT = 'f1072eb0350638a3390ddb6afbcaa8c6b237c6fd'
RATIOS = {'portrait': (832,1216), 'square': (1024,1024), 'landscape': (1216,832)}
LOCAL_RATIOS = {'portrait': (640,896), 'square': (768,768), 'landscape': (896,640)}
# เก็บขนาดเดิมเป็นโหมดเร็ว และเพิ่มขนาดใกล้ native สำหรับ PC
LOCAL_FAST_RATIOS = dict(LOCAL_RATIOS)
LOCAL_RATIOS = {'portrait': (768,1152), 'square': (1024,1024), 'landscape': (1152,768)}
NEGATIVE = 'low quality, blurry, distorted anatomy, extra fingers, extra limbs, fused fingers, mutated hands, plastic skin, oversmooth skin, cgi, 3d render, doll, waxy, airbrushed, bad proportions, watermark'
POSITIVE_PREFIX = 'photorealistic, RAW photo, natural skin texture, film grain, sharp focus, '
LOCAL_MODELS = ('sdxl','juggernaut_x','realvisxl')
POD_MODELS = ('qwen','flux1_dev')
FEATURES = ['realism-presets','realvisxl','flux1_dev']

def atomic(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.'+secrets.token_hex(8)+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def validate(body, pod=False):
    target='runpod' if pod else body.get('target','local')
    if target not in ('local','runpod'): raise ValueError('เลือก PC หรือ RunPod')
    prompt=body.get('prompt','')
    if not isinstance(prompt,str) or not 3<=len(prompt.strip())<=3000: raise ValueError('ใส่คำบรรยายภาพ 3–3,000 ตัวอักษร')
    negative=body.get('negative',NEGATIVE)
    if not isinstance(negative,str) or len(negative)>1000: raise ValueError('ข้อความสิ่งที่ไม่ต้องการยาวเกินไป')
    ratio=body.get('ratio','portrait')
    if ratio not in RATIOS: raise ValueError('สัดส่วนภาพไม่ถูกต้อง')
    seed=body.get('seed')
    if seed in (None,''): seed=secrets.randbelow(2**53)
    elif isinstance(seed,bool) or not isinstance(seed,int) or not 0<=seed<2**53: raise ValueError('Seed ต้องเป็นจำนวนเต็ม 0–9007199254740991')
    quality=body.get('quality','standard')
    if quality not in ('draft','standard','high'): raise ValueError('ระดับคุณภาพไม่ถูกต้อง')
    model=body.get('model','qwen' if target=='runpod' else 'juggernaut_x')
    if model not in (LOCAL_MODELS if target=='local' else POD_MODELS): raise ValueError('โมเดลไม่ตรงกับโหมด PC / RunPod ที่เลือก')
    resolution=body.get('resolution','native')
    if resolution not in ('native','fast'): raise ValueError('เลือกขนาดภาพแบบมาตรฐานหรือเร็ว')
    # FLUX ใช้ guidance ใน conditioning แยกจาก CFG ของ KSampler
    steps=({'draft':24,'standard':40,'high':48} if target=='local' else
           {'draft':20,'standard':24,'high':28} if model=='flux1_dev' else {'draft':20,'standard':32,'high':40})[quality]
    w,h=(LOCAL_FAST_RATIOS if target=='local' and resolution=='fast' else LOCAL_RATIOS if target=='local' else RATIOS)[ratio]
    return dict(prompt=prompt.strip(),negative=negative.strip(),target=target,ratio=ratio,seed=seed,
                quality=quality,steps=steps,width=w,height=h,model=model,resolution=resolution,
                positive_prompt=POSITIVE_PREFIX+prompt.strip(),
                cfg=1.0 if model=='flux1_dev' else 5.0 if model in ('juggernaut_x','realvisxl') else 6.0 if model=='sdxl' else 4.0,
                sampler='dpmpp_2m' if target=='local' else 'euler',
                scheduler='karras' if target=='local' else 'simple',
                **({'guidance':3.5} if model=='flux1_dev' else {}))

def graph(plan, job_id):
    def node(cls, **inputs): return {'class_type':cls,'inputs':inputs}
    if plan['model'] in LOCAL_MODELS:
        checkpoint={'sdxl':SDXL,'juggernaut_x':JUGGERNAUT,'realvisxl':REALVIS}[plan['model']]
        g={'1':node('CheckpointLoaderSimple',ckpt_name=Path(checkpoint['path']).name)}
        model=['1',0]; clip=['1',1]; vae=['1',2]; empty='EmptyLatentImage'
    elif plan['model']=='qwen':
        g={'1':node('UNETLoader',unet_name='qwen_image_fp8_e4m3fn.safetensors',weight_dtype='default'),
           '2':node('CLIPLoader',clip_name='qwen_2.5_vl_7b_fp8_scaled.safetensors',type='qwen_image',device='default'),
           '3':node('VAELoader',vae_name='qwen_image_vae.safetensors'),
           '4':node('ModelSamplingAuraFlow',model=['1',0],shift=3.1)}
        model=['4',0];clip=['2',0];vae=['3',0];empty='EmptySD3LatentImage'
    elif plan['model']=='flux1_dev':
        # เส้นทางใหม่ใช้ diffusion + T5/CLIP-L + AE ไม่ใช้ checkpoint SDXL
        g={'1':node('UNETLoader',unet_name='flux1-dev.safetensors',weight_dtype='default'),
           '2':node('DualCLIPLoader',clip_name1='t5xxl_fp16.safetensors',clip_name2='clip_l.safetensors',type='flux',device='default'),
           '3':node('VAELoader',vae_name='ae.safetensors'),
           '4':node('ModelSamplingFlux',model=['1',0],max_shift=1.15,base_shift=0.5,width=plan['width'],height=plan['height']),
           '11':node('FluxGuidance',conditioning=['5',0],guidance=plan.get('guidance',3.5))}
        model=['4',0];clip=['2',0];vae=['3',0];empty='EmptySD3LatentImage'
    else: raise ValueError('ไม่รู้จักโมเดลสร้างภาพ')
    # งานเก่าที่ไม่มี positive_prompt ยังคงใช้ข้อความเดิมทุกตัวอักษร
    g.update({'5':node('CLIPTextEncode',text=plan.get('positive_prompt',plan['prompt']),clip=clip),
      '6':node('CLIPTextEncode',text=plan['negative'],clip=clip),
      '7':node(empty,width=plan['width'],height=plan['height'],batch_size=1),
      '8':node('KSampler',model=model,positive=['11',0] if plan['model']=='flux1_dev' else ['5',0],negative=['6',0],latent_image=['7',0],
          seed=plan['seed'],steps=plan['steps'],cfg=plan.get('cfg',1.0 if plan['model']=='flux1_dev' else 6.0 if plan['model']=='sdxl' else 5.0 if plan['model'] in LOCAL_MODELS else 4.0),
          sampler_name=plan.get('sampler','euler' if plan['model'] in POD_MODELS else 'dpmpp_2m'),
          scheduler=plan.get('scheduler','simple' if plan['model'] in POD_MODELS else 'karras'),denoise=1.0),
      '9':node('VAEDecode',samples=['8',0],vae=vae),
      '10':node('SaveImage',images=['9',0],filename_prefix='image-studio/'+job_id)})
    return g

def model_artifacts(model, target):
    """แยกไฟล์ของ PC และ Pod ก่อนดาวน์โหลดทุกครั้ง"""
    allowed=LOCAL_MODELS if target=='local' else POD_MODELS if target=='runpod' else ()
    if model not in allowed: raise ValueError('ห้ามโหลดโมเดลข้ามโหมด PC / RunPod')
    items={'sdxl':[SDXL],'juggernaut_x':[JUGGERNAUT],'realvisxl':[REALVIS],'qwen':QWEN,'flux1_dev':FLUX}[model]
    result=[]
    for entry in items:
        item=dict(entry)
        if item['id']=='realvisxl' and (item['bytes'] is None or item['checksum'] is None):
            # ใช้ข้อมูลจริงที่ตรวจจากผู้พัฒนาแทน placeholder โดยไม่ข้าม checksum
            verified=json.loads(Path(__file__).with_name('model-manifest.json').read_text(encoding='utf-8'))['realvisxl']
            if verified['id']!=item['id'] or verified['path']!=item['path']: raise ValueError('ข้อมูล RealVisXL ไม่ตรง registry')
            item.update({k:verified[k] for k in ('bytes','checksum','url')})
        if type(item['bytes']) is not int or item['bytes']<=0 or item['checksum_algorithm']!='sha256' or not isinstance(item['checksum'],str) or not re.fullmatch(r'[a-f0-9]{64}',item['checksum']):
            raise ValueError('ให้เติมขนาดและ sha256 จริงก่อนติดตั้ง '+item['id'])
        result.append(item)
    return result

SDXL={'id':'sdxl','path':'checkpoints/sd_xl_base_1.0.safetensors','bytes':6938078334,
  'checksum_algorithm':'sha256','checksum':'31e35c80fc4829d14f90153f4c74cd59c90b779f6afe05a74cd6120b893f7e5b',
  'url':'https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/f298da3c058bd8f1f1c62f3ecfa775244a243897/sd_xl_base_1.0.safetensors'}
JUGGERNAUT={'id':'juggernaut_x','path':'checkpoints/Juggernaut-X-RunDiffusion-NSFW.safetensors','bytes':7105348672,
  'checksum_algorithm':'sha256','checksum':'d91d35736d8f2be038f760a9b0009a771ecf0a417e9b38c244a84ea4cb9c0c45',
  'url':'https://huggingface.co/RunDiffusion/Juggernaut-X-v10/resolve/35e4f3ccbe745c3e1221715d04a452aaa1ee5761/Juggernaut-X-RunDiffusion-NSFW.safetensors'}
# ให้ผู้ใช้เติมค่า sha256 จริง; manifest ที่แนบไว้มีค่าจริงสำหรับติดตั้งรุ่นนี้
REALVIS={'id':'realvisxl','path':'checkpoints/RealVisXL_V5.0_fp16.safetensors','bytes':None,
  'checksum_algorithm':'sha256','checksum':None,
  'url':'https://huggingface.co/SG161222/RealVisXL_V5.0/resolve/main/RealVisXL_V5.0_fp16.safetensors'}
# FLUX มี 4 ไฟล์จริง: diffusion, T5, CLIP-L และ VAE — ใช้เฉพาะ RunPod
FLUX=[{'id':'flux1_dev','path':'diffusion_models/flux1-dev.safetensors','bytes':23802932552,
  'checksum_algorithm':'sha256','checksum':'4610115bb0c89560703c892c59ac2742fa821e60ef5871b33493ba544683abd7',
  'url':'https://huggingface.co/black-forest-labs/FLUX.1-dev/resolve/3de623fc3c33e44ffbe2bad470d0f45bccf2eb21/flux1-dev.safetensors'},
 {'id':'flux_t5','path':'text_encoders/t5xxl_fp16.safetensors','bytes':9787841024,
  'checksum_algorithm':'sha256','checksum':'6e480b09fae049a72d2a8c5fbccb8d3e92febeb233bbe9dfe7256958a9167635',
  'url':'https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/6af2a98e3f615bdfa612fbd85da93d1ed5f69ef5/t5xxl_fp16.safetensors'},
 {'id':'flux_clip','path':'text_encoders/clip_l.safetensors','bytes':246144152,
  'checksum_algorithm':'sha256','checksum':'660c6f5b1abae9dc498ac2d21e1347d2abdb0cf6c0c0c8576cd796491d9a6cdd',
  'url':'https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/6af2a98e3f615bdfa612fbd85da93d1ed5f69ef5/clip_l.safetensors'},
 {'id':'flux_vae','path':'vae/ae.safetensors','bytes':335304388,
  'checksum_algorithm':'sha256','checksum':'afc8e28272cd15db3919bacdb6918ce9c1ed22e96cb12c4d5ed0fba823529e38',
  'url':'https://huggingface.co/black-forest-labs/FLUX.1-dev/resolve/3de623fc3c33e44ffbe2bad470d0f45bccf2eb21/ae.safetensors'}]
QWEN=[{'id':'qwen','path':'diffusion_models/qwen_image_fp8_e4m3fn.safetensors','bytes':20430635136,
  'checksum_algorithm':'sha256','checksum':'98763a127701eb6fb59096f7742cb3aa7d64ed510b9f4e882d8351f8176e3ce3',
  'url':'https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/a4875863818e93fdb65f366d1d7a201581d05eeb/split_files/diffusion_models/qwen_image_fp8_e4m3fn.safetensors'},
 {'id':'qwen_text','path':'text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors','bytes':9384670680,
  'checksum_algorithm':'sha256','checksum':'cb5636d852a0ea6a9075ab1bef496c0db7aef13c02350571e388aea959c5c0b4',
  'url':'https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/1405a2b738c29b890cf6d03fc038d8d3e92eeed7/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors'},
 {'id':'qwen_vae','path':'vae/qwen_image_vae.safetensors','bytes':253806246,
  'checksum_algorithm':'sha256','checksum':'a70580f0213e67967ee9c95f05bb400e8fb08307e017a924bf3441223e023d1f',
  'url':'https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/1f12b17be14c89b026c51a91d67c32f84bb047bc/split_files/vae/qwen_image_vae.safetensors'}]
