import asyncio
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import AsyncMock
from aiohttp.test_utils import TestClient,TestServer
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import validate,graph,SDXL,QWEN
from app import Studio,checked_png

class Plans(unittest.TestCase):
    def test_local_stays_in_small_vram_budget(self):
        for ratio in ('portrait','square','landscape'):
            p=validate(dict(prompt='a green forest',ratio=ratio))
            self.assertLessEqual(p['width']*p['height'],768*768)
            self.assertEqual(p['model'],'sdxl')
    def test_large_model_does_not_use_image_edit_or_video(self):
        p=validate(dict(prompt='two friends hiking',target='runpod'))
        g=graph(p,'a'*32)
        self.assertEqual(g['1']['inputs']['unet_name'],'qwen_image_fp8_e4m3fn.safetensors')
        self.assertFalse(any('Edit' in n['class_type'] or 'Video' in n['class_type'] or 'LoadImage'==n['class_type'] for n in g.values()))
        self.assertTrue(all(a['checksum_algorithm']=='sha256' and len(a['checksum'])==64 for a in [SDXL]+QWEN))
    def test_rejects_invalid_seed_and_unbounded_requests(self):
        for b in [dict(seed=True),dict(seed=-1),dict(seed=2**53),dict(prompt='x'*3001),dict(target='other'),dict(ratio='huge')]:
            with self.assertRaises(ValueError):validate(dict(prompt='a landscape',**b)) if 'prompt' not in b else validate(b)
    def test_checked_png_rejects_wrong_dimensions_and_format(self):
        p=validate(dict(prompt='a photo'));b=io.BytesIO();Image.new('RGB',(64,64)).save(b,format='PNG')
        with self.assertRaises(ValueError):checked_png(b.getvalue(),p)

class FakeEngine:
    def __init__(self):self.calls=0;self.gate=asyncio.Event();self.gate.set()
    def status(self):return dict(ready=True,message='test engine')
    async def render(self,j,persist,recover=False):
        self.calls+=1;await self.gate.wait();buf=io.BytesIO();Image.new('RGB',(j['plan']['width'],j['plan']['height']),'#81aa72').save(buf,format='PNG');return buf.getvalue()

class HTTP(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.engine=FakeEngine();self.studio=Studio(self.temp.name,engine=self.engine)
        self.client=TestClient(TestServer(self.studio.app()));await self.client.start_server()
        self.headers={'X-Requested-With':'ImageStudio'}
        r=await self.client.post('/image-studio/api/login',json={'code':self.studio.code},headers=self.headers);self.assertEqual(r.status,200)
    async def asyncTearDown(self):
        for task in self.studio.tasks.values():
            if not task.done():task.cancel()
        await self.client.close();self.temp.cleanup()
    async def submit(self,jid='a'*32,**kwargs):
        return await self.client.post('/image-studio/api/jobs',json=dict(id=jid,prompt='a green forest',**kwargs),headers=self.headers)
    async def finish(self):
        await asyncio.gather(*self.studio.tasks.values())
    async def test_one_submission_and_png_bundle(self):
        r=await self.submit();self.assertEqual(r.status,200);await self.finish()
        r=await self.submit();self.assertEqual(r.status,200);self.assertEqual(self.engine.calls,1)
        r=await self.client.get('/image-studio/api/jobs/'+'a'*32+'/image');self.assertEqual(r.status,200)
        checked_png(await r.read(),self.studio.jobs['a'*32]['plan'])
        r=await self.client.get('/image-studio/api/jobs/'+'a'*32+'/bundle');self.assertEqual(r.status,200);self.assertEqual(r.content_type,'application/zip')
    async def test_same_id_changed_prompt_rejected(self):
        await self.submit();await self.finish()
        r=await self.client.post('/image-studio/api/jobs',json={'id':'a'*32,'prompt':'another prompt'},headers=self.headers);self.assertEqual(r.status,409)
    async def test_busy_job_blocks_another_request(self):
        self.engine.gate.clear();await self.submit()
        r=await self.submit('b'*32);self.assertEqual(r.status,409);self.engine.gate.set();await self.finish()
    async def test_unauthorized_and_cross_origin_mutations_rejected(self):
        self.client.session.cookie_jar.clear()
        r=await self.submit();self.assertEqual(r.status,401)
        await self.client.post('/image-studio/api/login',json={'code':self.studio.code},headers=self.headers)
        r=await self.client.post('/image-studio/api/jobs',json={'id':'a'*32,'prompt':'a forest'},headers=dict(self.headers,Origin='https://evil.example'));self.assertEqual(r.status,403)
    async def test_download_traversal_rejected(self):
        r=await self.client.get('/image-studio/api/jobs/not-an-id/image');self.assertEqual(r.status,404)
    async def test_runpod_never_falls_back_to_local(self):
        r=await self.submit(target='runpod');self.assertGreaterEqual(r.status,400);self.assertEqual(self.engine.calls,0)
    async def test_invalid_connection_rejected_without_network(self):
        for url in ['http://127.0.0.1:22','https://example.com','https://pod-8188.proxy.runpod.net/@evil']:
            r=await self.client.post('/image-studio/api/connection',json={'url':url,'code':'x'*32},headers=self.headers);self.assertEqual(r.status,400)

if __name__=='__main__':unittest.main()
