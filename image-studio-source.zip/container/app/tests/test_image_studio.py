import asyncio
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import AsyncMock
from aiohttp.test_utils import TestClient,TestServer
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import validate,graph,SDXL,JUGGERNAUT,REALVIS,QWEN,FLUX,POSITIVE_PREFIX,NEGATIVE,model_artifacts
from app import Studio,checked_png
from engine import recover_prompt_id

class Plans(unittest.TestCase):
    def test_recover_accepted_job_from_queue_without_resubmission(self):
        self.assertEqual(recover_prompt_id({'queue_running':[[1,'prompt-1',{}, {'image_studio_job':'a'*32}]]},{},'a'*32),'prompt-1')
    def test_recover_finished_job_after_lost_post_response(self):
        history={'prompt-1':{'prompt':[1,'prompt-1',{}, {'image_studio_job':'a'*32}]}}
        self.assertEqual(recover_prompt_id({},history,'a'*32),'prompt-1')
        self.assertIsNone(recover_prompt_id({},history,'b'*32))
    def test_duplicate_gpu_jobs_do_not_choose_an_arbitrary_result(self):
        q={'queue_pending':[[1,'one',{}, {'image_studio_job':'a'*32}],[2,'two',{}, {'image_studio_job':'a'*32}]]}
        with self.assertRaises(ValueError):recover_prompt_id(q,{},'a'*32)
    def test_local_stays_in_small_vram_budget(self):
        for ratio in ('portrait','square','landscape'):
            p=validate(dict(prompt='a green forest',ratio=ratio,resolution='fast'))
            self.assertLessEqual(p['width']*p['height'],768*768)
            self.assertEqual(p['model'],'juggernaut_x')
    def test_juggernaut_settings_and_checkpoint(self):
        for quality,steps in [('draft',24),('standard',40),('high',48)]:
            p=validate(dict(prompt='a studio portrait',quality=quality))
            g=graph(p,'a'*32)
            self.assertEqual(g['1']['inputs']['ckpt_name'],'Juggernaut-X-RunDiffusion-NSFW.safetensors')
            self.assertEqual(g['8']['inputs']['steps'],steps)
            self.assertEqual(g['8']['inputs']['cfg'],5.0)
            self.assertEqual(g['8']['inputs']['sampler_name'],'dpmpp_2m')
            self.assertEqual(g['8']['inputs']['scheduler'],'karras')
            self.assertEqual(g['9']['inputs']['vae'],['1',2])
    def test_sdxl_and_old_saved_workflows_remain_supported(self):
        fixtures=json.loads((Path(__file__).parent/'fixtures/legacy-workflows.json').read_text())
        for model,row in fixtures.items():
            self.assertEqual(graph(row['plan'],'a'*32),row['workflow'],model)
        with self.assertRaises(ValueError):validate(dict(prompt='a landscape',model='unknown'))
        with self.assertRaises(ValueError):validate(dict(prompt='a landscape',model='juggernaut_x'),pod=True)
    def test_native_presets_and_prompt_preservation(self):
        for ratio,size in [('portrait',(768,1152)),('landscape',(1152,768)),('square',(1024,1024))]:
            p=validate(dict(prompt='  a forest path  ',ratio=ratio))
            self.assertEqual((p['width'],p['height']),size)
            self.assertEqual(p['steps'],40)
            self.assertEqual(p['prompt'],'a forest path')
            self.assertEqual(p['negative'],NEGATIVE)
            self.assertEqual(graph(p,'a'*32)['5']['inputs']['text'],POSITIVE_PREFIX+'a forest path')
            # ส่ง PC → Pod แล้วต้องไม่เติม prefix สองรอบ
            remote=validate(dict(p,target='runpod',model='qwen'),pod=True)
            self.assertEqual(remote['positive_prompt'].count(POSITIVE_PREFIX),1)
        p=validate(dict(prompt='a path',negative='user custom negative'))
        self.assertEqual(p['negative'],'user custom negative')
    def test_realvis_uses_verified_metadata_and_embedded_vae(self):
        p=validate(dict(prompt='a portrait',model='realvisxl'))
        g=graph(p,'a'*32)
        self.assertEqual(g['1']['inputs']['ckpt_name'],'RealVisXL_V5.0_fp16.safetensors')
        self.assertEqual(g['9']['inputs']['vae'],['1',2])
        self.assertEqual(REALVIS['bytes'],6938065488)
        self.assertEqual(REALVIS['checksum'],'6a35a7855770ae9820a3c931d4964c3817b6d9e3c6f9c4dabb5b3a94e5643b80')
        resolved=model_artifacts('realvisxl','local')[0]
        self.assertEqual(resolved['bytes'],6938065488)
        self.assertEqual(len(resolved['checksum']),64)
        self.assertNotIn('/main/',resolved['url'])
    def test_flux_graph_and_mode_isolation(self):
        for quality,steps in [('draft',20),('standard',24),('high',28)]:
            p=validate(dict(prompt='a forest portrait',target='runpod',model='flux1_dev',quality=quality))
            g=graph(p,'a'*32)
            self.assertEqual(g['2']['class_type'],'DualCLIPLoader')
            self.assertEqual(g['2']['inputs']['type'],'flux')
            self.assertEqual(g['4']['class_type'],'ModelSamplingFlux')
            self.assertEqual(g['4']['inputs']['width'],p['width'])
            self.assertEqual(g['11']['class_type'],'FluxGuidance')
            self.assertEqual(g['8']['inputs']['positive'],['11',0])
            self.assertEqual(g['8']['inputs']['cfg'],1.0)
            self.assertEqual(g['8']['inputs']['sampler_name'],'euler')
            self.assertEqual(g['8']['inputs']['steps'],steps)
            self.assertEqual(g['7']['class_type'],'EmptySD3LatentImage')
        self.assertEqual(len(model_artifacts('flux1_dev','runpod')),4)
        for model,target in [('flux1_dev','local'),('qwen','local'),('realvisxl','runpod'),('sdxl','runpod')]:
            with self.assertRaises(ValueError):model_artifacts(model,target)
            with self.assertRaises(ValueError):validate(dict(prompt='a portrait',model=model,target=target))
    def test_large_model_does_not_use_image_edit_or_video(self):
        p=validate(dict(prompt='two friends hiking',target='runpod'))
        g=graph(p,'a'*32)
        self.assertEqual(g['1']['inputs']['unet_name'],'qwen_image_fp8_e4m3fn.safetensors')
        self.assertFalse(any('Edit' in n['class_type'] or 'Video' in n['class_type'] or 'LoadImage'==n['class_type'] for n in g.values()))
        self.assertTrue(all(a['checksum_algorithm']=='sha256' and len(a['checksum'])==64 for a in [SDXL,JUGGERNAUT,REALVIS]+QWEN+FLUX))
    def test_rejects_invalid_seed_and_unbounded_requests(self):
        for b in [dict(seed=True),dict(seed=-1),dict(seed=2**53),dict(prompt='x'*3001),dict(target='other'),dict(ratio='huge'),dict(resolution='huge')]:
            with self.assertRaises(ValueError):validate(dict(prompt='a landscape',**b)) if 'prompt' not in b else validate(b)
    def test_checked_png_rejects_wrong_dimensions_and_format(self):
        p=validate(dict(prompt='a photo'));b=io.BytesIO();Image.new('RGB',(64,64)).save(b,format='PNG')
        with self.assertRaises(ValueError):checked_png(b.getvalue(),p)

class FakeEngine:
    def __init__(self):self.calls=0;self.gate=asyncio.Event();self.gate.set()
    def status(self):return dict(ready=True,message='test engine')
    async def render(self,j,persist,recover=False):
        self.calls+=1;await self.gate.wait();buf=io.BytesIO();Image.new('RGB',(j['plan']['width'],j['plan']['height']),'#81aa72').save(buf,format='PNG');return buf.getvalue()

class HTTP(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.engine=FakeEngine();self.studio=Studio(self.temp.name,engine=self.engine)
        self.client=TestClient(TestServer(self.studio.app()));await self.client.start_server()
        self.headers={'X-Requested-With':'ImageStudio'}
        r=await self.client.post('/image-studio/api/login',json={'code':self.studio.code},headers=self.headers);self.assertEqual(r.status,200)
    async def asyncTearDown(self):
        for task in self.studio.tasks.values():
            if not task.done():task.cancel()
        await self.client.close();self.temp.cleanup()
    async def submit(self,jid='a'*32,**kwargs):
        return await self.client.post('/image-studio/api/jobs',json=dict(id=jid,prompt='a green forest',**kwargs),headers=self.headers)
    async def finish(self):
        await asyncio.gather(*self.studio.tasks.values())
    async def test_one_submission_and_png_bundle(self):
        r=await self.submit();self.assertEqual(r.status,200);await self.finish()
        r=await self.submit();self.assertEqual(r.status,200);self.assertEqual(self.engine.calls,1)
        r=await self.client.get('/image-studio/api/jobs/'+'a'*32+'/image');self.assertEqual(r.status,200)
        checked_png(await r.read(),self.studio.jobs['a'*32]['plan'])
        r=await self.client.get('/image-studio/api/jobs/'+'a'*32+'/bundle');self.assertEqual(r.status,200);self.assertEqual(r.content_type,'application/zip')
    async def test_same_id_changed_prompt_rejected(self):
        await self.submit();await self.finish()
        r=await self.client.post('/image-studio/api/jobs',json={'id':'a'*32,'prompt':'another prompt'},headers=self.headers);self.assertEqual(r.status,409)
    async def test_same_id_changed_model_rejected(self):
        await self.submit(model='sdxl');await self.finish()
        r=await self.submit(model='juggernaut_x');self.assertEqual(r.status,409)
        self.assertEqual(self.engine.calls,1)
    async def test_same_id_changed_resolution_rejected(self):
        await self.submit(resolution='fast');await self.finish()
        r=await self.submit(resolution='native');self.assertEqual(r.status,409)
        self.assertEqual(self.engine.calls,1)
    async def test_old_pod_cannot_silently_replace_flux_with_qwen(self):
        self.studio.remote=AsyncMock(return_value={'local':{'ready':True}})
        r=await self.submit(target='runpod',model='flux1_dev')
        self.assertEqual(r.status,409);self.assertEqual(self.engine.calls,0)
        self.assertEqual(self.studio.remote.await_count,1)
    async def test_busy_job_blocks_another_request(self):
        self.engine.gate.clear();await self.submit()
        r=await self.submit('b'*32);self.assertEqual(r.status,409);self.engine.gate.set();await self.finish()
    async def test_unauthorized_and_cross_origin_mutations_rejected(self):
        self.client.session.cookie_jar.clear()
        r=await self.submit();self.assertEqual(r.status,401)
        await self.client.post('/image-studio/api/login',json={'code':self.studio.code},headers=self.headers)
        r=await self.client.post('/image-studio/api/jobs',json={'id':'a'*32,'prompt':'a forest'},headers=dict(self.headers,Origin='https://evil.example'));self.assertEqual(r.status,403)
    async def test_download_traversal_rejected(self):
        r=await self.client.get('/image-studio/api/jobs/not-an-id/image');self.assertEqual(r.status,404)
    async def test_runpod_never_falls_back_to_local(self):
        r=await self.submit(target='runpod');self.assertGreaterEqual(r.status,400);self.assertEqual(self.engine.calls,0)
    async def test_invalid_connection_rejected_without_network(self):
        for url in ['http://127.0.0.1:22','https://example.com','https://pod-8188.proxy.runpod.net/@evil']:
            r=await self.client.post('/image-studio/api/connection',json={'url':url,'code':'x'*32},headers=self.headers);self.assertEqual(r.status,400)

if __name__=='__main__':unittest.main()
