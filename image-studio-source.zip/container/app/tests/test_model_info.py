import io
import json
from pathlib import Path
import sys
import unittest
from contextlib import redirect_stdout, redirect_stderr
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tools import model_info as m

REPO='owner/model';REV='a'*40;SHA='b'*64
FILE={'type':'file','path':'nested/model.safetensors','size':123,'lfs':{'oid':SHA,'size':123}}

class Metadata(unittest.TestCase):
    def test_cli_prints_pasteable_entry_and_pins_revision(self):
        def request(url):
            return ({'sha':REV},'') if url.endswith(REPO) else ([FILE],'')
        entries=m.model_info(REPO,['model.safetensors'],request=request)
        self.assertEqual(entries[0]['checksum'],SHA)
        self.assertEqual(entries[0]['bytes'],123)
        self.assertIn('/resolve/'+REV+'/nested/model.safetensors',entries[0]['url'])
        with patch.object(m,'model_info',return_value=entries),redirect_stdout(io.StringIO()) as output:
            self.assertEqual(m.main([REPO,'model.safetensors']),0)
        self.assertEqual(eval(output.getvalue(),{'__builtins__':{}}),entries[0])
    def test_realvis_short_command_selects_fp16(self):
        fp16=dict(FILE,path='RealVisXL_V5.0_fp16.safetensors')
        rows=m.select_files([fp16,FILE],[])
        entry=m.entry(REPO,REV,rows[0])
        self.assertEqual(entry['id'],'realvisxl')
        self.assertEqual(entry['path'],'checkpoints/RealVisXL_V5.0_fp16.safetensors')
    def test_all_four_flux_filenames_have_correct_comfy_folders(self):
        for filename,(model_id,folder) in m.KNOWN.items():
            row=dict(FILE,path=filename)
            entry=m.entry(REPO,REV,row)
            self.assertEqual(entry['id'],model_id)
            self.assertEqual(entry['path'],folder+'/'+filename)
    def test_nested_files_and_pagination(self):
        url=f'https://huggingface.co/api/models/{REPO}/tree/main?recursive=true&limit=1000'
        second=url+'&cursor=2';calls=[]
        def request(current):
            calls.append(current)
            return ([FILE],f'<{second}>; rel="next"') if current==url else ([dict(FILE,path='next/other.safetensors')],'')
        files=m.tree(REPO,'main',request)
        self.assertEqual(len(files),2)
        self.assertEqual(calls,[url,second])
    def test_ambiguous_filename_rejected(self):
        with self.assertRaises(m.MetadataError):m.select_files([FILE,dict(FILE,path='other/model.safetensors')],['model.safetensors'])
    def test_git_blob_oid_and_masked_gated_oid_are_not_sha256(self):
        for lfs in ({},{'oid':'*'*64},{'oid':None}):
            item=dict(FILE,lfs=lfs,oid='c'*40)
            self.assertIsNone(m.entry(REPO,REV,item)['checksum'])
        entries=[m.entry(REPO,REV,dict(FILE,lfs={}))]
        with patch.object(m,'model_info',return_value=entries),redirect_stdout(io.StringIO()) as output:
            m.main([REPO])
        self.assertIn('รัน tools/model_info.py เพื่อเติม',output.getvalue())
    def test_size_conflict_rejected(self):
        with self.assertRaises(m.MetadataError):m.entry(REPO,REV,dict(FILE,lfs={'oid':SHA,'size':99}))
    def test_external_pagination_rejected(self):
        with self.assertRaises(m.MetadataError):m.tree(REPO,'main',lambda url:([FILE],'<https://example.com/file>; rel="next"'))
    def test_invalid_repo_path_and_api_endpoint_rejected(self):
        for repo in ('../repo','https://example.com/repo','owner/repo/extra'):
            with self.assertRaises(m.MetadataError):m.repo_name(repo)
        for path in ('../model','/model','nested/../model','nested\\model'):
            with self.assertRaises(m.MetadataError):m.safe_path(path)
        with self.assertRaises(m.MetadataError):m.api_json('https://example.com/api/models/owner/repo')
    def test_json_output_and_safe_error_exit(self):
        entry=m.entry(REPO,REV,FILE)
        with patch.object(m,'model_info',return_value=[entry]),redirect_stdout(io.StringIO()) as output:
            self.assertEqual(m.main([REPO,'--json']),0)
            self.assertEqual(json.loads(output.getvalue()),[entry])
        with patch.object(m,'model_info',side_effect=m.MetadataError('HF API HTTP 403')),redirect_stderr(io.StringIO()) as error:
            self.assertEqual(m.main([REPO]),1)
            self.assertIn('403',error.getvalue())

if __name__=='__main__':unittest.main()
