import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import urllib.request
from contextlib import redirect_stdout
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import download_model as d
from core import FLUX,REALVIS
from engine import Engine

DATA = b'first-download-test-model-content\n'
DIGEST = hashlib.sha256(DATA).hexdigest()

def artifact(digest=None, model_id='test', path='checkpoints/test.safetensors'):
    return {'id':model_id,'path':path,'bytes':len(DATA),'checksum_algorithm':'sha256','checksum':digest,
            'url':'https://huggingface.co/example/test/resolve/'+'a'*40+'/test.safetensors'}

class FakeOpener:
    def __init__(self,data=DATA):self.data=data;self.requests=[]
    def open(self,request,timeout):
        self.requests.append(request)
        response=io.BytesIO(self.data);response.status=200
        response.headers={'Content-Length':str(len(self.data))}
        return response

def statuses(output):
    return [json.loads(line)['status'] for line in output.getvalue().splitlines() if '"status"' in line]

class Downloads(unittest.TestCase):
    def test_unknown_size_cannot_start_download(self):
        with tempfile.TemporaryDirectory() as folder:
            item=artifact();item['bytes']=None
            with self.assertRaises(d.InstallError):d.download_artifact(Path(folder),item,FakeOpener())
            self.assertEqual(list(Path(folder).iterdir()),[])
    def test_first_download_records_sha_then_verifies_on_reuse(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()) as output:
            root=Path(folder);item=artifact();opener=FakeOpener()
            target=d.download_artifact(root,item,opener)
            self.assertEqual(target.read_bytes(),DATA)
            self.assertEqual(d.read_sidecar(root)['artifacts'][item['path']]['checksum'],DIGEST)
            self.assertEqual(statuses(output),['checksum recorded (first download)'])
            d.download_artifact(root,item,opener)
            self.assertEqual(statuses(output)[-1],'verified')
            self.assertEqual(len(opener.requests),1)
            self.assertEqual(d.pending_models(root,[item]),[])
            self.assertIsNone(item['checksum'])  # registry ไม่ถูกเขียนทับ
    def test_empty_checksum_records_like_none(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            d.download_artifact(folder,artifact(''),FakeOpener())
            self.assertEqual(d.read_sidecar(folder)['artifacts']['checkpoints/test.safetensors']['checksum'],DIGEST)
    def test_known_checksum_verified_without_sidecar(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()) as output:
            d.download_artifact(folder,artifact(DIGEST),FakeOpener())
            self.assertEqual(statuses(output),['verified'])
            self.assertFalse((Path(folder)/'.checksums.json').exists())
    def test_known_wrong_checksum_rejects_download_without_recording(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(d.InstallError,'checksum mismatch'):
                d.download_artifact(folder,artifact('0'*64),FakeOpener())
            self.assertFalse((Path(folder)/'.checksums.json').exists())
            self.assertFalse(d.destination(folder,artifact()).exists())
            self.assertFalse(any(Path(folder).rglob('*.part')))
    def test_recorded_hash_rejects_changed_file_and_keeps_record(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            root=Path(folder);item=artifact();target=d.download_artifact(root,item,FakeOpener())
            original=(root/'.checksums.json').read_bytes()
            target.write_bytes(b'X'*len(DATA))
            with self.assertRaises(d.InstallError):d.pending_models(root,[item])
            with self.assertRaises(d.InstallError):d.download_artifact(root,item,FakeOpener())
            self.assertEqual((root/'.checksums.json').read_bytes(),original)
            self.assertEqual(target.read_bytes(),b'X'*len(DATA))
    def test_registry_hash_takes_precedence_over_recorded_hash(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            root=Path(folder);d.download_artifact(root,artifact(),FakeOpener())
            with self.assertRaises(d.InstallError):d.pending_models(root,[artifact('0'*64)])
    def test_changed_source_and_malformed_sidecar_fail_closed(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            root=Path(folder);d.download_artifact(root,artifact(),FakeOpener())
            changed=artifact();changed['url']+='?revision=changed'
            with self.assertRaisesRegex(d.InstallError,'another model/source'):d.pending_models(root,[changed])
            (root/'.checksums.json').write_text('{broken',encoding='utf-8')
            with self.assertRaisesRegex(d.InstallError,'sidecar is invalid'):d.pending_models(root,[artifact()])
    def test_existing_file_without_record_cannot_be_silently_trusted(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);item=artifact();target=d.destination(root,item)
            target.parent.mkdir(parents=True);target.write_bytes(DATA)
            with self.assertRaisesRegex(d.InstallError,'no trusted or recorded'):d.pending_models(root,[item])
            opener=FakeOpener()
            with self.assertRaisesRegex(d.InstallError,'no trusted or recorded'):d.download_artifact(root,item,opener)
            self.assertEqual(opener.requests,[])
            self.assertFalse((root/'.checksums.json').exists())
    def test_wrong_size_does_not_record_first_download(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(d.InstallError):d.download_artifact(folder,artifact(),FakeOpener(DATA+b'extra'))
            self.assertFalse((Path(folder)/'.checksums.json').exists())
    def test_recorded_partial_recovers_after_interrupted_atomic_install(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()) as output:
            root=Path(folder);item=artifact();target=d.destination(root,item);target.parent.mkdir(parents=True)
            partial,metadata=d.partial_paths(target);partial.write_bytes(DATA)
            metadata.write_text(json.dumps({k:item[k] for k in ('url','checksum_algorithm','checksum','bytes')}),encoding='utf-8')
            d.record_checksum(root,item,DIGEST)
            opener=FakeOpener();d.download_artifact(root,item,opener)
            self.assertEqual(target.read_bytes(),DATA);self.assertEqual(opener.requests,[])
            self.assertEqual(statuses(output),['verified'])
    def test_empty_checksum_partial_resumes_and_records_only_when_complete(self):
        class Interrupted(FakeOpener):
            def open(self,request,timeout):
                response=super().open(request,timeout)
                response.headers['Content-Length']=str(len(DATA))
                return response
        class Resumed(FakeOpener):
            def open(self,request,timeout):
                response=super().open(request,timeout)
                response.status=206
                response.headers['Content-Range']=f'bytes 5-{len(DATA)-1}/{len(DATA)}'
                return response
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()) as output:
            item=artifact('');root=Path(folder)
            with self.assertRaises(d.InstallError):d.download_artifact(root,item,Interrupted(DATA[:5]))
            self.assertFalse((root/'.checksums.json').exists())
            self.assertEqual(d.partial_size(d.destination(root,item),item),5)
            opener=Resumed(DATA[5:]);d.download_artifact(root,item,opener)
            self.assertEqual(opener.requests[0].get_header('Range'),'bytes=5-')
            self.assertEqual(d.read_sidecar(root)['artifacts'][item['path']]['checksum'],DIGEST)
            self.assertEqual(statuses(output),['checksum recorded (first download)'])
    def test_two_downloads_preserve_both_sidecar_records(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            root=Path(folder);items=[artifact(model_id=str(i),path=f'checkpoints/test{i}.safetensors') for i in range(2)]
            with ThreadPoolExecutor(max_workers=2) as executor:
                list(executor.map(lambda item:d.download_artifact(root,item,FakeOpener()),items))
            self.assertEqual(set(d.read_sidecar(root)['artifacts']),{item['path'] for item in items})
    def test_engine_accepts_empty_checksum_and_reuses_sidecar_after_restart(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            item=artifact(model_id='realvisxl');opener=FakeOpener()
            with patch.dict(REALVIS,item),patch('download_model.urllib.request.build_opener',return_value=opener),patch('download_model.storage_preflight'):
                engine=Engine(folder);engine.install_for_model('realvisxl')
                Engine(folder).install_for_model('realvisxl')
            self.assertEqual(len(opener.requests),1)
    def test_hf_token_never_leaves_huggingface_on_redirect(self):
        request=urllib.request.Request('https://huggingface.co/example/resolve/main/file',headers={'Authorization':'Bearer test-only-token'})
        redirected=d.HTTPSOnlyRedirect().redirect_request(request,None,302,'Found',{},'https://cdn.example/file')
        self.assertIsNone(redirected.get_header('Authorization'))
        same=d.HTTPSOnlyRedirect().redirect_request(request,None,302,'Found',{},'https://huggingface.co/example/new-file')
        self.assertEqual(same.get_header('Authorization'),'Bearer test-only-token')
    def test_missing_flux_token_does_not_start_model_transfer(self):
        with tempfile.TemporaryDirectory() as folder,patch.dict(os.environ,{},clear=True):
            with self.assertRaisesRegex(d.InstallError,'HF_TOKEN'):d.download_artifact(Path(folder),FLUX[0])
            self.assertFalse(any(Path(folder).rglob('*.part')))
    def test_local_engine_rejects_cloud_model_before_any_download(self):
        with tempfile.TemporaryDirectory() as folder:
            engine=Engine(folder)
            self.assertEqual(set(engine.model_sets),{'sdxl','juggernaut_x','realvisxl'})
            with patch('download_model.pending_models') as pending:
                with self.assertRaises(ValueError):engine.install_for_model('flux1_dev')
                pending.assert_not_called()
    def test_install_selected_model_does_not_prepare_unselected_models(self):
        with tempfile.TemporaryDirectory() as folder:
            engine=Engine(folder,pod=True)
            with patch('download_model.pending_models',return_value=[]) as pending,patch('download_model.storage_preflight'):
                engine.install_for_model('flux1_dev')
                self.assertEqual(pending.call_args.args[1],FLUX)
                self.assertEqual(engine.checked_models,{'flux1_dev'})
                engine.install_for_model('flux1_dev')
                self.assertEqual(pending.call_count,1)

if __name__=='__main__':unittest.main()
