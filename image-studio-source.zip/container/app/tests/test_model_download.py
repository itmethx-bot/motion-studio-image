import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import urllib.request

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import download_model as d
from core import FLUX,REALVIS
from engine import Engine

class Downloads(unittest.TestCase):
    def test_placeholder_cannot_download_without_sha256(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(d.InstallError):d.download_artifact(Path(folder),REALVIS)
            self.assertEqual(list(Path(folder).iterdir()),[])
    def test_hf_token_never_leaves_huggingface_on_redirect(self):
        request=urllib.request.Request('https://huggingface.co/example/resolve/main/file',headers={'Authorization':'Bearer test-only-token'})
        redirected=d.HTTPSOnlyRedirect().redirect_request(request,None,302,'Found',{},'https://cdn.example/file')
        self.assertIsNone(redirected.get_header('Authorization'))
        same=d.HTTPSOnlyRedirect().redirect_request(request,None,302,'Found',{},'https://huggingface.co/example/new-file')
        self.assertEqual(same.get_header('Authorization'),'Bearer test-only-token')
    def test_missing_flux_token_does_not_start_model_transfer(self):
        with tempfile.TemporaryDirectory() as folder,patch.dict(os.environ,{},clear=True):
            with self.assertRaisesRegex(d.InstallError,'HF_TOKEN'):d.download_artifact(Path(folder),FLUX[0])
            self.assertFalse(any(Path(folder).rglob('*.part')))
    def test_local_engine_rejects_cloud_model_before_any_download(self):
        with tempfile.TemporaryDirectory() as folder:
            engine=Engine(folder)
            self.assertEqual(set(engine.model_sets),{'sdxl','juggernaut_x','realvisxl'})
            with patch('download_model.pending_models') as pending:
                with self.assertRaises(ValueError):engine.install_for_model('flux1_dev')
                pending.assert_not_called()
    def test_install_selected_model_does_not_prepare_unselected_models(self):
        with tempfile.TemporaryDirectory() as folder:
            engine=Engine(folder,pod=True)
            with patch('download_model.pending_models',return_value=[]) as pending,patch('download_model.storage_preflight'):
                engine.install_for_model('flux1_dev')
                self.assertEqual(pending.call_args.args[1],FLUX)
                self.assertEqual(engine.checked_models,{'flux1_dev'})
                engine.install_for_model('flux1_dev')
                self.assertEqual(pending.call_count,1)

if __name__=='__main__':unittest.main()
