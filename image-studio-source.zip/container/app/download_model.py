"""Pinned image-model transfers with checksum, ownership and bounded resume."""
import http.client, hashlib, json, os, re, secrets, shutil, time
from pathlib import Path, PurePosixPath
from contextlib import contextmanager
import urllib.error, urllib.parse, urllib.request
GIB=1024**3

class InstallError(RuntimeError):
    def __init__(self, message, *, retryable=False):
        super().__init__(message)
        self.retryable = bool(retryable)

def transient_transfer_error(error):
    """Retry transport failures, never authorization, capacity or integrity failures."""
    import errno
    if isinstance(error, urllib.error.HTTPError):
        return error.code in (408, 429, 500, 502, 503, 504)
    cause = error.reason if isinstance(error, urllib.error.URLError) else error
    if isinstance(cause, OSError) and cause.errno in (errno.ENOSPC, errno.EACCES, errno.EPERM, errno.EROFS, errno.EIO):
        return False
    return isinstance(error, (urllib.error.URLError, TimeoutError)) or (
        isinstance(error, OSError) and error.errno in (errno.ECONNRESET, errno.ECONNABORTED, errno.ETIMEDOUT, errno.EPIPE))

def checksum(path, algorithm):
    digest = hashlib.new(algorithm)
    with Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def destination(models_root, artifact):
    root = Path(models_root).resolve()
    target = root.joinpath(*PurePosixPath(artifact['path']).parts)
    # Windows อาจ resolve โฟลเดอร์ที่เพิ่งถูกสร้างพร้อมกันไม่เสถียร ตรวจซ้ำโดยคงข้อจำกัด path
    for attempt in range(3):
        if target.is_symlink():
            break
        if target.resolve().is_relative_to(root):
            return target
        if attempt < 2:
            time.sleep(0.01)
    raise InstallError('Model destination must stay inside the ComfyUI models folder.')

def validate_artifact(artifact):
    # ขนาดต้องทราบเพื่อจำกัดพื้นที่/การรับข้อมูล; checksum ว่างใช้ TOFU ได้
    digest = artifact.get('checksum')
    if type(artifact.get('bytes')) is not int or artifact['bytes'] <= 0 or artifact.get('checksum_algorithm') != 'sha256':
        raise InstallError('เติมขนาดจริงและใช้ SHA256 ก่อนดาวน์โหลด ' + artifact['id'] + ': รัน tools/model_info.py เพื่อเติม')
    if digest not in (None, '') and (not isinstance(digest, str) or not re.fullmatch('[a-f0-9]{64}', digest)):
        raise InstallError('SHA256 ใน registry ไม่ถูกต้อง: ' + artifact['id'])
    parsed = urllib.parse.urlsplit(artifact['url'])
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise InstallError('Model URL must use HTTPS without embedded credentials.')

def sidecar_path(models_root):
    root = Path(models_root).resolve()
    path = root / '.checksums.json'
    if path.is_symlink():
        raise InstallError('Refusing a symbolic-link checksum sidecar.')
    return path

def read_sidecar(models_root):
    path = sidecar_path(models_root)
    if not path.exists():
        return {'version': 1, 'artifacts': {}}
    try:
        if not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
            raise ValueError('invalid file')
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('version') != 1 or not isinstance(data.get('artifacts'), dict):
            raise ValueError('invalid schema')
        return data
    except (OSError, ValueError, AttributeError) as exc:
        raise InstallError('Checksum sidecar is invalid; nothing was overwritten: .checksums.json') from exc

def effective_artifact(models_root, artifact):
    validate_artifact(artifact)
    item = dict(artifact)
    if item.get('checksum'):
        return item  # SHA256 ที่กำหนดโดยผู้เผยแพร่มีลำดับสูงสุด
    item['checksum'] = None
    record = read_sidecar(models_root)['artifacts'].get(item['path'])
    if record is not None:
        identity = {key: item[key] for key in ('id', 'url', 'bytes', 'checksum_algorithm')}
        if not isinstance(record, dict) or any(record.get(k) != v for k, v in identity.items()):
            raise InstallError('Checksum sidecar belongs to another model/source: ' + item['path'])
        digest = record.get('checksum')
        if not isinstance(digest, str) or not re.fullmatch('[a-f0-9]{64}', digest):
            raise InstallError('Checksum sidecar has an invalid SHA256: ' + item['path'])
        item['checksum'] = digest
    return item

def record_checksum(models_root, artifact, digest):
    # บันทึกครั้งแรกแบบ atomic และล็อกไฟล์กลาง ป้องกันหลายโมเดลเขียนทับกัน
    path = sidecar_path(models_root)
    with download_lock(path, wait=True):
        data = read_sidecar(models_root)
        record = {key: artifact[key] for key in ('id', 'url', 'bytes', 'checksum_algorithm')}
        record.update(checksum=digest, source='first_download')
        old = data['artifacts'].get(artifact['path'])
        if old is not None and old != record:
            raise InstallError('Refusing to replace an existing recorded checksum: ' + artifact['path'])
        data['artifacts'][artifact['path']] = record
        temporary = path.with_name(path.name + '.' + secrets.token_hex(8) + '.tmp')
        try:
            with temporary.open('x', encoding='utf-8') as file:
                json.dump(data, file, ensure_ascii=False, indent=2)
                file.flush(); os.fsync(file.fileno())
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)

def verified_log(artifact, path, source):
    print(json.dumps({'model': artifact['id'], 'status': 'verified', 'bytes': path.stat().st_size,
                      'checksum_source': source}), flush=True)

def verify_file(path, artifact):
    if artifact['bytes'] is not None and path.stat().st_size != artifact['bytes']:
        return False
    return bool(artifact.get('checksum')) and checksum(path, artifact['checksum_algorithm']) == artifact['checksum']

def pending_models(models_root, artifacts):
    pending = []
    for artifact in artifacts:
        item = effective_artifact(models_root, artifact)
        target = destination(models_root, artifact)
        if target.exists():
            if not item['checksum']:
                raise InstallError('Existing model has no trusted or recorded checksum: ' + artifact['path']
                                   + '. Move that file aside before a first download; nothing was overwritten.')
            if not target.is_file() or not verify_file(target, item):
                raise InstallError('Existing model is not the verified file: ' + artifact['path']
                                   + '. Nothing was overwritten; move that file aside before retrying.')
            verified_log(item, target, 'registry' if artifact.get('checksum') else 'recorded-first-download')
        else:
            pending.append(artifact)
    return pending

def partial_paths(target):
    return Path(str(target)+'.part'), Path(str(target)+'.part.json')

def partial_size(target, artifact):
    partial, metadata = partial_paths(target)
    if partial.is_symlink() or metadata.is_symlink():
        raise InstallError('Refusing a symbolic-link partial download.')
    identity = {key: artifact[key] for key in ('url', 'checksum_algorithm', 'checksum', 'bytes')}
    identity['checksum'] = identity['checksum'] or None
    if partial.exists():
        try:
            saved = json.loads(metadata.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            raise InstallError('Partial download has no valid ownership metadata: ' + target.name
                               + '. Move its .part file aside before retrying.')
        # ถ้าบันทึก sidecar แล้วแต่โปรเซสจบก่อนย้าย .part ยังตรวจ SHA256 ที่บันทึกได้
        compatible = isinstance(saved, dict) and saved.get('checksum') is None and identity['checksum'] and all(saved.get(k) == v for k, v in identity.items() if k != 'checksum') and set(saved) == set(identity)
        if saved != identity and not compatible:
            raise InstallError('Partial download belongs to another model: ' + target.name
                               + '. Move its .part and .part.json files aside before retrying.')
        size = partial.stat().st_size
        if size > (artifact['bytes'] if artifact['bytes'] is not None else 2*GIB):
            raise InstallError('Partial download is larger than the expected model: ' + target.name)
        return size
    return 0

def storage_preflight(comfy, artifacts):
    root = comfy/'models'
    required = 2*GIB  # Reserve for the extension, pip scratch space and filesystem overhead.
    for artifact in artifacts:
        required += max(0, (artifact['bytes'] or GIB) - partial_size(destination(root, artifact), artifact))
    check_at = root if root.exists() else comfy
    free = shutil.disk_usage(check_at).free
    if free < required:
        raise InstallError(f'Insufficient disk space: need {required/GIB:.1f} GiB free for this installation, '
                           f'but only {free/GIB:.1f} GiB is available. No download was started.')
    return {'required_free_bytes': required, 'free_bytes': free}

class HTTPSOnlyRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        if parsed.scheme != 'https' or parsed.username or parsed.password:
            raise InstallError('Refusing an insecure model download redirect.')
        redirected=super().redirect_request(req, fp, code, msg, headers, newurl)
        # ห้ามส่ง HF token ต่อไปยัง CDN หรือโดเมนอื่นเมื่อ redirect
        if redirected and parsed.hostname!='huggingface.co':redirected.remove_header('Authorization')
        return redirected

@contextmanager
def download_lock(target, wait=False):
    """Advisory locks release on process exit, so interrupted downloads can resume."""
    lock = Path(str(target)+'.download.lock')
    if lock.is_symlink():
        raise InstallError('Refusing a symbolic-link download lock.')
    with lock.open('a+b') as file:
        if os.name == 'nt':
            import msvcrt
            if file.tell() == 0:
                file.write(b'0'); file.flush()
            file.seek(0)
            try:
                msvcrt.locking(file.fileno(), msvcrt.LK_LOCK if wait else msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise InstallError('Another installer is downloading ' + target.name) from exc
            try:
                yield
            finally:
                file.seek(0); msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            deadline = time.monotonic() + (10 if wait else 0)
            while True:
                try:
                    fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError as exc:
                    if time.monotonic() >= deadline:
                        raise InstallError('Another installer is downloading ' + target.name) from exc
                    time.sleep(0.05)
            try:
                yield
            finally:
                fcntl.flock(file.fileno(), fcntl.LOCK_UN)

def download_artifact(models_root, artifact, opener=None):
    validate_artifact(artifact)
    checksum_source = 'registry' if artifact.get('checksum') else 'recorded-first-download'
    target = destination(models_root, artifact)
    target.parent.mkdir(parents=True, exist_ok=True)
    opener = opener or urllib.request.build_opener(HTTPSOnlyRedirect())
    with download_lock(target):
        artifact = effective_artifact(models_root, artifact)
        if target.exists():
            if not artifact['checksum']:
                raise InstallError('Existing model has no trusted or recorded checksum: ' + artifact['path']
                                   + '. Move that file aside before a first download; nothing was overwritten.')
            if verify_file(target, artifact):
                verified_log(artifact, target, checksum_source)
                return target
            raise InstallError('Existing model checksum mismatch; nothing overwritten: ' + artifact['path'])
        parsed=urllib.parse.urlsplit(artifact['url'])
        hf_token=os.environ.get('HF_TOKEN') or os.environ.get('HUGGING_FACE_HUB_TOKEN')
        gated=parsed.hostname=='huggingface.co' and parsed.path.startswith('/black-forest-labs/FLUX.1-dev/')
        if gated and not hf_token:
            raise InstallError('FLUX.1-dev ต้องยอมรับเงื่อนไขบน Hugging Face และตั้ง HF_TOKEN เป็น Secret ใน Pod ก่อนดาวน์โหลด')
        partial, metadata = partial_paths(target)
        offset = partial_size(target, artifact)
        identity = {key: artifact[key] for key in ('url', 'checksum_algorithm', 'checksum', 'bytes')}
        if not partial.exists():
            metadata.write_text(json.dumps(identity, sort_keys=True), encoding='utf-8')
        if artifact['bytes'] is None or offset != artifact['bytes']:
            headers = {'User-Agent': 'ImageStudioInstaller/1', 'Accept-Encoding': 'identity'}
            if parsed.hostname=='huggingface.co' and hf_token:headers['Authorization']='Bearer '+hf_token
            if offset:
                headers['Range'] = f'bytes={offset}-'
            request = urllib.request.Request(artifact['url'], headers=headers)
            try:
                with opener.open(request, timeout=60) as response:
                    status = response.status
                    if status not in (200, 206):
                        raise InstallError('Unexpected model download response for ' + target.name)
                    total = artifact['bytes']
                    if status == 206:
                        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
                        if not match or int(match[1]) != offset or int(match[2]) < offset:
                            raise InstallError('Invalid resumed-download range for ' + target.name)
                        if total is not None and int(match[3]) != total:
                            raise InstallError('Resumed-download size differs from the verified model: ' + target.name)
                        total = int(match[3])
                    elif offset:
                        offset = 0  # Server ignored Range: restart, never append a complete file.
                    length = response.headers.get('Content-Length')
                    if total is not None and length is not None and int(length) != total-offset:
                        raise InstallError('Download size differs from the verified model: ' + target.name)
                    limit = total if total is not None else 2*GIB
                    received = offset
                    last_progress = 0.
                    with partial.open('ab' if offset else 'wb') as file:
                        while True:
                            chunk = response.read(1024*1024)
                            if not chunk:
                                break
                            if received + len(chunk) > limit:
                                raise InstallError('Download exceeded verified model size: ' + target.name)
                            file.write(chunk); received += len(chunk)
                            if time.monotonic() - last_progress > 10:
                                print(json.dumps({'model': artifact['id'], 'downloaded_bytes': received,
                                                  'expected_bytes': total}), flush=True)
                                last_progress = time.monotonic()
                        file.flush(); os.fsync(file.fileno())
                    if total is not None and received != total:
                        raise InstallError('Download interrupted; the verified partial can be resumed: ' + target.name, retryable=True)
            except urllib.error.HTTPError as exc:
                if gated and exc.code in (401,403):
                    raise InstallError('Hugging Face ไม่อนุญาต FLUX.1-dev: ตรวจการยอมรับเงื่อนไขและสิทธิ์อ่านโมเดลของ HF_TOKEN ใน Pod') from exc
                raise InstallError('HTTP '+str(exc.code)+' downloading '+target.name,retryable=transient_transfer_error(exc)) from exc
            except (urllib.error.URLError, TimeoutError, OSError, http.client.IncompleteRead) as exc:
                raise InstallError('Network/storage error downloading ' + target.name
                                   + '. Partial data is retained; rerun the same command to resume.',
                                   retryable=isinstance(exc, http.client.IncompleteRead) or transient_transfer_error(exc)) from exc
        if partial.stat().st_size != artifact['bytes']:
            raise InstallError('Downloaded model size mismatch: ' + target.name)
        first_download = not artifact['checksum']
        if first_download:
            # TOFU ตรวจการเปลี่ยนไฟล์ในครั้งต่อไป ไม่ใช่การรับรองไฟล์โดยผู้เผยแพร่
            digest = checksum(partial, 'sha256')
            record_checksum(models_root, artifact, digest)
            artifact['checksum'] = digest
        elif not verify_file(partial, artifact):
            partial.unlink(missing_ok=True); metadata.unlink(missing_ok=True)
            raise InstallError('Downloaded model checksum mismatch: ' + target.name
                               + '. Rejected data was removed; no model was installed.')
        partial.replace(target)
        metadata.unlink(missing_ok=True)
        if first_download:
            print(json.dumps({'model': artifact['id'], 'status': 'checksum recorded (first download)',
                              'bytes': target.stat().st_size, 'checksum': artifact['checksum'],
                              'checksum_source': 'first-download; not publisher-verified'}), flush=True)
        else:
            verified_log(artifact, target, checksum_source)
        return target
