"""Pinned image-model transfers with checksum, ownership and bounded resume."""
import http.client, hashlib, json, os, re, shutil, time
from pathlib import Path, PurePosixPath
from contextlib import contextmanager
import urllib.error, urllib.parse, urllib.request
GIB=1024**3

class InstallError(RuntimeError):
    def __init__(self, message, *, retryable=False):
        super().__init__(message)
        self.retryable = bool(retryable)

def transient_transfer_error(error):
    """Retry transport failures, never authorization, capacity or integrity failures."""
    import errno
    if isinstance(error, urllib.error.HTTPError):
        return error.code in (408, 429, 500, 502, 503, 504)
    cause = error.reason if isinstance(error, urllib.error.URLError) else error
    if isinstance(cause, OSError) and cause.errno in (errno.ENOSPC, errno.EACCES, errno.EPERM, errno.EROFS, errno.EIO):
        return False
    return isinstance(error, (urllib.error.URLError, TimeoutError)) or (
        isinstance(error, OSError) and error.errno in (errno.ECONNRESET, errno.ECONNABORTED, errno.ETIMEDOUT, errno.EPIPE))

def checksum(path, algorithm):
    digest = hashlib.new(algorithm)
    with Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def destination(models_root, artifact):
    root = Path(models_root).resolve()
    target = root.joinpath(*PurePosixPath(artifact['path']).parts)
    if target.is_symlink() or not target.resolve().is_relative_to(root):
        raise InstallError('Model destination must stay inside the ComfyUI models folder.')
    return target

def verify_file(path, artifact):
    if artifact['bytes'] is not None and path.stat().st_size != artifact['bytes']:
        return False
    return checksum(path, artifact['checksum_algorithm']) == artifact['checksum']

def pending_models(models_root, artifacts):
    pending = []
    for artifact in artifacts:
        target = destination(models_root, artifact)
        if target.exists():
            if not target.is_file() or not verify_file(target, artifact):
                raise InstallError('Existing model is not the verified file: ' + artifact['path']
                                   + '. Nothing was overwritten; move that file aside before retrying.')
        else:
            pending.append(artifact)
    return pending

def partial_paths(target):
    return Path(str(target)+'.part'), Path(str(target)+'.part.json')

def partial_size(target, artifact):
    partial, metadata = partial_paths(target)
    if partial.is_symlink() or metadata.is_symlink():
        raise InstallError('Refusing a symbolic-link partial download.')
    identity = {key: artifact[key] for key in ('url', 'checksum_algorithm', 'checksum', 'bytes')}
    if partial.exists():
        try:
            saved = json.loads(metadata.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            raise InstallError('Partial download has no valid ownership metadata: ' + target.name
                               + '. Move its .part file aside before retrying.')
        if saved != identity:
            raise InstallError('Partial download belongs to another model: ' + target.name
                               + '. Move its .part and .part.json files aside before retrying.')
        size = partial.stat().st_size
        if size > (artifact['bytes'] if artifact['bytes'] is not None else 2*GIB):
            raise InstallError('Partial download is larger than the expected model: ' + target.name)
        return size
    return 0

def storage_preflight(comfy, artifacts):
    root = comfy/'models'
    required = 2*GIB  # Reserve for the extension, pip scratch space and filesystem overhead.
    for artifact in artifacts:
        required += max(0, (artifact['bytes'] or GIB) - partial_size(destination(root, artifact), artifact))
    check_at = root if root.exists() else comfy
    free = shutil.disk_usage(check_at).free
    if free < required:
        raise InstallError(f'Insufficient disk space: need {required/GIB:.1f} GiB free for this installation, '
                           f'but only {free/GIB:.1f} GiB is available. No download was started.')
    return {'required_free_bytes': required, 'free_bytes': free}

class HTTPSOnlyRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        if parsed.scheme != 'https' or parsed.username or parsed.password:
            raise InstallError('Refusing an insecure model download redirect.')
        return super().redirect_request(req, fp, code, msg, headers, newurl)

@contextmanager
def download_lock(target):
    """Advisory locks release on process exit, so interrupted downloads can resume."""
    lock = Path(str(target)+'.download.lock')
    if lock.is_symlink():
        raise InstallError('Refusing a symbolic-link download lock.')
    with lock.open('a+b') as file:
        if os.name == 'nt':
            import msvcrt
            if file.tell() == 0:
                file.write(b'0'); file.flush()
            file.seek(0)
            try:
                msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise InstallError('Another installer is downloading ' + target.name) from exc
            try:
                yield
            finally:
                file.seek(0); msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            try:
                fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                raise InstallError('Another installer is downloading ' + target.name) from exc
            try:
                yield
            finally:
                fcntl.flock(file.fileno(), fcntl.LOCK_UN)

def download_artifact(models_root, artifact, opener=None):
    target = destination(models_root, artifact)
    target.parent.mkdir(parents=True, exist_ok=True)
    opener = opener or urllib.request.build_opener(HTTPSOnlyRedirect())
    with download_lock(target):
        if target.exists():
            if verify_file(target, artifact):
                return target
            raise InstallError('Existing model checksum mismatch; nothing overwritten: ' + artifact['path'])
        partial, metadata = partial_paths(target)
        offset = partial_size(target, artifact)
        identity = {key: artifact[key] for key in ('url', 'checksum_algorithm', 'checksum', 'bytes')}
        if not partial.exists():
            metadata.write_text(json.dumps(identity, sort_keys=True), encoding='utf-8')
        if artifact['bytes'] is None or offset != artifact['bytes']:
            headers = {'User-Agent': 'ImageStudioInstaller/1', 'Accept-Encoding': 'identity'}
            if offset:
                headers['Range'] = f'bytes={offset}-'
            request = urllib.request.Request(artifact['url'], headers=headers)
            try:
                with opener.open(request, timeout=60) as response:
                    status = response.status
                    if status not in (200, 206):
                        raise InstallError('Unexpected model download response for ' + target.name)
                    total = artifact['bytes']
                    if status == 206:
                        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
                        if not match or int(match[1]) != offset or int(match[2]) < offset:
                            raise InstallError('Invalid resumed-download range for ' + target.name)
                        if total is not None and int(match[3]) != total:
                            raise InstallError('Resumed-download size differs from the verified model: ' + target.name)
                        total = int(match[3])
                    elif offset:
                        offset = 0  # Server ignored Range: restart, never append a complete file.
                    length = response.headers.get('Content-Length')
                    if total is not None and length is not None and int(length) != total-offset:
                        raise InstallError('Download size differs from the verified model: ' + target.name)
                    limit = total if total is not None else 2*GIB
                    received = offset
                    last_progress = 0.
                    with partial.open('ab' if offset else 'wb') as file:
                        while True:
                            chunk = response.read(1024*1024)
                            if not chunk:
                                break
                            if received + len(chunk) > limit:
                                raise InstallError('Download exceeded verified model size: ' + target.name)
                            file.write(chunk); received += len(chunk)
                            if time.monotonic() - last_progress > 10:
                                print(json.dumps({'model': artifact['id'], 'downloaded_bytes': received,
                                                  'expected_bytes': total}), flush=True)
                                last_progress = time.monotonic()
                        file.flush(); os.fsync(file.fileno())
                    if total is not None and received != total:
                        raise InstallError('Download interrupted; the verified partial can be resumed: ' + target.name, retryable=True)
            except (urllib.error.URLError, TimeoutError, OSError, http.client.IncompleteRead) as exc:
                raise InstallError('Network/storage error downloading ' + target.name
                                   + '. Partial data is retained; rerun the same command to resume.',
                                   retryable=isinstance(exc, http.client.IncompleteRead) or transient_transfer_error(exc)) from exc
        if not verify_file(partial, artifact):
            partial.unlink(missing_ok=True); metadata.unlink(missing_ok=True)
            raise InstallError('Downloaded model checksum mismatch: ' + target.name
                               + '. Rejected data was removed; no model was installed.')
        partial.replace(target)
        metadata.unlink(missing_ok=True)
        print(json.dumps({'model': artifact['id'], 'status': 'verified', 'bytes': target.stat().st_size}), flush=True)
        return target
