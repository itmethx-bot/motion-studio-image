"""Print pinned registry entries from Hugging Face metadata, without downloading weights."""
import argparse
import json
import os
from pathlib import PurePosixPath
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

KNOWN = {
    'RealVisXL_V5.0_fp16.safetensors': ('realvisxl', 'checkpoints'),
    'flux1-dev.safetensors': ('flux1_dev', 'diffusion_models'),
    't5xxl_fp16.safetensors': ('flux_t5', 'text_encoders'),
    'clip_l.safetensors': ('flux_clip', 'text_encoders'),
    'ae.safetensors': ('flux_vae', 'vae'),
}


class MetadataError(ValueError):
    pass


def repo_name(value):
    if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*/[A-Za-z0-9_][A-Za-z0-9_.-]*', value):
        raise MetadataError('repo ต้องเป็น owner/name')
    return value


def safe_path(value):
    path = PurePosixPath(value)
    if not value or value.startswith('/') or '\\' in value or any(p in ('.', '..', '') for p in value.split('/')):
        raise MetadataError('ชื่อไฟล์/path ไม่ถูกต้อง')
    return str(path)


def api_json(url):
    # ส่ง token เฉพาะ HF API และไม่พิมพ์ token หรือ URL ที่ลงลายเซ็น
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or parsed.netloc != 'huggingface.co' or not parsed.path.startswith('/api/models/'):
        raise MetadataError('ปฏิเสธ URL metadata นอก Hugging Face API')
    headers = {'User-Agent': 'ImageStudioModelInfo/1', 'Accept': 'application/json'}
    token = os.environ.get('HF_TOKEN') or os.environ.get('HUGGING_FACE_HUB_TOKEN')
    if token:
        headers['Authorization'] = 'Bearer ' + token

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            raise MetadataError('HF API redirect ไม่ได้รับอนุญาต')

    try:
        with urllib.request.build_opener(NoRedirect()).open(urllib.request.Request(url, headers=headers), timeout=45) as response:
            raw = response.read(16 * 1024 * 1024 + 1)
            if len(raw) > 16 * 1024 * 1024:
                raise MetadataError('HF metadata ใหญ่เกินขอบเขต')
            return json.loads(raw), response.headers.get('Link', '')
    except urllib.error.HTTPError as exc:
        raise MetadataError(f'HF API HTTP {exc.code}: ตรวจ repo/ชื่อไฟล์/สิทธิ์อ่าน') from exc
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        if isinstance(exc, MetadataError):
            raise
        raise MetadataError('อ่าน HF metadata ไม่สำเร็จ: ' + type(exc).__name__) from exc


def tree(repo, revision, request=api_json):
    url = f'https://huggingface.co/api/models/{repo}/tree/{revision}?recursive=true&limit=1000'
    items, visited = [], set()
    for _ in range(100):
        if url in visited:
            raise MetadataError('HF pagination วนซ้ำ')
        visited.add(url)
        page, link = request(url)
        if not isinstance(page, list):
            raise MetadataError('HF tree ไม่ใช่รายการไฟล์')
        items.extend(page)
        next_link = re.search(r'<([^>]+)>;\s*rel="next"', link)
        if not next_link:
            return items
        url = next_link[1]
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != 'https' or parsed.netloc != 'huggingface.co' or parsed.path != f'/api/models/{repo}/tree/{revision}':
            raise MetadataError('ปฏิเสธ pagination นอก repo/revision ที่เลือก')
    raise MetadataError('HF tree มีจำนวนหน้ามากเกินขอบเขต')


def select_files(items, filenames):
    files = {safe_path(item['path']): item for item in items if item.get('type') == 'file' and isinstance(item.get('path'), str)}
    if not filenames:
        # คำสั่งสั้นของ RealVis เลือก FP16 ซึ่งตรงกับโหมด PC
        names = ['RealVisXL_V5.0_fp16.safetensors'] if 'RealVisXL_V5.0_fp16.safetensors' in files else sorted(p for p in files if p.endswith('.safetensors'))
    else:
        names = []
        for filename in filenames:
            filename = safe_path(filename)
            matches = [filename] if filename in files else [p for p in files if PurePosixPath(p).name == filename]
            if len(matches) != 1:
                raise MetadataError('ไม่พบไฟล์หรือชื่อไฟล์ซ้ำหลาย path: ' + filename)
            names.append(matches[0])
    if not names:
        raise MetadataError('ไม่พบไฟล์โมเดล .safetensors; ระบุชื่อไฟล์เอง')
    return [files[name] for name in dict.fromkeys(names)]


def entry(repo, revision, item, model_id=None, model_path=None):
    name = safe_path(item['path'])
    basename = PurePosixPath(name).name
    default_id, folder = KNOWN.get(basename, (re.sub(r'[^a-z0-9]+', '_', basename.rsplit('.', 1)[0].lower()).strip('_'), 'checkpoints'))
    size = item.get('size')
    lfs = item.get('lfs') or {}
    oid = lfs.get('oid', '')
    if isinstance(oid, str) and oid.startswith('sha256:'):
        oid = oid[7:]
    if type(size) is not int or size <= 0:
        raise MetadataError('HF ไม่คืน size ที่ใช้ได้: ' + name)
    if lfs.get('size', size) != size:
        raise MetadataError('size ของไฟล์และ LFS ไม่ตรงกัน: ' + name)
    # Git blob oid ไม่ใช่ SHA256 ของไฟล์ ห้ามนำมาใช้แทน lfs.oid
    digest = oid.lower() if isinstance(oid, str) and re.fullmatch(r'[a-fA-F0-9]{64}', oid) else None
    return {'id': model_id or default_id, 'path': safe_path(model_path or folder + '/' + basename),
            'bytes': size, 'checksum_algorithm': 'sha256', 'checksum': digest,
            'url': f'https://huggingface.co/{repo}/resolve/{revision}/' + urllib.parse.quote(name, safe='/')}


def model_info(repo, filenames=(), request=api_json, model_id=None, model_path=None):
    repo = repo_name(repo)
    # อ่าน tree/main ตามคำขอ แล้วตรวจซ้ำที่ commit เพื่อให้ URL กับ checksum เป็นรุ่นเดียวกัน
    select_files(tree(repo, 'main', request), filenames)
    metadata, _ = request(f'https://huggingface.co/api/models/{repo}')
    revision = metadata.get('sha') if isinstance(metadata, dict) else None
    if not isinstance(revision, str) or not re.fullmatch(r'[a-f0-9]{40}', revision):
        raise MetadataError('HF ไม่คืน commit ที่ pin ได้')
    selected = select_files(tree(repo, revision, request), filenames)
    if (model_id or model_path) and len(selected) != 1:
        raise MetadataError('--id/--path ใช้กับไฟล์เดียวเท่านั้น')
    return [entry(repo, revision, item, model_id, model_path) for item in selected]


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', help='owner/repo')
    parser.add_argument('files', nargs='*', help='filename หรือ path ใน repo; เว้นว่างเพื่อหาโมเดล')
    parser.add_argument('--id', help='id ใน registry (ใช้กับไฟล์เดียว)')
    parser.add_argument('--path', help='path ปลายทางใน ComfyUI models (ใช้กับไฟล์เดียว)')
    parser.add_argument('--json', action='store_true', help='พิมพ์ JSON แทน Python entry')
    args = parser.parse_args(argv)
    try:
        entries = model_info(args.repo, args.files, model_id=args.id, model_path=args.path)
    except MetadataError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(entries, ensure_ascii=False, indent=2))
    else:
        for item in entries:
            if item['checksum'] is None:
                print('# รัน tools/model_info.py เพื่อเติม: HF ไม่คืน lfs.oid SHA256 (repo gated อาจต้องมี HF_TOKEN)')
            print('{')
            for key, value in item.items():
                print(f'    {key!r}: {value!r},')
            print('}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
