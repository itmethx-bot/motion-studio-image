import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'payload-manifest.json').read_text())
found={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts and p.name!='payload-manifest.json'}
assert found==set(manifest['files']), 'Unexpected or missing repository file'
for name,expected in manifest['files'].items():
 path=root/name
 assert not path.is_symlink(), 'Linked payload'
 data=path.read_bytes()
 assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'], 'Payload hash mismatch: '+name
 if name.endswith('.py'):compile(data,name,'exec')
assert not any('private-data/' in n or 'fullgen-fixtures/' in n for n in found)
assert not any(n.lower().endswith(('.png','.jpg','.jpeg','.mp4','.dpapi')) for n in found)
print('Verified source payload; no media, provider credentials, or model weights included')
