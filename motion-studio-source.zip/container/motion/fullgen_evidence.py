"""Package one job's bounded JSON evidence and selected scene for local retention.

No network or provider access. Existing files are never overwritten. The archive
contains no model weights, input media or generated video, only explicitly
selected evidence. Credential-like JSON keys are rejected, not silently redacted.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile


MAX_JSON_FILES = 128
MAX_JSON_BYTES = 8 * 1024 * 1024
MAX_JSON_TOTAL = 32 * 1024 * 1024
MAX_PNG_BYTES = 32 * 1024 * 1024


def _path(value):
    path = Path(value)
    if '..' in path.parts:
        raise ValueError('Path traversal is not allowed in evidence paths')
    path = path.absolute()
    for item in (path, *path.parents):
        if item.is_symlink() or getattr(item, 'is_junction', lambda: False)():
            raise ValueError('Symlinks and junctions are not allowed in evidence paths')
    return path


def _credential_keys(value):
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = re.sub(r'[^a-z0-9]', '', str(key).lower())
            if (normalized in {'key', 'token', 'password', 'passwd', 'pwd', 'authorization',
                               'auth', 'bearer', 'cookie', 'cookies', 'setcookie', 'secret',
                               'secrets', 'credential', 'credentials', 'accesscode', 'pincode'}
                    or any(marker in normalized for marker in ('apikey', 'privatekey', 'secretkey',
                        'secretaccesskey', 'accesskeyid', 'accesstoken', 'refreshtoken',
                        'sessiontoken', 'clientsecret', 'idtoken', 'accesscode'))):
                # Do not echo the key or value, which may themselves contain secrets.
                raise ValueError('Credential-like JSON key found; refusing to package this evidence')
            _credential_keys(child)
    elif isinstance(value, list):
        for child in value:
            _credential_keys(child)


def _json_bytes(content):
    if len(content) > MAX_JSON_BYTES:
        raise ValueError('Evidence JSON exceeds the per-file size limit')
    def invalid_constant(_):
        raise ValueError('Non-finite values are not valid evidence JSON')
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON keys are not allowed in evidence')
            result[key] = value
        return result
    value = json.loads(content.decode('utf-8-sig'), parse_constant=invalid_constant,
                       object_pairs_hook=unique_object)
    _credential_keys(value)
    return content


def _read_bounded(path, limit):
    if not path.is_file() or path.stat().st_size > limit:
        raise ValueError('Evidence file is absent or exceeds its size limit')
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Evidence file grew beyond its size limit')
    return data


def package_job_evidence(evidence_dir, scene_png, finalizer_report, output_zip):
    """Return {path, bytes, sha256} only after CRC and every member hash pass.

    finalizer_report may be its existing JSON path or the finalizer's result dict.
    output_zip must be a new .zip filename. Only JSON files under this exact job
    directory are enumerated; unrelated media and neighbouring jobs are excluded.
    """
    root, scene, output = _path(evidence_dir), _path(scene_png), _path(output_zip)
    if not root.is_dir():
        raise ValueError('Evidence directory does not exist')
    if output.suffix.lower() != '.zip' or output.exists():
        raise ValueError('Choose a new .zip output path; existing files are never overwritten')
    members = {}
    json_total = 0
    walked_entries = 0
    for directory, folders, files in os.walk(root, followlinks=False):
        walked_entries += len(folders) + len(files)
        if walked_entries > 2048 or len(Path(directory).relative_to(root).parts) > 4:
            raise ValueError('Job evidence directory exceeds enumeration or nesting limits')
        for name in folders + files:
            _path(Path(directory) / name)  # Reject links even when not JSON.
        for name in sorted(files):
            path = Path(directory) / name
            if path.suffix.lower() != '.json':
                continue
            relative = path.relative_to(root)
            if len(relative.parts) > 5 or any(part in ('', '.', '..') or '\\' in part or ':' in part for part in relative.parts):
                raise ValueError('Unsafe or excessively nested evidence archive path')
            if len(members) >= MAX_JSON_FILES:
                raise ValueError('Too many JSON evidence files in one job')
            content = _json_bytes(_read_bounded(path, MAX_JSON_BYTES))
            json_total += len(content)
            if json_total > MAX_JSON_TOTAL:
                raise ValueError('Evidence JSON exceeds the total size limit')
            members['evidence/' + relative.as_posix()] = content
    if not members:
        raise ValueError('Job evidence directory contains no JSON records')
    if isinstance(finalizer_report, dict):
        finalizer = json.dumps(finalizer_report, ensure_ascii=False, allow_nan=False, indent=2).encode('utf-8')
    else:
        finalizer = _read_bounded(_path(finalizer_report), MAX_JSON_BYTES)
    finalizer = _json_bytes(finalizer)
    if json_total + len(finalizer) > MAX_JSON_TOTAL:
        raise ValueError('Evidence and finalizer JSON exceed the total size limit')
    members['finalizer-report.json'] = finalizer
    if scene.suffix.lower() != '.png':
        raise ValueError('Selected scene must use the .png extension')
    image_bytes = _read_bounded(scene, MAX_PNG_BYTES)
    from io import BytesIO
    from PIL import Image
    with Image.open(BytesIO(image_bytes)) as image:
        if image.format != 'PNG' or image.width * image.height > 32_000_000:
            raise ValueError('Selected scene is not a bounded PNG image')
        image.verify()
    members['scene/first-scene.png'] = image_bytes
    records = [{'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
               for name, data in sorted(members.items())]
    members['manifest.json'] = json.dumps({'version': 1, 'files': records,
        'visual_quality_verified': False, 'scope': 'One job JSON evidence, selected PNG and finalizer report'},
        ensure_ascii=False, indent=2).encode('utf-8')
    expected = {name: hashlib.sha256(data).hexdigest() for name, data in members.items()}
    output.parent.mkdir(parents=True, exist_ok=True)
    created = False
    try:
        with output.open('xb') as stream:
            created = True
            with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                for name, data in sorted(members.items()):
                    archive.writestr(name, data)
        with zipfile.ZipFile(output) as archive:
            if archive.testzip() is not None or set(archive.namelist()) != set(expected):
                raise ValueError('Evidence archive CRC or member inventory verification failed')
            for name, digest in expected.items():
                if hashlib.sha256(archive.read(name)).hexdigest() != digest:
                    raise ValueError('Evidence archive member hash verification failed')
        digest = hashlib.sha256()
        with output.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
        return {'path': str(output), 'bytes': output.stat().st_size, 'sha256': digest.hexdigest()}
    except BaseException:
        if created:
            output.unlink(missing_ok=True)
        raise
