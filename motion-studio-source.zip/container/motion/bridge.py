"""PC controller: keep results available on Tailscale after stopping the Pod."""
import asyncio
import contextlib
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import time
from aiohttp import ClientError, ClientSession, ClientTimeout, CookieJar, web
from yarl import URL
from .service import Studio, OfflineBackend, atomic_json, verify_result, validate_two_file_job, SYSTEM_VERSION
from .provider import Provider

POD_URL=re.compile(r'^https://[a-zA-Z0-9]+-8188\.proxy\.runpod\.net/?$')

class BootstrapFailed(ValueError):pass


def stop_error_summary(value):
    """Keep only the service's bounded diagnostic fields, never arbitrary text."""
    if not isinstance(value,dict):return {}
    result={}
    for field in ('stop_http_status','confirmation_http_status'):
        number=value.get(field)
        if type(number) is int and 100<=number<=599:result[field]=number
    choices={
        'phase':{'configuration','stop_request','provider_confirmation','queue_check','queue_or_stop'},
        'reason':{'missing_or_invalid_stop_configuration','stop_request_rejected',
                  'provider_stop_not_confirmed','other_comfy_jobs','unconfirmed'},
        'confirmation_state':{'EXITED','STOPPED','RUNNING','CREATED','PAUSED','unrecognized'},
    }
    for field,allowed in choices.items():
        text=value.get(field)
        if isinstance(text,str) and text in allowed:result[field]=text
    if type(value.get('pod_id_matches')) is bool:result['pod_id_matches']=value['pod_id_matches']
    exception=value.get('exception_class')
    if isinstance(exception,str) and re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,79}',exception):
        result['exception_class']=exception
    return result


def keep_awake(enabled):
    """Prevent automatic PC sleep during a job; do not keep the display on."""
    if os.name=='nt':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | (1 if enabled else 0))


class Remote:
    def __init__(self,settings):
        self.base=settings['url'].rstrip('/')+'/motion-studio/api'
        self.code=settings['access_code']
        self.session=None

    async def open(self):
        self.session=ClientSession(cookie_jar=CookieJar(),timeout=ClientTimeout(total=120))
        await self.request('POST','/login',{'code':self.code})

    async def request(self,method,path,body=None,data=None):
        # Only this idempotent status read may be replayed. Mutations (including
        # login/release) and streamed downloads always remain a single attempt.
        retry_status=method.upper()=='GET' and path=='/status'
        attempts=3 if retry_status else 1
        options={'timeout':ClientTimeout(total=30)} if retry_status else {}
        for attempt in range(attempts):
            try:
                async with self.session.request(method,self.base+path,json=body if data is None else None,data=data,
                            headers={'X-Requested-With':'MotionStudioAuto'},**options) as response:
                    if response.status in (401,403):
                        raise ValueError(f'Pod ไม่อนุญาตให้เข้าถึง (HTTP {response.status}) กรุณาตรวจรหัสเชื่อมต่อ')
                    if response.status>=400:
                        # No proxy/provider response body, headers or exception
                        # text may enter diagnostics or the browser.
                        if not (retry_status and response.status in (429,502,503,504)
                                and attempt+1<attempts):
                            raise ValueError(f'ติดต่อระบบบน Pod ไม่สำเร็จ (HTTP {response.status}) กรุณาตรวจ URL รหัส และการติดตั้ง')
                    else:
                        return await response.json()
            except (ClientError,asyncio.TimeoutError):
                if not retry_status or attempt+1>=attempts:
                    raise ValueError('ติดต่อระบบบน Pod ไม่สำเร็จหลังรอการเชื่อมต่อ กรุณาตรวจสถานะ Pod') from None
            # Close the failed response before backoff. Three 30-second reads
            # plus 2/5-second delays stay below the PC guard heartbeat window.
            await asyncio.sleep((2,5)[attempt])

    async def close(self):
        if self.session: await self.session.close()


class BridgeBackend(OfflineBackend):
    def __init__(self,data):
        super().__init__(data)
        self.provider=Provider(self.data)

    async def ready(self):
        automatic={**self.provider.public(),'pc_controller':True}
        if self.provider.config().get('mode')=='manual_owned':
            if not automatic['ready']:return automatic
            remote=Remote(json.loads((self.data/'pod-connection.json').read_text()))
            try:
                await remote.open();status=await remote.request('GET','/status')
                compatible=status.get('system_version')==SYSTEM_VERSION and status.get('cleanup_owner')=='pc'
                row=self.provider.lease()
                if compatible and row.get('state')=='awaiting_input':
                    row['heartbeat_at']=time.time()
                    if status.get('bootstrap_failed'):row['state']='bootstrap_failed'
                    atomic_json(self.provider.ledger_path,row)
                return {**automatic,'ready':bool(compatible and status.get('ready')),
                    'message':status.get('message','กำลังเตรียม Pod') if compatible else 'Pod ไม่ใช่รุ่นที่ PC ควบคุมการส่งมอบ',
                    'manual_owned':True,'connection_needed':False}
            except Exception:
                return {**automatic,'ready':False,'message':'กำลังรอระบบบน Pod ที่คุณเปิดเอง'}
            finally:await remote.close()
        if self.provider.config().get('mode')=='fresh':return automatic
        if self.provider.config().get('enabled'):
            installed=self.provider.config().get('deployment_verified',False)
            installed=installed and self.provider.config().get('deployment_version')==SYSTEM_VERSION
            installed=installed and (self.data/'pod-connection.json').is_file()
            if installed:
                settings=json.loads((self.data/'pod-connection.json').read_text(encoding='utf-8'))
                connected_id=settings['url'].split('://',1)[1].split('-8188.',1)[0]
                installed=connected_id==self.provider.config().get('pod_id')
            if not installed:
                return {**automatic,'ready':False,'connection_needed':True,
                        'message':'ยังต้องตรวจการติดตั้งบน Pod ครั้งแรกก่อนเริ่มเช่าอัตโนมัติ'}
            return automatic
        connection=self.data/'pod-connection.json'
        if connection.is_file():
            remote=Remote(json.loads(connection.read_text(encoding='utf-8')))
            try:
                await remote.open();status=await remote.request('GET','/status')
                compatible=status.get('system_version')==SYSTEM_VERSION
                return {**automatic,'ready':compatible and status.get('ready',False),
                    'connection_needed':False,'already_running_pod':True,
                    'automatic_stop_ready':status.get('automatic_stop_ready',False),
                    'message':status.get('message','กำลังตรวจ Pod') if compatible else 'ต้องอัปเดตระบบบน Pod เป็นรุ่นสร้างฉากใหม่ก่อน'}
            except Exception:
                return {**automatic,'ready':False,'connection_needed':False,'already_running_pod':True,
                    'message':'เปิด Pod ที่เชื่อมไว้ก่อนสร้างงาน ระบบจะบันทึกผลลง PC แล้วส่งคำสั่งหยุด GPU'}
            finally:await remote.close()
        return {**automatic,'ready':False,'connection_needed':True,
                'message':'เชื่อมต่อ Pod ที่เตรียมไว้ก่อน แล้วอัปโหลดรูปกับคลิปเพื่อสร้างวิดีโอ'}


class BridgeStudio(Studio):
    def __init__(self,backend):
        super().__init__(backend)
        row=backend.provider.lease()
        # A crash can happen before acquire writes its ownership record. In that
        # case no start mutation was sent, so an interrupted job must not lock
        # the UI forever. A pending recorded lease still requires reconciliation.
        for job in self.jobs.values():
            if job.get('stored_record_invalid'):continue
            if not job.get('automatic_lease') and job.get('status')=='interrupted':
                job.update(requires_idle_reconcile=True,message='ระบบ PC เปิดใหม่ ต้องตรวจว่าคิว Pod ว่างก่อนเริ่มรอบใหม่')
                self.persist(job)
            if job.get('automatic_lease') and job.get('status')=='interrupted':
                if not row:
                    job.update(status='failed',stop_confirmed=None,message='ระบบเปิดใหม่ก่อนเริ่ม GPU กรุณาสร้างงานอีกครั้ง')
                    self.persist(job)
                elif row.get('job_id')==job['id'] and not row.get('cleanup_pending'):
                    complete=bool(job.get('result') and job.get('evidence_download_status')=='verified')
                    job.update(status='completed' if complete else 'failed',stop_confirmed=True,
                               message=('เก็บวิดีโอแล้ว แต่หลักฐาน workflow ยังไม่ครบ; '
                                        if job.get('result') and not complete else '')+
                                       'ระบบเปิดใหม่ และพบหลักฐานยืนยันหยุด GPU ของรอบนี้แล้ว')
                    self.persist(job)

    async def configure_auto(self,request):
        self.authorize(request,True)
        body=await self.body(request)
        if self.task and not self.task.done():raise web.HTTPConflict(text='รอให้งานเดิมเสร็จก่อนตั้งค่า')
        if body.get('mode')=='fresh':
            try:self.backend.provider.configure_fresh(body.get('image_name','').strip(),body.get('api_key',''),
                hourly_ceiling=body.get('hourly_ceiling_usd',1.5))
            except ValueError as error:raise web.HTTPBadRequest(text=str(error))
            return web.json_response({'ok':True,'message':'บันทึกโหมดสร้าง Pod ใหม่แล้ว ยังไม่เริ่มเช่า; ต้องตรวจเครดิตและสิทธิ์จริงเมื่อกดสร้าง'})
        connection=self.data/'pod-connection.json'
        if not connection.is_file():raise web.HTTPConflict(text='เชื่อมต่อระบบที่ติดตั้งบน Pod ให้สำเร็จก่อนตั้งค่าเช่าอัตโนมัติ')
        saved=json.loads(connection.read_text(encoding='utf-8'))
        pod_id=saved['url'].split('://',1)[1].split('-8188.',1)[0]
        # Validate deployment while the user-prepared Pod is online, before arming auto-rental.
        remote=Remote(saved)
        try:
            await remote.open();status=await remote.request('GET','/status')
            if not status.get('ready') or status.get('system_version')!=SYSTEM_VERSION:
                raise ValueError('ติดตั้งชุดระบบและตั้งค่าหยุด GPU บน Pod ให้ครบก่อน')
            self.backend.provider.configure(pod_id,body.get('api_key',''))
            config=self.backend.provider.config();config['deployment_verified']=True
            config['deployment_version']=SYSTEM_VERSION
            atomic_json(self.backend.provider.config_path,config)
        except ValueError as error:raise web.HTTPBadRequest(text=str(error))
        finally:await remote.close()
        return web.json_response({'ok':True,'message':'บันทึกโหมด RunPod อัตโนมัติแล้ว กรุณาหยุด Pod ก่อนเริ่มงานแรก'})

    async def resolve_allocation(self,request):
        self.authorize(request,True);body=await self.body(request)
        if self.task and not self.task.done():raise web.HTTPConflict(text='รอให้งานปัจจุบันเสร็จก่อนตรวจคำขอ')
        try:
            resolved=await self.backend.provider.resolve_unknown_allocation(body.get('job_id'),body.get('confirm_absence'))
        except ValueError as error:raise web.HTTPConflict(text=str(error))
        job=self.jobs.get(resolved['job_id'])
        if job:
            job.update(retired_lease=True,status='failed',stage='failed',
                allocation_resolution='user_and_account_list_no_match',
                message='ผู้ใช้ยืนยันไม่พบเครื่อง และรายการบัญชีไม่พบคำขอนี้ ปลดล็อกแล้วโดยไม่ได้ส่งคำสั่งเช่า หยุด หรือลบเครื่อง')
            self.persist(job)
        return web.json_response({'ok':True,'message':'ตรวจไม่พบเครื่องจากคำขอเดิม ปลดล็อกแล้ว ยังไม่ได้เช่าเครื่องใหม่'})

    async def save_key(self,request):
        self.authorize(request,True)
        body=await self.body(request)
        if self.task and not self.task.done():raise web.HTTPConflict(text='รอให้งานปัจจุบันเสร็จก่อนเปลี่ยนกุญแจ')
        try:self.backend.provider.save_account_key(body.get('api_key',''))
        except ValueError as error:raise web.HTTPBadRequest(text=str(error))
        return web.json_response({'ok':True,'message':'บันทึก API key แบบเข้ารหัสบน PC แล้ว ยังไม่เริ่มเช่าหรือตรวจสิทธิ์กับ RunPod'})

    async def configure(self,request):
        self.authorize(request,True)
        body=await self.body(request)
        if body.get('mode')=='manual_owned':return await self.connect_manual(body)
        url=body.get('url','').strip(); code=body.get('access_code','')
        if not POD_URL.fullmatch(url) or not isinstance(code,str) or not 8<=len(code)<=128:
            raise web.HTTPBadRequest(text='ใช้ URL ComfyUI ของ RunPod และรหัสของระบบบน Pod')
        if self.task and not self.task.done(): raise web.HTTPConflict(text='รอให้งานปัจจุบันเสร็จก่อนเปลี่ยน Pod')
        if self.backend.provider.lease().get('cleanup_pending'):
            raise web.HTTPConflict(text='ยังต้องยืนยันการหยุด GPU เดิมก่อนเปลี่ยน Pod')
        remote=Remote({'url':url,'access_code':code})
        try:
            await remote.open(); remote_status=await remote.request('GET','/status')
            if remote_status.get('system_version')!=SYSTEM_VERSION:
                raise ValueError('Pod ต้องติดตั้งระบบสร้างฉากใหม่รุ่นล่าสุด')
        except Exception: raise web.HTTPBadRequest(text='ยังเชื่อมต่อไม่ได้ กรุณาติดตั้งชุดบน Pod และตรวจรหัส')
        finally: await remote.close()
        path=self.data/'pod-connection.json'
        atomic_json(path,{'url':url.rstrip('/'),'access_code':code})
        config=self.backend.provider.config()
        if config.get('mode')=='fresh':
            config['enabled']=False;config['mode']='manual'
            atomic_json(self.backend.provider.config_path,config)
        with contextlib.suppress(OSError): path.chmod(0o600)
        return web.json_response({'ok':True})

    async def prepare_manual(self,request):
        self.authorize(request,True);body=await self.body(request)
        if self.task and not self.task.done():raise web.HTTPConflict(text='รอให้งานปัจจุบันเสร็จก่อนเตรียมชุดเชื่อม')
        try:setup=self.backend.provider.manual_setup(body.get('image_name') or None)
        except ValueError as error:raise web.HTTPBadRequest(text=str(error))
        return web.json_response(setup,headers={'Cache-Control':'no-store'})

    async def read_manual(self,request):
        self.authorize(request)
        path=self.data/'manual-pod-setup.json'
        return web.json_response(json.loads(path.read_text()) if path.exists() else {'prepared':False},
            headers={'Cache-Control':'no-store'})

    async def connect_manual(self,body):
        if self.task and not self.task.done():raise web.HTTPConflict(text='รอให้งานปัจจุบันเสร็จก่อนเชื่อมเครื่องใหม่')
        url=body.get('url','').strip()
        if not POD_URL.fullmatch(url):raise web.HTTPBadRequest(text='ใช้ URL 8188 ของ Pod ที่คุณเปิดไว้')
        path=self.data/'manual-pod-setup.json'
        if not path.is_file():raise web.HTTPBadRequest(text='กดเตรียมค่าเปิด Pod ด้วยตัวเองก่อน')
        setup=json.loads(path.read_text());settings={'url':url.rstrip('/'),'access_code':setup['env']['MOTION_ACCESS_CODE']}
        remote=Remote(settings)
        try:
            await remote.open();status=await remote.request('GET','/status')
            if (status.get('system_version')!=SYSTEM_VERSION or status.get('cleanup_owner')!='pc'
                or status.get('bootstrap_failed') or status.get('jobs')):
                raise ValueError('ระบบบน Pod ไม่ตรงชุดเตรียม ล้มเหลว หรือมีงานอยู่แล้ว')
            provider=self.backend.provider
            row,resolved=await provider.adopt_manual(url.split('://')[1].split('-8188.')[0],setup,
                consent=body.get('stop_delete_consent'),confirm_absence=body.get('confirm_old_absence'),
                hourly_ceiling=body.get('hourly_ceiling_usd',1.5))
            atomic_json(self.data/'pod-connection.json',settings)
            if resolved:
                old=self.jobs.get(resolved['job_id'])
                if old:
                    old.update(retired_lease=True,allocation_resolution='user_and_account_list_no_match',
                        message='เก็บคำขอเดิมไว้แล้ว ผู้ใช้ยืนยันไม่พบเครื่อง และรายการบัญชีไม่พบตัวระบุที่ตรงกัน; ไม่ได้ยืนยัน Stop หรือ Terminate')
                    self.persist(old)
            return web.json_response({'ok':True,'message':'เชื่อม Pod ที่คุณเปิดเองแล้ว รอโมเดลพร้อมก่อนกดสร้าง'})
        except ValueError as error:raise web.HTTPBadRequest(text=str(error))
        finally:await remote.close()

    async def create(self,request):
        self.authorize(request,True)
        body=await self.body(request)
        async with self.lock:
            if self.task and not self.task.done(): raise web.HTTPConflict(text='กำลังสร้างงานก่อนหน้าอยู่')
            try:
                if self.backend.provider.config().get('mode')=='fresh':await self.reconcile_old_pods()
                else:await self.reconcile_direct_sessions()
            except ValueError as error:
                raise web.HTTPConflict(text=str(error))
            except Exception:
                raise web.HTTPConflict(text='ยังตรวจรอบใหม่และคิวว่างของ Pod ไม่สำเร็จ จึงไม่ล้างข้อขัดข้องรอบเดิม')
            if any((j.get('stop_confirmed') is False or j.get('stop_observation_pending'))
                   and not j.get('retired_lease') for j in self.jobs.values()):
                raise web.HTTPConflict(text='งานก่อนหน้ายังยืนยันการหยุด Pod ไม่ได้ กรุณาตรวจและหยุด Pod ก่อน')
            ready=await self.backend.ready()
            if not ready.get('ready'): raise web.HTTPConflict(text=ready['message'])
            try:
                image=self.input_record(body.get('image'),'image');video=self.input_record(body.get('video'),'video')
                duration=body.get('duration',10)
                validate_two_file_job(image,video,duration)
            except ValueError as error:raise web.HTTPBadRequest(text=str(error))
            except (FileNotFoundError,KeyError): raise web.HTTPBadRequest(text='ตรวจรูป คลิป และความยาวอีกครั้ง')
            manual=self.backend.provider.config().get('mode')=='manual_owned'
            uid=self.backend.provider.config()['reserved_job_id'] if manual else secrets.token_hex(16)
            if uid in self.jobs:raise web.HTTPConflict(text='ชุดเชื่อมนี้ใช้สร้างงานแล้ว ต้องเตรียมและเชื่อมเครื่องใหม่')
            job={'id':uid,'created':time.time(),'status':'queued','stop_confirmed':None,
                 'executor':'runpod','automatic_lease':self.backend.provider.public()['auto_lease'],
                 'message':'กำลังใช้ GPU ที่คุณเชื่อมไว้' if manual else
                    'กำลังเริ่มเช่า GPU บน RunPod' if self.backend.provider.public()['auto_lease'] else 'กำลังส่งไฟล์ให้ GPU'}
            self.jobs[uid]=job;self.persist(job)
            self.task=asyncio.create_task(self.run_remote(job,image,video,duration))
            return web.json_response(job,status=202)

    async def reconcile_old_pods(self):
        """No historical 403 is cleared merely by selecting fresh mode.

        Only account API reads by the configured application may verify that the
        old Pod is stopped or absent. No user-created Pod is mutated here.
        """
        pending=[j for j in self.jobs.values() if not j.get('retired_lease') and
            (j.get('stop_confirmed') is False or j.get('stop_observation_pending') or j.get('requires_idle_reconcile'))]
        if not pending:return
        pods=await self.backend.provider.listed_pods();by_id={p['id']:p for p in pods}
        for job in pending:
            pod_id=job.get('pod_id')
            if not pod_id:
                url=job.get('remote_pod_url','')
                if POD_URL.fullmatch(url):pod_id=url.split('://',1)[1].split('-8188.',1)[0]
            if not pod_id:raise ValueError('ยังระบุ Pod ของงานเก่าไม่ได้')
            if pod_id in by_id and by_id[pod_id].get('desiredStatus') not in ('EXITED','STOPPED'):
                raise ValueError('Pod เก่ายังทำงานอยู่ ต้องหยุดก่อนเริ่มเครื่องใหม่')
            job.update(retired_lease=True,old_provider_state='stopped' if pod_id in by_id else 'absent')
            self.persist(job)

    async def reconcile_direct_sessions(self):
        """Retire failures only after a different remote boot verifies its idle queue.

        Never changes historical status or stop_confirmed. A missing previous
        instance may be recovered only from the authenticated remote job record.
        """
        pending=[j for j in self.jobs.values() if not j.get('automatic_lease')
                 and not j.get('retired_lease') and
                 (j.get('stop_confirmed') is False or j.get('requires_idle_reconcile')
                  or j.get('stop_observation_pending'))]
        if not pending or self.backend.provider.config().get('enabled'):
            return False
        connection=self.data/'pod-connection.json'
        if not connection.is_file():return False
        settings=json.loads(connection.read_text(encoding='utf-8'))
        url=settings['url'].rstrip('/')
        remote=Remote(settings)
        try:
            await remote.open();status=await remote.request('GET','/status')
            current=status.get('instance_id')
            if (status.get('system_version')!=SYSTEM_VERSION or not isinstance(current,str)
                    or not re.fullmatch(r'[a-f0-9]{32}',current)):
                return False
            candidates=[]
            for prior in pending:
                previous=prior.get('remote_instance_id')
                bound_url=prior.get('remote_pod_url')
                # This recovers a pre-upgrade record without inventing its boot.
                historical=next((item for item in status.get('jobs',[]) if
                    isinstance(item,dict) and item.get('id')==prior.get('remote_id')
                    and prior.get('remote_id')),None)
                if historical and (not previous or not bound_url):
                    observed=historical.get('instance_id')
                    if previous and previous!=observed:continue
                    previous=observed;bound_url=url
                if (not isinstance(previous,str) or not re.fullmatch(r'[a-f0-9]{32}',previous)
                        or previous==current or bound_url!=url):
                    continue
                candidates.append((prior,previous))
            if not candidates:return False
            response=await remote.request('POST','/session',
                {'job_id':secrets.token_hex(16),'instance_id':current})
            if (response.get('ok') is not True or response.get('instance_id')!=current
                    or response.get('provider_stop_verified') is not False):
                raise ValueError('Idle session acknowledgment does not match current remote boot')
            for prior,previous in candidates:
                prior.update(requires_idle_reconcile=False,retired_lease=True,stop_observation_pending=False,
                    remote_instance_id=previous,remote_pod_url=url,
                    reconciled_remote_instance_id=current,previous_session_reconciled=True,
                    message='ตรวจรอบใหม่และคิวว่างแล้ว เก็บข้อผิดพลาดรอบเดิมไว้; ไม่ได้ยืนยันว่าค่าเช่ารอบเดิมหยุด')
                self.persist(prior)
            return True
        finally:await remote.close()

    async def observe_remote_stop(self,remote,job,*,timeout_seconds=60,poll_seconds=2):
        """Read only after ACK; disappearing HTTP is never proof of provider stop."""
        if not 0<timeout_seconds<=60 or not 0<=poll_seconds<=5:
            raise ValueError('Stop observation must be bounded to 60 seconds')
        expected=job.get('remote_instance_id')
        job.update(status='stopping',stage='stopping',stop_confirmed=None,
                   stop_observation_pending=True,
                   message='เก็บวิดีโอและหลักฐานครบแล้ว กำลังรอผลการหยุด GPU จาก Pod')
        self.persist(job)
        reason='observation_deadline'
        deadline=time.monotonic()+timeout_seconds
        if not isinstance(expected,str) or not re.fullmatch(r'[a-f0-9]{32}',expected):
            reason='missing_remote_instance'
        else:
            while time.monotonic()<deadline:
                remaining=deadline-time.monotonic()
                if remaining<=0:break
                try:
                    status=await asyncio.wait_for(remote.request('GET','/status'),timeout=min(15,remaining))
                except (ValueError,ClientError,asyncio.TimeoutError,OSError):
                    reason='status_connection_unconfirmed';break
                if (not isinstance(status,dict) or status.get('system_version')!=SYSTEM_VERSION
                        or status.get('instance_id')!=expected or not isinstance(status.get('jobs'),list)):
                    reason='remote_instance_or_status_mismatch';break
                matches=[row for row in status['jobs'] if isinstance(row,dict)
                         and row.get('id')==job.get('remote_id')]
                if len(matches)!=1 or matches[0].get('instance_id')!=expected:
                    reason='remote_job_mismatch';break
                current=matches[0]
                if current.get('stop_confirmed') is True and current.get('status') in ('completed','failed'):
                    job.update(status='completed',stage='completed',stop_confirmed=True,
                               stop_observation_pending=False,
                               message='บันทึกวิดีโอและหลักฐานลง PC แล้ว และ Pod ยืนยันสถานะหยุด GPU จากผู้ให้บริการ')
                    job.pop('stop_error',None);job.pop('stop_observation_error',None)
                    self.persist(job);return True
                if current.get('stop_confirmed') is False and current.get('status') in ('stop_failed','failed','interrupted'):
                    job.update(status='stop_failed',stage='stop_failed',stop_confirmed=False,
                               stop_error=stop_error_summary(current.get('stop_error')),
                               stop_observation_error='remote_stop_failed',
                               message='เก็บวิดีโอและหลักฐานครบแล้ว แต่ Pod รายงานว่ายังหยุด GPU ไม่สำเร็จ กรุณาตรวจและ Stop Pod')
                    self.persist(job);return False
                if current.get('status') not in ('ready','stopping','running'):
                    reason='remote_stop_state_unconfirmed';break
                await asyncio.sleep(min(poll_seconds,max(0,deadline-time.monotonic())))
        job.update(status='stop_failed',stage='stop_failed',stop_observation_error=reason,
                   message='เก็บวิดีโอและหลักฐานครบแล้ว แต่ยังยืนยันการหยุด GPU ไม่ได้ การขาดการเชื่อมต่อไม่ใช่หลักฐานว่าหยุดแล้ว กรุณาตรวจและ Stop Pod')
        self.persist(job)
        return False

    async def run_remote(self,job,image,video,duration):
        remote=None
        started=False; saved=False; evidence_saved=False
        provider=self.backend.provider
        managed=job.get('automatic_lease',False)
        fresh=managed and provider.config().get('mode') in ('fresh','manual_owned')
        try:
            keep_awake(True)
            if not fresh:
                settings=json.loads((self.data/'pod-connection.json').read_text(encoding='utf-8'))
                remote=Remote(settings)
            if managed:
                def lease_progress(row):
                    job.update(pod_id=row['pod_id'],lease_deadline=row['deadline'],fresh_pod=fresh,
                        message='กำลังสร้าง Pod ใหม่และเตรียมโมเดล' if fresh else 'กำลังเปิด GPU และรอระบบพร้อม')
                    self.persist(job)
                row=await provider.acquire(job['id'],lease_progress)
                if fresh:
                    settings=json.loads((self.data/'pod-connection.json').read_text(encoding='utf-8'))
                    remote=Remote(settings)
                job['status']='starting_gpu';self.persist(job)
                ready_deadline=min(row['deadline']-(3600 if fresh else 120),time.time()+(3600 if fresh else 600))
                while time.time()<ready_deadline:
                    self.persist(job) # Keep independent PC guard alive during downloads.
                    try:
                        await remote.open()
                        readiness=await remote.request('GET','/status')
                        if fresh and readiness.get('bootstrap_failed'):
                            raise BootstrapFailed('การเตรียมโมเดลหรือระบบบน Pod ใหม่ล้มเหลว กำลังหยุดและ Terminate เครื่อง')
                        if fresh and readiness.get('bootstrap_phase'):
                            job.update(message=readiness.get('message','กำลังเตรียม Pod'));self.persist(job)
                        if readiness.get('ready') and readiness.get('system_version')==SYSTEM_VERSION:
                            if fresh and readiness.get('cleanup_owner')!='pc':raise ValueError('Pod ไม่ใช่รุ่น PC ควบคุม Terminate')
                            break
                        raise ValueError('ชุดบน Pod ยังไม่พร้อม')
                    except BootstrapFailed:raise
                    except Exception:
                        await remote.close();await asyncio.sleep(5)
                else:raise ValueError('Pod เริ่มระบบไม่ทันเวลา ระบบกำลังหยุด GPU')
                await remote.request('POST','/lease',{'job_id':job['id'],'pod_id':row['pod_id'],
                    **({'mode':'fresh','nonce':row['nonce']} if fresh else {'previously_stopped':True})})
            else:
                await remote.open()
                # Verify no accepted GPU job remains before retiring records from
                # a prior service boot. No provider-stop claim is inferred.
                readiness=await remote.request('GET','/status')
                if readiness.get('system_version')!=SYSTEM_VERSION:
                    raise ValueError('ต้องอัปเดตระบบสร้างฉากใหม่บน Pod ก่อนเริ่มงาน')
                await remote.request('POST','/session',{'job_id':job['id'],'instance_id':readiness.get('instance_id')})
            job.update(remote_instance_id=readiness.get('instance_id'),
                       remote_pod_url=settings['url'].rstrip('/'))
            self.persist(job)
            ids={}
            for record in (image,video):
                with (self.backend.inputs/record['file']).open('rb') as file:
                    uploaded=await remote.request('POST','/upload/'+record['kind'],data=file)
                ids[record['kind']]=uploaded['id']
            allowance=min(7200,int(job.get('lease_deadline',time.time()+7440)-time.time()-240))
            if allowance<600:raise ValueError('เวลาเช่าที่เหลือไม่เพียงพอสำหรับสร้างวิดีโอ')
            if fresh:provider.before_submit(job['id'])
            remote_job=await remote.request('POST','/jobs',{**ids,'duration':duration,'runtime_limit_seconds':allowance})
            started=True;job['remote_id']=remote_job['id'];job['plan']=remote_job['plan']
            self.persist(job)
            deadline=time.monotonic()+min(7500,max(0,job.get('lease_deadline',time.time()+7500)-time.time()-60))
            while time.monotonic()<deadline:
                status=await remote.request('GET','/status')
                current=next((j for j in status['jobs'] if j['id']==job['remote_id']),None)
                if not current: raise ValueError('ไม่พบงานบน Pod')
                job.update(status=current['status'],message=current['message'],stop_confirmed=current.get('stop_confirmed'))
                for key in ('stage','progress','plan','quality_review_pending','visual_quality_verified',
                            'error_stage','error_message','reference_analysis','output_sha256','stop_error',
                            'analysis_diagnostics','generation_warnings','failure_stage'):
                    if key in current:job[key]=current[key]
                if isinstance(current.get('scene_analysis'),dict):
                    job['scene_analysis']=current['scene_analysis']
                if current.get('result') and not saved:
                    if fresh and not re.fullmatch(r'[a-f0-9]{64}',str(current.get('output_sha256',''))):
                        raise ValueError('Pod ไม่ส่ง SHA256 ของวิดีโอครบ จึงยังไม่ยืนยันการรับไฟล์')
                    job.update(stage='downloading',message='กำลังบันทึกวิดีโอลง PC และตรวจไฟล์');self.persist(job)
                    path=self.backend.outputs/(job['id']+'.mp4');temp=path.with_suffix('.part')
                    # Stream to disk, flush, then ACK. The Pod will stop only after this.
                    async with remote.session.get(remote.base+'/jobs/'+job['remote_id']+'/result') as response:
                        if response.status!=200: raise ValueError('รับผลลัพธ์จาก Pod ไม่สำเร็จ')
                        count=0
                        with temp.open('wb') as file:
                            async for chunk in response.content.iter_chunked(1024*1024):
                                count+=len(chunk)
                                if count>512*1024*1024: raise ValueError('ผลลัพธ์ใหญ่เกินกำหนด')
                                file.write(chunk)
                            file.flush();os.fsync(file.fileno())
                    if count<1024: raise ValueError('ไฟล์ผลลัพธ์ไม่ครบ')
                    if current.get('output_sha256'):
                        if hashlib.sha256(temp.read_bytes()).hexdigest()!=current['output_sha256']:
                            raise ValueError('ไฟล์ที่ดาวน์โหลดไม่ตรงกับผลบน Pod จึงยังไม่ยืนยันการรับไฟล์')
                    await asyncio.to_thread(verify_result,temp,job['plan'])
                    os.replace(temp,path);job['result']=path.name;saved=True;self.persist(job)
                    # All compatible v5 full-generation jobs require evidence.
                    # A video alone is retained, but is not a completed handoff.
                    job.update(evidence_download_status='downloading');self.persist(job)
                    try:
                        if (not isinstance(current.get('evidence_sha256'),str)
                                or not re.fullmatch(r'[a-f0-9]{64}',current['evidence_sha256'])
                                or type(current.get('evidence_bytes')) is not int
                                or not 0<current['evidence_bytes']<=72*1024*1024):
                            raise ValueError('Pod ไม่ส่งขนาดและ SHA256 ของหลักฐาน workflow ครบ จึงยังไม่ยืนยันการรับงาน')
                        evidence_path=self.backend.outputs/(job['id']+'.evidence.zip')
                        evidence_temp=evidence_path.with_suffix('.part')
                        digest=hashlib.sha256();proof_bytes=0
                        try:
                            async with remote.session.get(remote.base+'/jobs/'+job['remote_id']+'/evidence') as response:
                                if response.status!=200:raise ValueError('รับหลักฐาน workflow ไม่สำเร็จ')
                                with evidence_temp.open('wb') as proof_file:
                                    async for chunk in response.content.iter_chunked(1024*1024):
                                        proof_bytes+=len(chunk)
                                        if proof_bytes>72*1024*1024:raise ValueError('หลักฐานงานมีขนาดเกินกำหนด')
                                        proof_file.write(chunk);digest.update(chunk)
                                    proof_file.flush();os.fsync(proof_file.fileno())
                            if digest.hexdigest()!=current['evidence_sha256'] or proof_bytes!=current.get('evidence_bytes'):
                                raise ValueError('หลักฐานงานที่ดาวน์โหลดไม่ตรงกับไฟล์บน Pod')
                            os.replace(evidence_temp,evidence_path)
                            evidence_saved=True
                            job.update(evidence_file=evidence_path.name,evidence_sha256=digest.hexdigest(),
                                evidence_bytes=proof_bytes,evidence_download_status='verified')
                            self.persist(job)
                        finally:evidence_temp.unlink(missing_ok=True)
                    except Exception as error:
                        job.update(evidence_download_status='failed',
                            evidence_download_error=str(error) if isinstance(error,ValueError) else
                                'การดาวน์โหลดหลักฐาน workflow ขัดข้อง')
                        self.persist(job)
                        raise
                    # A successful result copy is not evidence that provider billing stopped.
                    if fresh:provider.record_handoff(job['id'],job['result'],job['evidence_file'])
                    await remote.request('POST','/jobs/'+job['remote_id']+'/release',{})
                    job.update(status='completed',stage='completed',render_status='completed',stop_confirmed=None,
                               message='เก็บวิดีโอบน PC แล้ว ระบบบน Pod กำลังส่งคำสั่งหยุด GPU; ยังไม่ยืนยันสถานะจากผู้ให้บริการ')
                    self.persist(job)
                    if not managed:
                        await self.observe_remote_stop(remote,job)
                    return
                self.persist(job)
                if current['status'] in ('failed','stop_failed','completed','interrupted'):
                    if fresh and current.get('instance_id')==job.get('remote_instance_id'):
                        provider.record_no_result(job['id'],current)
                    return
                await asyncio.sleep(4)
            raise ValueError('หมดเวลารอผลลัพธ์ กรุณาตรวจ Pod')
        except Exception as error:
            complete=saved and evidence_saved
            job.setdefault('error_message',str(error) if isinstance(error,ValueError) else
                'ติดต่อ Pod ขัดข้อง กรุณาตรวจสถานะ GPU')
            job.setdefault('failure_stage',job.get('stage') or
                ('pod_allocation' if managed and not started else job.get('status','unknown')))
            if fresh:
                row=provider.lease()
                if row.get('job_id')==job['id'] and row.get('create_error_message'):
                    job.update(create_error_message=row['create_error_message'],
                        create_error_http_status=row.get('create_error_http_status'))
            job.update(status='completed' if complete else 'failed',stage='completed' if complete else 'failed',
                       message=('เก็บวิดีโอแล้ว แต่หลักฐาน workflow ยังไม่ครบ จึงยังไม่ยืนยันการรับงาน: '+
                                job.get('evidence_download_error','กรุณาตรวจ Pod และดาวน์โหลดหลักฐานอีกครั้ง'))
                               if saved and not evidence_saved else
                               'เก็บวิดีโอและหลักฐานครบแล้ว แต่ขาดการเชื่อมต่อขณะหยุด GPU กรุณาตรวจ Pod ทันที' if complete else
                               (str(error) if isinstance(error,ValueError) else 'ติดต่อ Pod ขัดข้อง กรุณาตรวจสถานะ GPU'),
                       stop_confirmed=False if started else None)
        finally:
            (self.backend.outputs/(job['id']+'.part')).unlink(missing_ok=True)
            if managed and provider.lease().get('job_id')==job['id']:
                job.update(status='stopping',stage='stopping',message='กำลังหยุด GPU หลังบันทึกผล' if saved else 'กำลังหยุด GPU หลังงานขัดข้อง')
                self.persist(job)
                confirmed=False
                for i in range(3):
                    confirmed=await provider.stop_owned(job['id'])
                    if confirmed:break
                    await asyncio.sleep(3)
                job['stop_confirmed']=confirmed
                if fresh:
                    row=provider.lease();job['terminate_confirmed']=confirmed
                    job['gpu_stop_confirmed']=bool(row.get('gpu_stop_confirmed') or confirmed)
                    job['cleanup_state']=row.get('state')
                    job['cleanup_error']=row.get('last_error') if not confirmed else None
                job['status']=('completed' if saved and evidence_saved else 'failed') if confirmed else 'stop_failed'
                job['stage']=job['status']
                if confirmed:
                    job['message']=('บันทึกวิดีโอและหลักฐานลง PC แล้ว และ RunPod ยืนยันสถานะหยุด GPU'
                        if saved and evidence_saved else
                        'เก็บวิดีโอแล้ว แต่หลักฐาน workflow ยังไม่ครบ; RunPod ยืนยันสถานะหยุด GPU แล้ว'
                        if saved else 'งานไม่สำเร็จ แต่ RunPod ยืนยันสถานะหยุด GPU แล้ว')
                else:
                    job['message']=('เก็บวิดีโอแล้ว แต่หลักฐาน workflow ยังไม่ครบ; ' if saved and not evidence_saved else '')+'ยังยืนยันการหยุด GPU ไม่ได้ ระบบบล็อกงานใหม่และจะลองหยุดซ้ำ กรุณาตรวจ Pod'
                if fresh:
                    job['message']=('บันทึกวิดีโอและหลักฐานลง PC แล้ว และยืนยัน Terminate Pod สำเร็จ' if saved and evidence_saved else
                        'งานไม่สำเร็จ และยืนยัน Terminate Pod สำเร็จ') if confirmed else (provider.lease().get('last_error') or 'ยังยืนยัน Terminate ไม่ได้ กรุณาตรวจ Pod')
                    if row.get('state')=='create_rejected':
                        job.update(terminate_confirmed=False,gpu_stop_confirmed=False,
                            message=row.get('last_error','RunPod ปฏิเสธการสร้าง เครื่องยังไม่เริ่มเช่า'))
            self.persist(job)
            if remote:await remote.close()
            keep_awake(False)

    async def monitor_leases(self):
        while True:
            try:
                if not self.task or self.task.done():
                    row=self.backend.provider.lease()
                    if row.get('cleanup_pending'):
                        if (row.get('allocation_source')=='user' and row.get('state')=='awaiting_input'
                            and time.time()<row.get('deadline',0) and time.time()-row.get('heartbeat_at',0)<300):
                            await asyncio.sleep(30);continue
                        confirmed=await self.backend.provider.reconcile()
                        job=self.jobs.get(row.get('job_id'))
                        if confirmed and job:
                            complete=bool(job.get('result') and job.get('evidence_download_status')=='verified')
                            job.update(stop_confirmed=True,status='completed' if complete else 'failed',
                                       message=('เก็บวิดีโอแล้ว แต่หลักฐาน workflow ยังไม่ครบ; '
                                                if job.get('result') and not complete else '')+'RunPod ยืนยันสถานะหยุด GPU แล้ว')
                            self.persist(job)
                            if row.get('mode')=='fresh':
                                job.update(terminate_confirmed=True,gpu_stop_confirmed=True,cleanup_state='terminated',
                                    message='ยืนยัน Terminate Pod ของงานนี้แล้ว; ไฟล์ที่บันทึกบน PC ยังอยู่')
                                self.persist(job)
            except Exception:pass
            await asyncio.sleep(30)

    async def evidence(self,request):
        self.authorize(request)
        job=self.jobs.get(request.match_info['id'])
        if not job or not job.get('evidence_file'):raise web.HTTPNotFound()
        path=(self.backend.outputs/job['evidence_file']).resolve()
        if not path.is_relative_to(self.backend.outputs.resolve()) or not path.is_file():raise web.HTTPNotFound()
        return web.FileResponse(path,headers={'Content-Type':'application/zip'})

    def routes(self):
        routes=super().routes()
        routes.post('/motion-studio/api/connection')(self.configure)
        routes.post('/motion-studio/api/automation')(self.configure_auto)
        routes.post('/motion-studio/api/account-key')(self.save_key)
        routes.post('/motion-studio/api/allocation/resolve')(self.resolve_allocation)
        routes.post('/motion-studio/api/manual/setup')(self.prepare_manual)
        routes.get('/motion-studio/api/manual/setup')(self.read_manual)
        return routes
