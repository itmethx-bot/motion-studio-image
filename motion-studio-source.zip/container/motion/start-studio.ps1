$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$pythonPath = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'Motion Studio Python environment is missing.' }
$dataRoot = Join-Path $projectRoot 'private-data'
New-Item -ItemType Directory -Force -Path $dataRoot | Out-Null
$probe = [System.Net.Sockets.TcpClient]::new()
try { $probe.Connect('127.0.0.1',8767); throw 'Port 8767 is already in use.' } catch [System.Net.Sockets.SocketException] { } finally { $probe.Dispose() }
$process = Start-Process -FilePath $pythonPath -ArgumentList @('-X','utf8',('"' + (Join-Path $projectRoot 'preview_server.py') + '"'),'--port','8767') -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $dataRoot 'server.log') -RedirectStandardError (Join-Path $dataRoot 'server-error.log')
@{pid=$process.Id;port=8767;startedUtc=$process.StartTime.ToUniversalTime().ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $dataRoot 'server-process.json') -Encoding UTF8
Write-Host 'Motion Studio: http://127.0.0.1:8767/motion-studio/'
