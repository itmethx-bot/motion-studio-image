"""Immutable scene provenance and exact target contracts; no writes or runtime calls."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path


IMPLEMENTATION_FILES=('fullgen_graph.py','graph.py','scene_core.py','fullgen_nodes.py',
                      'nodes.py','fullgen_smoke.py','fullgen_preflight.py','fullgen_reuse.py','clip_duration.py')


def fingerprint(path):
    path=Path(path)
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
    return dict(bytes=path.stat().st_size,sha256=digest.hexdigest())


def evidence_file(path):
    path=Path(path)
    if not path.is_dir():return path
    direct=path/'result.json'
    if direct.exists():return direct
    candidates=sorted(child/'result.json' for child in path.iterdir()
                      if child.is_dir() and (child/'result.json').is_file())
    if not candidates:
        raise ValueError('No result.json found in evidence directory or its immediate run directories: '+str(path))
    if len(candidates)!=1:
        raise ValueError('Multiple run results; select an explicit run directory or result.json: '
                         +', '.join(str(item.parent) for item in candidates))
    return candidates[0]


def read_completed(path,phase):
    path=evidence_file(path)
    result=json.loads(path.read_text(encoding='utf-8'))
    if (not isinstance(result,dict) or result.get('success') is not True
            or result.get('execution_completed') is not True or result.get('phase')!=phase):
        raise ValueError('Requires successfully completed '+phase+' evidence')
    return path,result


def input_binding(contract):
    required=('image','video','input_fingerprints')
    if not isinstance(contract,dict) or any(name not in contract for name in required):
        raise ValueError('Scene evidence lacks input provenance')
    binding={name:deepcopy(contract[name]) for name in required}
    if not isinstance(binding['input_fingerprints'],dict):
        raise ValueError('Scene evidence lacks input fingerprints')
    for name in (binding['image'],binding['video']):
        item=binding['input_fingerprints'].get(name)
        if not isinstance(item,dict) or not item.get('sha256') or not isinstance(item.get('bytes'),int):
            raise ValueError('Scene evidence lacks complete input fingerprints')
    return binding


def check_png(scene,comfy,plan):
    from PIL import Image
    if not isinstance(scene,dict) or not isinstance(scene.get('file'),str):
        raise ValueError('Evidence lacks the original approved scene PNG')
    path=Path(scene['file']).resolve()
    if (not path.is_relative_to((Path(comfy)/'output').resolve())
            or not path.is_file() or path.suffix.lower()!='.png'):
        raise ValueError('Approved PNG must exist inside this ComfyUI/output')
    if fingerprint(path)!={key:scene.get(key) for key in ('bytes','sha256')}:
        raise ValueError('Approved scene PNG bytes have changed')
    try:
        with Image.open(path) as image:
            size=list(image.size)
            actual_format=image.format
            image.verify()
    except (OSError,ValueError) as error:
        raise ValueError('Approved scene is not a valid PNG') from error
    if (actual_format!='PNG' or size!=scene.get('size')
            or size!=[plan['width'],plan['height']]):
        raise ValueError('Approved scene must have the same actual canvas dimensions; resizing is not permitted')
    return path


def source_scene(evidence,current_inputs,comfy,plan):
    path,result=read_completed(evidence,'scene')
    producer=result.get('review_contract')
    if input_binding(producer)!=input_binding(current_inputs):
        raise ValueError('Approved scene source media does not match current input bytes')
    scene=result.get('first_scene')
    approved=check_png(scene,comfy,plan)
    provenance=dict(source_evidence=str(path.resolve()),source_evidence_fingerprint=fingerprint(path),
                    producer_prompt_id=result.get('prompt_id'),producer_review_contract=deepcopy(producer),
                    original_scene=deepcopy(scene))
    return approved,deepcopy(scene),provenance


def checked_provenance(provenance,current_inputs,comfy,plan):
    if not isinstance(provenance,dict):raise ValueError('Missing original scene provenance')
    source=provenance.get('source_evidence')
    if not isinstance(source,str) or fingerprint(source)!=provenance.get('source_evidence_fingerprint'):
        raise ValueError('Original scene evidence has changed')
    path,scene,reconstructed=source_scene(source,current_inputs,comfy,plan)
    if reconstructed!=provenance:
        raise ValueError('Original scene provenance does not match its evidence')
    return path,scene


def validated_scene(evidence,current_inputs,comfy,plan):
    _,result=read_completed(evidence,'validate')
    if result.get('geometry_validation_completed') is not True:
        raise ValueError('Evidence lacks completed full-source geometry validation')
    provenance=result.get('scene_provenance')
    path,scene=checked_provenance(provenance,current_inputs,comfy,plan)
    # SaveImage may re-encode a validation preview. It is deliberately NOT the
    # approved asset: preserve the producer's original PNG and exact bytes.
    if result.get('approved_scene_input')!=scene:
        raise ValueError('Validation evidence does not bind the original approved PNG')
    return path,scene,deepcopy(provenance),result


def target_contract(graph,current_inputs,requested_seconds,plan,provenance,root=None):
    """Bind the FULL intended video graph before validation-only pruning."""
    root=Path(root) if root is not None else Path(__file__).resolve().parent
    normalized=deepcopy(graph)
    for node in normalized.values():
        if 'filename_prefix' in node['inputs']:node['inputs']['filename_prefix']='TARGET_OUTPUT'
    return dict(version=2,inputs=input_binding(current_inputs),requested_seconds=requested_seconds,
                plan=deepcopy(plan),scene_provenance=deepcopy(provenance),
                video_graph_sha256=hashlib.sha256(json.dumps(normalized,sort_keys=True).encode()).hexdigest(),
                implementation_sha256={name:fingerprint(root/name)['sha256'] for name in IMPLEMENTATION_FILES})


def require_target(record,contract):
    if record.get('target_contract')!=contract:
        raise ValueError('Validated target does not match current inputs, PNG, duration, FPS, canvas, chunks, sampling, reference mode or code; rerun --phase validate')
