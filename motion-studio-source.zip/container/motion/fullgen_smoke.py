"""Run one scene or reviewed video test on the local ComfyUI server.

The observer has a deadline. On timeout only this prompt's pending queue entry
can be deleted safely; a running GPU job may still need manual stop. Evidence
never certifies visual quality. Video requires review of a matching scene run.
"""
import argparse
import datetime
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import shutil
import sys
import time
import types
import urllib.request
import urllib.error
import uuid

if __package__:
    from . import fullgen_preflight as preflight
    from . import fullgen_reuse as reuse
else:
    import fullgen_preflight as preflight
    import fullgen_reuse as reuse

COMFY=Path('/workspace/runpod-slim/ComfyUI')

def request(path,data=None,timeout=15):
    req=urllib.request.Request('http://127.0.0.1:8188'+path,
        data=None if data is None else json.dumps(data).encode(),
        headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)
    except urllib.error.HTTPError as e:
        raise RuntimeError(e.read().decode(errors='replace')) from e

def inputs_from_saved_workflow():
    return preflight.inputs_from_saved_workflow(COMFY)


def cancel_own_pending_prompt(prompt_id):
    """Delete only our pending ID. A global interrupt could affect another job.

    A running job may remain active after the bounded observer exits. Report
    this honestly instead of pretending an unscoped /interrupt is safe.
    """
    report=dict(prompt_id=prompt_id, pending_delete_requested=False,
                cancellation_confirmed=False, running_state_unknown=True)
    try:
        queue=request('/queue')
        if 'error' in preflight.inspect_queue(queue):
            raise ValueError('Invalid /queue response during cleanup')
        owns=lambda rows:any(isinstance(row,(list,tuple)) and len(row)>1
                             and row[1]==prompt_id for row in rows)
        if owns(queue['queue_pending']):
            request('/queue',{'delete':[prompt_id]})
            report['pending_delete_requested']=True
            queue=request('/queue')
            if 'error' in preflight.inspect_queue(queue):
                raise ValueError('Invalid /queue response after pending deletion')
        running=owns(queue['queue_running'])
        pending=owns(queue['queue_pending'])
        report.update(running_state_unknown=False, own_prompt_running=running,
                      own_prompt_pending=pending,
                      cancellation_confirmed=report['pending_delete_requested'] and not running and not pending)
        report['manual_stop_may_be_needed']=running or pending
    except Exception as error:
        report.update(error=str(error),manual_stop_may_be_needed=True)
    return report


def failed_observation(evidence,prompt_id,reason):
    result=dict(success=False,prompt_id=prompt_id,error=reason,
                quality_review_pending=True,gpu_quality_verified=False,
                cleanup=cancel_own_pending_prompt(prompt_id))
    preflight.write_report(evidence/'result.json',result)
    print('INCOMPLETE',json.dumps(result,ensure_ascii=False),flush=True)
    return 1


def file_fingerprint(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            digest.update(chunk)
    return {'sha256':digest.hexdigest(),'bytes':Path(path).stat().st_size}


def review_contract(graph,comfy,image,video,seconds,seed):
    """Bind operator review to media bytes, scene settings and planner code."""
    scene=preflight.graph_module().prune_scene_graph(graph)
    for node in scene.values():
        if 'filename_prefix' in node['inputs']:
            node['inputs']['filename_prefix']='REVIEW_OUTPUT'
    video_graph=deepcopy(graph)
    for node in video_graph.values():
        if 'filename_prefix' in node['inputs']:
            node['inputs']['filename_prefix']='REVIEW_OUTPUT'
    root=Path(__file__).resolve().parent
    return dict(image=image,video=video,requested_seconds=seconds,seed=seed,
        input_fingerprints={name:file_fingerprint(preflight.resolve_input(comfy,name))
                            for name in (image,video)},
        scene_graph_sha256=hashlib.sha256(json.dumps(scene,sort_keys=True).encode()).hexdigest(),
        video_graph_sha256=hashlib.sha256(json.dumps(video_graph,sort_keys=True).encode()).hexdigest(),
        implementation_sha256={name:file_fingerprint(root/name)['sha256']
            for name in ('fullgen_graph.py','fullgen_nodes.py','anatomy_reference.py','scene_core.py','graph.py','nodes.py')})


def output_scene_record(history,comfy,plan):
    """Identify the generated scene specifically, never a diagnostic proof panel."""
    from PIL import Image
    entries=history.get('outputs',{}).get('scene_preview',{}).get('images',[])
    entries=[item for item in entries if isinstance(item,dict) and item.get('type')=='output']
    if len(entries)!=1:
        raise ValueError('Completed scene must identify exactly one scene_preview output image')
    item=entries[0]
    output_root=(Path(comfy)/'output').resolve()
    path=(output_root/item.get('subfolder','')/item['filename']).resolve()
    if not path.is_relative_to(output_root) or not path.is_file() or path.suffix.lower()!='.png':
        raise ValueError('Scene preview must be a PNG inside ComfyUI/output')
    with Image.open(path) as image:
        size=list(image.size)
        image.verify()
    if size!=[plan['width'],plan['height']]:
        raise ValueError('Scene preview dimensions differ from the generation plan')
    return dict(file=str(path),size=size,**file_fingerprint(path))


def validate_reviewed_scene(evidence_path,contract,comfy,plan):
    """Read evidence only; the caller must separately assert visual review."""
    evidence=Path(evidence_path)
    if evidence.is_dir():
        direct=evidence/'result.json'
        if direct.exists():
            evidence=direct
        else:
            # --evidence-dir contains one directory per run. Never infer the
            # reviewed run from timestamps or skip failed/mismatching results.
            candidates=sorted(child/'result.json' for child in evidence.iterdir()
                              if child.is_dir() and (child/'result.json').is_file())
            if not candidates:
                raise ValueError('No scene result.json found in evidence directory or its immediate run directories: '
                                 +str(evidence))
            if len(candidates)!=1:
                raise ValueError('Multiple run results found; select the reviewed scene run explicitly with '
                                 '--reviewed-scene-evidence <run-directory-or-result.json>: '
                                 +', '.join(str(path.parent) for path in candidates))
            evidence=candidates[0]
    result=json.loads(evidence.read_text(encoding='utf-8'))
    if result.get('success') is not True or result.get('phase')!='scene':
        raise ValueError('Video requires evidence from a successfully completed scene-only run')
    if result.get('review_contract')!=contract:
        raise ValueError('Reviewed scene does not match current media bytes, seed, duration, settings or implementation')
    scene=result.get('first_scene')
    if not isinstance(scene,dict) or not isinstance(scene.get('file'),str):
        raise ValueError('Evidence does not contain the generated first-scene fingerprint')
    path=Path(scene['file']).resolve()
    if not path.is_relative_to((Path(comfy)/'output').resolve()) or not path.is_file():
        raise ValueError('Reviewed scene must still exist inside this ComfyUI/output')
    if path.suffix.lower()!='.png' or scene.get('size')!=[plan['width'],plan['height']]:
        raise ValueError('Reviewed scene format or dimensions do not match')
    if file_fingerprint(path)!={key:scene.get(key) for key in ('sha256','bytes')}:
        raise ValueError('Reviewed scene image bytes have changed')
    return path,scene


def use_reviewed_scene(graph,path,scene,comfy):
    """Stage the reviewed PNG and keep only ancestors of the requested outputs."""
    input_root=(Path(comfy)/'input').resolve()
    relative='fullgen-reviewed-'+scene['sha256']+'.png'
    destination=(input_root/relative).resolve()
    if not destination.is_relative_to(input_root):
        raise ValueError('Reviewed-scene staging path escapes ComfyUI/input')
    destination.parent.mkdir(parents=True,exist_ok=True)
    if not destination.exists():
        shutil.copyfile(path,destination)
    if file_fingerprint(destination)!={key:scene[key] for key in ('sha256','bytes')}:
        raise ValueError('Staged reviewed scene does not match the approved bytes')
    graph=deepcopy(graph)
    # A saved high-resolution Qwen master is a scene-generation output only.
    # Retaining it here would keep Qwen alive despite loading a reviewed PNG.
    graph.pop('qwen_master_preview',None)
    graph['generated_scene']={'class_type':'LoadImage','inputs':{'image':relative}}
    needed=set()
    def visit(key):
        if key in needed:return
        if key not in graph:raise ValueError('Missing graph ancestor: '+key)
        needed.add(key)
        for value in graph[key]['inputs'].values():
            if isinstance(value,list) and len(value)==2 and isinstance(value[0],str) and isinstance(value[1],int):
                visit(value[0])
    for key,node in graph.items():
        if node['class_type'] in ('SaveImage','SaveVideo','MotionSceneReport'):
            visit(key)
    return {key:node for key,node in graph.items() if key in needed}

def run(args):
    if args.phase not in ('scene','validate','video'):
        raise ValueError('Phase must be scene, validate or video')
    if not math.isfinite(args.seconds) or not 0<args.seconds<=10.25:
        raise ValueError('Bounded smoke duration must be greater than 0 and at most 10.25 seconds (bounded latent overrun for final trimming)')
    if not math.isfinite(args.timeout_minutes) or not 0<args.timeout_minutes<=120:
        raise ValueError('Observer timeout must be greater than 0 and at most 120 minutes')
    reviewed_evidence=getattr(args,'reviewed_scene_evidence',None)
    validated_evidence=getattr(args,'validated_video_evidence',None)
    if args.phase=='video' and (not getattr(args,'approve_video_after_review',False)
                                or bool(reviewed_evidence)==bool(validated_evidence)):
        raise ValueError('Video requires --approve-video-after-review and --reviewed-scene-evidence from a matching scene-only run')
    if args.phase=='validate' and (not reviewed_evidence or validated_evidence):
        raise ValueError('Validate requires --reviewed-scene-evidence from the original scene run')
    if args.phase!='video' and validated_evidence:
        raise ValueError('--validated-video-evidence is only used for the video phase')
    import av
    package=types.ModuleType('motion_fullgen_test')
    package.__path__=[str(Path(__file__).resolve().parent)]
    sys.modules[package.__name__]=package
    from motion_fullgen_test.fullgen_graph import build_fullgen_graph,prune_scene_graph
    comfy=Path(getattr(args,'comfy_root',None) or COMFY)
    image,video=preflight.select_inputs(comfy,getattr(args,'image',None),getattr(args,'video',None))
    meta,reference_size=preflight.media_metadata(comfy,image,video)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
    job='fullgen-'+args.phase+'-'+stamp+'-'+uuid.uuid4().hex[:8]
    evidence=Path(getattr(args,'evidence_dir',None) or '/workspace')/job
    evidence.mkdir(parents=True)
    graph,plan=build_fullgen_graph(image,video,meta,duration=args.seconds,seed=args.seed,
        job_id=job,reference_size=reference_size,
        action_description=getattr(args,'action_description',''),
        garment_sequence=getattr(args,'garment_sequence',''),**preflight.graph_options(args))
    if args.scene_prompt_file:
        scene_prompt=Path(args.scene_prompt_file).read_text(encoding='utf-8').strip()
        if not scene_prompt or len(scene_prompt)>12000:raise ValueError('Invalid scene prompt override')
        graph['qwen_positive']['inputs']['prompt']=scene_prompt
        (evidence/'scene-prompt.txt').write_text(scene_prompt,encoding='utf-8')
    if args.base_qwen:
        graph['qwen_model']['inputs']['model']=['qwen_unet',0]
        graph['qwen_sample']['inputs'].update(steps=20,cfg=4.)
    if args.photo_first:
        if not args.scene_prompt_file:raise ValueError('Photo-first comparison needs a matching prompt file')
        for key in ('qwen_positive','qwen_negative'):
            graph[key]['inputs'].update(image1=['reference_size',0],image2=['scene',1],image3=['qwen_layout_scaled',0])
    for key,slot in [('layout',0),('appearance',1),('clean-room',10),('identities',11)]:
        graph['proof_'+key]={'class_type':'SaveImage','inputs':{'images':['scene',slot],
            'filename_prefix':'motion-studio/'+job+'-'+key}}
    contract=review_contract(graph,comfy,image,video,args.seconds,args.seed)
    reviewed_scene=None
    scene_provenance=None
    target=None
    validation_record=None
    if args.phase=='validate':
        reviewed_path,reviewed_scene,scene_provenance=reuse.source_scene(reviewed_evidence,contract,comfy,plan)
    elif args.phase=='video':
        if validated_evidence:
            reviewed_path,reviewed_scene,scene_provenance,validation_record=reuse.validated_scene(
                validated_evidence,contract,comfy,plan)
        else:
            reviewed_path,reviewed_scene=validate_reviewed_scene(reviewed_evidence,contract,comfy,plan)
    if args.phase in ('validate','video'):
        graph=use_reviewed_scene(graph,reviewed_path,reviewed_scene,comfy)
        plan.update(first_scene='Exact reviewed PNG loaded; Qwen scene generation removed from this video graph',
                    reviewed_first_scene_sha256=reviewed_scene['sha256'],
                    gpu_quality_verified=False)
        if scene_provenance is not None:
            target=reuse.target_contract(graph,contract,args.seconds,plan,scene_provenance)
            if validation_record is not None:reuse.require_target(validation_record,target)
        plan['operator_scene_review_asserted']=args.phase=='video'
    if args.phase in ('scene','validate'):
        full=graph
        graph=prune_scene_graph(graph)
        for key in ('proof_layout','proof_appearance','proof_clean-room','proof_identities'):graph[key]=full[key]
        if args.phase=='validate' and any(node['class_type'] in ('KSampler','SamplerCustom','WanSCAILToVideo') for node in graph.values()):
            raise ValueError('Validation graph unexpectedly includes diffusion/video generation')
    preflight.write_report(evidence/'prompt.json',graph)
    preflight.write_report(evidence/'plan.json',plan)
    preflight.write_report(evidence/'review-contract.json',contract)
    if target is not None:preflight.write_report(evidence/'target-contract.json',target)
    try:
        readiness=preflight.check_runtime(graph,reader=request)
    except Exception as error:
        readiness=dict(ready=False,errors=[str(error)],render_submitted=False,
                       gpu_quality_verified=False)
    readiness.update(inputs={'image':image,'video':video},source_metadata=meta,
                     reference_size=list(reference_size))
    preflight.write_report(evidence/'preflight.json',readiness)
    if not readiness['ready']:
        print('NOT_READY',json.dumps(readiness,ensure_ascii=False),flush=True)
        return 1
    # Recheck immediately before submitting; preflight is not a queue lock.
    q=preflight.inspect_queue(request('/queue'))
    if not q['empty']:
        preflight.write_report(evidence/'result.json',dict(success=False,render_submitted=False,
            gpu_quality_verified=False,error=q.get('error','Queue became busy before submission')))
        return 1
    submission=dict(prompt=graph,client_id=str(uuid.uuid4()))
    preflight.write_report(evidence/'submission-request.json',submission)
    try:
        result=request('/prompt',submission)
    except Exception as error:
        preflight.write_report(evidence/'result.json',dict(success=False,
            submission_outcome_unknown=True,error=str(error),gpu_quality_verified=False,
            next='Inspect ComfyUI queue and history; do not retry blindly'))
        raise
    preflight.write_report(evidence/'submission.json',result)
    pid=result.get('prompt_id')
    if not pid:raise RuntimeError('No accepted prompt: '+str(result))
    print('ACCEPTED',pid,'EVIDENCE',str(evidence),flush=True)
    deadline=time.monotonic()+args.timeout_minutes*60
    while time.monotonic()<deadline:
        try:
            data=request('/history/'+pid,timeout=max(.1,min(15,deadline-time.monotonic())))
        except Exception as error:
            return failed_observation(evidence,pid,'Could not observe prompt: '+str(error))
        if pid in data:
            record=data[pid]
            preflight.write_report(evidence/'history.json',record)
            state=record.get('status',{})
            if state.get('status_str')=='error':
                (evidence/'result.json').write_text(json.dumps({'success':False,'status':state,
                    'gpu_quality_verified':False},ensure_ascii=False,indent=2),encoding='utf-8')
                print('ERROR',json.dumps(state,ensure_ascii=False),flush=True);return 1
            if state.get('completed'):
                files=[]
                for value in record.get('outputs',{}).values():
                    for item in value.get('images',[])+value.get('videos',[]):
                        if isinstance(item,dict) and item.get('type')=='output':
                            p=(comfy/'output'/item.get('subfolder','')/item['filename']).resolve()
                            if p.is_relative_to((comfy/'output').resolve()) and p.is_file():files.append(str(p))
                videos=[path for path in (comfy/'output'/'motion-studio').glob(job+'*.mp4')
                        if path.resolve().is_relative_to((comfy/'output').resolve())]
                details=[]
                for path in videos:
                    count=0
                    with av.open(str(path)) as c:
                        s=c.streams.video[0]
                        for frame in c.decode(video=0):
                            if count in (0,plan['frames']//2,plan['frames']-1):frame.to_image().save(evidence/f'frame-{count:04d}.jpg')
                            count+=1
                        details.append(dict(file=str(path),frames=count,fps=float(s.average_rate),seconds=count/float(s.average_rate),width=s.width,height=s.height))
                    if count!=plan['frames']:raise RuntimeError('Output frame count differs from plan')
                if args.phase=='video' and len(details)!=1:raise RuntimeError('Expected one video output')
                try:
                    first_scene=output_scene_record(record,comfy,plan)
                except Exception as error:
                    return failed_observation(evidence,pid,'Output scene verification failed: '+str(error))
                summary=dict(success=True,execution_completed=True,phase=args.phase,prompt_id=pid,
                    files=files,videos=details,plan=plan,quality_review_pending=True,gpu_quality_verified=False,
                    review_contract=contract,first_scene=first_scene,
                    operator_scene_review_asserted=args.phase=='video',
                    approved_scene_input=reviewed_scene,
                    geometry_validation_completed=args.phase=='validate',
                    target_contract=target,scene_provenance=scene_provenance)
                preflight.write_report(evidence/'result.json',summary)
                print('COMPLETE',json.dumps(summary,ensure_ascii=False),flush=True);return 0
        print('WAITING',pid,flush=True)
        time.sleep(max(0,min(15,deadline-time.monotonic())))
    return failed_observation(evidence,pid,'Observer deadline reached; a running GPU job may still need manual stop')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase',choices=['scene','validate','video'],default='scene')
    p.add_argument('--seconds',type=float,default=1.1,
                   help='Source window up to 10.25 seconds; latent-compatible overrun can be trimmed afterward without retiming')
    p.add_argument('--seed',type=int,default=32139832)
    p.add_argument('--timeout-minutes',type=float,default=20,
                   help='Observer deadline only; a running GPU job may still need manual stop')
    p.add_argument('--scene-prompt-file')
    p.add_argument('--base-qwen',action='store_true')
    p.add_argument('--photo-first',action='store_true')
    p.add_argument('--comfy-root',type=Path,default=COMFY)
    p.add_argument('--image',help='Relative file name inside ComfyUI/input; requires --video')
    p.add_argument('--video',help='Relative file name inside ComfyUI/input; requires --image')
    p.add_argument('--evidence-dir',type=Path,default=Path('/workspace'))
    p.add_argument('--action-description',default='',help='Describe the resulting video action')
    p.add_argument('--garment-sequence',default='',help='Describe initial garments and changes over time')
    p.add_argument('--approve-video-after-review',action='store_true',
                   help='Assert that you visually reviewed the matching scene; does not certify video quality')
    p.add_argument('--reviewed-scene-evidence',type=Path,
                   help='Completed scene-only run directory, result.json, or parent containing exactly one run result; inputs/settings must match')
    p.add_argument('--validated-video-evidence',type=Path,
                   help='Successful --phase validate evidence matching the complete target video settings and original approved PNG')
    preflight.add_graph_arguments(p)
    sys.exit(run(p.parse_args()))
