"""Portable additive-node installer. CLI is read-only unless --install is given."""
import argparse
import ast
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import urllib.error
import urllib.request
import uuid

import install_on_pod as base

DEFAULT_COMFY = Path('/workspace/runpod-slim/ComfyUI')
SOURCE = Path(__file__).resolve().parent
FILES = ('fullgen_nodes.py', 'nodes.py', 'scene_core.py', 'anatomy_reference.py')
OWNED_FILES = FILES + ('__init__.py',)
NATIVE_NODES = ('SAM3_Detect', 'SAM3_VideoTrack', 'WanSCAILToVideo',
                'TextEncodeQwenImageEditPlus', 'FluxKontextImageScale',
                'FluxKontextMultiReferenceLatentMethod', 'CFGNorm')
BASE_NODES = ('MotionLoadClip', 'MotionFitImage', 'MotionCanvasSize', 'MotionSceneReport')
INIT_SOURCE = 'from .fullgen_nodes import NODE_CLASS_MAPPINGS, NODE_DISPLAY_NAME_MAPPINGS\n'


def is_link(path):
    path = Path(path)
    return path.is_symlink() or bool(getattr(path, 'is_junction', lambda: False)())


def check_comfy(comfy=DEFAULT_COMFY):
    """Check source evidence without imports; live /object_info is authoritative."""
    comfy = Path(comfy).resolve()
    if not (comfy/'main.py').is_file() or not (comfy/'custom_nodes').is_dir():
        raise base.InstallError('ComfyUI folder not found. Pass --comfy /workspace/ComfyUI.')
    if is_link(comfy/'custom_nodes'):
        raise base.InstallError('Refusing installation through a linked custom_nodes directory.')
    found = set()
    paths = sorted((comfy/'comfy_extras').glob('nodes_*.py'))
    if (comfy/'nodes.py').is_file():
        paths.append(comfy/'nodes.py')
    for path in paths:
        try:
            tree = ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
        except (OSError, UnicodeError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                found.add(node.name)
            elif isinstance(node, ast.keyword) and node.arg == 'node_id':
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    found.add(node.value.value)
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if any(isinstance(target, ast.Name) and target.id == 'NODE_CLASS_MAPPINGS'
                       for target in targets) and isinstance(node.value, ast.Dict):
                    found.update(key.value for key in node.value.keys
                                 if isinstance(key, ast.Constant) and isinstance(key.value, str))
    missing = [name for name in NATIVE_NODES if name not in found]
    if missing:
        raise base.InstallError('ComfyUI lacks native SAM3/SCAIL/Qwen support: ' + ', '.join(missing))
    return comfy


def check_opencv():
    """Import only cv2 for a CPU feature check; do not run vision or CUDA calls."""
    result = {'version': None, 'features': {}, 'ready': False, 'import_error': None}
    try:
        cv2 = importlib.import_module('cv2')
        result['version'] = str(getattr(cv2, '__version__', 'unknown'))
        data_path = getattr(getattr(cv2, 'data', None), 'haarcascades', None)
        result['features'] = {
            'CascadeClassifier': callable(getattr(cv2, 'CascadeClassifier', None)),
            'data.haarcascades': isinstance(data_path, str) and bool(data_path),
            'frontalface_cascade': bool(data_path) and isinstance(data_path, str)
                                  and (Path(data_path)/'haarcascade_frontalface_default.xml').is_file(),
        }
        result['ready'] = all(result['features'].values())
    except (ImportError, OSError, AttributeError, RuntimeError) as exc:
        result['import_error'] = f'{type(exc).__name__}: {exc}'
    result['missing_features'] = [name for name, present in result['features'].items() if not present]
    return result


def dependency_error(runtime):
    """Turn a read-only dependency report into an actionable installation error."""
    problems = []
    if runtime['missing_modules']:
        problems.append('Missing dependencies: ' + ', '.join(runtime['missing_modules']) + '.')
    opencv = runtime.get('opencv', {})
    if opencv and not opencv['ready']:
        reason = opencv['import_error'] or ', '.join(opencv['missing_features'])
        problems.append(f"OpenCV {opencv['version'] or 'unavailable'} lacks required support: {reason}.")
    return ' '.join(problems + [runtime.get('instruction', 'Use the Python executable that starts ComfyUI.')])


def check_dependencies():
    """Inspect metadata plus CPU-only cv2 features; never import torch or call CUDA."""
    missing = []
    for name in ('torch', 'av', 'PIL', 'numpy', 'aiohttp', 'cv2', 'safetensors'):
        try:
            found = importlib.util.find_spec(name) is not None
        except (ImportError, ValueError, AttributeError):
            found = False
        if not found:
            missing.append(name)
    opencv = check_opencv()
    instruction = 'Use the Python executable that starts ComfyUI.'
    if not opencv['ready']:
        instruction += (' Repair OpenCV explicitly in that environment: '
                        'python -m pip install opencv-python-headless==4.11.0.86 --no-deps. '
                        'Then rerun --check-only; restart ComfyUI after the repair. '
                        'This checker does not install packages.')
    return {'python': sys.executable, 'missing_modules': missing,
            'ready': not missing and opencv['ready'], 'opencv': opencv,
            'cuda_checked': False, 'instruction': instruction}


def read_runtime(endpoint, port=8188):
    if endpoint not in ('/queue', '/object_info') or type(port) is not int or not 1 <= port <= 65535:
        raise base.InstallError('Only local queue/object_info reads on a valid port are permitted.')
    request = urllib.request.Request(f'http://127.0.0.1:{port}{endpoint}', method='GET')
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            return json.load(response)
    except (urllib.error.URLError, OSError, ValueError) as exc:
        raise base.InstallError('Cannot verify local ComfyUI. Start it with its own Python and retry; '
                                'installation is blocked.') from exc


def require_idle(port=8188):
    queue = read_runtime('/queue', port)
    if not isinstance(queue, dict) or any(not isinstance(queue.get(key), list)
                                         for key in ('queue_running', 'queue_pending')):
        raise base.InstallError('Invalid /queue response; installation is blocked.')
    if queue['queue_running'] or queue['queue_pending']:
        raise base.InstallError('Queue is busy; wait for running and pending jobs before installing.')
    return queue


def check_live_nodes(port=8188):
    info = read_runtime('/object_info', port)
    if not isinstance(info, dict):
        raise base.InstallError('Invalid /object_info response; installation is blocked.')
    missing = [name for name in NATIVE_NODES if not isinstance(info.get(name), dict)]
    if missing:
        raise base.InstallError('Native nodes are not loaded: ' + ', '.join(missing))
    return info


def addon_destination(comfy, addon_name='motion_studio_fullgen', filenames=OWNED_FILES):
    if addon_name not in ('motion_studio_fullgen', 'motion_studio_io'):
        raise base.InstallError('Only Motion Studio fullgen/IO destinations are permitted.')
    custom = comfy/'custom_nodes'
    dest = custom/addon_name
    if is_link(dest) or not dest.resolve().is_relative_to(custom.resolve()):
        raise base.InstallError('Fullgen addon must be a normal folder inside ComfyUI/custom_nodes.')
    if dest.exists() and not dest.is_dir():
        raise base.InstallError('Addon destination is not a directory; nothing overwritten.')
    for name in filenames:
        if name not in OWNED_FILES:
            raise base.InstallError('Unexpected addon filename.')
        path = dest/name
        if is_link(path) or (path.exists() and not path.is_file()):
            raise base.InstallError('Refusing linked/non-file addon component: ' + name)
    return dest


def check_sources(source=SOURCE, files=FILES, init_source=INIT_SOURCE):
    source = Path(source).resolve()
    for name in files:
        if name not in FILES:
            raise base.InstallError('Unexpected source filename.')
        path = source/name
        if not path.is_file():
            raise base.InstallError('Package is incomplete: ' + name)
        compile(path.read_text(encoding='utf-8-sig'), str(path), 'exec')
    compile(init_source, '__init__.py', 'exec')
    return source


def install(comfy=DEFAULT_COMFY, *, check_only=False, source=SOURCE, port=8188,
            addon_name='motion_studio_fullgen', files=FILES, init_source=INIT_SOURCE):
    """Keep the old no-argument function call; CLI explicitly opts into installation."""
    comfy, source = check_comfy(comfy), check_sources(source, files, init_source)
    owned_files = tuple(files) + ('__init__.py',)
    runtime, dest = check_dependencies(), addon_destination(comfy, addon_name, owned_files)
    report = {'comfy': str(comfy), 'destination': str(dest), 'runtime': runtime,
              'check_only': check_only, 'old_extension_unchanged': True,
              'base_nodes_required': list(BASE_NODES), 'gpu_generation_tested': False}
    if check_only:
        report['ready_to_install'] = runtime['ready']
        return report
    if not runtime['ready']:
        raise base.InstallError(dependency_error(runtime))
    require_idle(port)
    check_live_nodes(port)
    token = uuid.uuid4().hex
    stage = comfy/'custom_nodes'/('.motion-fullgen-stage-'+token)
    backup = comfy/'motion-studio-backups'/(addon_name+'-'+token)
    if is_link(backup.parent) or not backup.resolve().is_relative_to(comfy):
        raise base.InstallError('Unsafe addon backup directory.')
    previous = [name for name in owned_files if (dest/name).exists()]
    written, created = [], not dest.exists()
    stage.mkdir()
    try:
        for name in files:
            shutil.copy2(source/name, stage/name)
        (stage/'__init__.py').write_text(init_source, encoding='utf-8')
        if previous:
            backup.mkdir(parents=True)
            for name in previous:
                shutil.copy2(dest/name, backup/name)
        require_idle(port)
        addon_destination(comfy, addon_name, owned_files)
        dest.mkdir(exist_ok=True)
        try:
            for name in owned_files:
                (stage/name).replace(dest/name)
                written.append(name)
        except Exception:
            for name in written:
                if name in previous:
                    shutil.copy2(backup/name, dest/name)
                else:
                    (dest/name).unlink(missing_ok=True)
            if created and dest.exists() and not any(dest.iterdir()):
                dest.rmdir()
            raise
    finally:
        # Only these four known staging files are removable; no recursive delete.
        for name in owned_files:
            (stage/name).unlink(missing_ok=True)
        stage.rmdir()
    report.update(installed=str(dest), backup=str(backup) if previous else None,
                  sha256={name: base.checksum(dest/name, 'sha256') for name in owned_files},
                  next='Restart ComfyUI while idle, then run fullgen_preflight.py with selected inputs.')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy', default=str(DEFAULT_COMFY))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--install', action='store_true')
    mode.add_argument('--check-only', action='store_true', help='Read-only checks (default).')
    parser.add_argument('--port', type=int, default=8188)
    args = parser.parse_args(argv)
    try:
        report = install(args.comfy, check_only=not args.install, port=args.port)
    except (base.InstallError, OSError, ValueError, SyntaxError) as exc:
        parser.exit(1, f'Installation stopped: {exc}\n')
    print(json.dumps(report, indent=2))
    return report


if __name__ == '__main__':
    main()
