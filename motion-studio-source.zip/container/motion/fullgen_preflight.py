"""Read-only ComfyUI readiness checks. Never submits or cancels a prompt.

Run on the Pod after starting ComfyUI. Only the local JSON evidence report is
written; GET /object_info and GET /queue do not load models or execute a graph.
Readiness is not evidence of successful generation or visual quality.
"""
import argparse
import datetime
import importlib
import json
import math
from pathlib import Path, PurePosixPath, PureWindowsPath
import sys
import types
import urllib.request


DEFAULT_COMFY = Path('/workspace/runpod-slim/ComfyUI')
MODEL_INPUTS = {'ckpt_name', 'unet_name', 'clip_name', 'clip_name1', 'clip_name2',
                'vae_name', 'lora_name', 'model_name'}

GRAPH_OPTION_DEFAULTS = dict(long_edge=704,upscale_canvas=False,target_fps=None,chunk_frames=33,
                            video_steps=8,video_cfg=1.,video_shift=1.,use_lightx=True,
                            video_sampler='euler',single_scene_reference=False,lightx_lora=None,
                            no_source_props=False)


def graph_options(args):
    return {name:getattr(args,name,default) for name,default in GRAPH_OPTION_DEFAULTS.items()}


def add_graph_arguments(parser):
    parser.add_argument('--long-edge',type=int,default=704)
    parser.add_argument('--upscale-canvas',action='store_true',help='Allow canvas enlargement up to --long-edge')
    parser.add_argument('--fps','--target-fps',dest='target_fps',type=float,
                        help='12 to 30 FPS, no higher than the source; default caps source FPS at 30')
    parser.add_argument('--chunk-frames',type=int,choices=(33,49,65,81),default=33)
    parser.add_argument('--video-steps',type=int,default=8)
    parser.add_argument('--video-cfg',type=float,default=1.)
    parser.add_argument('--video-shift',type=float,default=1.)
    light=parser.add_mutually_exclusive_group()
    light.add_argument('--use-lightx',dest='use_lightx',action='store_true')
    light.add_argument('--no-lightx',dest='use_lightx',action='store_false')
    parser.set_defaults(use_lightx=True)
    parser.add_argument('--video-sampler',choices=('euler','uni_pc','dpmpp_2m'),default='euler')
    parser.add_argument('--lightx-lora',help='Optional .safetensors basename already installed in models/loras; requires Lightx')
    parser.add_argument('--single-scene-reference',action='store_true',
                        help='Use only the generated scene and its matching identity mask for SCAIL references')
    parser.add_argument('--no-source-props',action='store_true',
                        help='Explicitly omit source prop tracking and guidance for a reviewed clip with no interaction props')


def read_runtime(path, timeout=15):
    """Intentionally expose no mutation endpoint or user-supplied remote URL."""
    if path not in ('/object_info', '/queue'):
        raise ValueError('Preflight permits GET /object_info and GET /queue only')
    if not math.isfinite(timeout) or not 0 < timeout <= 60:
        raise ValueError('Runtime request timeout must be between 0 and 60 seconds')
    request = urllib.request.Request('http://127.0.0.1:8188' + path, method='GET')
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def resolve_input(comfy_root, name):
    """Accept relative input names only, including on a different host OS."""
    if not isinstance(name, str) or not name or '\x00' in name or ':' in name:
        raise ValueError('Input must be a non-empty relative file name')
    normalized = name.replace('\\', '/')
    if (PurePosixPath(normalized).is_absolute() or PureWindowsPath(name).drive
            or PureWindowsPath(name).root
            or any(part in ('', '.', '..') for part in normalized.split('/'))):
        raise ValueError('Absolute paths and traversal are not accepted for inputs')
    directory = (Path(comfy_root) / 'input').resolve()
    selected = (directory / normalized).resolve()
    if not selected.is_relative_to(directory) or not selected.is_file():
        raise ValueError('Selected input must be a file inside ComfyUI/input')
    if selected.stat().st_size == 0:
        raise ValueError('Selected input is empty')
    return selected


def inputs_from_saved_workflow(comfy_root):
    """Compatibility fallback; explicit --image and --video need no saved UI."""
    paths = list(Path(comfy_root).glob('user/**/joint_scene_workflow_10_seconds.json'))
    if len(paths) != 1:
        raise ValueError('Pass --image and --video, or keep exactly one saved ten-second workflow')
    workflow = json.loads(paths[0].read_text(encoding='utf-8'))
    selected = []
    for kind in ('LoadImage', 'MotionLoadClip'):
        candidates = [node for node in workflow.get('nodes', []) if node.get('type') == kind]
        if len(candidates) != 1 or not candidates[0].get('widgets_values'):
            raise ValueError('Saved workflow has ambiguous or missing media selections')
        selected.append(candidates[0]['widgets_values'][0])
    for name in selected:
        resolve_input(comfy_root, name)
    return tuple(selected)


def select_inputs(comfy_root, image=None, video=None):
    if (image is None) != (video is None):
        raise ValueError('Supply --image and --video together')
    if image is None:
        return inputs_from_saved_workflow(comfy_root)
    for name in (image, video):
        resolve_input(comfy_root, name)
    return image.replace('\\', '/'), video.replace('\\', '/')


def media_metadata(comfy_root, image, video):
    """Validate image structure and decode one video frame on CPU."""
    import av
    from PIL import Image
    image_path, video_path = [resolve_input(comfy_root, name) for name in (image, video)]
    with Image.open(image_path) as reference:
        reference_size = reference.size
        reference.verify()
    with av.open(str(video_path)) as container:
        if not container.streams.video:
            raise ValueError('Selected video contains no video stream')
        stream = container.streams.video[0]
        fps = float(stream.average_rate) if stream.average_rate else 0
        duration = (float(container.duration) / av.time_base if container.duration is not None
                    else float(stream.duration * stream.time_base) if stream.duration is not None
                    else 0)
        meta = dict(width=stream.width, height=stream.height, fps=fps, duration=duration)
        if not all(math.isfinite(float(value)) and value > 0 for value in meta.values()):
            raise ValueError('Selected video has invalid dimensions, frame rate or duration')
        if next(container.decode(video=0), None) is None:
            raise ValueError('Cannot decode a frame from selected video')
    return meta, reference_size


def graph_module():
    package_name = '_motion_fullgen_preflight'
    if package_name not in sys.modules:
        package = types.ModuleType(package_name)
        package.__path__ = [str(Path(__file__).resolve().parent)]
        sys.modules[package_name] = package
    return importlib.import_module(package_name + '.fullgen_graph')


def inspect_graph(graph, object_info):
    """Check the installed schema, its required inputs and selectable weights."""
    errors, models = [], []
    if not isinstance(object_info, dict):
        return {'errors': ['Invalid /object_info response'], 'models': [], 'needed_nodes': []}
    for key, node in graph.items():
        kind = node['class_type']
        schema = object_info.get(kind)
        if not isinstance(schema, dict):
            errors.append(f'{key}: missing installed node {kind}')
            continue
        required = schema.get('input', {}).get('required', {})
        optional = schema.get('input', {}).get('optional', {})
        definitions = {**required, **optional}
        supplied = node.get('inputs', {})
        for name in required:
            if name not in supplied:
                errors.append(f'{key}: installed {kind} requires input {name}')
        for name, value in supplied.items():
            if name not in definitions:
                errors.append(f'{key}: installed {kind} has no input {name}')
                continue
            definition = definitions[name]
            choices = definition[0] if isinstance(definition, (list, tuple)) and definition else None
            if (choices == 'COMBO' and len(definition)>1 and isinstance(definition[1],dict)
                    and isinstance(definition[1].get('options'),list)):
                choices=definition[1]['options']
            if isinstance(value, list) and len(value) == 2 and isinstance(value[1], int):
                upstream = graph.get(str(value[0]))
                if upstream is None:
                    errors.append(f'{key}.{name}: missing upstream node {value[0]}')
                    continue
                upstream_schema = object_info.get(upstream['class_type'], {})
                outputs = upstream_schema.get('output', [])
                if not 0 <= value[1] < len(outputs):
                    errors.append(f'{key}.{name}: unavailable output {value[1]} on {upstream["class_type"]}')
                elif isinstance(choices, str) and choices != '*':
                    actual = outputs[value[1]]
                    if isinstance(actual, str) and actual != '*' and not set(actual.split(',')).intersection(choices.split(',')):
                        errors.append(f'{key}.{name}: installed link type is {actual}, expected {choices}')
                continue
            if choices in ('INT','FLOAT'):
                limits=definition[1] if len(definition)>1 and isinstance(definition[1],dict) else {}
                valid=(isinstance(value,(int,float)) and not isinstance(value,bool)
                       and math.isfinite(value) and (choices!='INT' or isinstance(value,int)))
                if not valid:
                    errors.append(f'{key}.{name}: expected finite {choices}')
                elif (('min' in limits and value<limits['min'])
                      or ('max' in limits and value>limits['max'])):
                    errors.append(f'{key}.{name}: value {value} outside installed range '
                                  f'{limits.get("min", "unbounded")}..{limits.get("max", "unbounded")}')
            if name in MODEL_INPUTS:
                available = isinstance(choices, list) and value in choices
                models.append(dict(node=key, input=name, file=value, listed_by_runtime=available))
                if not available:
                    errors.append(f'{key}.{name}: model not listed by runtime: {value}')
            elif isinstance(choices, list) and value not in choices:
                errors.append(f'{key}.{name}: value is not supported by installed schema: {value}')
    return {'needed_nodes': sorted({node['class_type'] for node in graph.values()}),
            'models': models, 'errors': errors}


def inspect_queue(queue):
    if not isinstance(queue, dict) or any(not isinstance(queue.get(key), list)
                                         for key in ('queue_running', 'queue_pending')):
        return {'empty': False, 'error': 'Invalid /queue response'}
    return {'empty': not queue['queue_running'] and not queue['queue_pending'],
            'running_count': len(queue['queue_running']), 'pending_count': len(queue['queue_pending'])}


def check_runtime(graph, reader=read_runtime):
    report = inspect_graph(graph, reader('/object_info'))
    report['queue'] = inspect_queue(reader('/queue'))
    if not report['queue']['empty']:
        report['errors'].append(report['queue'].get('error', 'Queue is busy; do not submit a smoke test'))
    report['ready'] = not report['errors']
    report['render_submitted'] = False
    report['gpu_quality_verified'] = False
    report['model_evidence'] = 'Runtime loader choices only; weights are not loaded or checksum-verified'
    return report


def collect_preflight(comfy_root=DEFAULT_COMFY, image=None, video=None, seconds=1.1,
                      seed=32139832, phase='scene', reader=read_runtime,
                      action_description='', garment_sequence='',*,
                      long_edge=704,upscale_canvas=False,target_fps=None,chunk_frames=33,
                      video_steps=8,video_cfg=1.,video_shift=1.,use_lightx=True,
                      video_sampler='euler',single_scene_reference=False,lightx_lora=None,
                      no_source_props=False):
    report = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'comfy_root': str(Path(comfy_root).resolve()), 'phase': phase,
              'ready': False, 'render_submitted': False, 'gpu_quality_verified': False,
              'visual_review_required': True, 'errors': []}
    try:
        if phase not in ('scene', 'video'):
            raise ValueError('Phase must be scene or video')
        if not math.isfinite(seconds) or not 0 < seconds <= 10.25:
            raise ValueError('Bounded preflight duration must be greater than 0 and at most 10.25 seconds (bounded latent overrun for final trimming)')
        image, video = select_inputs(comfy_root, image, video)
        report['inputs'] = {'image': image, 'video': video, 'selection_valid': True}
        meta, reference_size = media_metadata(comfy_root, image, video)
        report['inputs'].update(source_metadata=meta, reference_size=list(reference_size),
                                media_valid=True)
        module = graph_module()
        graph, plan = module.build_fullgen_graph(image, video, meta, duration=seconds,
            seed=seed, job_id='fullgen-preflight', reference_size=reference_size,
            action_description=action_description, garment_sequence=garment_sequence,
            long_edge=long_edge,upscale_canvas=upscale_canvas,target_fps=target_fps,
            chunk_frames=chunk_frames,video_steps=video_steps,video_cfg=video_cfg,
            video_shift=video_shift,use_lightx=use_lightx,video_sampler=video_sampler,
            single_scene_reference=single_scene_reference,lightx_lora=lightx_lora,
            no_source_props=no_source_props)
        if phase == 'scene':
            graph = module.prune_scene_graph(graph)
        report.update(check_runtime(graph, reader=reader))
        report['plan'] = plan
        report['readiness_scope'] = 'Selected graph schema, listed weights and current idle queue; no inference performed'
    except Exception as error:
        report['errors'].append(f'{type(error).__name__}: {error}')
        report['ready'] = False
    return report


def write_report(path, report):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy-root', type=Path, default=DEFAULT_COMFY)
    parser.add_argument('--image', help='Relative file name inside ComfyUI/input')
    parser.add_argument('--video', help='Relative file name inside ComfyUI/input')
    parser.add_argument('--seconds', type=float, default=1.1,
                        help='Source window up to 10.25 seconds; latent-compatible overrun may be trimmed without retiming')
    parser.add_argument('--seed', type=int, default=32139832)
    parser.add_argument('--phase', choices=('scene', 'video'), default='scene')
    parser.add_argument('--action-description', default='')
    parser.add_argument('--garment-sequence', default='')
    parser.add_argument('--report', type=Path, default=Path('fullgen-preflight-report.json'))
    add_graph_arguments(parser)
    args = parser.parse_args()
    report = collect_preflight(args.comfy_root, args.image, args.video,
                              args.seconds, args.seed, args.phase,
                              action_description=args.action_description,
                              garment_sequence=args.garment_sequence,**graph_options(args))
    write_report(args.report, report)
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report['ready'] else 1


if __name__ == '__main__':
    sys.exit(main())
