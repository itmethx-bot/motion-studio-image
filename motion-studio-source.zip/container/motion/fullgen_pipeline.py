"""Automatic two-upload full-generation orchestration, independent of the web UI.

Backend request is an injected async callable: request(method, path, body=None).
The service owns admission, downloading, final 160-frame encoding and GPU stop.
This module never calls provider APIs, retries an uncertain submission, or claims
that structural mask checks verify visual quality. Fixtures are trusted local
manifests supplied by the service, never client-provided paths or approvals.
"""
import asyncio
from copy import deepcopy
import inspect
import json
import math
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import shutil
import time
import uuid

try:
    from aiohttp import ClientError
except ImportError:  # aiohttp is supplied by the service on a real ComfyUI host.
    class ClientError(Exception):
        pass

from .fullgen_graph import build_fullgen_graph, prune_scene_graph
from .scene_core import size_for_video
from .clip_duration import duration_contract
from . import fullgen_preflight as preflight
from . import fullgen_reuse as reuse


VERSION = '6-source-duration'
ROOT = Path(__file__).resolve().parent
MAX_CANVAS_PIXELS = 704 * 1280


class PipelineError(ValueError):
    def __init__(self, stage, message, *, prompt_id=None, submission_outcome_unknown=False):
        super().__init__(message)
        self.stage = stage
        self.prompt_id = prompt_id
        self.submission_outcome_unknown = submission_outcome_unknown


def recipe_settings(*, no_source_props=False, action_description='', garment_sequence='',
                    canvas=(704, 1280)):
    """The fixed tested-quality preset. Captions may come only from a trusted fixture."""
    if type(no_source_props) is not bool:
        raise ValueError('no_source_props must be a boolean')
    for value in (action_description, garment_sequence):
        if not isinstance(value, str) or len(value) > 4000:
            raise ValueError('Fixture captions must be strings of at most 4000 characters')
    if (len(canvas) != 2 or any(type(value) is not int or value < 32 or value % 32 for value in canvas)
            or max(canvas) > 1280 or min(canvas) < 32 or canvas[0] * canvas[1] > MAX_CANVAS_PIXELS):
        raise ValueError('Canvas must be 32-aligned, long edge at most 1280 and area at most 901120 pixels')
    return dict(version=VERSION, requested_seconds=10., source_seconds=10.1,
                canvas=list(canvas), fps=16., frames=161, final_frames=160,
                seed=32139832, long_edge=max(canvas), upscale_canvas=True, chunk_frames=65,
                video_steps=8, video_cfg=1., video_shift=1., use_lightx=True,
                video_sampler='euler', lightx_lora=None, single_scene_reference=True,
                no_source_props=no_source_props, action_description=action_description,
                garment_sequence=garment_sequence,
                qwen_recipe='2511-base-20steps-cfg4-aura3.1-cfgnorm-index_timestep_zero-1MP')


def canvas_for_reference(width, height):
    if (type(width) is not int or type(height) is not int or min(width, height) < 1):
        raise ValueError('ขนาดรูปอ้างอิงไม่ถูกต้อง กรุณาอัปโหลดรูปอีกครั้ง')
    ratio = max(width, height) / min(width, height)
    if ratio > 4:
        raise ValueError('รูปอ้างอิงแคบหรือกว้างเกินไป กรุณาใช้รูปที่มีสัดส่วนไม่เกิน 4:1')
    # Check the actual 32-pixel grid rather than a continuous area estimate:
    # 576×1024 rounds to the proven 704×1280 canvas at edge1280, whose area
    # fits even though the unrounded 720×1280 estimate would exceed the cap.
    edge = 1280
    while edge >= 256:
        canvas = size_for_video(width, height, long_edge=edge, upscale=True)
        if canvas[0] * canvas[1] <= MAX_CANVAS_PIXELS:
            return canvas
        edge -= 32
    raise ValueError('ไม่สามารถจัดขนาดภาพให้อยู่ในงบหน่วยความจำของสูตรนี้ได้')


def implementation_hashes():
    return {name: reuse.fingerprint(ROOT / name)['sha256'] for name in reuse.IMPLEMENTATION_FILES}


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _inside(root, relative):
    if (not isinstance(relative, str) or not relative or '\\' in relative
            or PureWindowsPath(relative).drive or PurePosixPath(relative).is_absolute()
            or any(part in ('', '.', '..') for part in relative.split('/')) or ':' in relative):
        raise ValueError('ชื่อไฟล์ไม่ถูกต้อง กรุณาอัปโหลดไฟล์อีกครั้ง')
    path = (Path(root) / relative).resolve()
    if not path.is_relative_to(Path(root).resolve()) or not path.is_file() or path.stat().st_size == 0:
        raise ValueError('ไม่พบไฟล์ที่อัปโหลดหรือไฟล์ว่าง กรุณาอัปโหลดอีกครั้ง')
    return path


def _read_png(path, expected_size, expected_fingerprint=None):
    from PIL import Image
    path = Path(path).resolve()
    fingerprint = reuse.fingerprint(path)
    if expected_fingerprint is not None and fingerprint != expected_fingerprint:
        raise ValueError('ภาพฉากแรกเปลี่ยนไปจากหลักฐานเดิม กรุณาใช้ไฟล์ PNG ต้นฉบับ')
    with Image.open(path) as image:
        actual_format, size = image.format, list(image.size)
        image.verify()
    if actual_format != 'PNG' or size != list(expected_size):
        raise ValueError('ภาพฉากแรกต้องเป็น PNG ขนาดตรงกับแผน ไม่อนุญาตให้ย่อหรือขยายเพื่อใช้หลักฐานเดิม')
    return dict(file=str(path), size=size, **fingerprint)


def _report(history, key):
    texts = history.get('outputs', {}).get(key, {}).get('text', [])
    if len(texts) != 1 or not isinstance(texts[0], str):
        raise ValueError('ไม่พบรายงานตรวจโครงสร้างฉากครบถ้วน จึงยังไม่เริ่มสร้างวิดีโอ')
    report = json.loads(texts[0])
    if not isinstance(report, dict):
        raise ValueError('รูปแบบรายงานตรวจฉากไม่ถูกต้อง')
    return report


def structural_reports(history):
    scene, reference = _report(history, 'analysis_report'), _report(history, 'reference_report')
    people = scene.get('people')
    assignment = reference.get('generated_person_assignment')
    if (type(people) is not int or not 1 <= people <= 3 or reference.get('people') != people
            or not isinstance(assignment, list) or len(assignment) != people
            or any(type(value) is not int for value in assignment) or len(set(assignment)) != people):
        raise ValueError('จำนวนหรือตำแหน่งคนไม่ตรงกัน กรุณาใช้คลิปที่เห็นคน 1–3 คนตั้งแต่ต้นและไม่บังกันมาก')
    # Later-only object candidates include the demonstrated false-background
    # failure. Do not spend the video budget on this unsupported automatic case.
    if scene.get('later_source_props'):
        raise ValueError('พบสิ่งของหรือพื้นที่กำกวมที่เข้ามาภายหลัง ระบบอัตโนมัติยังไม่รองรับ กรุณาตัดคลิปให้เห็นสิ่งของที่ใช้งานตั้งแต่ต้น')
    if reference.get('source_background_in_rgb_guide') is not False:
        raise ValueError('รายงานไม่ยืนยันว่าแนวทางการเคลื่อนไหวตัดฉากหลังต้นฉบับออกแล้ว')
    return scene, reference


def analysis_diagnostics(history):
    """Bounded source-only diagnostic fields that survive PC-side cleanup."""
    scene = _report(history, 'analysis_report')
    props = []
    for item in scene.get('source_props', [])[:12]:
        if not isinstance(item, dict):
            continue
        props.append({key: item[key] for key in (
            'object_track', 'accepted', 'reason', 'initial_mask_area',
            'initial_scene_excluded', 'longest_contact_run', 'participant_tracks') if key in item})
    excluded = [value for value in scene.get('excluded_later_source_props', [])[:12]
                if type(value) is int]
    warnings = (['ข้ามหน้ากากสิ่งของที่ไม่มีหลักฐานใช้ได้ในเฟรมแรก '
                 'อุปกรณ์ที่เข้ามาภายหลังอาจไม่ปรากฏในผลลัพธ์'] if excluded else [])
    return dict(people=scene.get('people'), primary_track=scene.get('primary_track'),
                source_props=props, excluded_later_source_props=excluded), warnings


def _replay_graph(graph, filename):
    graph = deepcopy(graph)
    graph.pop('qwen_master_preview', None)
    graph['generated_scene'] = {'class_type': 'LoadImage', 'inputs': {'image': filename}}
    needed = set()

    def visit(key):
        if key in needed:
            return
        needed.add(key)
        for value in graph[key]['inputs'].values():
            if isinstance(value, list) and len(value) == 2 and isinstance(value[0], str) and isinstance(value[1], int):
                visit(value[0])

    for key, node in graph.items():
        if node['class_type'] in ('SaveImage', 'SaveVideo', 'MotionSceneReport'):
            visit(key)
    result = {key: node for key, node in graph.items() if key in needed}
    if any(key.startswith('qwen_') for key in result):
        raise ValueError('Internal error: reviewed PNG replay retained Qwen generation')
    return result


class FullGenerationPipeline:
    def __init__(self, *, request, inputs, outputs, evidence_dir, fixtures=None,
                 on_update=None, poll_seconds=5, timeout_seconds=7200):
        if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 7200:
            raise ValueError('Pipeline observer timeout must be 0–7200 seconds')
        if not math.isfinite(poll_seconds) or not 0 <= poll_seconds <= 30:
            raise ValueError('Poll interval must be 0–30 seconds')
        self.request, self.on_update = request, on_update
        self.inputs, self.outputs = Path(inputs).resolve(), Path(outputs).resolve()
        self.evidence_dir = Path(evidence_dir)
        self.fixtures = fixtures
        self.poll_seconds, self.timeout_seconds = poll_seconds, timeout_seconds
        self.state = {}

    async def _history(self, stage, prompt_id, progress):
        """Retry read-only transport failures, never submissions or graph errors."""
        delays = (2, 5, 10)
        for attempt in range(4):
            remaining = self.deadline - time.monotonic()
            if remaining <= 0:
                raise PipelineError(stage, 'หมดเวลาสังเกตงาน งาน GPU อาจยังทำอยู่ กรุณาตรวจคิวก่อนเริ่มใหม่',
                                    prompt_id=prompt_id)
            try:
                return await asyncio.wait_for(self.request('GET', '/history/' + prompt_id),
                                              timeout=min(30, remaining))
            except (OSError, asyncio.TimeoutError, ClientError) as error:
                if attempt == 3:
                    raise PipelineError(stage, 'ติดต่อผลของงานเดิมไม่ได้หลังลองเชื่อมต่อซ้ำ งาน GPU อาจยังทำอยู่ กรุณาตรวจคิวก่อนเริ่มใหม่',
                                        prompt_id=prompt_id) from error
                await self._update(stage, self.state['message'], progress, prompt_id=prompt_id,
                                   observer_read_retries=attempt + 1)
                remaining = self.deadline - time.monotonic()
                if remaining > 0:
                    await asyncio.sleep(min(delays[attempt], remaining))

    async def _update(self, stage, message, progress, **details):
        update = dict(stage=stage, message=message, progress=progress, **details)
        self.state.update(update, updated=time.time())
        atomic_json(self.evidence_dir / 'pipeline-state.json', self.state)
        if self.on_update is not None:
            result = self.on_update(deepcopy(update))
            if inspect.isawaitable(result):
                await result

    def _binding(self, image, video):
        return {'image': reuse.fingerprint(_inside(self.inputs, image['file'])),
                'video': reuse.fingerprint(_inside(self.inputs, video['file']))}

    def _stage_root_asset(self, source, prefix, suffix, fingerprint):
        """Native LoadImage lists input-root files, so copy exact bytes there."""
        filename = prefix + fingerprint['sha256'] + suffix
        destination = self.inputs / filename
        if destination.is_symlink() or not destination.resolve().is_relative_to(self.inputs):
            raise ValueError('ตำแหน่งไฟล์สำหรับ LoadImage ไม่ปลอดภัย')
        created = False
        try:
            if not destination.exists():
                try:
                    with Path(source).open('rb') as incoming, destination.open('xb') as outgoing:
                        created = True
                        shutil.copyfileobj(incoming, outgoing)
                except FileExistsError:
                    pass  # A concurrent identical stage is allowed only after hash verification.
            if reuse.fingerprint(destination) != fingerprint:
                raise ValueError('ไฟล์ที่จัดเตรียมสำหรับ LoadImage ไม่ตรงกับไบต์ต้นฉบับ')
        except BaseException:
            if created:
                destination.unlink(missing_ok=True)
            raise
        return filename, destination

    def _fixture(self, binding, code, canvas):
        if self.fixtures is None:
            return None
        location = Path(self.fixtures)
        if not location.exists():
            return None
        paths = sorted(location.glob('*.json')) if location.is_dir() else [location]
        matches = []
        for path in paths:
            # The service controls this dedicated manifest path/folder.
            item = json.loads(path.read_text(encoding='utf-8'))
            if item.get('input_fingerprints') != binding:
                continue
            if (item.get('version') != 1 or item.get('successful') is not True
                    or item.get('quality_reviewed') is not True or item.get('implementation_sha256') != code):
                continue
            recipe = item.get('recipe', {})
            expected = recipe_settings(no_source_props=recipe.get('no_source_props', False),
                action_description=recipe.get('action_description', ''), garment_sequence=recipe.get('garment_sequence', ''),
                canvas=canvas)
            if recipe != expected:
                continue
            scene = item.get('scene', {})
            scene_path = Path(scene['file'])
            if not scene_path.is_absolute():
                scene_path = path.parent / scene_path
            record = _read_png(scene_path, recipe['canvas'], {key: scene.get(key) for key in ('bytes', 'sha256')})
            if scene.get('size') != record['size']:
                raise ValueError('ขนาดภาพในหลักฐาน fixture ไม่ตรงกับไฟล์จริง')
            matches.append(dict(id=item['id'], recipe=recipe, scene=record,
                                manifest=str(path.resolve()), manifest_fingerprint=reuse.fingerprint(path)))
        if len(matches) > 1:
            raise ValueError('พบชุดอ้างอิงที่ตรงกันมากกว่าหนึ่งชุด กรุณาให้ผู้ดูแลเลือก fixture เดียว')
        return matches[0] if matches else None

    async def _execute(self, stage, graph, plan, progress):
        folder = self.evidence_dir / stage
        atomic_json(folder / 'prompt.json', graph)
        atomic_json(folder / 'plan.json', plan)
        await self._update(stage, {'scene': 'กำลังสร้างฉากใหม่ทั้งภาพ',
            'validate': 'กำลังตรวจจำนวนคน ตำแหน่ง และสิ่งของก่อนสร้างวิดีโอ',
            'video': 'กำลังสร้างทุกคนและการเคลื่อนไหวร่วมกัน'}[stage], progress,
            prompt_id=None, submission_outcome_unknown=False)
        schemas = await self.request('GET', '/object_info')
        report = preflight.inspect_graph(graph, schemas)
        queue = preflight.inspect_queue(await self.request('GET', '/queue'))
        report['queue'] = queue
        atomic_json(folder / 'preflight.json', report)
        if report['errors']:
            raise PipelineError(stage, 'โหนดหรือโมเดลยังไม่พร้อม: ' + '; '.join(report['errors'][:4]))
        if not queue['empty']:
            raise PipelineError(stage, 'ComfyUI มีงานอื่นอยู่ กรุณารอให้คิวว่างก่อนสร้างอีกครั้ง')
        if time.monotonic() >= self.deadline:
            raise PipelineError(stage, 'หมดเวลาสังเกตงานก่อนเริ่มขั้นถัดไป กรุณาตรวจสถานะ GPU')
        submission = dict(prompt=graph, client_id='motion-studio-' + self.state['job_id'] + '-' + stage)
        atomic_json(folder / 'submission-request.json', submission)
        # Persist uncertainty BEFORE sending: a disconnected response must not
        # result in automatic replay of a potentially accepted expensive job.
        self.state['submission_outcome_unknown'] = True
        atomic_json(self.evidence_dir / 'pipeline-state.json', self.state)
        try:
            response = await self.request('POST', '/prompt', submission)
        except Exception as error:
            raise PipelineError(stage, 'ไม่ทราบว่า ComfyUI รับงานแล้วหรือยัง กรุณาตรวจคิวก่อนลองใหม่',
                                submission_outcome_unknown=True) from error
        atomic_json(folder / 'submission.json', response)
        prompt_id = response.get('prompt_id')
        if not isinstance(prompt_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', prompt_id):
            raise PipelineError(stage, 'ComfyUI ไม่ส่งหมายเลขงานกลับมา กรุณาตรวจคิวก่อนลองใหม่',
                                submission_outcome_unknown=True)
        await self._update(stage, self.state['message'], progress, prompt_id=prompt_id,
                           submission_outcome_unknown=False)
        while time.monotonic() < self.deadline:
            history = await self._history(stage, prompt_id, progress)
            item = history.get(prompt_id)
            if item:
                status = item.get('status', {})
                if status.get('status_str') == 'error':
                    atomic_json(folder / 'history.json', item)
                    errors = [message[1] for message in status.get('messages', [])
                              if isinstance(message, list) and len(message) > 1
                              and message[0] == 'execution_error' and isinstance(message[1], dict)]
                    detail = str(errors[0].get('exception_message', ''))[:1500] if errors else ''
                    raise PipelineError(stage, 'สร้างขั้นนี้ไม่สำเร็จ: ' + detail +
                        ' กรุณาใช้คลิปที่เห็นคนครบ 1–3 คนตั้งแต่ต้นและรูปอ้างอิงที่เห็นตัวชัด', prompt_id=prompt_id)
                if status.get('completed') is True:
                    if status.get('status_str') != 'success':
                        raise PipelineError(stage, 'งานจบโดยไม่มีสถานะสำเร็จ จึงไม่เริ่มขั้นถัดไป', prompt_id=prompt_id)
                    atomic_json(folder / 'history.json', item)
                    atomic_json(folder / 'result.json', dict(success=True, execution_completed=True,
                        phase=stage, prompt_id=prompt_id, quality_review_pending=True, gpu_quality_verified=False))
                    return item
            await self._update(stage, self.state['message'], progress, prompt_id=prompt_id)
            await asyncio.sleep(self.poll_seconds)
        raise PipelineError(stage, 'หมดเวลาสังเกตงาน งาน GPU อาจยังทำอยู่ กรุณาตรวจคิวก่อนเริ่มใหม่', prompt_id=prompt_id)

    def _output(self, history, key, suffix):
        values = history.get('outputs', {}).get(key, {})
        paths = set()
        for entry in values.get('images', []) + values.get('videos', []):
            if not isinstance(entry, dict) or entry.get('type') != 'output':
                continue
            subfolder, filename = entry.get('subfolder', ''), entry.get('filename')
            if not isinstance(subfolder, str) or not isinstance(filename, str):
                continue
            path = _inside(self.outputs, '/'.join(part for part in (subfolder, filename) if part))
            if path.suffix.lower() == suffix:
                paths.add(path)
        if len(paths) != 1:
            raise ValueError(f'ไม่พบผลลัพธ์ {key} ที่สมบูรณ์เพียงไฟล์เดียว')
        return paths.pop()

    async def run(self, image, video, *, job_id, seconds=10):
        if not isinstance(job_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,96}', job_id):
            raise ValueError('Invalid pipeline job ID')
        if (self.evidence_dir / 'pipeline-state.json').exists():
            raise ValueError('งานนี้มีหลักฐานแล้ว กรุณาตรวจสถานะเดิมก่อนเริ่มใหม่ ระบบไม่ส่งงานซ้ำอัตโนมัติ')
        self.deadline = time.monotonic() + self.timeout_seconds
        self.state = dict(version=VERSION, job_id=job_id, created=time.time(),
                          quality_review_pending=True, gpu_quality_verified=False,
                          operator_scene_review_asserted=False, status='running')
        await self._update('prepare', 'กำลังตรวจไฟล์ทั้งสองและเลือกแผนสร้างฉากใหม่', 0.02)
        try:
            timing=duration_contract(video,seconds)
            binding = await asyncio.to_thread(self._binding, image, video)
            code = implementation_hashes()
            canvas = canvas_for_reference(image['width'], image['height'])
            fixture = await asyncio.to_thread(self._fixture, binding, code, canvas)
            recipe = deepcopy(fixture['recipe']) if fixture else recipe_settings(canvas=canvas)
            recipe.update(timing)
            original_reference = _inside(self.inputs, image['file'])
            suffix = original_reference.suffix.lower()
            if suffix not in ('.jpg', '.jpeg', '.png', '.webp'):
                raise ValueError('รูปอ้างอิงต้องเป็น JPG, PNG หรือ WebP ที่อ่านได้')
            reference_name, reference_path = await asyncio.to_thread(self._stage_root_asset,
                original_reference, 'motion-studio-reference-', suffix, binding['image'])
            graph, plan = build_fullgen_graph(reference_name, video['file'], video,
                duration=recipe['source_seconds'], seed=recipe['seed'], job_id='auto-' + job_id,
                reference_size=(image['width'], image['height']), action_description=recipe['action_description'],
                garment_sequence=recipe['garment_sequence'], long_edge=recipe['long_edge'],
                upscale_canvas=recipe['upscale_canvas'], target_fps=recipe['fps'],
                chunk_frames=recipe['chunk_frames'], video_steps=recipe['video_steps'],
                video_cfg=recipe['video_cfg'], video_shift=recipe['video_shift'],
                use_lightx=recipe['use_lightx'], video_sampler=recipe['video_sampler'],
                lightx_lora=recipe['lightx_lora'], single_scene_reference=True,
                no_source_props=recipe['no_source_props'],tail_pad_frames=timing['tail_pad_frames'])
            if (plan['frames'], plan['fps'], plan['width'], plan['height']) != (timing['frames'], 16, *canvas):
                raise ValueError('แผนไม่ตรงกับความยาวต้นฉบับ / 16 FPS และขนาดภาพที่เลือก กรุณาตรวจข้อมูลคลิป')
            self.state.update(recipe=recipe, plan=plan, input_fingerprints=binding,
                              implementation_sha256=code, fixture_id=fixture['id'] if fixture else None,
                              scene_selection='audited_fixture' if fixture else 'automatic_generation',
                              staged_reference=dict(file=str(reference_path), **binding['image']))
            atomic_json(self.evidence_dir / 'recipe.json', recipe)
            if fixture:
                scene = fixture['scene']
                atomic_json(self.evidence_dir / 'fixture-selection.json', fixture)
                await self._update('scene_reused', 'ใช้ฉากที่เคยตรวจแล้วสำหรับไฟล์และสูตรเดียวกัน กำลังตรวจการเคลื่อนไหวซ้ำ', .25)
            else:
                history = await self._execute('scene', prune_scene_graph(graph), plan, .10)
                diagnostics, warnings = analysis_diagnostics(history)
                await self._update('scene', 'ตรวจโครงสร้างฉากแรกแล้ว', .25,
                                   analysis_diagnostics=diagnostics, generation_warnings=warnings)
                structural_reports(history)
                scene = await asyncio.to_thread(_read_png, self._output(history, 'scene_preview', '.png'), recipe['canvas'])
            staged, destination = await asyncio.to_thread(self._stage_root_asset,
                scene['file'], 'motion-studio-scene-', '.png',
                {key: scene[key] for key in ('bytes', 'sha256')})
            staged_scene = await asyncio.to_thread(_read_png, destination, recipe['canvas'],
                {key: scene[key] for key in ('bytes', 'sha256')})
            graph = _replay_graph(graph, staged)
            plan.update(first_scene='Exact staged generated PNG; Qwen generation removed from video graph',
                        reviewed_first_scene_sha256=scene['sha256'], operator_scene_review_asserted=False,
                        automatic_structure_only=True, requested_final_seconds=timing['final_seconds'], final_frames=timing['final_frames'],
                        duration_policy=timing['duration_policy'],internal_tail_pad_frames=timing['tail_pad_frames'])
            inputs_contract = dict(image=image['file'], video=video['file'],
                input_fingerprints={image['file']: binding['image'], video['file']: binding['video']})
            provenance = dict(selection=self.state['scene_selection'], original_scene=scene,
                              fixture_id=fixture['id'] if fixture else None,
                              fixture_manifest_fingerprint=fixture['manifest_fingerprint'] if fixture else None)
            target = reuse.target_contract(graph, inputs_contract, recipe['source_seconds'], plan, provenance)
            atomic_json(self.evidence_dir / 'target-contract.json', target)
            validation = prune_scene_graph(graph)
            if any(node['class_type'] in ('KSampler', 'SamplerCustom', 'WanSCAILToVideo') for node in validation.values()):
                raise ValueError('Internal error: structural validation retained diffusion sampling')
            history = await self._execute('validate', validation, plan, .35)
            diagnostics, warnings = analysis_diagnostics(history)
            await self._update('validate', 'ตรวจโครงสร้างการเคลื่อนไหวแล้ว', .40,
                               analysis_diagnostics=diagnostics, generation_warnings=warnings)
            scene_analysis, reference_analysis = structural_reports(history)
            # Bind bytes and implementation again immediately before video. A
            # new validation preview is diagnostic, never the selected PNG.
            if await asyncio.to_thread(self._binding, image, video) != binding:
                raise ValueError('ไฟล์นำเข้าเปลี่ยนหลังตรวจฉาก กรุณาเริ่มงานใหม่')
            if reuse.fingerprint(reference_path) != binding['image']:
                raise ValueError('สำเนารูปอ้างอิงสำหรับ LoadImage เปลี่ยนหลังตรวจฉาก กรุณาเริ่มงานใหม่')
            if fixture and reuse.fingerprint(fixture['manifest']) != fixture['manifest_fingerprint']:
                raise ValueError('หลักฐาน fixture เปลี่ยนหลังเลือกฉาก กรุณาเริ่มงานใหม่')
            await asyncio.to_thread(_read_png, destination, recipe['canvas'],
                                  {key: staged_scene[key] for key in ('bytes', 'sha256')})
            reuse.require_target({'target_contract': target},
                reuse.target_contract(graph, inputs_contract, recipe['source_seconds'], plan, provenance))
            atomic_json(self.evidence_dir / 'geometry-validation.json', dict(success=True,
                scene_analysis=scene_analysis, reference_analysis=reference_analysis,
                target_contract=target, quality_review_pending=True, gpu_quality_verified=False))
            history = await self._execute('video', graph, plan, .55)
            video_path = self._output(history, 'save', '.mp4')
            result = dict(result=video_path.relative_to(self.outputs).as_posix(), plan=plan,
                first_scene=scene, staged_scene=staged_scene, scene_analysis=scene_analysis,
                reference_analysis=reference_analysis, evidence_dir=str(self.evidence_dir.resolve()),
                fixture_id=fixture['id'] if fixture else None, raw_video_fingerprint=reuse.fingerprint(video_path),
                raw_video_requires_decode_and_finalization=True, final_frames=timing['final_frames'], final_seconds=timing['final_seconds'],
                quality_review_pending=True, gpu_quality_verified=False, automatic_structure_only=True)
            atomic_json(self.evidence_dir / 'pipeline-result.json', result)
            self.state['status'] = 'completed'
            await self._update('render_complete', 'สร้างวิดีโอดิบแล้ว กำลังส่งออกและตรวจไฟล์ 10 วินาที', .95)
            return result
        except Exception as error:
            self.state['status'] = 'failed'
            details = dict(error=str(error), failure_stage=getattr(error, 'stage', self.state.get('stage')),
                           submission_outcome_unknown=getattr(error, 'submission_outcome_unknown',
                                                              self.state.get('submission_outcome_unknown', False)))
            if getattr(error, 'prompt_id', None):
                details['prompt_id'] = error.prompt_id
            await self._update('failed', str(error), self.state.get('progress', 0), **details)
            raise
