'use strict';
const root = '/motion-studio';
const OUTPUT_SECONDS = 10;
const MIN_SOURCE_SECONDS = 10.1;
const MAX_SOURCE_SECONDS = 120;
const $ = id => document.getElementById(id);
const activeStages = new Set(['queued', 'starting_gpu', 'running', 'analyzing', 'scene_generating', 'scene_validating', 'generating', 'finalizing', 'ready', 'downloading', 'stopping']);
const terminalStages = new Set(['succeeded', 'completed', 'failed', 'cancelled', 'canceled', 'interrupted', 'stop_failed']);
const stageLabels = {
 queued: 'งานอยู่ในคิว', starting_gpu: 'กำลังเริ่ม GPU', running: 'กำลังเตรียมวิดีโอ',
 analyzing: 'กำลังตรวจภาพและการเคลื่อนไหว', scene_generating: 'กำลังสร้างฉากเริ่มต้น',
 scene_validating: 'กำลังตรวจฉากและจำนวนคน', generating: 'กำลังสร้างวิดีโอ',
 finalizing: 'กำลังเตรียมวิดีโอ 10 วินาที', ready: 'กำลังเตรียมดาวน์โหลด',
 downloading: 'กำลังเก็บวิดีโอลงเครื่อง', stopping: 'กำลังหยุด GPU',
 succeeded: 'วิดีโอพร้อมแล้ว', completed: 'สร้างวิดีโอแล้ว', failed: 'สร้างวิดีโอไม่สำเร็จ',
 cancelled: 'ยกเลิกงานแล้ว', canceled: 'ยกเลิกงานแล้ว', interrupted: 'งานหยุดก่อนเสร็จ',
 stop_failed: 'ต้องตรวจการหยุด GPU'
};
const stageOrder = ['analyzing', 'scene_generating', 'scene_validating', 'generating', 'finalizing', 'downloading', 'stopping'];
let ready = false, busy = false, submitting = false, jobId = null, timer = null;
let videoSeconds = null, videoMetadataPending = false;
const previews = {}, fileErrors = {image: '', video: ''}, rendered = new Map();

async function api(path, body, raw = false) {
 const options = {credentials: 'same-origin', headers: {'X-Requested-With': 'MotionStudioAuto'}};
 if (body !== undefined) {
  options.method = 'POST'; options.body = raw ? body : JSON.stringify(body);
  if (!raw) options.headers['Content-Type'] = 'application/json';
 }
 const response = await fetch(root + '/api' + path, options);
 if (!response.ok) {
  let message = await response.text();
  try { message = JSON.parse(message).error || message; } catch {}
  const error = new Error(message); error.status = response.status; throw error;
 }
 return response.json();
}
function jobStage(job) {
 // A terminal server status takes precedence over an earlier progress stage.
 return job.status === 'stopping' || terminalStages.has(job.status) ? job.status : job.stage || job.status;
}
function isActive(job) {
 const stage = jobStage(job);
 return !terminalStages.has(stage) && (activeStages.has(stage) || activeStages.has(job.status));
}
function stopMessage(job) {
 if (job.terminate_confirmed === true) return 'ยืนยันว่า Terminate Pod แล้ว';
 if (job.gpu_stop_confirmed === true && job.terminate_confirmed === false)
  return 'GPU หยุดแล้ว แต่ยังเก็บ Pod ไว้กู้ไฟล์ ดิสก์ยังมีค่าใช้จ่าย';
 if (job.stop_confirmed === true) return 'ยืนยันว่าหยุด GPU แล้ว';
 if (job.retired_lease) return '';
 if (job.stop_confirmed === false || (job.result && job.remote_id))
  return 'ยังไม่ยืนยันว่าหยุด GPU แล้ว กรุณาตรวจสถานะใน Runpod Console';
 return '';
}
function durationProblem(seconds) {
 if (seconds < MIN_SOURCE_SECONDS) return 'ต้องใช้คลิปอย่างน้อย 10.1 วินาที เพื่อสร้างวิดีโอ 10 วินาที ระบบไม่ยืดหรือวนคลิป';
 if (seconds > MAX_SOURCE_SECONDS) return 'คลิปยาวเกิน 120 วินาที กรุณาตัดคลิปให้สั้นลงก่อนอัปโหลด';
 return '';
}
function fileProblem(kind, file) {
 if (!file) return '';
 const image = kind === 'image';
 const allowed = image ? ['image/jpeg', 'image/png'] : ['video/mp4'];
 const extension = image ? /\.(jpe?g|png)$/i : /\.mp4$/i;
 if (!allowed.includes(file.type) && (file.type || !extension.test(file.name)))
  return image ? 'กรุณาเลือกรูป JPG หรือ PNG' : 'กรุณาเลือกวิดีโอ MP4';
 if (file.size > (image ? 20 : 200) * 1024 * 1024)
  return image ? 'รูปใหญ่เกิน 20 MB กรุณาลดขนาดไฟล์' : 'วิดีโอใหญ่เกิน 200 MB กรุณาลดขนาดไฟล์';
 return '';
}
function selectionValid() {
 return $('image').files.length && $('video').files.length && !fileErrors.image && !fileErrors.video && !videoMetadataPending;
}
function enable() {
 $('generate').disabled = !ready || busy || submitting || !selectionValid();
 $('generate').textContent = submitting ? 'กำลังส่งไฟล์…' : busy ? 'กำลังทำงาน…' : 'สร้างวิดีโอ 10 วินาที';
 $('image').disabled = submitting; $('video').disabled = submitting;
}
function showFileInfo(kind) {
 const file = $(kind).files[0];
 const duration = kind === 'video' && videoSeconds !== null ? ' · ' + videoSeconds.toLocaleString('th-TH', {maximumFractionDigits: 2}) + ' วินาที' : '';
 $(kind + '-name').textContent = file ? file.name + ' · ' + (file.size / 1024 / 1024).toFixed(1) + ' MB' + duration : '';
 $(kind + '-error').textContent = fileErrors[kind];
 $(kind).setAttribute('aria-invalid', fileErrors[kind] ? 'true' : 'false');
}
for (const kind of ['image', 'video']) $(kind).addEventListener('change', () => {
 const preview = $(kind + '-preview');
 if (previews[kind]) URL.revokeObjectURL(previews[kind]);
 delete previews[kind]; preview.removeAttribute('src'); preview.hidden = true;
 const file = $(kind).files[0]; fileErrors[kind] = fileProblem(kind, file);
 if (kind === 'video') { videoSeconds = null; videoMetadataPending = Boolean(file && !fileErrors.video); }
 if (file && !fileErrors[kind]) {
  previews[kind] = URL.createObjectURL(file); preview.src = previews[kind]; preview.hidden = false;
 }
 showFileInfo(kind); enable();
});
$('video-preview').addEventListener('loadedmetadata', () => {
 const preview = $('video-preview');
 if (!previews.video || preview.currentSrc !== previews.video) return;
 videoMetadataPending = false;
 videoSeconds = Number.isFinite(preview.duration) ? preview.duration : null;
 fileErrors.video = fileProblem('video', $('video').files[0]) || (videoSeconds === null ? '' : durationProblem(videoSeconds));
 showFileInfo('video'); enable();
});
$('video-preview').addEventListener('error', () => {
 // Some valid MP4 codecs cannot be previewed by the browser; the server still checks the file before starting a job.
 videoMetadataPending = false; enable();
});
$('login-form').addEventListener('submit', async event => {
 event.preventDefault(); $('login-error').textContent = '';
 try { await api('/login', {code: $('code').value}); $('code').value = ''; await refresh(); }
 catch (error) { $('login-error').textContent = error.message; }
});
function setLeaseMode() {
 const fresh = $('lease-mode').value === 'fresh';
 $('fresh-settings').hidden = !fresh; $('manual-settings').hidden = fresh;
 for (const name of ['pod-url', 'pod-code']) $(name).disabled = fresh;
 for (const name of ['pod-image', 'hourly-ceiling']) $(name).disabled = !fresh;
}
$('lease-mode').addEventListener('change', setLeaseMode); setLeaseMode();
$('save-key').addEventListener('click', async () => {
 const button = $('save-key'); button.disabled = true; $('connection-error').textContent = '';
 try {
  const response = await api('/account-key', {api_key: $('runpod-key').value.trim()});
  $('runpod-key').value = ''; $('key-status').textContent = response.message; await refresh();
 } catch (error) { $('connection-error').textContent = error.message; }
 finally { button.disabled = false; }
});
$('connection-form').addEventListener('submit', async event => {
 event.preventDefault(); $('connection-error').textContent = '';
 const button = $('connection-form').querySelector('button'); button.disabled = true;
 try {
  const automaticKey = $('runpod-key').value.trim();
  if ($('lease-mode').value === 'fresh') {
   await api('/automation', {mode: 'fresh', image_name: $('pod-image').value.trim(),
    hourly_ceiling_usd: Number($('hourly-ceiling').value), api_key: automaticKey});
  } else {
   await api('/connection', {url: $('pod-url').value, access_code: $('pod-code').value});
  }
  $('pod-code').value = ''; $('runpod-key').value = '';
  $('connection-error').textContent = 'บันทึกแล้ว ยังไม่เริ่มเช่า ตรวจความพร้อมก่อนกดสร้างวิดีโอ';
  await refresh();
 } catch (error) { $('connection-error').textContent = error.message; }
 finally { button.disabled = false; }
});
function updateSteps(stage, stopConfirmed = false) {
 const index = stage === 'ready' ? stageOrder.indexOf('downloading') : stageOrder.indexOf(stage);
 const done = stage === 'succeeded' || stage === 'completed';
 for (const step of document.querySelectorAll('[data-stage]')) {
  const position = stageOrder.indexOf(step.dataset.stage);
  step.classList.toggle('current', position === index);
  step.classList.toggle('done', (done && (position < stageOrder.indexOf('stopping') || stopConfirmed)) || (index >= 0 && position < index));
  if (position === index) step.setAttribute('aria-current', 'step'); else step.removeAttribute('aria-current');
 }
}
function showJob(job) {
 const stage = jobStage(job);
 $('work').hidden = false;
 $('work-title').textContent = stageLabels[stage] || 'สถานะงาน';
 $('work-message').textContent = job.message || '';
 $('spinner').hidden = !isActive(job);
 $('work-stop').textContent = stopMessage(job);
 updateSteps(stage, job.stop_confirmed === true);
}
$('create-form').addEventListener('submit', async event => {
 event.preventDefault();
 if (!ready || busy || submitting || !selectionValid()) return;
 submitting = true; enable(); $('error').textContent = ''; $('work').hidden = false;
 $('spinner').hidden = false; $('work-stop').textContent = ''; updateSteps('uploading');
 try {
  $('work-title').textContent = 'กำลังส่งไฟล์'; $('work-message').textContent = 'อัปโหลดภาพอ้างอิง';
  const image = await api('/upload/image', $('image').files[0], true);
  $('work-message').textContent = 'อัปโหลดและตรวจความยาวคลิปการเคลื่อนไหว';
  const video = await api('/upload/video', $('video').files[0], true);
  const seconds = Number(video.duration);
  const problem = Number.isFinite(seconds) ? durationProblem(seconds) : '';
  if (problem) throw new Error(problem);
  const job = await api('/jobs', {image: image.id, video: video.id, duration: OUTPUT_SECONDS});
  jobId = job.id; busy = true; submitting = false; await refresh();
 } catch (error) {
  $('error').textContent = error.message; $('work').hidden = true;
 } finally { submitting = false; enable(); }
});
function renderJob(job) {
 let row = rendered.get(job.id);
 if (!row) {
  const box = document.createElement('article'); box.className = 'result';
  const detail = document.createElement('div'); detail.className = 'detail';
  const title = document.createElement('h3');
  const message = document.createElement('p');
  const stop = document.createElement('p'); stop.className = 'stop-status';
  const error = document.createElement('p'); error.className = 'error';
  const warning = document.createElement('p'); warning.className = 'notice';
  detail.append(title, message, error, warning, stop); box.append(detail);
  $('results').querySelector('.empty')?.remove(); $('results').prepend(box);
  row = {box, detail, title, message, error, warning, stop, player: null, evidence: null}; rendered.set(job.id, row);
 }
 row.title.textContent = stageLabels[jobStage(job)] || 'สถานะงาน';
 row.message.textContent = job.message || '';
 row.error.textContent = job.error_message ? 'สาเหตุ: ' + job.error_message : '';
 row.error.hidden = !job.error_message;
 row.warning.textContent = Array.isArray(job.generation_warnings) ? job.generation_warnings.join(' · ') : '';
 row.warning.hidden = !row.warning.textContent;
 row.stop.textContent = stopMessage(job);
 // Downloads can arrive after a result row already exists. Keep existing players intact while polling.
 if (job.result && !row.player) {
  const player = document.createElement('video'); player.controls = true; player.playsInline = true; player.preload = 'metadata';
  player.src = root + '/api/jobs/' + encodeURIComponent(job.id) + '/result';
  player.setAttribute('aria-label', 'วิดีโอที่สร้างแล้ว'); row.box.prepend(player);
  const link = document.createElement('a'); link.href = player.src;
  link.download = 'motion-studio-' + job.id + '.mp4'; link.textContent = 'ดาวน์โหลดวิดีโอ'; row.detail.append(link);
  row.player = player;
 }
 if (job.evidence_file && !row.evidence) {
  const evidence = document.createElement('div');
  const link = document.createElement('a');
  link.href = root + '/api/jobs/' + encodeURIComponent(job.id) + '/evidence';
  link.download = 'motion-studio-' + job.id + '-evidence.zip';
  link.textContent = 'ดาวน์โหลดชุด workflow และหลักฐาน';
  evidence.append(link); row.detail.append(evidence); row.evidence = evidence;
 }
 if (row.evidence) row.evidence.hidden = !job.evidence_file;
}
async function refresh() {
 clearTimeout(timer);
 try {
  const status = await api('/status'); $('login').hidden = true; $('studio').hidden = false;
  if (status.account_key_saved && !$('key-status').textContent)
   $('key-status').textContent = 'มี API key เข้ารหัสบน PC แล้ว ยังต้องยืนยันสิทธิ์จริงเมื่อเริ่มงาน';
  ready = status.ready === true; $('readiness').textContent = status.message || '';
  $('status-bar').classList.toggle('unavailable', !ready);
  $('connection').hidden = status.pc_controller !== true;
  if (status.pc_controller && status.connection_needed) $('connection').open = true;
  const jobs = Array.isArray(status.jobs) ? status.jobs : [];
  const unresolvedStop = jobs.some(job => !job.retired_lease &&
   (job.stop_confirmed === false || job.stop_observation_pending));
  if (unresolvedStop && !status.fresh_pod) {
   $('readiness').textContent = 'ต้องตรวจการหยุด GPU ของงานก่อนหน้า ก่อนเริ่มรอบใหม่';
   $('status-bar').classList.add('unavailable');
  }
  busy = jobs.some(isActive);
  const current = jobs.find(job => job.id === jobId && isActive(job)) || jobs.find(isActive) || jobs.find(job => job.id === jobId);
  if (current && !submitting) { jobId = current.id; showJob(current); }
  for (const job of [...jobs].reverse()) if (job.result || job.evidence_file || !isActive(job)) renderJob(job);
  enable(); timer = setTimeout(refresh, busy || submitting ? 3000 : 15000);
 } catch (error) {
  ready = false; enable();
  if (error.status === 401) { $('login').hidden = false; $('studio').hidden = true; }
  else {
   $('readiness').textContent = 'ติดต่อระบบไม่ได้ กำลังลองเชื่อมต่ออีกครั้ง';
   $('status-bar').classList.add('unavailable'); $('error').textContent = error.message;
   timer = setTimeout(refresh, 10000);
  }
 }
}
refresh();



