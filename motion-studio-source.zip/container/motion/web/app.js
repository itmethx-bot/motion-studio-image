'use strict';
const root = '/motion-studio';
const OUTPUT_SECONDS = 10;
const MIN_SOURCE_SECONDS = 1;
const MAX_SOURCE_SECONDS = 120;
const $ = id => document.getElementById(id);
const activeStages = new Set(['queued', 'starting_gpu', 'running', 'analyzing', 'scene_generating', 'scene_validating', 'generating', 'finalizing', 'ready', 'downloading']);
const terminalStages = new Set(['succeeded', 'completed', 'failed', 'cancelled', 'canceled', 'interrupted']);
const stageLabels = {
 queued: 'งานอยู่ในคิว', starting_gpu: 'กำลังเริ่ม GPU', running: 'กำลังเตรียมวิดีโอ',
 analyzing: 'กำลังตรวจภาพและการเคลื่อนไหว', scene_generating: 'กำลังสร้างฉากเริ่มต้น',
 scene_validating: 'กำลังตรวจฉากและจำนวนคน', generating: 'กำลังสร้างวิดีโอ',
 finalizing: 'กำลังเตรียมไฟล์วิดีโอ', ready: 'กำลังเตรียมดาวน์โหลด',
 downloading: 'กำลังเก็บวิดีโอลงเครื่อง',
 succeeded: 'วิดีโอพร้อมแล้ว', completed: 'สร้างวิดีโอแล้ว', failed: 'สร้างวิดีโอไม่สำเร็จ',
 cancelled: 'ยกเลิกงานแล้ว', canceled: 'ยกเลิกงานแล้ว', interrupted: 'งานหยุดก่อนเสร็จ'
};
const stageOrder = ['analyzing', 'scene_generating', 'scene_validating', 'generating', 'finalizing', 'downloading'];
let ready = false, busy = false, submitting = false, jobId = null, timer = null;
let videoSeconds = null, videoMetadataPending = false;
const previews = {}, fileErrors = {image: '', video: ''}, rendered = new Map();
async function api(path, body, raw = false) {
 const options = {credentials: 'same-origin', headers: {'X-Requested-With': 'MotionStudioAuto'}};
 if (body !== undefined) {
  options.method = 'POST'; options.body = raw ? body : JSON.stringify(body);
  if (!raw) options.headers['Content-Type'] = 'application/json';
 }
 const response = await fetch(root + '/api' + path, options);
 if (!response.ok) {
  let message = await response.text();
  try { message = JSON.parse(message).error || message; } catch {}
  const error = new Error(message); error.status = response.status; throw error;
 }
 return response.json();
}
function jobStage(job) {
 // A terminal server status takes precedence over an earlier progress stage.
 return terminalStages.has(job.status) ? job.status : job.stage || job.status;
}
function isActive(job) {
 const stage = jobStage(job);
 return !terminalStages.has(stage) && (activeStages.has(stage) || activeStages.has(job.status));
}
function stopMessage(job) {
 return job.session_mode === 'manual_session' ? 'Pod ยังเปิดอยู่ — เมื่อเลิกใช้ให้ Stop และ Terminate เองใน RunPod' : '';
}
function durationProblem(seconds) {
 if (seconds < MIN_SOURCE_SECONDS) return 'กรุณาใช้คลิปอย่างน้อย 1 วินาที ระบบไม่ยืดหรือวนคลิป';
 if (seconds > MAX_SOURCE_SECONDS) return 'คลิปยาวเกิน 120 วินาที กรุณาตัดคลิปให้สั้นลงก่อนอัปโหลด';
 return '';
}
function fileProblem(kind, file) {
 if (!file) return '';
 const image = kind === 'image';
 const allowed = image ? ['image/jpeg', 'image/png'] : ['video/mp4'];
 const extension = image ? /\.(jpe?g|png)$/i : /\.mp4$/i;
 if (!allowed.includes(file.type) && (file.type || !extension.test(file.name)))
  return image ? 'กรุณาเลือกรูป JPG หรือ PNG' : 'กรุณาเลือกวิดีโอ MP4';
 if (file.size > (image ? 20 : 200) * 1024 * 1024)
  return image ? 'รูปใหญ่เกิน 20 MB กรุณาลดขนาดไฟล์' : 'วิดีโอใหญ่เกิน 200 MB กรุณาลดขนาดไฟล์';
 return '';
}
function selectionValid() {
 return $('image').files.length && $('video').files.length && !fileErrors.image && !fileErrors.video && !videoMetadataPending;
}
function enable() {
 $('generate').disabled = !ready || busy || submitting || !selectionValid();
 const seconds = videoSeconds !== null && !fileErrors.video ? Math.floor(Math.min(videoSeconds, OUTPUT_SECONDS) * 16 + 1e-9) / 16 : null;
 const label = seconds === null ? 'สูงสุด 10' : seconds.toLocaleString('th-TH', {maximumFractionDigits: 4});
 $('output-duration').textContent = label;
 $('generate').textContent = submitting ? 'กำลังส่งไฟล์…' : busy ? 'กำลังทำงาน…' : 'สร้างวิดีโอ ' + label + ' วินาที';
 $('image').disabled = submitting; $('video').disabled = submitting;
 $('pod-url').disabled = busy || submitting;
 $('connection-form').querySelector('button').disabled = busy || submitting;
}
function showFileInfo(kind) {
 const file = $(kind).files[0];
 const duration = kind === 'video' && videoSeconds !== null ? ' · ' + videoSeconds.toLocaleString('th-TH', {maximumFractionDigits: 2}) + ' วินาที' : '';
 $(kind + '-name').textContent = file ? file.name + ' · ' + (file.size / 1024 / 1024).toFixed(1) + ' MB' + duration : '';
 $(kind + '-error').textContent = fileErrors[kind];
 $(kind).setAttribute('aria-invalid', fileErrors[kind] ? 'true' : 'false');
}
for (const kind of ['image', 'video']) $(kind).addEventListener('change', () => {
 const preview = $(kind + '-preview');
 if (previews[kind]) URL.revokeObjectURL(previews[kind]);
 delete previews[kind]; preview.removeAttribute('src'); preview.hidden = true;
 const file = $(kind).files[0]; fileErrors[kind] = fileProblem(kind, file);
 if (kind === 'video') { videoSeconds = null; videoMetadataPending = Boolean(file && !fileErrors.video); }
 if (file && !fileErrors[kind]) {
  previews[kind] = URL.createObjectURL(file); preview.src = previews[kind]; preview.hidden = false;
 }
 showFileInfo(kind); enable();
});
$('video-preview').addEventListener('loadedmetadata', () => {
 const preview = $('video-preview');
 if (!previews.video || preview.currentSrc !== previews.video) return;
 videoMetadataPending = false;
 videoSeconds = Number.isFinite(preview.duration) ? preview.duration : null;
 fileErrors.video = fileProblem('video', $('video').files[0]) || (videoSeconds === null ? '' : durationProblem(videoSeconds));
 showFileInfo('video'); enable();
});
$('video-preview').addEventListener('error', () => {
 // Some valid MP4 codecs cannot be previewed by the browser; the server still checks the file before starting a job.
 videoMetadataPending = false; enable();
});
$('login-form').addEventListener('submit', async event => {
 event.preventDefault(); $('login-error').textContent = '';
 try { await api('/login', {code: $('code').value}); $('code').value = ''; await refresh(); }
 catch (error) { $('login-error').textContent = error.message; }
});
$('prepare-template').addEventListener('click', async () => {
 const button = $('prepare-template'); button.disabled = true; $('template-error').textContent = '';
 try {
  const setup = await api('/template');
  $('template-values').value = [
   'Template name: ' + setup.name, 'Container image: ' + setup.image_name,
   'Container disk: ' + setup.container_gb + ' GB', 'Volume disk: ' + setup.volume_gb + ' GB',
   'Network Volume: ไม่ใช้', 'HTTP port: 8188',
   'Container Start Command: เว้นว่าง ใช้ค่าเริ่มต้นของ image', '',
   'Environment variables:', ...Object.entries(setup.env).map(([name,value]) => name + '=' + value)
  ].join('\n');
  $('template-values').hidden = false;
 } catch (error) { $('template-error').textContent = error.message; }
 finally { button.disabled = false; }
});
$('connection-form').addEventListener('submit', async event => {
 event.preventDefault(); $('connection-error').textContent = '';
 const button = $('connection-form').querySelector('button'); button.disabled = true;
 try {
  const result = await api('/connection', {url: $('pod-url').value.trim()});
  $('connection-error').textContent = result.message;
  await refresh();
 } catch (error) { $('connection-error').textContent = error.message; }
 finally { button.disabled = busy || submitting; }
});
function updateSteps(stage) {
 const index = stage === 'ready' ? stageOrder.indexOf('downloading') : stageOrder.indexOf(stage);
 const done = stage === 'succeeded' || stage === 'completed';
 for (const step of document.querySelectorAll('[data-stage]')) {
  const position = stageOrder.indexOf(step.dataset.stage);
  step.classList.toggle('current', position === index);
  step.classList.toggle('done', done || (index >= 0 && position < index));
  if (position === index) step.setAttribute('aria-current', 'step'); else step.removeAttribute('aria-current');
 }
}
function showJob(job) {
 const stage = jobStage(job);
 $('work').hidden = false;
 $('work-title').textContent = stageLabels[stage] || 'สถานะงาน';
 $('work-message').textContent = job.message || '';
 $('spinner').hidden = !isActive(job);
 $('work-stop').textContent = stopMessage(job);
 updateSteps(stage);
}
$('create-form').addEventListener('submit', async event => {
 event.preventDefault();
 if (!ready || busy || submitting || !selectionValid()) return;
 submitting = true; enable(); $('error').textContent = ''; $('work').hidden = false;
 $('spinner').hidden = false; $('work-stop').textContent = ''; updateSteps('uploading');
 try {
  $('work-title').textContent = 'กำลังส่งไฟล์'; $('work-message').textContent = 'อัปโหลดภาพอ้างอิง';
  const image = await api('/upload/image', $('image').files[0], true);
  $('work-message').textContent = 'อัปโหลดและตรวจความยาวคลิปการเคลื่อนไหว';
  const video = await api('/upload/video', $('video').files[0], true);
  const seconds = Number(video.duration);
  const problem = Number.isFinite(seconds) ? durationProblem(seconds) : '';
  if (problem) throw new Error(problem);
  const job = await api('/jobs', {image: image.id, video: video.id, duration: OUTPUT_SECONDS});
  jobId = job.id; busy = true; submitting = false; await refresh();
 } catch (error) {
  $('error').textContent = error.message; $('work').hidden = true;
 } finally { submitting = false; enable(); }
});
function renderJob(job) {
 let row = rendered.get(job.id);
 if (!row) {
  const box = document.createElement('article'); box.className = 'result';
  const detail = document.createElement('div'); detail.className = 'detail';
  const title = document.createElement('h3');
  const message = document.createElement('p');
  const stop = document.createElement('p'); stop.className = 'stop-status';
  const error = document.createElement('p'); error.className = 'error';
  const warning = document.createElement('p'); warning.className = 'notice';
  detail.append(title, message, error, warning, stop); box.append(detail);
  $('results').querySelector('.empty')?.remove(); $('results').prepend(box);
  const recover = document.createElement('button'); recover.type = 'button'; recover.textContent = 'ตรวจงานและกู้ผลเดิม'; recover.hidden = true; detail.append(recover);
  recover.addEventListener('click', async () => {
   recover.disabled = true;
   try { await api('/jobs/' + encodeURIComponent(job.id) + '/recover', {}); jobId = job.id; await refresh(); }
   catch (error) { $('error').textContent = error.message; }
   finally { recover.disabled = busy; }
  });
  row = {box, detail, title, message, error, warning, stop, recover, player: null, evidence: null}; rendered.set(job.id, row);
 }
 const previousMode = job.session_mode !== 'manual_session';
 row.title.textContent = previousMode ? 'วิดีโอที่บันทึกไว้ก่อนเปลี่ยนโหมด' : stageLabels[jobStage(job)] || 'สถานะงาน';
 row.message.textContent = previousMode ? 'ไฟล์เดิมบน PC เปิดและดาวน์โหลดได้' : job.message || '';
 row.error.textContent = !previousMode && job.error_message ? 'สาเหตุ: ' + job.error_message : '';
 row.error.hidden = !row.error.textContent;
 row.warning.textContent = !previousMode && Array.isArray(job.generation_warnings) ? job.generation_warnings.join(' · ') : '';
 row.warning.hidden = !row.warning.textContent;
 row.stop.textContent = stopMessage(job);
 row.recover.hidden = !job.recoverable; row.recover.disabled = busy || submitting;
 // Downloads can arrive after a result row already exists. Keep existing players intact while polling.
 if (job.result && !row.player) {
  const player = document.createElement('video'); player.controls = true; player.playsInline = true; player.preload = 'metadata';
  player.src = root + '/api/jobs/' + encodeURIComponent(job.id) + '/result';
  player.setAttribute('aria-label', 'วิดีโอที่สร้างแล้ว'); row.box.prepend(player);
  const link = document.createElement('a'); link.href = player.src;
  link.download = 'motion-studio-' + job.id + '.mp4'; link.textContent = 'ดาวน์โหลดวิดีโอ'; row.detail.append(link);
  row.player = player;
 }
 if (job.evidence_file && !row.evidence) {
  const evidence = document.createElement('div');
  const link = document.createElement('a');
  link.href = root + '/api/jobs/' + encodeURIComponent(job.id) + '/evidence';
  link.download = 'motion-studio-' + job.id + '-evidence.zip';
  link.textContent = 'ดาวน์โหลดชุด workflow และหลักฐาน';
  evidence.append(link); row.detail.append(evidence); row.evidence = evidence;
 }
 if (row.evidence) row.evidence.hidden = !job.evidence_file;
}
async function refresh() {
 clearTimeout(timer);
 try {
  const status = await api('/status'); $('login').hidden = true; $('studio').hidden = false;
  ready = status.ready === true; $('readiness').textContent = status.message || '';
  $('connection').hidden = status.pc_controller !== true;
  $('status-bar').classList.toggle('unavailable', !ready);
  if (status.connected_url && !$('pod-url').value && document.activeElement !== $('pod-url'))
   $('pod-url').value = status.connected_url;
  const jobs = Array.isArray(status.jobs) ? status.jobs : [];
  const unresolved = jobs.some(job => job.recoverable && job.remote_url === status.connected_url);
  if (unresolved) {
   ready = false; $('readiness').textContent = 'มีงานเดิมที่ต้องตรวจหรือกู้ผลก่อนส่งคลิปใหม่';
   $('status-bar').classList.add('unavailable');
  }
  busy = jobs.some(isActive);
  const current = jobs.find(job => job.id === jobId && isActive(job)) || jobs.find(isActive) || jobs.find(job => job.id === jobId);
  if (current && !submitting) { jobId = current.id; showJob(current); }
  for (const job of [...jobs].reverse()) if (job.result || job.evidence_file || !isActive(job)) renderJob(job);
  $('pod-url').disabled = busy || submitting;
  $('connection-form').querySelector('button').disabled = busy || submitting;
  enable(); timer = setTimeout(refresh, busy || submitting ? 3000 : 15000);
 } catch (error) {
  ready = false; enable();
  if (error.status === 401) { $('login').hidden = false; $('studio').hidden = true; }
  else {
   $('readiness').textContent = 'ติดต่อระบบไม่ได้ กำลังลองเชื่อมต่ออีกครั้ง';
   $('status-bar').classList.add('unavailable'); $('error').textContent = error.message;
   timer = setTimeout(refresh, 10000);
  }
 }
}
refresh();



