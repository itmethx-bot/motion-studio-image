"""Fresh per-job Pods. No network volumes, provider keys on GPU, or POST replay.

All API calls are made by the user's PC application after configuration. Import,
configuration, and server startup never rent a Pod. A controller crash stops
GPU billing but preserves an unreceived output on the Pod's ordinary disk.
"""
import asyncio
import hashlib
import math
import os
from pathlib import Path
import re
import secrets
import time
import zipfile

IMAGE=re.compile(r'^[a-z0-9][a-z0-9./_:-]{1,240}@sha256:[a-f0-9]{64}$')
ID=re.compile(r'^[a-zA-Z0-9]{8,40}$')
JOB=re.compile(r'^[a-f0-9]{32}$')


def number(value):
    if isinstance(value,bool):return 0.
    try:value=float(value)
    except (TypeError,ValueError):return 0.
    return value if math.isfinite(value) and value>0 else 0.


class FreshPodLifecycle:
    def configure_fresh(self,image,api_key='',*,hourly_ceiling=1.5):
        from .provider import protect
        from .service import atomic_json
        if self.lease().get('cleanup_pending'):raise ValueError('ยังต้องจัดการ Pod ของรอบเดิมก่อนเปลี่ยนการตั้งค่า')
        if not isinstance(image,str) or not IMAGE.fullmatch(image):
            raise ValueError('ต้องระบุ Docker image ของ Motion Studio ที่เผยแพร่แล้วพร้อม @sha256:digest')
        ceiling=number(hourly_ceiling)
        if not .1<=ceiling<=10:raise ValueError('ค่าเช่าต่อชั่วโมงสูงสุดต้องอยู่ระหว่าง $0.10–$10')
        if api_key:
            if not isinstance(api_key,str) or not 16<=len(api_key)<=512 or any(c.isspace() for c in api_key):
                raise ValueError('API key ไม่ถูกต้อง')
            temp=self.key_path.with_suffix('.tmp');temp.write_bytes(protect(api_key.encode()))
            os.replace(temp,self.key_path)
        if not self.key_path.is_file():raise ValueError('กรุณาใส่ RunPod API key ของบัญชีในช่องบน PC')
        atomic_json(self.config_path,{'mode':'fresh','enabled':True,'image_name':image,
            'gpu_type':'NVIDIA A40','volume_gb':100,'container_gb':30,
            'hourly_ceiling_usd':ceiling,'max_runtime_seconds':10800,
            'bootstrap_seconds':3600,'network_volume':False,'cleanup_owner':'pc',
            'live_lifecycle_verified':False})

    def fresh_public(self):
        config=self.config();row=self.lease()
        enabled=bool(config.get('enabled') and self.key_path.is_file() and IMAGE.fullmatch(config.get('image_name','')))
        pending=row.get('cleanup_pending',False)
        return {'auto_lease':enabled,'ready':enabled and not pending,'connection_needed':not enabled,
            'account_key_saved':self.key_path.is_file(),
            'cleanup_pending':pending,'automatic_stop_ready':enabled,'fresh_pod':True,
            'terminate_after_job':True,'network_volume':False,
            'live_lifecycle_verified':bool(config.get('live_lifecycle_verified')),
            'message':('ยังต้องยืนยันหยุด/ลบ Pod รอบเดิม หรือกู้ไฟล์ที่ยังส่งไม่ครบ' if pending else
                'พร้อมสร้าง Pod ใหม่เมื่อกดสร้าง บันทึกผลลง PC แล้ว Terminate; สิทธิ์จริงจะตรวจเมื่อเริ่มงาน' if enabled else
                'บันทึก API key บน PC แล้ว รอ Docker image ของระบบก่อนสร้างวิดีโอ' if self.key_path.is_file() else
                'เตรียมโหมด Pod ใหม่ทุกงานแล้ว ต้องตั้งค่า image และ API key บน PC ก่อน')}

    async def account_check(self):
        result=await self.call('POST','graphql',{'query':'query { myself { clientBalance isAutoPayEnabled } }'})
        account=result.get('data',{}).get('myself',{})
        if account.get('isAutoPayEnabled') is not False:raise ValueError('ต้องปิดการเติมเงินอัตโนมัติก่อนเริ่มเช่า')
        credits=number(account.get('clientBalance'))
        if not credits:raise ValueError('อ่านเครดิตไม่ได้หรือเครดิตหมด จึงยังไม่เริ่มเช่า')
        return credits

    async def listed_pods(self):
        pods=await self.call('GET','/pods?includeNetworkVolume=true')
        if not isinstance(pods,list) or any(not isinstance(p,dict) or not ID.fullmatch(p.get('id','')) for p in pods):
            raise ValueError('อ่านรายการ Pod ไม่ครบ จึงยังไม่ยืนยันการสร้างหรือลบ')
        return pods

    @staticmethod
    def owns(row,pod):
        env=pod.get('env',{})
        return (isinstance(env,dict) and row.get('mode')=='fresh'
            and pod.get('id')==row.get('pod_id') and pod.get('name')==row.get('name')
            and env.get('MOTION_LEASE_NONCE')==row.get('nonce')
            and env.get('MOTION_PC_JOB')==row.get('job_id')
            and env.get('MOTION_CLEANUP_OWNER')=='pc'
            and (pod.get('imageName') or pod.get('image'))==row.get('image_name')
            and not pod.get('networkVolume') and not pod.get('networkVolumeId'))

    async def acquire_fresh(self,job_id,persist):
        from .service import atomic_json
        if not JOB.fullmatch(job_id):raise ValueError('หมายเลขงานไม่ถูกต้อง')
        async with self.lifecycle_lock():
            if not self.fresh_public()['ready']:raise ValueError(self.fresh_public()['message'])
            config=self.config();credits=await self.account_check()
            await self.listed_pods()  # Check account read access BEFORE allocating.
            # Reserve disk charges and a margin. No fixed $1/job cap and no top-up.
            ceiling=number(config.get('hourly_ceiling_usd'))
            allowance=min(10800,int(credits*.70/(ceiling+.10)*3600))
            if allowance<7200:raise ValueError('เครดิตไม่พอเผื่อดาวน์โหลดโมเดลใหม่และเรนเดอร์อย่างน้อย 2 ชั่วโมง จึงยังไม่เช่า')
            now=time.time();nonce=secrets.token_hex(16);code=secrets.token_urlsafe(24)
            row={'mode':'fresh','job_id':job_id,'pod_id':'','name':'motion-'+job_id+'-'+nonce[:12],
                'nonce':nonce,'image_name':config['image_name'],'cleanup_pending':True,
                'started_at':now,'deadline':now+allowance,'state':'create_pending',
                'handoff_verified':False,'no_result_confirmed':True}
            atomic_json(self.ledger_path,row);persist(row)
            self.start_guard(job_id)  # Includes ambiguous allocation on POST timeout.
            body={'name':row['name'],'cloudType':'SECURE','computeType':'GPU','gpuCount':1,
                'gpuTypeIds':['NVIDIA A40'],'gpuTypePriority':'availability','interruptible':False,
                'imageName':config['image_name'],'containerDiskInGb':30,'volumeInGb':100,
                'volumeMountPath':'/workspace','minRAMPerGPU':64,'minVCPUPerGPU':8,
                'ports':['8188/http'],'dockerEntrypoint':['python','/opt/motion/pod_bootstrap.py'],'dockerStartCmd':[],
                'env':{'MOTION_CLEANUP_OWNER':'pc','MOTION_LEASE_NONCE':nonce,
                    'MOTION_PC_JOB':job_id,'MOTION_ACCESS_CODE':code,'MOTION_COMFY_PORT':'8188'}}
            try:pod=await self.call('POST','/pods',body)
            except Exception as error:
                row.update(state='create_unknown',last_error=str(error) if isinstance(error,ValueError) else type(error).__name__)
                atomic_json(self.ledger_path,row)
                # A definitive auth rejection cannot have created a Pod. A timeout
                # or server error can, and must NEVER trigger a second create.
                if getattr(error,'status',None) in (400,401,403,422):
                    row.update(cleanup_pending=False,state='create_rejected');atomic_json(self.ledger_path,row)
                raise
            if not isinstance(pod,dict) or not ID.fullmatch(pod.get('id','')):
                row['state']='create_unknown';atomic_json(self.ledger_path,row)
                raise ValueError('คำขอสร้างส่งแล้วแต่ไม่ได้รหัส Pod ห้ามกดสร้างซ้ำจนตรวจบัญชีสำเร็จ')
            row.update(pod_id=pod['id'],state='bootstrapping');atomic_json(self.ledger_path,row);persist(row)
            inspected=await self.call('GET','/pods/'+row['pod_id']+'?includeNetworkVolume=true')
            if not self.owns(row,inspected):raise ValueError('ข้อมูลเจ้าของหรือพื้นที่เก็บ Pod ไม่ตรง จึงไม่ส่งไฟล์หรือสั่งลบ')
            hourly=number(inspected.get('adjustedCostPerHr') or inspected.get('costPerHr'))
            if not hourly or hourly>ceiling:raise ValueError('ค่าเช่า Pod จริงไม่ตรงเพดานต่อชั่วโมง ระบบจะหยุดเครื่องของงานนี้')
            row['hourly_usd']=hourly;atomic_json(self.ledger_path,row)
            # App code is per-lease and is not the account API key.
            atomic_json(self.data/'pod-connection.json',{'url':'https://'+row['pod_id']+'-8188.proxy.runpod.net','access_code':code})
            persist(row);return row

    def record_handoff(self,job_id,result,evidence):
        from .service import atomic_json
        row=self.lease()
        if row.get('job_id')!=job_id or row.get('mode')!='fresh':raise ValueError('รอบเช่าเปลี่ยนระหว่างบันทึกไฟล์')
        files=[];root=(self.data/'output').resolve()
        for name in (result,evidence):
            path=root/name
            if path.is_symlink() or path.resolve().parent!=root or not path.is_file():raise ValueError('ไฟล์ส่งมอบไม่อยู่บน PC')
            files.append({'name':name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        with zipfile.ZipFile(root/evidence) as proof:
            if sum(item.file_size for item in proof.infolist())>128*1024*1024:
                raise ValueError('หลักฐาน ZIP ใหญ่เกินกำหนดหลังคลายข้อมูล')
            if proof.testzip() is not None:raise ValueError('หลักฐาน ZIP ไม่สมบูรณ์')
        row.update(handoff_verified=True,handoff_files=files,handoff_at=time.time())
        atomic_json(self.ledger_path,row)

    def handoff_intact(self,row):
        try:
            files=row.get('handoff_files',[]);root=(self.data/'output').resolve()
            if not row.get('handoff_verified') or len(files)!=2:return False
            for item in files:
                path=root/item['name']
                if path.is_symlink() or path.resolve().parent!=root or not path.is_file():return False
                if path.stat().st_size!=item['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:return False
            return True
        except (OSError,KeyError,TypeError,ValueError):return False

    def record_no_result(self,job_id,remote):
        from .service import atomic_json
        row=self.lease()
        if (row.get('mode')=='fresh' and row.get('job_id')==job_id and remote.get('result') is None
                and remote.get('render_status')=='failed' and JOB.fullmatch(remote.get('instance_id',''))):
            row['no_result_confirmed']=True;atomic_json(self.ledger_path,row)

    def before_submit(self,job_id):
        from .service import atomic_json
        row=self.lease()
        if row.get('mode')=='fresh' and row.get('job_id')==job_id:
            row['no_result_confirmed']=False;atomic_json(self.ledger_path,row)

    async def cleanup_fresh(self,job_id):
        from .service import atomic_json
        async with self.lifecycle_lock():
            row=self.lease()
            if row.get('job_id')!=job_id:return False
            if not row.get('cleanup_pending'):return row.get('state') in ('terminated','create_rejected')
            try:
                if not row.get('pod_id'):
                    matches=[]
                    for pod in await self.listed_pods():
                        candidate={**row,'pod_id':pod['id']}
                        if self.owns(candidate,pod):matches.append(pod)
                    if len(matches)!=1:raise ValueError('ยังระบุ Pod ของคำขอสร้างไม่ได้ ห้ามสร้างซ้ำหรือเลือก Pod อื่นแทน')
                    row['pod_id']=matches[0]['id'];atomic_json(self.ledger_path,row)
                path='/pods/'+row['pod_id']
                try:pod=await self.call('GET',path+'?includeNetworkVolume=true')
                except ValueError as error:
                    if getattr(error,'status',None)!=404:raise
                    if any(p['id']==row['pod_id'] for p in await self.listed_pods()):raise ValueError('สถานะลบยังไม่ตรงกัน')
                    # Only a known DELETE intent or confirmed provider absence
                    # for the bound created Pod is accepted; never infer from proxy.
                    row.update(state='terminated',cleanup_pending=False,terminated_at=time.time())
                    atomic_json(self.ledger_path,row);return True
                if not self.owns(row,pod):raise ValueError('Pod ไม่ตรงหลักฐานเจ้าของ จึงไม่หยุดหรือลบ')
                if pod.get('desiredStatus') not in ('EXITED','STOPPED'):
                    await self.call('POST',path+'/stop')
                for _ in range(12):
                    pod=await self.call('GET',path+'?includeNetworkVolume=true')
                    if not self.owns(row,pod):raise ValueError('Pod เปลี่ยนเจ้าของระหว่างหยุด')
                    if pod.get('desiredStatus') in ('EXITED','STOPPED'):break
                    await asyncio.sleep(2)
                else:raise ValueError('RunPod ยังไม่ยืนยันหยุด GPU')
                row['gpu_stop_confirmed']=True
                # Never destroy incomplete downloads. A crashed controller may
                # resume recovery or the user may download from the stopped Pod.
                if not self.handoff_intact(row) and not row.get('no_result_confirmed'):
                    row.update(state='stopped_awaiting_backup',last_error='GPU หยุดแล้ว แต่ไฟล์ยังส่งไม่ครบ จึงเก็บ Pod ไว้กู้ไฟล์; ดิสก์ยังมีค่าใช้จ่าย')
                    atomic_json(self.ledger_path,row);return False
                row['state']='delete_pending';atomic_json(self.ledger_path,row)
                await self.call('DELETE',path)
                for _ in range(12):
                    try:await self.call('GET',path+'?includeNetworkVolume=true')
                    except ValueError as error:
                        if getattr(error,'status',None)!=404:raise
                        if not any(p['id']==row['pod_id'] for p in await self.listed_pods()):
                            row.update(state='terminated',cleanup_pending=False,terminated_at=time.time())
                            atomic_json(self.ledger_path,row)
                            config=self.config();config['live_lifecycle_verified']=True
                            atomic_json(self.config_path,config);return True
                    await asyncio.sleep(2)
                raise ValueError('ส่งคำสั่ง Terminate แล้วแต่ยังไม่ยืนยันว่าลบสำเร็จ')
            except Exception as error:
                row['last_error']=str(error) if isinstance(error,ValueError) else type(error).__name__
                row['error_http_status']=getattr(error,'status',None)
                atomic_json(self.ledger_path,row);return False
