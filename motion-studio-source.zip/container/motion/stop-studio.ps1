$ErrorActionPreference = 'Stop'
$studioRoot = $PSScriptRoot
$recordPath = Join-Path $studioRoot 'private-data\server-process.json'
if (-not (Test-Path -LiteralPath $recordPath)) { exit 0 }
$record = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
$ownedProcess = Get-Process -Id $record.pid -ErrorAction SilentlyContinue
if (-not $ownedProcess) { exit 0 }
$expectedTime = ([datetime]$record.startedUtc).ToUniversalTime()
$scriptPath = Join-Path $studioRoot 'preview_server.py'
$commandLine = (Get-CimInstance Win32_Process -Filter ('ProcessId=' + $record.pid)).CommandLine
if ([Math]::Abs(($ownedProcess.StartTime.ToUniversalTime() - $expectedTime).TotalSeconds) -gt 1 -or -not $commandLine.Contains($scriptPath)) { throw 'Process identity mismatch. Nothing stopped.' }
# Keep synchronized with service.ACTIVE_STATUSES; a staged render or transfer
# must finish before its PC controller can be stopped.
$activeStatuses = @('queued','starting_gpu','running','analyzing','scene_generating','scene_validating','generating','finalizing','downloading','ready','stopping')
$activeJobs = Get-ChildItem -LiteralPath (Join-Path $studioRoot 'private-data\jobs') -Filter '*.json' | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json } | Where-Object { $_.status -in $activeStatuses }
if ($activeJobs) { throw 'Wait for the current job to finish and receive the result before stopping the PC controller.' }
$children = Get-CimInstance Win32_Process -Filter ('ParentProcessId=' + $record.pid)
foreach ($child in $children) {
    $isConsoleHost = $child.ExecutablePath -eq (Join-Path $env:SystemRoot 'System32\conhost.exe')
    if (-not $isConsoleHost -and -not $child.CommandLine.Contains($scriptPath)) { throw 'Unexpected child process. Nothing stopped.' }
}
foreach ($studioChild in ($children | Where-Object Name -eq 'python.exe')) {
    $verifiedChildProcess = [System.Diagnostics.Process]::GetProcessById([int]$studioChild.ProcessId)
    if (-not $verifiedChildProcess.HasExited) { $verifiedChildProcess.Kill(); $verifiedChildProcess.WaitForExit(5000) | Out-Null }
}
if (-not $ownedProcess.HasExited) { $ownedProcess.Kill(); $ownedProcess.WaitForExit(5000) | Out-Null }
