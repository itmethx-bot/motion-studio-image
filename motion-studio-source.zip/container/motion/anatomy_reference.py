"""Bounded primary-person geometry evidence for full-scene generation.

These panels condition a generator. They are never output-video patches, and
they do not detect individual organs, certify skin tone, or recover true 3-D
body measurements from a single photograph.
"""
import math

import numpy as np


def _bounds(mask):
    ys, xs = np.nonzero(mask)
    if not len(xs):
        return None
    return int(xs.min()), int(ys.min()), int(xs.max() + 1), int(ys.max() + 1)


def _mask(value, shape, name):
    array = np.asarray(value)
    if array.shape != shape or not np.issubdtype(array.dtype, np.number) and array.dtype != bool:
        raise ValueError(f'{name} dimensions or type are invalid')
    if array.dtype == bool:
        # All booleans are finite. Reuse the read-only input rather than copying
        # a complete source-video mask merely to validate its type.
        return array
    planes = array if array.ndim == 3 else (array,)
    if any(not np.isfinite(plane).all() for plane in planes):
        raise ValueError(f'{name} must contain finite values')
    return np.asarray(array > .5, dtype=bool)


def _image(value, shape, name, *, clip=True):
    array = np.asarray(value)
    if array.shape != shape or not np.issubdtype(array.dtype, np.number):
        raise ValueError(f'{name} dimensions or type are invalid')
    # Lanczos4 fitting can ring slightly below zero or above one. Accept the
    # bounded interpolation envelope, but reject nonfinite/incorrect RGB scales.
    # Validate one frame at a time: a 161x704x1280 sequence must not require a
    # video-sized isfinite temporary or an additional clipped RGB sequence.
    planes = array if array.ndim == 4 else (array,)
    for plane in planes:
        if not np.isfinite(plane).all() or plane.min() < -.25 or plane.max() > 1.25:
            raise ValueError(f'{name} must contain finite normalized RGB values within the interpolation range [-.25, 1.25]')
    return np.clip(array, 0, 1).astype(np.float32, copy=False) if clip else array


def match_person_face(image_mask, boxes):
    """Return one upper-person face rectangle, or None if evidence is weak.

    Membership and upper-body position are geometric checks. They do not verify
    face identity or prove that the supplied detector found an actual face.
    Malformed or out-of-frame detector boxes are ignored.
    """
    raw = np.asarray(image_mask)
    if raw.ndim != 2:
        raise ValueError('Face membership needs a two-dimensional person mask')
    person = _mask(raw, raw.shape, 'person mask')
    body = _bounds(person)
    if body is None:
        return None
    h, w = person.shape
    top, bottom = body[1], body[3]
    candidates = []
    for box in (() if boxes is None else boxes):
        try:
            values = tuple(float(value) for value in box)
        except (TypeError, ValueError, OverflowError):
            continue
        if len(values) != 4 or not all(math.isfinite(value) for value in values):
            continue
        x, y, fw, fh = tuple(round(value) for value in values)
        if fw < 2 or fh < 2 or x < 0 or y < 0 or x + fw > w or y + fh > h:
            continue
        if y + fh / 2 > top + .55 * (bottom - top):
            continue
        coverage = float(person[y:y+fh, x:x+fw].mean())
        if coverage >= .60:
            candidates.append((fw * fh, coverage, -y, -x, (x, y, fw, fh)))
    return max(candidates)[-1] if candidates else None


def _selected_frames(areas):
    """First, best, and late visible evidence, with a middle view when needed."""
    active = np.flatnonzero(areas >= 16)
    if not len(active):
        return []
    best = int(active[np.argmax(areas[active])])
    chosen = {int(active[0]), best, int(active[-1])}
    if len(chosen) < min(3, len(active)):
        unused = [int(k) for k in active if int(k) not in chosen]
        middle = max(unused, key=lambda k: (min(abs(k-v) for v in chosen), int(areas[k]), -k))
        chosen.add(middle)
    return sorted(chosen)


def _content_rectangle(value, width, height):
    if value is None:
        return (0, 0, width, height)
    try:
        rectangle = tuple(int(v) for v in value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError('Reference content bounds are invalid') from None
    if (len(rectangle) != 4 or any(isinstance(v, bool) for v in value)
            or any(float(v) != rounded for v, rounded in zip(value, rectangle))):
        raise ValueError('Reference content bounds must be four finite integers')
    left, top, right, bottom = rectangle
    if not 0 <= left < right <= width or not 0 <= top < bottom <= height:
        raise ValueError('Reference content bounds fall outside the image')
    return rectangle


def prepare_anatomy_evidence(source, primary_visible, other_people, reference,
                             reference_mask, face_detector, content_bounds=None):
    """Return independent panels, panel masks, and bounded JSON-safe evidence.

    The generator decides which unobserved regions need completion. There is no
    semantic missing-body-part classifier here. Source hue is discarded; face
    and upper-head pixels never provide source texture. Constant-gray head-edge
    silhouettes can provide outline evidence, including a possible ear outline,
    but they are explicitly not semantic ear segmentation.
    """
    raw = np.asarray(source)
    if raw.ndim != 4 or raw.shape[-1] != 3 or min(raw.shape[:3]) < 1:
        raise ValueError('Source anatomy evidence needs a nonempty T,H,W,3 RGB sequence')
    frames, height, width = raw.shape[:3]
    images = _image(raw, raw.shape, 'source', clip=False)
    primary = _mask(primary_visible, (frames, height, width), 'primary visible mask')
    others = _mask(other_people, primary.shape, 'other people mask')
    photo = _image(reference, (height, width, 3), 'reference')
    person = _mask(reference_mask, (height, width), 'reference mask')
    if not callable(face_detector):
        raise ValueError('Face detector must be callable')
    rectangle = _content_rectangle(content_bounds, width, height)
    left, top, right, bottom = rectangle
    content = np.zeros(person.shape, bool)
    content[top:bottom, left:right] = True
    person = person & content
    ref_face = match_person_face(person, face_detector(photo))
    tint = None
    if ref_face is not None:
        x, y, fw, fh = ref_face
        patch = np.zeros(person.shape, bool)
        # Central face color is only an appearance proxy, not skin parsing.
        patch[y+fh//4:y+3*fh//4, x+fw//4:x+3*fw//4] = True
        pixels = photo[patch & person]
        if len(pixels) >= 16:
            median = np.median(pixels, axis=0)
            if float(median.mean()) >= .05:
                tint = np.clip(median / max(.1, float(median.mean())), .35, 1.65)
    # Count membership per frame, then materialize only selected masks. This
    # avoids a second complete T,H,W visibility tensor for long source videos.
    areas = np.fromiter((np.count_nonzero(primary[k] & ~others[k]) for k in range(frames)),
                        dtype=np.int64, count=frames)
    selected = _selected_frames(areas)
    views, masks, reports = [], [], []
    for frame in selected:
        mask = primary[frame] & ~others[frame]
        selected_image = np.clip(images[frame], 0, 1).astype(np.float32, copy=False)
        x0, y0, x1, y1 = _bounds(mask)
        face = match_person_face(mask, face_detector(selected_image))
        head_bottom = y0 + max(1, round(.28 * (y1-y0)))
        face_guard = np.zeros(mask.shape, bool)
        if face is not None:
            fx, fy, fw, fh = face
            head_bottom = max(head_bottom, min(height, math.ceil(fy + 1.5 * fh)))
            gx0, gx1 = max(0, math.floor(fx-.25*fw)), min(width, math.ceil(fx+1.25*fw))
            gy0, gy1 = max(0, math.floor(fy-.65*fh)), min(height, math.ceil(fy+1.5*fh))
            face_guard[gy0:gy1, gx0:gx1] = True
        head = mask.copy()
        head[head_bottom:] = False
        body = mask & ~head & ~face_guard
        head_edges = np.zeros_like(mask)
        head_bounds = _bounds(head)
        if head_bounds is not None:
            hx0, hy0, hx1, hy1 = head_bounds
            flank = max(1, round(.20 * (hx1-hx0)))
            head_edges[hy0:hy1, hx0:hx0+flank] = True
            head_edges[hy0:hy1, hx1-flank:hx1] = True
            head_edges &= head & ~face_guard
        evidence = body | head_edges
        if evidence.sum() < 16:
            reports.append({'frame': frame, 'available': False,
                            'reason': 'insufficient face-excluded primary geometry'})
            continue
        view = np.zeros((height, width, 3), np.float32)
        if face is None:
            # A close crop or profile can defeat the frontal detector and make
            # the estimated head band too short. Entire-person geometry stays
            # texture-free in that case, so missed face pixels cannot carry
            # their original facial details into the template.
            view[body] = .55
        else:
            luminance = selected_image @ np.array([.2126, .7152, .0722], np.float32)
            gray = .20 + .60*luminance
            view[body] = gray[body, None]
        if tint is not None:
            view[body] = np.clip(view[body] * tint, 0, 1)
        # No original source color or texture is used for any upper-head pixel.
        view[head_edges] = .55
        colors = np.zeros_like(view)
        colors[evidence] = .7
        views.append(view); masks.append(colors)
        reports.append({'frame': frame, 'available': True,
                        'face_box': list(face) if face else None,
                        'body_geometry_method': 'source_luminance_with_matched_face_guard' if face else 'uniform_silhouette_no_source_texture',
                        'body_geometry_pixels': int(body.sum()),
                        'anonymized_head_flank_pixels': int(head_edges.sum()),
                        'excluded_face_and_head_pixels': int((mask & ~evidence).sum()),
                        'excluded_other_person_pixels': int((primary[frame] & others[frame]).sum())})
    summary = {
        'version': 1, 'available': bool(views), 'panel_count': len(views),
        'source_frame_ids': [item['frame'] for item in reports if item['available']],
        'frame_evidence': reports, 'sampling': 'at most three first/best/late visible primary frames',
        'conditioning_only': True, 'output_pixel_pasting': False,
        'source_colors_preserved': False, 'source_face_texture_preserved': False,
        'undetected_face_policy': 'uniform silhouette, no source image texture anywhere in the template',
        'input_rgb_policy': 'finite Lanczos interpolation range [-.25,1.25]; selected pixels clipped to [0,1] without modifying input',
        'body_part_segmentation': False, 'semantic_ear_detection': False,
        'ear_outline_evidence': 'constant-gray head flanks only; not semantic ear detection',
        'color_method': 'reference_face_median_proxy_on_grayscale_body' if tint is not None else 'grayscale_body_geometry',
        'reference_face_box': list(ref_face) if ref_face else None,
        'reference_content_bounds': list(rectangle),
        'reference_bottom_border_touched': bool(person[max(top, bottom-2):bottom, left:right].any()),
        'color_verified': False, 'skin_tone_verified': False,
        'proportions_verified': False, 'quality_verified': False,
        'missing_region_policy': 'generator completes only unobserved reference anatomy needed by the source action; photo identity takes priority',
        'limitations': '2-D geometry and appearance proxies; exact organs, proportions, skin color and temporal reconstruction are not verified',
    }
    return views, masks, summary
