"""A separate two-stage graph: generate the whole first scene, then animate it.

The existing graph remains the source of SCAIL chunk scheduling. Its composited
reference preparation is replaced here, without changing the legacy workflow.
"""
from copy import deepcopy

from .graph import SOURCE_OBJECT_QUERY, build_graph


QWEN_MODELS = {
    'unet': ('diffusion_models', 'qwen_image_edit_2511_fp8mixed.safetensors'),
    'text': ('text_encoders', 'qwen_2.5_vl_7b_fp8_scaled.safetensors'),
    'vae': ('vae', 'qwen_image_vae.safetensors'),
    'light': ('loras', 'Qwen-Image-Edit-2511-Lightning-4steps-V1.0-bf16.safetensors'),
}


def build_fullgen_graph(image, video, meta, duration=10, seed=32139832,
                        job_id='full-generation', reference_size=None,
                        action_description='', garment_sequence='',*,
                        long_edge=704,upscale_canvas=False,target_fps=None,chunk_frames=33,
                        video_steps=8,video_cfg=1.,video_shift=1.,use_lightx=True,
                        video_sampler='euler',single_scene_reference=False,lightx_lora=None,
                        no_source_props=False,tail_pad_frames=0):
    """Return API graph and plan, sharing exactly one generated scene per run."""
    graph, plan = build_graph(image, video, meta, duration=duration, seed=seed,
                              job_id=job_id, reference_size=reference_size,
                              long_edge=long_edge,upscale_canvas=upscale_canvas,target_fps=target_fps,
                              chunk_frames=chunk_frames,video_steps=video_steps,video_cfg=video_cfg,
                              video_shift=video_shift,use_lightx=use_lightx,video_sampler=video_sampler,
                              lightx_lora=lightx_lora,no_source_props=no_source_props,tail_pad_frames=tail_pad_frames)
    if type(single_scene_reference) is not bool:
        raise ValueError('single_scene_reference must be a boolean')
    # build_graph returns fresh dictionaries, so the legacy API is never mutated.
    graph['tracking']['inputs']['detection_threshold'] = .50
    graph['scene']['class_type'] = 'MotionFullGenerationPlan'
    graph['scene']['inputs'].update(action_description=action_description,
                                    garment_sequence=garment_sequence)
    if reference_size is not None:
        graph['scene']['inputs'].update(reference_original_width=int(reference_size[0]),
                                        reference_original_height=int(reference_size[1]))
    graph['analysis_report']['inputs']['analysis'] = ['scene', 8]
    graph['positive']['inputs']['text'] = ['scene', 7]
    width, height = plan['width'], plan['height']

    def add(key, kind, **inputs):
        graph[key] = {'class_type': kind, 'inputs': inputs}
        return [key, 0]

    qwen = add('qwen_unet', 'UNETLoader', unet_name=QWEN_MODELS['unet'][1],
               weight_dtype='default')
    # Official base multi-reference recipe; the downloaded Lightning LoRA is not
    # applied. Keep qwen_model as the raw AuraFlow node for bounded smoke tools.
    qwen_model = add('qwen_model', 'ModelSamplingAuraFlow', model=qwen, shift=3.1)
    qwen_norm = add('qwen_norm', 'CFGNorm', model=qwen_model, strength=1., pre_cfg=False)
    qwen_text = add('qwen_text', 'CLIPLoader', clip_name=QWEN_MODELS['text'][1],
                    type='qwen_image', device='default')
    qwen_vae = add('qwen_vae', 'VAELoader', vae_name=QWEN_MODELS['vae'][1])
    # Match the empty latent to the ~1MP layout-conditioning image. A smaller
    # output canvas can change the apparent scale of the multi-reference scene.
    layout = add('qwen_layout_scaled', 'FluxKontextImageScale', image=['scene', 0])
    add('qwen_dimensions', 'GetImageSize', image=layout)
    # These images condition the new scene. None initializes the output latent.
    # Give the main reference a dedicated image instead of shrinking her into
    # the same identity sheet as companions. The v6 sheet duplicated a companion;
    # photo-first passed only a short diagnostic, so v7 still needs GPU review.
    qwen_refs = dict(clip=qwen_text, vae=qwen_vae, image1=['reference_size', 0],
                     image2=['scene', 1], image3=layout)
    positive = add('qwen_positive', 'TextEncodeQwenImageEditPlus',
                   prompt=['scene', 6], **qwen_refs)
    negative = add('qwen_negative', 'TextEncodeQwenImageEditPlus', prompt='', **qwen_refs)
    positive = add('qwen_positive_method', 'FluxKontextMultiReferenceLatentMethod',
                   conditioning=positive, reference_latents_method='index_timestep_zero')
    negative = add('qwen_negative_method', 'FluxKontextMultiReferenceLatentMethod',
                   conditioning=negative, reference_latents_method='index_timestep_zero')
    empty = add('qwen_empty', 'EmptySD3LatentImage', width=['qwen_dimensions', 0],
                height=['qwen_dimensions', 1], batch_size=1)
    sampled = add('qwen_sample', 'KSampler', model=qwen_norm, seed=seed, steps=20,
                  cfg=4., sampler_name='euler', scheduler='simple', positive=positive,
                  negative=negative, latent_image=empty, denoise=1.)
    decoded = add('qwen_decode', 'VAEDecode', samples=sampled, vae=qwen_vae)
    add('qwen_master_preview', 'SaveImage', images=decoded,
        filename_prefix=f'motion-studio/{job_id}-qwen-master')
    # SAM3 and SCAIL must receive exactly the planner's dimensions. No pixels
    # from a source photo are introduced by this final image-only downscale.
    generated = add('generated_scene', 'ImageScale', image=decoded, upscale_method='lanczos',
                    width=width, height=height, crop='disabled')
    add('scene_preview', 'SaveImage', images=generated,
        filename_prefix=f'motion-studio/{job_id}-first-scene')
    # SAM3's text tokenizer defaults to one detection per category. Separate
    # counted prompts let the validation gate see extra people beyond its limit.
    people_text = add('generated_people_text', 'CLIPTextEncode', clip=['sam', 1], text='person:6')
    objects_text = add('generated_objects_text', 'CLIPTextEncode', clip=['sam', 1],
                       text=f'{SOURCE_OBJECT_QUERY}:12')
    people = add('generated_people', 'SAM3_Detect', model=['sam', 0], image=generated,
                 conditioning=people_text, threshold=.30,
                 refine_iterations=2, individual_masks=True)
    objects = add('generated_objects', 'SAM3_Detect', model=['sam', 0], image=generated,
                  conditioning=objects_text, threshold=.35,
                  refine_iterations=2, individual_masks=True)
    prepared = add('prepared_reference', 'MotionFullGenerationReference',
                   generated=generated, generated_people=people, plan=['scene', 9],
                   motion_rgb=['scene', 2], motion_ids=['scene', 3],
                   identity_refs=['scene', 4], identity_masks=['scene', 5],
                   generated_objects=objects)
    add('reference_report', 'MotionSceneReport', analysis=['prepared_reference', 4])
    reference_images,reference_masks=prepared,['prepared_reference',1]
    if single_scene_reference:
        reference_images=add('single_scene_image','ImageFromBatch',image=prepared,batch_index=0,length=1)
        reference_masks=add('single_scene_mask','ImageFromBatch',image=['prepared_reference',1],batch_index=0,length=1)
    # CLIP sees the newly generated first scene, never an old composited plate.
    graph['main_reference']['inputs']['image'] = generated
    for node in graph.values():
        if node['class_type'] == 'WanSCAILToVideo':
            node['inputs'].update(reference_image=reference_images,
                                  reference_image_mask=reference_masks,
                                  pose_video=['prepared_reference', 2],
                                  pose_video_mask=['prepared_reference', 3])
    plan.update(generation_mode='full_generation_two_stage',
                long_edge=long_edge,upscale_canvas=upscale_canvas,
                chunk_frames=chunk_frames,chunk_overlap=5,
                video_sampling=dict(steps=video_steps,cfg=video_cfg,shift=video_shift,
                                    use_lightx=use_lightx,sampler=video_sampler,scheduler='simple',
                                    lightx_lora=graph['light']['inputs']['lora_name'] if use_lightx else None),
                single_scene_reference=single_scene_reference,
                no_source_props=no_source_props,
                source_props_policy='disabled_explicitly' if no_source_props else 'automatic_contact_candidates',
                first_scene='Qwen Image Edit 2511 base; CFGNorm; 20 steps CFG 4; empty latent; full denoise; generated once',
                qwen_reference_method='index_timestep_zero',
                revision='v8-source-anatomy-template',
                qwen_reference_order=['reference_photo', 'companion_and_object_sheet', 'layout_guide'],
                qwen_canvas='matches scaled layout near 1MP; image downscaled to SCAIL canvas before SAM3',
                person_tracking_detection_threshold=.50,
                person_tracking_confidence='SAM3 person detection threshold 0.50 to reduce weak late track fragments; not a quality score',
                video_stage='SCAIL-2 joint scene animation from the generated first scene',
                source_scene='filtered motion and identity references only; not an output plate',
                props=('disabled by explicit no_source_props policy; source prop tracking and guidance omitted'
                       if no_source_props else 'any-participant repeated 2D contact; independent object identity colors; not verified physical contact'),
                max_people=3, initially_visible_people_only=True,
                action_description_source='explicit text if supplied; no automatic action captioner implemented',
                anatomy_fallback_implemented=True,
                anatomy_policy='source-primary-geometry-template-v1',
                anatomy_reference_image=2, anatomy_max_temporal_panels=3,
                anatomy_conditioning_only=True, body_part_segmentation=False,
                output_pixel_pasting=False,
                physical_contact_guaranteed=False, gpu_quality_verified=False)
    return graph, plan


def prune_scene_graph(graph):
    """Copy the scene preview, planner/layout reports, and their ancestors.

    The generated-scene layout/prop gate runs, but no SCAIL sampler is included.
    SaveImage precedes the layout report in insertion order so a failed gate can
    still leave the generated preview available for inspection.
    """
    required = set()

    def visit(key):
        if key in required:
            return
        if key not in graph:
            raise ValueError(f'Missing scene graph node: {key}')
        required.add(key)
        for value in graph[key]['inputs'].values():
            if (isinstance(value, list) and len(value) == 2
                    and isinstance(value[0], str) and isinstance(value[1], int)):
                visit(value[0])

    for output in ('scene_preview', 'analysis_report', 'reference_report'):
        visit(output)
    if 'qwen_master_preview' in graph:
        visit('qwen_master_preview')
    return {key: deepcopy(node) for key, node in graph.items() if key in required}
