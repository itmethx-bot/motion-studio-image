"""Extract CPU-only video evidence; statistics are review cues, not quality scores.

Example:
  python inspect_video_quality.py clip.mp4 --output review --sample-seconds .5 --seams 28,56

Seams are zero-based output-frame indices. A seam value measures the change
from seam-1 to seam. This tool cannot verify identity, anatomy, contact, or motion
fidelity. It never loads models, uses a GPU, or accesses the network.
"""
import argparse
import json
import math
from pathlib import Path

import av
import numpy as np
from PIL import Image, ImageDraw, ImageOps


def _parse_seams(text):
    if not text.strip():
        return []
    try:
        values = sorted(set(int(item.strip()) for item in text.split(',')))
    except ValueError as exc:
        raise argparse.ArgumentTypeError('Seams must be comma-separated integer frame indices.') from exc
    if any(value < 0 for value in values):
        raise argparse.ArgumentTypeError('Seam frame indices must be nonnegative.')
    return values


def _contact_sheets(samples, output):
    paths = []
    tile_w, image_h, label_h = 320, 480, 40
    for start in range(0, len(samples), 12):
        page = samples[start:start+12]
        columns = min(4, len(page))
        rows = math.ceil(len(page)/columns)
        canvas = Image.new('RGB', (columns*tile_w, rows*(image_h+label_h)), '#eeeeee')
        draw = ImageDraw.Draw(canvas)
        for index, sample in enumerate(page):
            left, top = (index % columns)*tile_w, (index//columns)*(image_h+label_h)
            with Image.open(output/sample['file']) as image:
                fitted = ImageOps.contain(image, (tile_w, image_h), Image.Resampling.LANCZOS)
                canvas.paste(fitted, (left+(tile_w-fitted.width)//2, top+label_h+(image_h-fitted.height)//2))
            draw.text((left+7, top+5), f"Frame {sample['frame']} | {sample['seconds']:.3f}s", fill='black')
            draw.text((left+7, top+21), ', '.join(sample['reasons']), fill='black')
        filename = f'contact-sheet-{start//12+1:03d}.jpg'
        canvas.save(output/filename, quality=94)
        paths.append(filename)
    return paths


def inspect_video(video, output, sample_seconds=.5, seams=()):
    """Decode every frame on CPU, retaining only the previous frame in memory."""
    video, output = Path(video).resolve(), Path(output).resolve()
    if not video.is_file():
        raise ValueError('Video file does not exist.')
    if not math.isfinite(sample_seconds) or sample_seconds <= 0:
        raise ValueError('sample-seconds must be a finite positive number.')
    if any(type(index) is not int or index < 0 for index in seams):
        raise ValueError('Seams must be nonnegative integer frame indices.')
    seams = sorted(set(seams))
    wanted = {index for seam in seams for index in (seam-1, seam, seam+1) if index >= 0}
    output.mkdir(parents=True, exist_ok=True)
    previous = previous_luma = None
    black, duplicates, samples, differences, seam_values = [], [], [], [], {}
    dimensions = set()
    first_time = last_time = None
    last_duration = 0.
    next_sample = 0.
    nonincreasing_times = []
    decoded_count = 0
    with av.open(str(video), options={'protocol_whitelist': 'file'}) as container:
        if not container.streams.video:
            raise ValueError('File contains no video stream.')
        stream = container.streams.video[0]
        fps = float(stream.average_rate) if stream.average_rate else None
        nominal_interval = 1/fps if fps and fps > 0 else 0.
        metadata = {
            'codec': stream.codec_context.name,
            'width': stream.width, 'height': stream.height,
            'fps': fps, 'average_rate': str(stream.average_rate) if stream.average_rate else None,
            'declared_frames': stream.frames,
            'stream_duration_seconds': float(stream.duration*stream.time_base) if stream.duration is not None else None,
        }
        for index, frame in enumerate(container.decode(stream)):
            rgb = frame.to_ndarray(format='rgb24')
            dimensions.add((rgb.shape[1], rgb.shape[0]))
            absolute_time = float(frame.time) if frame.time is not None else index*nominal_interval
            if first_time is None:
                first_time = absolute_time
            seconds = absolute_time-first_time
            if last_time is not None and seconds <= last_time:
                nonincreasing_times.append(index)
            last_time = seconds
            frame_duration = getattr(frame, 'duration', 0)
            last_duration = float(frame_duration*frame.time_base) if frame_duration and frame.time_base else nominal_interval
            if not rgb.any():
                black.append(index)
            # Luma L1 is normalized to [0,1]. It measures pixel changes, not perceptual quality.
            luma = (rgb[..., 0].astype(np.float32)*.2126 + rgb[..., 1]*.7152 + rgb[..., 2]*.0722)/255.
            difference = None
            if previous is not None:
                if previous.shape == rgb.shape:
                    if np.array_equal(previous, rgb):
                        duplicates.append(index)
                    difference = float(np.abs(luma-previous_luma).mean())
                differences.append(difference)
            if index in seams:
                seam_values[str(index)] = {'frame': index, 'seconds': seconds,
                                           'luma_l1_from_previous': difference,
                                           'exact_duplicate_of_previous': index in duplicates,
                                           'exact_black': index in black}
            reasons = []
            if seconds+1e-6 >= next_sample:
                reasons.append('time sample')
                next_sample = (math.floor((seconds+1e-6)/sample_seconds)+1)*sample_seconds
            if index in wanted:
                reasons.append('seam neighborhood')
            if reasons:
                filename = f'frame-{index:06d}.jpg'
                Image.fromarray(rgb).save(output/filename, quality=95)
                samples.append({'frame': index, 'seconds': seconds, 'file': filename, 'reasons': reasons})
            previous, previous_luma = rgb, luma
            decoded_count = index+1
    if not decoded_count:
        raise ValueError('No video frames decoded.')
    valid = np.asarray([value for value in differences if value is not None], np.float64)
    statistics = {'count': int(valid.size), 'min': None, 'mean': None, 'median': None,
                  'p95': None, 'max': None, 'spike_threshold': None}
    threshold = None
    if valid.size:
        median = float(np.median(valid))
        mad = float(np.median(np.abs(valid-median)))
        # A robust, transparent inspection threshold, not an output acceptance gate.
        threshold = max(.03, median+6*mad)
        statistics.update(min=float(valid.min()), mean=float(valid.mean()), median=median,
                          p95=float(np.percentile(valid, 95)), max=float(valid.max()),
                          spike_threshold=threshold)
    top = sorted(((index+1, value) for index, value in enumerate(differences) if value is not None),
                 key=lambda item: (-item[1], item[0]))[:12]
    for value in seam_values.values():
        delta = value['luma_l1_from_previous']
        value['temporal_spike_review_cue'] = bool(threshold is not None and delta is not None and delta > threshold)
    report = {
        'video': str(video), **metadata, 'decoded_frames': decoded_count,
        'decoded_duration_seconds': last_time+last_duration,
        'dimensions_seen': [list(size) for size in sorted(dimensions)],
        'nonincreasing_timestamp_frames': nonincreasing_times,
        'exact_black_frames': black, 'exact_black_frame_count': len(black),
        'duplicate_adjacent_frames': duplicates, 'duplicate_adjacent_frame_count': len(duplicates),
        'temporal_luma_l1': statistics,
        'top_temporal_changes': [{'frame': index, 'luma_l1_from_previous': value,
                                  'temporal_spike_review_cue': bool(value > threshold)} for index, value in top],
        'seams': [seam_values[str(index)] for index in seams if str(index) in seam_values],
        'seams_outside_decoded_video': [index for index in seams if index >= decoded_count],
        'sample_seconds': sample_seconds, 'samples': samples,
        'contact_sheets': _contact_sheets(samples, output),
        'interpretation': 'Black frames, exact duplicates, and temporal spikes are review cues only; '
                          'stillness, cuts, lighting, or compression can explain them. '
                          'No identity, anatomy, physical contact, motion fidelity, or overall quality is verified.',
        'automatic_quality_verdict': None,
    }
    (output/'report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('video', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--sample-seconds', type=float, default=.5)
    parser.add_argument('--seams', type=_parse_seams, default=[], help='Zero-based output-frame indices, comma-separated.')
    args = parser.parse_args(argv)
    try:
        report = inspect_video(args.video, args.output, args.sample_seconds, args.seams)
    except (OSError, ValueError, av.error.FFmpegError) as exc:
        parser.exit(1, f'Video inspection stopped: {exc}\n')
    print(json.dumps({'report': str(args.output.resolve()/'report.json'),
                      'decoded_frames': report['decoded_frames'], 'fps': report['fps'],
                      'duration_seconds': report['decoded_duration_seconds'],
                      'size': [report['width'], report['height']],
                      'exact_black_frames': report['exact_black_frame_count'],
                      'duplicate_adjacent_frames': report['duplicate_adjacent_frame_count'],
                      'contact_sheets': report['contact_sheets']}, indent=2))
    return report


if __name__ == '__main__':
    main()
