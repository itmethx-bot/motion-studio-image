"""ComfyUI adapters. They run on the rented GPU host, never on the user's PC GPU."""
from pathlib import Path
import json
import numpy as np
from .scene_core import (alignment, choose_primary_window, identity_order, render_identities,
                        PALETTE, fit_image, size_for_video, associate_props,
                        best_appearance_frame, resolve_visible_masks, safe_primary_prop_mask,
                        select_primary_interaction_props, motion_foreground, filter_person_tracks)


def face_boxes(image):
    import cv2
    detector=cv2.CascadeClassifier(str(Path(cv2.data.haarcascades)/'haarcascade_frontalface_default.xml'))
    gray=cv2.cvtColor(np.uint8(np.clip(image,0,1)*255),cv2.COLOR_RGB2GRAY)
    return [tuple(map(int,b)) for b in detector.detectMultiScale(gray,1.1,5,minSize=(18,18))]


def lama_path():
    import folder_paths
    return Path(folder_paths.models_dir)/'inpaint'/'big-lama.pt'


def clean_background(image,mask):
    import cv2
    import torch
    path=lama_path()
    if not path.is_file():
        raise ValueError('ยังไม่มีโมเดลเติมฉาก LaMa กรุณาติดตั้งชุด Motion Studio ให้ครบก่อน')
    grown=cv2.dilate(np.uint8(mask>.5),np.ones((17,17),np.uint8))
    h,w=image.shape[:2]
    ph,pw=(-h)%8,(-w)%8
    padded=np.pad(image,((0,ph),(0,pw),(0,0)),mode='reflect')
    padded_mask=np.pad(grown,((0,ph),(0,pw)),mode='reflect')
    # CPU keeps this preparation step away from the SAM3 + video model VRAM budget.
    model=torch.jit.load(str(path),map_location='cpu').eval()
    with torch.inference_mode():
        result=model(torch.from_numpy(padded.transpose(2,0,1)).float()[None],
                     torch.from_numpy(padded_mask).float()[None,None])
    out=result[0].permute(1,2,0).cpu().numpy()[:h,:w].clip(0,1)
    del model
    # Preserve all known background pixels exactly at reference-preparation time.
    return np.where(grown[...,None]>0,out,image)


class MotionPrepareScene:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'reference':('IMAGE',),'reference_mask':('MASK',),
                'source_frames':('IMAGE',),'track_data':('SAM3_TRACK_DATA',),'women_mask':('MASK',)},
                'optional':{'reference_objects':('MASK',),'source_object_tracks':('SAM3_TRACK_DATA',),
                            'fps':('FLOAT',{'default':30.,'min':1.,'max':30.})}}
    RETURN_TYPES=('IMAGE','IMAGE','IMAGE','STRING','STRING','IMAGE')
    RETURN_NAMES=('reference_views','reference_identity_masks','driving_identity_masks','prompt','analysis','filtered_motion_frames')
    FUNCTION='prepare'
    CATEGORY='Motion Studio'

    def prepare(self,reference,reference_mask,source_frames,track_data,women_mask,
                reference_objects=None,source_object_tracks=None,fps=30.):
        import cv2
        import torch
        from comfy.ldm.sam3.tracker import unpack_masks
        import comfy.model_management as mm
        packed=track_data.get('packed_masks')
        if packed is None or packed.shape[1]==0:
            raise ValueError('ตรวจไม่พบคนในคลิป กรุณาใช้คลิปที่เห็นคนชัดขึ้น')
        source=source_frames.cpu().float().numpy()
        ref=reference[0].cpu().float().numpy()
        h,w=source.shape[1:3]
        if ref.shape[:2]!=(h,w):
            raise ValueError('ขนาดภาพนำทางไม่ตรงกับคลิป')
        def decode_tracks(data):
            value=data.get('packed_masks') if data else None
            if value is None or value.shape[1]==0:
                return np.zeros((len(source),0,h,w),dtype=bool)
            raw=unpack_masks(value).cpu().numpy()
            if len(raw)!=len(source):
                raise ValueError('จำนวนเฟรมข้อมูลติดตามไม่ตรงกับวิดีโอ ระบบหยุดเพื่อป้องกันท่าทางเลื่อน')
            return np.stack([np.stack([cv2.resize(m.astype('uint8'),(w,h),interpolation=cv2.INTER_NEAREST)
                             for m in frame]) for frame in raw]).astype(bool)
        masks=decode_tracks(track_data)
        women=women_mask.float().cpu().numpy()
        if women.shape[-2:]!=(h,w):
            women=np.stack([cv2.resize(m,(w,h),interpolation=cv2.INTER_NEAREST) for m in women])
        indices=np.unique(np.linspace(0,min(len(source)-1,round(float(fps))),
                                      min(8,len(source)),dtype=int)).tolist()
        faces={t:face_boxes(source[t]) for t in indices}
        masks,person_track_report=filter_person_tracks(masks,faces)
        primary,info=choose_primary_window(masks,women,faces,indices)
        order=identity_order(masks,primary)
        refs=reference_mask.float().cpu().numpy()
        if refs.ndim==2: refs=refs[None]
        if not len(refs) or not (refs>.5).any():
            raise ValueError('ไม่พบผู้หญิงในภาพอ้างอิง กรุณาใช้ภาพที่เห็นคนหลักชัด')
        ref_person=refs[np.argmax(refs.sum(axis=(1,2)))]
        if ref_person.shape!=(h,w):
            ref_person=cv2.resize(ref_person,(w,h),interpolation=cv2.INTER_NEAREST)
        ref_person=ref_person>.5
        ref_accessory=np.zeros_like(ref_person)
        ref_prop_report=[]
        if reference_objects is not None:
            objects=reference_objects.float().cpu().numpy()
            if objects.ndim==2: objects=objects[None]
            if len(objects):
                objects=np.stack([cv2.resize(m,(w,h),interpolation=cv2.INTER_NEAREST) for m in objects])>.5
                ref_assigned,ref_prop_report=associate_props(ref_person[None,None],objects[None])
                ref_accessory=ref_assigned[0,0]
        props=decode_tracks(source_object_tracks)
        selected_props,source_prop_report=select_primary_interaction_props(masks,props,primary)
        source_accessories=np.zeros_like(masks)
        # Only MAIN-person interaction props qualify; companion-only belongings
        # and unrelated source scenery do not get object appearance references.
        companion_masks=np.delete(masks,primary,axis=1).any(axis=1)
        source_accessories[:,primary]=selected_props.any(axis=1) & ~companion_masks
        filtered_motion=motion_foreground(source,masks,selected_props)
        visible_people,conflict_fraction=resolve_visible_masks(masks)
        # Selected props share the main person's correspondence color, without
        # introducing an extra person identity. Their own RGB trajectories remain.
        identities,prop_conflict_fraction=resolve_visible_masks(visible_people | source_accessories)
        reference_subject=ref_person | ref_accessory
        matrix,method=alignment(ref_person,masks[0,primary],face_boxes(ref),faces[0])
        ref_image=cv2.warpAffine(ref,matrix,(w,h),flags=cv2.INTER_LANCZOS4,borderMode=cv2.BORDER_CONSTANT)
        moved=cv2.warpAffine(reference_subject.astype('float32'),matrix,(w,h),flags=cv2.INTER_LINEAR).clip(0,1)
        if (moved>.5).sum()<.002*h*w:
            raise ValueError('ตำแหน่งที่คำนวณทำให้คนหลักหลุดเฟรม กรุณาเปลี่ยนภาพอ้างอิง')
        background=clean_background(ref,reference_subject)
        composite=background.copy()
        ref_color=np.ones((h,w,3),dtype=np.float32)
        views=[]
        view_masks=[]
        # Unobstructed identity evidence remains available even when the target
        # starting position places the woman partly behind a companion.
        primary_view=np.zeros((h,w,3),dtype=np.float32)
        primary_view[reference_subject]=ref[reference_subject]
        primary_colors=np.zeros_like(primary_view);primary_colors[reference_subject]=PALETTE[0]
        views.append(primary_view);view_masks.append(primary_colors)
        appearance_frames={}
        # Each companion has a sharp stable-track view, including later entrants.
        for color_id,object_id in reversed(list(enumerate(order[1:],start=1))):
            times=np.flatnonzero(masks[:,object_id].sum(axis=(1,2))>=16)
            first=int(times[0])
            best=best_appearance_frame(source,masks,object_id)
            appearance_frames[str(object_id)]=best
            mask=identities[best,object_id]
            single=np.zeros((h,w,3),dtype=np.float32)
            single[mask]=source[best][mask]
            colors=np.zeros_like(single); colors[mask]=PALETTE[color_id]
            views.append(single); view_masks.append(colors)
            if first==0:
                mask=identities[0,object_id]
                alpha=cv2.GaussianBlur(mask.astype('float32'),(5,5),0)[...,None]
                composite=composite*(1-alpha)+source[0]*alpha
                ref_color[mask]=PALETTE[color_id]
        # Do not paint the reference woman over pixels belonging to a visible
        # companion. This is a conditioning estimate, not verified physical depth.
        companion_region=identities[0,[i for i in order if i!=primary]].any(axis=0) if len(order)>1 else np.zeros((h,w),bool)
        moved=moved*(~companion_region)
        if (moved>.5).sum()<.002*h*w:
            raise ValueError('คนหลักถูกบังเกือบหมดหลังจัดตำแหน่ง กรุณาเริ่มคลิปในช่วงที่คนหลักเห็นชัด')
        alpha=cv2.GaussianBlur(moved,(5,5),0)[...,None]
        alpha[companion_region]=0
        composite=composite*(1-alpha)+ref_image*alpha
        ref_color[moved>.5]=PALETTE[0]
        # Main subject's source prop is evidence for an object, never a cutout of
        # the original main person's face or body. Add later prop views if needed.
        prop_times=np.flatnonzero(source_accessories[:,primary].sum(axis=(1,2))>=16)
        prop_appearance_guards=[]
        if len(prop_times):
            best=int(max(prop_times,key=lambda k:source_accessories[k,primary].sum()))
            mask,guard=safe_primary_prop_mask(source_accessories[best,primary],masks[best,primary],
                                              faces.get(best) if best in faces else face_boxes(source[best]))
            prop_appearance_guards.append(guard)
            if mask.sum()>=16:
                single=np.zeros((h,w,3),dtype=np.float32);single[mask]=source[best][mask]
                colors=np.zeros_like(single);colors[mask]=PALETTE[0]
                views.append(single);view_masks.append(colors)
            mask,guard=safe_primary_prop_mask(source_accessories[0,primary],masks[0,primary],faces[0])
            prop_appearance_guards.append(guard)
            mask=mask & ~companion_region
            composite[mask]=source[0][mask];ref_color[mask]=PALETTE[0]
        drive_color=render_identities(identities,order,background=0)
        prop_count=sum(p['accepted'] for p in source_prop_report)
        prompt=(f'A continuous photorealistic video with {len(order)} distinct people appearing over the '
                'sequence, inside the environment shown in the reference photograph. The main woman has '
                'the face, hairstyle, clothing and body proportions of the woman in the photograph. '
                'She moves through the positions and actions of the main performer in the motion example. '
                'The companions have their own distinct appearances from the motion example. Their entrances, '
                'exits, relative positions and movements occur at the demonstrated times. '
                'The people share one coherent space, with continuous body motion, naturally aligned '
                'interactions, plausible hand contact, stable appearances, consistent lighting and shadows. '
                + ('The source objects involved in the main woman\'s demonstrated physical interactions '
                   'appear at the demonstrated positions and times, including stationary supports and '
                   'objects that she holds, touches, puts down or passes to a companion. '
                   if prop_count else '')+
                'The environment and decorative background belong to the reference photograph throughout '
                'the video. The source clip contributes the people\'s movements and the main woman\'s '
                'interaction objects; its unrelated scene contents are absent.')
        info.update(primary_track=primary,identity_order=order,people=len(order),alignment=method,
                    person_tracks=person_track_report,
                    transform=matrix.tolist(),background_fill_fraction=float(reference_subject.mean()),
                    appearance_frames=appearance_frames,reference_props=ref_prop_report,source_props=source_prop_report,
                    prop_appearance_guards=prop_appearance_guards,
                    overlap_fraction=round(conflict_fraction,5),prop_overlap_fraction=round(prop_conflict_fraction,5),
                    prop_scope='only source objects with repeated contact evidence for the main person',
                    source_background_in_rgb_guide=False,
                    prop_analysis='SAM3 object candidates + repeated 2D main-person contact; incomplete and unverified',
                    occlusion_analysis='nearest exclusive mask evidence; not physical depth verification',
                    generation_mode='whole-scene animation; no final-video face/body compositing',
                    multi_reference='experimental; extra views can also degrade generation quality',
                    hand_contact='joint generation guided by original RGB motion; not guaranteed',
                    automatic_quality_verified=False)
        dtype=mm.intermediate_dtype(); device=mm.intermediate_device()
        to_tensor=lambda arr:torch.from_numpy(np.ascontiguousarray(arr)).to(device=device,dtype=dtype)
        return (to_tensor(np.stack([composite]+views)),to_tensor(np.stack([ref_color]+view_masks)),
                to_tensor(drive_color),prompt,json.dumps(info,ensure_ascii=False),to_tensor(filtered_motion))


class MotionLoadClip:
    @classmethod
    def INPUT_TYPES(cls):
        import folder_paths
        files=[str(p.relative_to(folder_paths.get_input_directory())).replace('\\','/')
               for p in Path(folder_paths.get_input_directory()).rglob('*.mp4')]
        return {'required':{'file':(sorted(files),{'video_upload':True}),'seconds':('FLOAT',{'default':5,'min':1,'max':15}),
                'fps':('FLOAT',{'default':30,'min':1,'max':30}),
                'width':('INT',{'default':512,'min':32,'max':1280,'step':32}),
                'height':('INT',{'default':896,'min':32,'max':1280,'step':32})},
                'optional':{'expected_frames':('INT',{'default':0,'min':0,'max':451}),
                            'tail_pad_frames':('INT',{'default':0,'min':0,'max':3})}}
    RETURN_TYPES=('IMAGE','AUDIO','FLOAT')
    FUNCTION='load'
    CATEGORY='Motion Studio'

    @classmethod
    def IS_CHANGED(cls,file,**kwargs):
        import folder_paths
        p=Path(folder_paths.get_input_directory())/file
        return p.stat().st_mtime_ns

    def load(self,file,seconds,fps,width,height,expected_frames=0,tail_pad_frames=0):
        import av
        import cv2
        import torch
        import folder_paths
        root=Path(folder_paths.get_input_directory()).resolve()
        path=(root/file).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('ไม่พบคลิปนำเข้า')
        frames=[]; last_frame=None; last_image=None; start=None; timestamp=0.
        requested=int(expected_frames)
        if (type(tail_pad_frames) is not int or not 0<=tail_pad_frames<=3 or
            (tail_pad_frames and (requested<5 or (requested-1)%4 or
             requested-tail_pad_frames!=int(seconds*fps+1e-9)))):
            raise ValueError('Invalid internal tail padding for the requested source duration')
        sample_limit=requested if requested>0 else math_ceil(seconds*fps)
        if tail_pad_frames:sample_limit=requested-tail_pad_frames
        final_interval=1/fps

        def fill_until(boundary,inclusive=False):
            # Integer indices avoid accumulated 1/fps error at 1.1s/2.7s/10s.
            # Hold the preceding source frame through a VFR display interval;
            # a future frame must not fill earlier timestamps.
            nonlocal last_image
            while last_frame is not None and len(frames)<sample_limit:
                sample_time=len(frames)/fps
                if sample_time>=seconds: break
                if inclusive:
                    if sample_time>boundary+1e-6: break
                elif sample_time>=boundary-1e-6: break
                if last_image is None:
                    image=last_frame.to_ndarray(format='rgb24')
                    rotation=int(getattr(last_frame,'rotation',0) or 0)%360
                    if rotation: image=np.rot90(image,rotation//90)
                    last_image=fit_image(image,width,height)
                frames.append(last_image)

        with av.open(str(path),format='mov',options={'protocol_whitelist':'file'}) as container:
            stream=container.streams.video[0]
            input_rate=getattr(stream,'average_rate',None)
            nominal_interval=1/float(input_rate) if input_rate and float(input_rate)>0 else 1/fps
            for index,frame in enumerate(container.decode(video=0)):
                absolute=float(frame.time) if frame.time is not None else index*nominal_interval
                if start is None: start=absolute
                timestamp=absolute-start
                fill_until(min(timestamp,seconds))
                if len(frames)>=sample_limit or len(frames)/fps>=seconds: break
                if timestamp>=seconds: break
                last_frame=frame; last_image=None
                duration=getattr(frame,'duration',0)
                time_base=getattr(frame,'time_base',None)
                final_interval=float(duration*time_base) if duration and time_base else nominal_interval
                if final_interval<=0: final_interval=nominal_interval
                fill_until(timestamp,inclusive=True)
                if len(frames)>=sample_limit or len(frames)/fps>=seconds: break
            # Only the last frame's actual display interval is available at EOF.
            if last_frame is not None and len(frames)<sample_limit:
                fill_until(min(seconds,timestamp+final_interval))
        required=requested-tail_pad_frames
        if requested>0 and len(frames)<required:
            required_seconds=required/fps
            raise ValueError(f'คลิปสั้นกว่าช่วงที่ workflow ต้องใช้ ต้องมีอย่างน้อย {required_seconds:.3f} วินาที '
                             f'({required} เฟรมที่ {fps:g} fps) กรุณาใช้คลิปที่ยาวพอหรือสร้าง workflow ตามความยาวจริง')
        # Wan requires 4n+1 frames. These <=3 held guide frames are internal;
        # the final encoder discards them and never extends the delivered video.
        if tail_pad_frames:frames.extend([frames[-1]]*tail_pad_frames)
        count=requested if requested>0 else (len(frames)-1)//4*4+1
        if count<5: raise ValueError('คลิปสั้นเกินไป')
        frames=frames[:count]
        duration=count/fps
        audio_samples=math_ceil(count*48000/fps)
        samples=[]
        with av.open(str(path),format='mov',options={'protocol_whitelist':'file'}) as container:
            if container.streams.audio:
                resampler=av.AudioResampler(format='fltp',layout='stereo',rate=48000)
                for frame in container.decode(audio=0):
                    samples.extend(f.to_ndarray() for f in resampler.resample(frame))
                    if sum(s.shape[-1] for s in samples)>=audio_samples: break
                samples.extend(f.to_ndarray() for f in resampler.resample(None))
        wave=np.concatenate(samples,axis=-1)[:,:audio_samples] if samples else np.zeros((2,audio_samples),dtype=np.float32)
        if wave.shape[-1]<audio_samples:
            wave=np.pad(wave,((0,0),(0,audio_samples-wave.shape[-1])))
        return torch.from_numpy(np.stack(frames).astype('float32')/255),{'waveform':torch.from_numpy(wave.copy())[None],'sample_rate':48000},float(fps)


def math_ceil(value):
    import math
    return math.ceil(value)


class MotionCanvasSize:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'reference':('IMAGE',),'long_edge':('INT',{'default':704,'min':256,'max':1280,'step':32})}}
    RETURN_TYPES=('INT','INT')
    RETURN_NAMES=('width','height')
    FUNCTION='size'
    CATEGORY='Motion Studio'

    def size(self,reference,long_edge):
        return size_for_video(reference.shape[2],reference.shape[1],long_edge)


class MotionFitImage:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'image':('IMAGE',),'width':('INT',{'default':512,'min':32,'max':1280,'step':32}),
                            'height':('INT',{'default':704,'min':32,'max':1280,'step':32})}}
    RETURN_TYPES=('IMAGE',)
    FUNCTION='fit'
    CATEGORY='Motion Studio'

    def fit(self,image,width,height):
        import torch
        array=image.cpu().float().numpy()
        return (torch.from_numpy(np.stack([fit_image(im,width,height,edge_padding=True) for im in array]))
                .to(device=image.device,dtype=image.dtype),)


class MotionSceneReport:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'analysis':('STRING',{'forceInput':True})}}
    RETURN_TYPES=()
    OUTPUT_NODE=True
    FUNCTION='report'
    CATEGORY='Motion Studio'

    def report(self,analysis):
        return {'ui':{'text':[analysis]}}


NODE_CLASS_MAPPINGS={'MotionPrepareScene':MotionPrepareScene,'MotionLoadClip':MotionLoadClip,
                    'MotionCanvasSize':MotionCanvasSize,'MotionFitImage':MotionFitImage,
                    'MotionSceneReport':MotionSceneReport}
