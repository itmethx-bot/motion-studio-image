"""PC adoption of a dedicated, user-created Pod. Never allocates or resumes."""
import json
import secrets
import time
from .fresh_pod import IMAGE,JOB,ID,number
from .service import atomic_json


class ManualPodLifecycle:
    def manual_setup(self,image=None):
        image=image or self.config().get('image_name','')
        if not IMAGE.fullmatch(image):raise ValueError('ต้องใช้ image ที่เผยแพร่แล้วพร้อม SHA256')
        path=self.data/'manual-pod-setup.json'
        if path.exists():
            setup=json.loads(path.read_text())
            if not setup.get('consumed'):
                if setup['image_name']!=image:raise ValueError('ใช้ชุดเตรียมเดิมให้จบก่อนเปลี่ยน image')
                return setup
        if self.config().get('mode')=='manual_owned' and self.lease().get('cleanup_pending'):
            raise ValueError('ต้องจัดการ Pod ที่เชื่อมไว้ก่อนเตรียมเครื่องถัดไป')
        uid=secrets.token_hex(16);nonce=secrets.token_hex(16);code=secrets.token_urlsafe(24)
        setup={'job_id':uid,'nonce':nonce,'image_name':image,'consumed':False,
            'name':'motion-manual-'+uid[:12],'ports':'8188/http','volume_gb':100,'container_gb':30,
            'entrypoint':['python','/opt/motion/pod_bootstrap.py'],
            'env':{'MOTION_CLEANUP_OWNER':'pc','MOTION_PC_JOB':uid,'MOTION_LEASE_NONCE':nonce,
                'MOTION_ACCESS_CODE':code,'MOTION_COMFY_PORT':'8188'}}
        atomic_json(path,setup)
        return setup

    def manual_public(self):
        config=self.config();row=self.lease()
        bound=(config.get('enabled') and self.key_path.is_file() and
            row.get('allocation_source')=='user' and row.get('job_id')==config.get('reserved_job_id'))
        available=bound and row.get('cleanup_pending') and row.get('state')=='awaiting_input' and time.time()<row.get('deadline',0)
        return {'auto_lease':bool(bound),'manual_owned':True,'fresh_pod':True,
            'account_key_saved':self.key_path.is_file(),'pc_controller':True,
            'ready':bool(available),'connection_needed':not bool(bound and row.get('cleanup_pending')),
            'automatic_stop_ready':bool(bound),'terminate_after_job':True,
            'cleanup_pending':bool(row.get('cleanup_pending')),'network_volume':False,
            'message':'กำลังตรวจ Pod ที่คุณเปิดไว้' if available else
                'กำลังประมวลผลหรือจัดการส่งมอบบน Pod ที่คุณเชื่อมไว้' if bound and row.get('cleanup_pending') else
                'Pod นี้ใช้งานแล้ว ต้องเตรียมชุดเชื่อมสำหรับเครื่องใหม่' if bound else 'เตรียมและเชื่อม Pod ที่คุณเปิดเองก่อน'}

    async def adopt_manual(self,pod_id,setup,*,consent=False,confirm_absence=False,hourly_ceiling=1.5):
        if consent is not True:raise ValueError('ต้องยืนยันให้ PC หยุดและ Terminate Pod ที่ระบุ')
        if not ID.fullmatch(pod_id) or not JOB.fullmatch(setup.get('job_id','')):raise ValueError('รหัสเครื่องหรือชุดเตรียมไม่ถูกต้อง')
        if setup.get('consumed'):raise ValueError('ชุดเชื่อมนี้ใช้สร้างงานไปแล้ว ต้องเตรียมชุดใหม่')
        if not self.key_path.is_file():raise ValueError('ต้องบันทึก API key บน PC ก่อนเพื่อหยุดและลบเครื่อง')
        ceiling=number(hourly_ceiling)
        if not .1<=ceiling<=10:raise ValueError('ค่าเช่าต่อชั่วโมงไม่ถูกต้อง')
        async with self.lifecycle_lock():
            pods=await self.listed_pods()
            pod=await self.call('GET','/pods/'+pod_id+'?includeNetworkVolume=true')
            row={'mode':'fresh','allocation_source':'user','job_id':setup['job_id'],'nonce':setup['nonce'],
                'pod_id':pod_id,'name':pod.get('name'),'image_name':setup['image_name']}
            if not self.owns(row,pod):raise ValueError('Pod ไม่ตรง image และค่าเริ่มต้นที่เตรียมไว้ หรือมี Network Volume')
            if pod.get('desiredStatus')!='RUNNING':raise ValueError('เปิด Pod ให้ทำงานก่อนเชื่อม เว็บจะไม่ Resume ให้')
            hourly=number(pod.get('adjustedCostPerHr') or pod.get('costPerHr'))
            if not hourly or hourly>ceiling:raise ValueError('ค่าเช่าของ Pod เกินเพดานหรืออ่านไม่ได้')
            credits=await self.account_check()
            allowance=min(10800,int(credits*.70/(hourly+.10)*3600))
            if allowance<3600:raise ValueError('เครดิตไม่พอเผื่อเตรียมระบบและสร้างวิดีโอ 1 ชั่วโมง')
            old=self.lease();resolved=None
            if old.get('cleanup_pending'):
                if (old.get('job_id')==row['job_id'] and old.get('pod_id')==pod_id
                    and old.get('state')=='awaiting_input' and self.owns(old,pod)):
                    return old,None
                # Human attestation plus a successful complete account listing.
                # A partial identity match remains unresolved even if ownership fails.
                if (confirm_absence is not True or old.get('state')!='create_unknown' or old.get('pod_id')
                    or not old.get('no_result_confirmed') or time.time()-old.get('started_at',time.time())<300):
                    raise ValueError('ต้องจัดการคำขอเดิมก่อนเชื่อมเครื่องใหม่')
                if any(p.get('name')==old.get('name') or
                    (isinstance(p.get('env'),dict) and (p['env'].get('MOTION_PC_JOB')==old.get('job_id') or
                        p['env'].get('MOTION_LEASE_NONCE')==old.get('nonce'))) for p in pods):
                    raise ValueError('ยังพบเครื่องที่เกี่ยวข้องกับคำขอเดิม จึงไม่ปลดล็อก')
                history=self.data/'lease-history';history.mkdir(exist_ok=True)
                if not JOB.fullmatch(old.get('job_id','')):raise ValueError('ประวัติคำขอเดิมไม่ถูกต้อง')
                resolved={**old,'state':'create_absence_confirmed_by_user','cleanup_pending':False,
                    'resolved_at':time.time(),'user_confirmed_absence':True,'account_list_no_match':True}
                atomic_json(history/(old['job_id']+'-allocation.json'),resolved)
            now=time.time()
            row.update(cleanup_pending=True,state='awaiting_input',started_at=now,heartbeat_at=now,
                deadline=now+allowance,handoff_verified=False,no_result_confirmed=True,hourly_usd=hourly,
                stop_delete_consent=True)
            atomic_json(self.config_path,{'mode':'manual_owned','enabled':True,'image_name':setup['image_name'],
                'reserved_job_id':setup['job_id'],'pod_id':pod_id,'hourly_ceiling_usd':ceiling,
                'network_volume':False,'cleanup_owner':'pc','live_lifecycle_verified':False})
            atomic_json(self.ledger_path,row)
            self.start_guard(row['job_id'])
            return row,resolved

    async def acquire_manual(self,job_id,persist):
        async with self.lifecycle_lock():
            row=self.lease()
            if (job_id!=self.config().get('reserved_job_id') or row.get('job_id')!=job_id
                or row.get('allocation_source')!='user' or row.get('state')!='awaiting_input'
                or not row.get('cleanup_pending') or time.time()>=row['deadline']):
                raise ValueError('ชุดเชื่อมเครื่องนี้ไม่พร้อมหรือใช้ไปแล้ว ต้องเชื่อม Pod ใหม่')
            pod=await self.call('GET','/pods/'+row['pod_id']+'?includeNetworkVolume=true')
            if not self.owns(row,pod) or pod.get('desiredStatus')!='RUNNING':raise ValueError('Pod ที่เชื่อมไว้ไม่พร้อมหรือข้อมูลเครื่องเปลี่ยน')
            row['state']='bootstrapping';atomic_json(self.ledger_path,row)
            path=self.data/'manual-pod-setup.json';setup=json.loads(path.read_text());setup['consumed']=True
            atomic_json(path,setup);persist(row)
            return row
