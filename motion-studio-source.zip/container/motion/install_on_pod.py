"""Install into an existing Pod using ComfyUI's own Python environment.

Seven video/segmentation weights are downloaded only with --download-models.
No provider API, credentials, arbitrary remote Python or Pod provisioning is used.
"""
import http.client
import argparse
from contextlib import contextmanager
import hashlib
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
GIB = 1024 ** 3
LAMA_URL = 'https://github.com/Sanster/models/releases/download/add_big_lama/big-lama.pt'
LAMA_MD5 = 'e3aa4aaa15225a33ec84f9f4bc47e500'
LAMA = {'id': 'lama', 'path': 'inpaint/big-lama.pt', 'url': LAMA_URL,
        'checksum_algorithm': 'md5', 'checksum': LAMA_MD5, 'bytes': None}


class InstallError(RuntimeError):
    def __init__(self, message, *, retryable=False):
        super().__init__(message)
        self.retryable = bool(retryable)


def transient_transfer_error(error):
    """Retry transport failures, never authorization, capacity or integrity failures."""
    import errno
    if isinstance(error, urllib.error.HTTPError):
        return error.code in (408, 429, 500, 502, 503, 504)
    cause = error.reason if isinstance(error, urllib.error.URLError) else error
    if isinstance(cause, OSError) and cause.errno in (errno.ENOSPC, errno.EACCES, errno.EPERM, errno.EROFS, errno.EIO):
        return False
    return isinstance(error, (urllib.error.URLError, TimeoutError)) or (
        isinstance(error, OSError) and error.errno in (errno.ECONNRESET, errno.ECONNABORTED, errno.ETIMEDOUT, errno.EPIPE))


def load_manifest(path=None):
    manifest = json.loads(Path(path or ROOT/'model-manifest.json').read_text(encoding='utf-8'))
    models = manifest.get('models', [])
    if len(models) != 7 or len({m.get('id') for m in models}) != 7:
        raise InstallError('Model manifest must contain seven distinct verified models.')
    seen = set()
    for model in models:
        relative = PurePosixPath(model['path'])
        if relative.is_absolute() or '..' in relative.parts or '\\' in model['path'] or ':' in model['path']:
            raise InstallError('Unsafe model path in manifest.')
        if model['path'] in seen:
            raise InstallError('Duplicate model path in manifest.')
        seen.add(model['path'])
        url = urllib.parse.urlsplit(model['url'])
        if (url.scheme != 'https' or url.netloc != 'huggingface.co' or url.query or url.fragment
                or not re.search(r'/resolve/[0-9a-f]{40}/', url.path)):
            raise InstallError('Model URLs must use pinned Hugging Face repository revisions over HTTPS.')
        if (model.get('checksum_algorithm') != 'sha256'
                or not re.fullmatch(r'[0-9a-f]{64}', model.get('checksum', ''))
                or not isinstance(model.get('bytes'), int) or model['bytes'] <= 0):
            raise InstallError('Each video model needs a verified SHA256 and exact size.')
    return models


def check_comfy(comfy):
    comfy = Path(comfy).resolve()
    if not (comfy/'main.py').is_file() or not (comfy/'custom_nodes').is_dir():
        raise InstallError('ComfyUI folder not found. Pass --comfy /workspace/ComfyUI.')
    missing = [name for name in ('comfy_extras/nodes_scail.py', 'comfy_extras/nodes_sam3.py')
               if not (comfy/name).is_file()]
    if missing:
        raise InstallError('This ComfyUI is missing native SCAIL-2/SAM3 support. Update ComfyUI before installing.')
    return comfy


def check_runtime():
    modules = {}
    missing = []
    for name in ('torch', 'av', 'PIL.Image', 'numpy', 'aiohttp'):
        try:
            modules[name] = importlib.import_module(name)
        except (ImportError, OSError):
            missing.append(name)
    if missing:
        raise InstallError('Run with the same Python environment as ComfyUI. Missing/unloadable dependencies: '
                           + ', '.join(missing) + '. Install ComfyUI requirements in that environment first.')
    torch = modules['torch']
    try:
        cuda = bool(torch.cuda.is_available())
    except Exception as exc:
        raise InstallError('PyTorch could not check CUDA. Check the Pod driver and ComfyUI Python environment.') from exc
    if not cuda:
        raise InstallError('CUDA GPU is unavailable to this Python environment. Start the GPU Pod or fix its PyTorch runtime first.')
    opencv_ok = False
    try:
        cv2 = importlib.import_module('cv2')
        opencv_ok = hasattr(cv2, 'CascadeClassifier') and hasattr(cv2, 'data')
    except (ImportError, OSError):
        pass
    return {'python': sys.executable, 'torch': str(torch.__version__), 'cuda_available': True,
            'opencv_ready': opencv_ok}


def checksum(path, algorithm):
    digest = hashlib.new(algorithm)
    with Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def destination(models_root, artifact):
    root = Path(models_root).resolve()
    target = root.joinpath(*PurePosixPath(artifact['path']).parts)
    if target.is_symlink() or not target.resolve().is_relative_to(root):
        raise InstallError('Model destination must stay inside the ComfyUI models folder.')
    return target


def verify_file(path, artifact):
    if artifact['bytes'] is not None and path.stat().st_size != artifact['bytes']:
        return False
    return checksum(path, artifact['checksum_algorithm']) == artifact['checksum']


def pending_models(models_root, artifacts):
    pending = []
    for artifact in artifacts:
        target = destination(models_root, artifact)
        if target.exists():
            if not target.is_file() or not verify_file(target, artifact):
                raise InstallError('Existing model is not the verified file: ' + artifact['path']
                                   + '. Nothing was overwritten; move that file aside before retrying.')
        else:
            pending.append(artifact)
    return pending


def partial_paths(target):
    return Path(str(target)+'.part'), Path(str(target)+'.part.json')


def partial_size(target, artifact):
    partial, metadata = partial_paths(target)
    if partial.is_symlink() or metadata.is_symlink():
        raise InstallError('Refusing a symbolic-link partial download.')
    identity = {key: artifact[key] for key in ('url', 'checksum_algorithm', 'checksum', 'bytes')}
    if partial.exists():
        try:
            saved = json.loads(metadata.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            raise InstallError('Partial download has no valid ownership metadata: ' + target.name
                               + '. Move its .part file aside before retrying.')
        if saved != identity:
            raise InstallError('Partial download belongs to another model: ' + target.name
                               + '. Move its .part and .part.json files aside before retrying.')
        size = partial.stat().st_size
        if size > (artifact['bytes'] if artifact['bytes'] is not None else 2*GIB):
            raise InstallError('Partial download is larger than the expected model: ' + target.name)
        return size
    return 0


def storage_preflight(comfy, artifacts):
    root = comfy/'models'
    required = 2*GIB  # Reserve for the extension, pip scratch space and filesystem overhead.
    for artifact in artifacts:
        required += max(0, (artifact['bytes'] or GIB) - partial_size(destination(root, artifact), artifact))
    check_at = root if root.exists() else comfy
    free = shutil.disk_usage(check_at).free
    if free < required:
        raise InstallError(f'Insufficient disk space: need {required/GIB:.1f} GiB free for this installation, '
                           f'but only {free/GIB:.1f} GiB is available. No download was started.')
    return {'required_free_bytes': required, 'free_bytes': free}


class HTTPSOnlyRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        if parsed.scheme != 'https' or parsed.username or parsed.password:
            raise InstallError('Refusing an insecure model download redirect.')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


@contextmanager
def download_lock(target):
    """Advisory locks release on process exit, so interrupted downloads can resume."""
    lock = Path(str(target)+'.download.lock')
    if lock.is_symlink():
        raise InstallError('Refusing a symbolic-link download lock.')
    with lock.open('a+b') as file:
        if os.name == 'nt':
            import msvcrt
            if file.tell() == 0:
                file.write(b'0'); file.flush()
            file.seek(0)
            try:
                msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise InstallError('Another installer is downloading ' + target.name) from exc
            try:
                yield
            finally:
                file.seek(0); msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            try:
                fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                raise InstallError('Another installer is downloading ' + target.name) from exc
            try:
                yield
            finally:
                fcntl.flock(file.fileno(), fcntl.LOCK_UN)


def download_artifact(models_root, artifact, opener=None):
    target = destination(models_root, artifact)
    target.parent.mkdir(parents=True, exist_ok=True)
    opener = opener or urllib.request.build_opener(HTTPSOnlyRedirect())
    with download_lock(target):
        if target.exists():
            if verify_file(target, artifact):
                return target
            raise InstallError('Existing model checksum mismatch; nothing overwritten: ' + artifact['path'])
        partial, metadata = partial_paths(target)
        offset = partial_size(target, artifact)
        identity = {key: artifact[key] for key in ('url', 'checksum_algorithm', 'checksum', 'bytes')}
        if not partial.exists():
            metadata.write_text(json.dumps(identity, sort_keys=True), encoding='utf-8')
        if artifact['bytes'] is None or offset != artifact['bytes']:
            headers = {'User-Agent': 'MotionStudioInstaller/1', 'Accept-Encoding': 'identity'}
            if offset:
                headers['Range'] = f'bytes={offset}-'
            request = urllib.request.Request(artifact['url'], headers=headers)
            try:
                with opener.open(request, timeout=60) as response:
                    status = response.status
                    if status not in (200, 206):
                        raise InstallError('Unexpected model download response for ' + target.name)
                    total = artifact['bytes']
                    if status == 206:
                        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
                        if not match or int(match[1]) != offset or int(match[2]) < offset:
                            raise InstallError('Invalid resumed-download range for ' + target.name)
                        if total is not None and int(match[3]) != total:
                            raise InstallError('Resumed-download size differs from the verified model: ' + target.name)
                        total = int(match[3])
                    elif offset:
                        offset = 0  # Server ignored Range: restart, never append a complete file.
                    length = response.headers.get('Content-Length')
                    if total is not None and length is not None and int(length) != total-offset:
                        raise InstallError('Download size differs from the verified model: ' + target.name)
                    limit = total if total is not None else 2*GIB
                    received = offset
                    last_progress = 0.
                    with partial.open('ab' if offset else 'wb') as file:
                        while True:
                            chunk = response.read(1024*1024)
                            if not chunk:
                                break
                            if received + len(chunk) > limit:
                                raise InstallError('Download exceeded verified model size: ' + target.name)
                            file.write(chunk); received += len(chunk)
                            if time.monotonic() - last_progress > 10:
                                print(json.dumps({'model': artifact['id'], 'downloaded_bytes': received,
                                                  'expected_bytes': total}), flush=True)
                                last_progress = time.monotonic()
                        file.flush(); os.fsync(file.fileno())
                    if total is not None and received != total:
                        raise InstallError('Download interrupted; the verified partial can be resumed: ' + target.name, retryable=True)
            except (urllib.error.URLError, TimeoutError, OSError, http.client.IncompleteRead) as exc:
                raise InstallError('Network/storage error downloading ' + target.name
                                   + '. Partial data is retained; rerun the same command to resume.',
                                   retryable=isinstance(exc, http.client.IncompleteRead) or transient_transfer_error(exc)) from exc
        if not verify_file(partial, artifact):
            partial.unlink(missing_ok=True); metadata.unlink(missing_ok=True)
            raise InstallError('Downloaded model checksum mismatch: ' + target.name
                               + '. Rejected data was removed; no model was installed.')
        partial.replace(target)
        metadata.unlink(missing_ok=True)
        print(json.dumps({'model': artifact['id'], 'status': 'verified', 'bytes': target.stat().st_size}), flush=True)
        return target


def install(comfy, download_models=False, check_only=False):
    # The v7 bundle imports model/download helpers from this module but omits
    # the legacy web service. Fail before probing CUDA, downloading or writing.
    legacy_files = ('__init__.py', 'nodes.py', 'scene_core.py', 'graph.py', 'service.py', 'watchdog.py')
    missing_legacy = [name for name in legacy_files if not (ROOT/name).is_file()]
    if not (ROOT/'web').is_dir():
        missing_legacy.append('web/')
    if missing_legacy:
        raise InstallError('Legacy service package is incomplete: ' + ', '.join(missing_legacy)
                           + '. Use prepare_fullgen_pod.py for the full-generation bundle; nothing installed.')
    comfy = check_comfy(comfy)
    runtime = check_runtime()  # Fail before pip, downloads or changing an installation.
    models = load_manifest()
    missing = pending_models(comfy/'models', models)
    requested = [LAMA] + (missing if download_models else [])
    pending = pending_models(comfy/'models', requested)
    storage = storage_preflight(comfy, pending)
    report = {'runtime': runtime, 'storage': storage, 'missing_video_models': [m['path'] for m in missing],
              'large_model_downloads_enabled': download_models, 'check_only': check_only}
    print(json.dumps(report, indent=2), flush=True)
    if check_only:
        return report
    if not runtime['opencv_ready']:
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', 'opencv-python-headless==4.11.0.86'], check=True)
        except subprocess.CalledProcessError as exc:
            raise InstallError('OpenCV installation failed in the ComfyUI Python environment.') from exc
    for artifact in pending:
        download_artifact(comfy/'models', artifact)
    dest = comfy/'custom_nodes'/'motion_studio_auto'
    if dest.is_symlink():
        raise InstallError('Refusing to replace an extension through a symbolic link.')
    dest.mkdir(exist_ok=True)
    for filename in legacy_files:
        shutil.copy2(ROOT/filename, dest/filename)
    shutil.copytree(ROOT/'web', dest/'web', dirs_exist_ok=True)
    report.update({'installed': str(dest), 'next': 'Restart ComfyUI. Configure the dedicated Pod lifecycle '
                  'before relying on automatic downloads and GPU stop. Open /motion-studio/.',
                  'remaining_video_models': [] if download_models else [m['path'] for m in missing],
                  'gpu_generation_tested': False})
    print(json.dumps(report, indent=2), flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy', required=True)
    parser.add_argument('--download-models', action='store_true',
                        help='Download the seven pinned video/segmentation models if missing (tens of GB).')
    parser.add_argument('--check-only', action='store_true',
                        help='Validate this runtime, model files and free space without installing/downloading anything.')
    args = parser.parse_args()
    try:
        install(args.comfy, download_models=args.download_models, check_only=args.check_only)
    except (InstallError, ValueError, OSError) as exc:
        parser.exit(1, f'Installation stopped: {exc}\n')
