"""Local web controller. Does not start or rent a GPU on launch."""
import argparse
import asyncio
import contextlib
import importlib.util
from pathlib import Path
import sys
import types
from aiohttp import web

ROOT=Path(__file__).resolve().parent
# Load the package without ComfyUI's startup hook when running on the PC.
package=types.ModuleType('motion_studio_auto');package.__path__=[str(ROOT)]
sys.modules['motion_studio_auto']=package
from motion_studio_auto.bridge import BridgeStudio,BridgeBackend

def create_app(data):
    studio=BridgeStudio(BridgeBackend(data))
    app=web.Application(client_max_size=210*1024*1024)
    app['studio']=studio
    app.add_routes(studio.routes())
    async def home(request): return web.HTTPFound('/motion-studio/')
    app.router.add_get('/',home)
    async def start(app):app['lease_monitor']=asyncio.create_task(studio.monitor_leases())
    async def stop(app):
        task=app['lease_monitor'];task.cancel()
        with contextlib.suppress(asyncio.CancelledError):await task
    app.on_startup.append(start);app.on_cleanup.append(stop)
    return app

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--data',default=str(ROOT/'private-data'))
    args=parser.parse_args()
    web.run_app(create_app(args.data),host='127.0.0.1',port=args.port,print=None)
