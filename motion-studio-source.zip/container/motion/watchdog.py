"""Independent Pod guard: survives a Comfy process crash.

Invoked only by this extension for its own accepted job. Credentials stay in the
environment. No account enumeration, new rentals, or billing changes.
"""
import argparse
import json
import os
from pathlib import Path
import re
import time
import urllib.request


def post_stop(pod,key):
    req=urllib.request.Request('https://rest.runpod.io/v1/pods/'+pod+'/stop',data=b'',
                              headers={'Authorization':'Bearer '+key},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=20) as response:
            return response.status in (200,204)
    except Exception:return False


def run(state,deadline,comfy_port):
    pod=os.environ.get('RUNPOD_POD_ID','');key=os.environ.get('RUNPOD_API_KEY','')
    if not re.fullmatch(r'[a-zA-Z0-9]{8,40}',pod) or not key:return 2
    path=Path(state).resolve()
    job={}
    while time.time()<deadline:
        try:
            job=json.loads(path.read_text(encoding='utf-8'))
            if (job.get('stop_confirmed') is True or job.get('retired_lease') is True
                    or job.get('previous_session_reconciled') is True):return 0
            # Normal jobs update every five seconds. Completed jobs awaiting transfer
            # have a three-minute grace interval; don't pre-empt that handoff.
            if time.time()-path.stat().st_mtime>300:break
        except (FileNotFoundError,ValueError):pass
        time.sleep(10)
    try:
        # A newer idle-session handshake can retire this old job while the
        # deadline/heartbeat check is completing. Re-read before any stop call.
        job=json.loads(path.read_text(encoding='utf-8'))
        if job.get('retired_lease') is True or job.get('previous_session_reconciled') is True:return 0
        with urllib.request.urlopen('http://127.0.0.1:'+str(comfy_port)+'/queue',timeout=10) as response:
            queue=json.load(response)
        own=job.get('prompt_id')
        own_clients={'motion-studio-'+job.get('id','')+'-'+stage for stage in ('scene','validate','video')}
        other=[row for name in ('queue_running','queue_pending') for row in queue.get(name,[]) if row[1]!=own
               and not (len(row)>3 and isinstance(row[3],dict) and row[3].get('client_id') in own_clients)]
        if other:
            path.with_suffix('.shutdown.json').write_text(json.dumps({'stop_request_accepted':False,'reason':'other_comfy_jobs'}))
            return 3
    except Exception:
        # Comfy is unreachable: no live controller remains to release this GPU.
        pass
    accepted=False
    for attempt in range(3):
        try:
            current=json.loads(path.read_text(encoding='utf-8'))
            if current.get('retired_lease') is True or current.get('previous_session_reconciled') is True:return 0
        except (OSError,ValueError):pass
        accepted=post_stop(pod,key)
        if accepted:break
        time.sleep(5)
    path.with_suffix('.shutdown.json').write_text(json.dumps({'stop_request_accepted':accepted,'time':time.time()}))
    return 0 if accepted else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--state',required=True)
    parser.add_argument('--deadline',type=float,required=True);parser.add_argument('--port',type=int,default=8188)
    args=parser.parse_args();raise SystemExit(run(args.state,args.deadline,args.port))
