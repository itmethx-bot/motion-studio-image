"""Entrypoint baked into the fresh-Pod image. No provider credentials/calls.

Owns only an initially empty /workspace/ComfyUI. Pinned model downloader uses
the same manifests as the tested workflow. HTTP service starts AFTER download
and source/dependency checks. The user stops the Pod, including after failure.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

ROOT=Path('/opt/motion')
COMFY_SOURCE=Path('/opt/ComfyUI')
COMFY=Path('/workspace/ComfyUI')


def check_environment():
    if os.environ.get('MOTION_CLEANUP_OWNER')!='user':raise ValueError('Manual user-owned session is required')
    code=os.environ.get('MOTION_ACCESS_CODE','')
    if not re.fullmatch(r'[A-Za-z0-9_-]{24,128}',code):raise ValueError('Invalid template service access code')
    if not re.fullmatch(r'[A-Za-z0-9]{8,40}',os.environ.get('RUNPOD_POD_ID','')):raise ValueError('Pod identity is missing')
    return code


def download_with_recovery(base, models_root, artifact, attempts=3):
    from bootstrap_status import safe_error
    for attempt in range(1, attempts+1):
        try:
            return base.download_artifact(models_root, artifact)
        except Exception as error:
            error.model = artifact['id']
            record = safe_error(error)
            record.update(model=artifact['id'], attempt=attempt, max_attempts=attempts,
                          status='retrying' if getattr(error,'retryable',False) and attempt < attempts else 'failed')
            print(json.dumps(record), flush=True)
            if not getattr(error,'retryable',False) or attempt == attempts: raise
            time.sleep(2*attempt)


def download_pending(base, models_root, artifacts, status):
    # At most three downloads and three bounded attempts per artifact. Complete
    # verified files remain reusable. Never submit/retry a video render here.
    from bootstrap_status import safe_error
    failures = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(download_with_recovery, base, models_root, item): item for item in artifacts}
        for future in as_completed(futures):
            try: future.result()
            except Exception as error:
                failures.append(error)
                status.state = {**status.state, 'download_error': safe_error(error)}
    if failures: raise failures[0]


def main():
    code=check_environment()
    sys.path.insert(0,str(ROOT))
    from bootstrap_status import BootstrapStatus
    status=BootstrapStatus(code);status.start()
    try:prepare_and_launch(code,status)
    except Exception as error:
        from bootstrap_status import safe_error
        failure = safe_error(error)
        status.state={'phase':'bootstrap_failed','failed':True,'error':failure}
        print('BOOTSTRAP_FAILED '+json.dumps(failure),flush=True)
        while True:time.sleep(30)


def prepare_and_launch(code,status):
    import install_on_pod as base
    import fullgen_install_models as qwen
    import install_fullgen_addon as addon
    import install_two_upload as web_install
    # Provider credentials installed by a generic template are not used by this
    # image. Never transmit PC account credentials into this process.
    os.environ.pop('RUNPOD_API_KEY',None)
    import hashlib
    expected_owner={'mode':'manual_session','access_code_sha256':hashlib.sha256(code.encode()).hexdigest()}
    marker=COMFY/'.motion-manual-owner.json'
    if COMFY.exists():
        if COMFY.is_symlink() or not marker.is_file():raise ValueError('Workspace is not owned by this image')
        owner=json.loads(marker.read_text())
        if owner!=expected_owner:
            raise ValueError('Refusing to reuse another template workspace')
    else:
        shutil.copytree(COMFY_SOURCE,COMFY,ignore=shutil.ignore_patterns('.git','__pycache__'))
        marker.write_text(json.dumps(expected_owner))
    addon.check_comfy(COMFY)
    runtime=addon.check_dependencies()
    if not runtime['ready']:raise ValueError(addon.dependency_error(runtime))
    artifacts=base.load_manifest()+qwen.load_manifest(include_lightning=False)+[base.LAMA]
    pending=base.pending_models(COMFY/'models',artifacts)
    base.storage_preflight(COMFY,pending)
    log=COMFY/'motion-bootstrap.json'
    log.write_text(json.dumps({'phase':'downloading','missing':len(pending),'started':time.time()}))
    status.state={'phase':'downloading_models','failed':False}
    # Model bytes/URLs/checksums are fixed in local manifests, not user commands.
    download_pending(base,COMFY/'models',pending,status)
    for item in artifacts:
        if not base.verify_file(base.destination(COMFY/'models',item),item):raise ValueError('Model checksum verification failed')
    extensions=COMFY/'custom_nodes'
    io=extensions/'motion_studio_io';io.mkdir(exist_ok=True)
    for name in ('nodes.py','scene_core.py'):shutil.copy2(ROOT/name,io/name)
    (io/'__init__.py').write_text('from .nodes import NODE_CLASS_MAPPINGS as _all\n'
        "NODE_CLASS_MAPPINGS={k:v for k,v in _all.items() if k in ('MotionLoadClip','MotionFitImage','MotionCanvasSize','MotionSceneReport')}\n")
    full=extensions/'motion_studio_fullgen';full.mkdir(exist_ok=True)
    for name in addon.FILES:shutil.copy2(ROOT/name,full/name)
    (full/'__init__.py').write_text(addon.INIT_SOURCE)
    web=extensions/web_install.ADDON;web.mkdir(exist_ok=True)
    files=web_install.collect_files(ROOT)
    for name,data in files.items():
        dest=web/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    (web/'__init__.py').write_text(web_install.INIT_SOURCE)
    private=COMFY/'motion-studio-private';private.mkdir(exist_ok=True)
    pin=private/'access-code.txt';pin.write_text(code);pin.chmod(0o600)
    log.write_text(json.dumps({'phase':'launching','all_models_verified':True,'at':time.time()}))
    # No shell, no executable/user expression in API parameters.
    os.chdir(COMFY)
    status.close()
    os.execv(sys.executable,[sys.executable,str(COMFY/'main.py'),'--listen','0.0.0.0','--port','8188'])


if __name__=='__main__':main()
