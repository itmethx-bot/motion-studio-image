"""Additive, whole-scene generation adapters; existing composite workflow is unchanged.

Every motion remap is a single uniform scale and translation for the entire
sequence. Geometry is deliberately two dimensional and does not certify contact,
support planes, depth, or generated video quality.
"""
import itertools
import json
from copy import deepcopy

import numpy as np

from . import nodes
from .scene_core import (PALETTE, associate_props, best_appearance_frame, bounds,
                         choose_primary_window, filter_person_tracks, identity_order,
                         motion_foreground, render_identities, resolve_visible_masks,
                         safe_primary_prop_mask, select_scene_interaction_props)


def _array(value):
    return value.cpu().float().numpy()


def _tensor(value):
    import torch
    import comfy.model_management as mm
    return torch.from_numpy(np.ascontiguousarray(value, dtype=np.float32)).to(
        device=mm.intermediate_device(), dtype=mm.intermediate_dtype())


def _mask_batch(value, width, height):
    import cv2
    result = _array(value)
    if result.ndim == 2:
        result = result[None]
    if result.ndim != 3:
        raise ValueError('รูปแบบหน้ากากไม่ถูกต้อง ต้องเป็นหน้ากากแยกของแต่ละคน')
    if not len(result):
        return np.zeros((0, height, width), bool)
    return np.stack([cv2.resize(m, (width, height), interpolation=cv2.INTER_NEAREST)
                     for m in result]) > .5


def _decode(data, frames, width, height):
    import cv2
    from comfy.ldm.sam3.tracker import unpack_masks
    packed = data.get('packed_masks') if data else None
    if packed is None or packed.shape[1] == 0:
        return np.zeros((frames, 0, height, width), bool)
    raw = _array(unpack_masks(packed))
    if raw.ndim != 4 or len(raw) != frames:
        raise ValueError('จำนวนเฟรมข้อมูลติดตามไม่ตรงกับวิดีโอ กรุณาติดตามคลิปเดิมใหม่')
    return np.stack([np.stack([cv2.resize(m, (width, height), interpolation=cv2.INTER_NEAREST)
                               for m in frame]) for frame in raw]) > .5


def _anchors(mask):
    x0, y0, x1, y1 = bounds(mask)
    cx = (x0 + x1) / 2
    return np.array([[cx, y0], [cx, (y0 + y1) / 2], [cx, y1]], np.float64)


def _apply_points(points, matrix):
    return np.asarray(points) @ np.asarray(matrix)[:, :2].T + np.asarray(matrix)[:, 2]


def _trajectory_bounds(masks):
    return bounds(np.asarray(masks).any(axis=tuple(range(np.asarray(masks).ndim - 2))))


def _fit_path(desired_scale, desired_translation, trajectory, width, height, margin=2):
    """Clamp ONE constant transform to the union of the entire motion path."""
    x0, y0, x1, y1 = trajectory
    scale = min(float(desired_scale), (width - 2 * margin) / max(1, x1 - x0),
                (height - 2 * margin) / max(1, y1 - y0))
    if not np.isfinite(scale) or scale <= .08:
        raise ValueError('เส้นทางกลุ่มกว้างเกินฉาก กรุณาใช้คลิปที่คนเคลื่อนที่ในพื้นที่แคบลง')
    tx = float(np.clip(desired_translation[0], margin - scale*x0, width-margin-scale*x1))
    ty = float(np.clip(desired_translation[1], margin - scale*y0, height-margin-scale*y1))
    return np.array([[scale, 0., tx], [0., scale, ty]], np.float64)


def _warp_batch(images, matrix, width, height, nearest=False):
    import cv2
    interpolation = cv2.INTER_NEAREST if nearest else cv2.INTER_LINEAR
    matrix = np.asarray(matrix, np.float64)
    return np.stack([cv2.warpAffine(np.asarray(image, np.float32), matrix, (width, height),
                                    flags=interpolation, borderMode=cv2.BORDER_CONSTANT)
                     for image in images]).astype(np.float32)


def _isolated(image, mask, color):
    view = np.zeros_like(image, dtype=np.float32)
    colors = np.zeros_like(view)
    view[mask] = image[mask]
    colors[mask] = color
    return view, colors


def _appearance_sheet(views, masks, width, height):
    """Cropped appearance evidence, on neutral panels; never a target-scene collage."""
    import cv2
    sheet = np.full((height, width, 3), .5, np.float32)
    if not views:
        return sheet
    columns = min(3, len(views))
    rows = (len(views) + columns - 1) // columns
    for index, (view, colors) in enumerate(zip(views, masks)):
        mask = colors.any(axis=-1)
        if mask.sum() < 16:
            continue
        x0, y0, x1, y1 = bounds(mask)
        left = (index % columns) * width // columns
        right = (index % columns + 1) * width // columns
        top = (index // columns) * height // rows
        bottom = (index // columns + 1) * height // rows
        padding = max(2, min(right-left, bottom-top)//20)
        available_w, available_h = right-left-2*padding, bottom-top-2*padding
        scale = min(available_w/(x1-x0), available_h/(y1-y0))
        size = (max(1, round((x1-x0)*scale)), max(1, round((y1-y0)*scale)))
        rgb = np.where(mask[y0:y1, x0:x1, None], view[y0:y1, x0:x1], .5)
        crop = cv2.resize(rgb, size, interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
        x, y = left+(right-left-size[0])//2, top+(bottom-top-size[1])//2
        sheet[y:y+size[1], x:x+size[0]] = crop
    return sheet


def source_track_diagnostics(masks, filter_report, primary, order, fps):
    """Compact, read-only evidence for refused source tracks; never merges or drops IDs.

    Every track has at most three bounding-box examples and eight visibility
    runs. Each pair has at most twelve shared-frame overlap measurements. Raw
    masks, image pixels and full per-frame arrays never enter the error report.
    """
    masks = np.asarray(masks, dtype=bool)
    frames, tracks, height, width = masks.shape
    areas = masks.sum(axis=(2, 3))
    active = areas >= 16
    accepted = [int(index) for index in order]
    report_by_id = {int(item['track_id']): item for item in filter_report}
    first_occupancy = masks[0].sum(axis=0) if frames else np.zeros((height, width), np.uint8)
    summaries = []
    for index in range(tracks):
        times = np.flatnonzero(active[:, index])
        report = report_by_id.get(index, {})
        summary = {'track_id': index, 'accepted': index in accepted,
                   'active_frames': int(len(times)), 'first_frame': None, 'last_frame': None,
                   'first_frame_area_pixels': int(areas[0, index]) if frames else 0,
                   'first_frame_canvas_fraction': round(float(areas[0, index])/(height*width), 6) if frames else 0.,
                   'first_frame_exclusive_pixels': int((masks[0, index] & (first_occupancy == 1)).sum()) if frames else 0,
                   'first_frame_shared_pixels': int((masks[0, index] & (first_occupancy > 1)).sum()) if frames else 0,
                   'peak_frame': None, 'peak_area_pixels': 0, 'peak_canvas_fraction': 0.,
                   'body_support_frames': int(report.get('body_support_frames', 0)),
                   'face_support_frames': [int(k) for k in report.get('face_support_frames', [])[:12]],
                   'filter_reason': report.get('reason', 'unknown'),
                   'visibility_run_count': 0, 'visibility_runs': [], 'bounds_examples': []}
        if len(times):
            first, last = int(times[0]), int(times[-1])
            peak = int(areas[:, index].argmax())
            run_starts = np.r_[times[0], times[1:][np.diff(times) > 1]]
            run_ends = np.r_[times[:-1][np.diff(times) > 1], times[-1]]
            examples = list(dict.fromkeys([first, peak, last]))
            summary.update(first_frame=first, last_frame=last, peak_frame=peak,
                           peak_area_pixels=int(areas[peak, index]),
                           peak_canvas_fraction=round(float(areas[peak, index])/(height*width), 6),
                           visibility_run_count=int(len(run_starts)),
                           visibility_runs=[[int(a), int(b)] for a, b in zip(run_starts[:8], run_ends[:8])],
                           bounds_examples=[{'frame': k, 'area_pixels': int(areas[k, index]),
                                             'bounds': list(bounds(masks[k, index]))} for k in examples])
        summaries.append(summary)
    simultaneous = active[:, accepted].sum(axis=1) if accepted else np.zeros(frames, np.int64)
    counts, frequencies = np.unique(simultaneous, return_counts=True)
    pairs = []
    # Include rejected channels too: a tiny fragment or nested proposal may be
    # the evidence explaining why the tracker issued extra IDs.
    for first, second in itertools.combinations(range(tracks), 2):
        shared = np.flatnonzero(active[:, first] & active[:, second])
        samples = shared[np.unique(np.linspace(0, len(shared)-1, min(12, len(shared)), dtype=int))] if len(shared) else shared
        ious, containments = [], []
        for k in samples:
            intersection = int((masks[k, first] & masks[k, second]).sum())
            union = int(areas[k, first]+areas[k, second])-intersection
            ious.append(intersection/max(1, union))
            containments.append(intersection/max(1, int(min(areas[k, first], areas[k, second]))))
        def statistics(values):
            if not values:
                return None
            return {'min': round(float(min(values)), 5), 'median': round(float(np.median(values)), 5),
                    'max': round(float(max(values)), 5)}
        first_intersection = int((masks[0, first] & masks[0, second]).sum()) if frames else 0
        first_union = int(areas[0, first]+areas[0, second])-first_intersection if frames else 0
        first_smaller = int(min(areas[0, first], areas[0, second])) if frames else 0
        pairs.append({'tracks': [first, second], 'co_visible_frames': int(len(shared)),
                      'sampled_frames': [int(k) for k in samples],
                      'first_frame_iou': round(first_intersection/max(1, first_union), 5),
                      'first_frame_intersection_over_smaller': round(first_intersection/max(1, first_smaller), 5),
                      'iou': statistics(ious), 'intersection_over_smaller': statistics(containments)})
    return {'decoded_shape': list(masks.shape), 'fps': float(fps), 'selected_primary': int(primary),
            'accepted_order': accepted, 'tracks': summaries, 'pairs': pairs,
            'simultaneous_accepted_ids': {str(int(count)): int(frequency) for count, frequency in zip(counts, frequencies)},
            'max_simultaneous_accepted_ids': int(simultaneous.max()) if len(simultaneous) else 0,
            'sample_limit_per_pair': 12,
            'interpretation': 'Track IDs and 2D overlap evidence only; no identities merged or people removed.'}


def _refused_tracks(message, masks, report, primary, order, fps):
    summary = source_track_diagnostics(masks, report, primary, order, fps)
    return ValueError(message + '\nTRACK_DIAGNOSTICS=' +
                      json.dumps(summary, ensure_ascii=False, separators=(',', ':')))


class MotionFullGenerationPlan:
    @classmethod
    def INPUT_TYPES(cls):
        result = deepcopy(nodes.MotionPrepareScene.INPUT_TYPES())
        result.setdefault('optional', {}).update(
            action_description=('STRING', {'default': '', 'multiline': True}),
            garment_sequence=('STRING', {'default': '', 'multiline': True}))
        return result

    RETURN_TYPES = ('IMAGE', 'IMAGE', 'IMAGE', 'IMAGE', 'IMAGE', 'IMAGE',
                    'STRING', 'STRING', 'STRING', 'MOTION_SCENE_PLAN', 'IMAGE', 'IMAGE')
    RETURN_NAMES = ('layout_guide', 'companion_sheet', 'motion_rgb', 'motion_ids',
                    'identity_refs', 'identity_masks', 'image_prompt', 'video_prompt',
                    'analysis', 'plan', 'clean_room', 'full_identity_sheet')
    FUNCTION = 'prepare'
    CATEGORY = 'Motion Studio / Full Generation'

    def prepare(self, reference, reference_mask, source_frames, track_data, women_mask,
                reference_objects=None, source_object_tracks=None, fps=30.,
                action_description='', garment_sequence=''):
        for value in (action_description, garment_sequence):
            if not isinstance(value, str) or len(value) > 4000:
                raise ValueError('คำอธิบายการกระทำหรือเสื้อผ้าต้องเป็นข้อความไม่เกิน 4000 ตัวอักษร')
        action_description, garment_sequence = action_description.strip(), garment_sequence.strip()
        source, ref = _array(source_frames), _array(reference)[0]
        if source.ndim != 4 or len(source) < 1:
            raise ValueError('ไม่พบเฟรมวิดีโอสำหรับวางแผนฉาก')
        count, height, width = source.shape[:3]
        if ref.shape != (height, width, 3):
            raise ValueError('ขนาดภาพอ้างอิงไม่ตรงกับคลิป กรุณาปรับทั้งสองให้ใช้ขนาดเดียวกัน')
        people = _decode(track_data, count, width, height)
        if people.shape[1] == 0:
            raise ValueError('ตรวจไม่พบคนในคลิป กรุณาใช้คลิปที่เห็นคนชัดขึ้น')
        sample = np.unique(np.linspace(0, min(count-1, round(float(fps))),
                                       min(8, count), dtype=int)).tolist()
        faces = {k: nodes.face_boxes(source[k]) for k in sample}
        raw_people = people
        people, track_report = filter_person_tracks(people, faces)
        women = _mask_batch(women_mask, width, height)
        if not len(women):
            women = np.zeros((1, height, width), bool)
        primary, info = choose_primary_window(people, women, faces, sample)
        order = identity_order(people, primary)
        if len(order) > 3:
            raise _refused_tracks('โหมดสร้างทุกคนใหม่รองรับสูงสุด 3 คน กรุณาตัดคลิปให้มีคนไม่เกิน 3 คน',
                                 raw_people, track_report, primary, order, fps)
        if any(people[0, person].sum() < 16 for person in order):
            raise _refused_tracks('โหมดสร้างทุกคนใหม่ยังไม่รองรับคนที่เข้าฉากภายหลัง กรุณาตัดต้นคลิปให้เห็นทุกคนพร้อมกัน',
                                 raw_people, track_report, primary, order, fps)
        del raw_people
        refs = _mask_batch(reference_mask, width, height)
        if not len(refs) or not refs.any():
            raise ValueError('ไม่พบผู้หญิงในภาพอ้างอิง กรุณาใช้ภาพที่เห็นคนหลักชัด')
        ref_person = refs[np.argmax(refs.sum(axis=(1, 2)))]
        bounds(ref_person)
        ref_accessory = np.zeros_like(ref_person)
        ref_prop_report = []
        if reference_objects is not None:
            objects = _mask_batch(reference_objects, width, height)
            if len(objects):
                assigned, ref_prop_report = associate_props(ref_person[None, None], objects[None])
                ref_accessory = assigned[0, 0]
        props = _decode(source_object_tracks, count, width, height)
        from .scene_core import select_initial_scene_props
        selected, prop_report = select_initial_scene_props(people, props, primary)
        visible, overlap = resolve_visible_masks(people)
        companion_region = np.delete(people, primary, axis=1).any(axis=1)
        accepted_props = [index for index in range(selected.shape[1]) if selected[:, index].any()]
        if len(order) + len(accepted_props) > len(PALETTE):
            raise ValueError('จำนวนคนและอุปกรณ์ที่ติดตามรวมกันเกิน 6 รายการ กรุณาใช้ช่วงคลิปที่เรียบง่ายขึ้น')
        prop_color_index = {prop: len(order)+i for i, prop in enumerate(accepted_props)}
        identities = visible
        prop_overlap = float((selected.any(axis=1) & people.any(axis=1)).sum() /
                             max(1, selected.any(axis=1).sum()))
        foreground = motion_foreground(source, people, selected)
        trajectory = _trajectory_bounds(people.any(axis=1) | selected.any(axis=1))
        ref_anchor, source_anchor = _anchors(ref_person), _anchors(people[0, primary])
        desired_scale = (ref_anchor[2, 1]-ref_anchor[0, 1])/(source_anchor[2, 1]-source_anchor[0, 1])
        fitted_scale = min(desired_scale, (width-4)/(trajectory[2]-trajectory[0]),
                           (height-4)/(trajectory[3]-trajectory[1]))
        desired_delta = ref_anchor[2] - fitted_scale * source_anchor[2]
        matrix = _fit_path(fitted_scale, desired_delta, trajectory, width, height)
        motion_rgb = _warp_batch(foreground, matrix, width, height)
        source_ids = render_identities(identities, order)
        occupied_people = people.any(axis=1)
        for prop in accepted_props:
            source_ids[selected[:, prop] & ~occupied_people] = PALETTE[prop_color_index[prop]]
            prop_report[prop]['identity_color_index'] = prop_color_index[prop]
        motion_ids = _warp_batch(source_ids, matrix, width, height, nearest=True)
        initial_people = _warp_batch(visible[0, order], matrix, width, height, nearest=True) > .5
        if any(mask.sum() < 16 for mask in initial_people):
            raise ValueError('คนบางคนเล็กเกินไปหลังจัดกลุ่ม กรุณาใช้คลิปที่เห็นทุกคนชัดขึ้น')
        layout = np.full((height, width, 3), .5, np.float32)
        occupied = motion_ids[0].any(axis=-1)
        layout[occupied] = motion_ids[0][occupied]
        # Reference-only objects are not appearance requirements. Do not union
        # their pixels into the identity reference. Preserve overlap with the
        # person mask conservatively: subtracting it could erase hands or clothes.
        main_view, main_colors = _isolated(ref, ref_person, PALETTE[0])
        views, colors = [main_view], [main_colors]
        appearance_frames, guards, sheet_panels = {}, [], []
        for color_id, person in enumerate(order[1:], start=1):
            best = best_appearance_frame(source, people, person)
            # Never make the source main person into companion identity evidence.
            mask = visible[best, person] & ~people[best, primary]
            if mask.sum() < 16:
                raise ValueError('ภาพอ้างอิงคนร่วมฉากถูกคนหลักบัง กรุณาใช้คลิปที่เห็นแต่ละคนแยกชัด')
            view, color = _isolated(source[best], mask, PALETTE[color_id])
            views.append(view); colors.append(color)
            appearance_frames[str(person)] = best
            sheet_panels.append(f'panel {len(sheet_panels)+1}: companion {color_id}, '
                                f'{"red" if color_id == 1 else "green"} identity in image 3')
        for prop_id in range(selected.shape[1]):
            times = np.flatnonzero(selected[:, prop_id].sum(axis=(1, 2)) >= 16)
            candidates = []
            # Appearance sampling is bounded; do not run a face detector for
            # every frame of a long clip just to choose one object reference.
            times = times[np.unique(np.linspace(0, len(times)-1, min(16, len(times)), dtype=int))] if len(times) else times
            for k in times:
                mask, guard = safe_primary_prop_mask(selected[k, prop_id], people[k, primary],
                    faces[k] if k in faces else nodes.face_boxes(source[k]))
                # Never use skin/clothing belonging to any source person as
                # object appearance. This is conservative at fingers/handles.
                mask &= ~people[k].any(axis=0)
                candidates.append((int(mask.sum()), int(k), mask, guard))
            if candidates:
                area, best, mask, guard = max(candidates, key=lambda item: (item[0], -item[1]))
                guards.append({'object_track': prop_id, 'guard': guard, 'frame': best})
                if area >= 16:
                    color_index = prop_color_index[prop_id]
                    view, color = _isolated(source[best], mask, PALETTE[color_index])
                    views.append(view); colors.append(color)
                    sheet_panels.append(f'panel {len(sheet_panels)+1}: interaction object {prop_id+1}, '
                                        f'mask color {PALETTE[color_index].tolist()}, '
                                        'object reference only, not another person; '
                                        + ('visible in the first frame, include at the position in image 3'
                                           if selected[0, prop_id].sum() >= 16 else
                                           'later-only object, do not include in this initial scene'))
                else:
                    raise ValueError('แยกภาพอุปกรณ์ออกจากใบหน้าคนหลักไม่ได้ กรุณาใช้ช่วงคลิปที่เห็นอุปกรณ์ชัดขึ้น')
        sheet = _appearance_sheet(views[1:], colors[1:], width, height)
        # Keep the room and every identity in separate conditioning images so
        # the reference woman's old position cannot become a third person.
        # This plate is only a Qwen reference, never a final-scene composite.
        clean_room = nodes.clean_background(ref, ref_person | ref_accessory)
        full_identity_sheet = _appearance_sheet(views, colors, width, height)
        full_sheet_panels = ['panel 1: the main woman from the original reference photograph, '
                             'blue identity in image 3; face, hair, clothing and worn jewelry only; '
                             'use image 3 for pose and source interaction-object panels for handheld props']
        full_sheet_panels.extend(f'panel {index+2}: {panel.split(": ", 1)[1]}'
                                 for index, panel in enumerate(sheet_panels))
        initial_props = []
        later_props = []
        for prop_id in range(selected.shape[1]):
            if not selected[:, prop_id].any():
                continue
            if selected[0, prop_id].sum() >= 16:
                mask = _warp_batch(selected[0, prop_id][None], matrix, width, height, nearest=True)[0] > .5
                initial_props.append({'object_track': prop_id, 'bounds': list(bounds(mask)),
                                      'area': int(mask.sum()),
                                      'identity_color_index': prop_color_index[prop_id],
                                      'contact_identity_indices': [order.index(person) for person in order
                                          if 0 in prop_report[prop_id].get('contact_by_track', {}).get(str(person), {}).get('contact_frames', [])],
                                      'contact_at_start': 0 in prop_report[prop_id]['contact_frames']})
            else:
                later_props.append(prop_id)
        identity_count = len(order)
        prompt_positions = []
        for color_id, mask in enumerate(initial_people):
            anchors = _anchors(mask)
            color_name = ('Blue main woman', 'Red companion 1', 'Green companion 2')[color_id]
            prompt_positions.append(
                f'{color_name}: center x={100*anchors[0, 0]/width:.1f}% of width, '
                f'head top y={100*anchors[0, 1]/height:.1f}% of height, '
                f'visible body bottom y={100*anchors[2, 1]/height:.1f}%')
        image_prompt = (
            f'Recompose image 1 into one new photorealistic scene with exactly {identity_count} people. '
            'Image 1 supplies the ONLY main woman and the environment, perspective and lighting. '
            'MOVE that existing woman to the blue silhouette position in image 3; her old position '
            'becomes reconstructed background, never another copy of her. '
            'Preserve her face, hair, visible body proportions, clothing and worn jewelry. '
            'The source starting pose in image 3 overrides the reference photograph\'s pose: '
            'match its shoulders, elbows, wrists, hands and body position, including free or lowered arms. '
            'The blue person must come from image 1, not from any companion in image 2. '
            + (f'Add exactly {identity_count-1} distinct companion(s) from their image 2 panels at the '
               'red/green silhouette positions. ' if identity_count > 1 else 'Add no companions. ') +
            'Use each companion panel exactly once; object panels are not extra people. '
            'Read image 2 panels left-to-right within each row, then top-to-bottom: '
            + ('; '.join(sheet_panels) if sheet_panels else 'no companions or source objects') + '. '
            'Image 3 controls camera distance, poses, scale, spacing and the visible crop. Colors mark '
            'positions only: blue is the image 1 woman, never blue clothing or an extra person. '
            'Keep these positions exactly: ' + '; '.join(prompt_positions) + '. '
            'Preserve the empty space above and around the silhouettes and show bodies down to their '
            'visible bottoms. Do not zoom, change framing, enlarge a person, or crop a visible head. '
            'Handheld props come only from the accepted source interaction-object panels in image 2. '
            'Do not carry over bags, handheld items or gripping poses from image 1. '
            'Add only source objects labeled visible in the first frame, at their image 3 positions; '
            'exclude later-only objects and unrelated source scenery. '
            + ('Only the listed first-frame source objects may occupy the hands; all other hands '
               'follow the source starting pose without invented props. ' if initial_props else
               'No source interaction object is visible at the start: keep hands empty in the '
               'source starting pose, with no reference-only bag or invented handheld object. ') +
            'Generate all people naturally together in the room with consistent perspective, lighting, '
            'shadows and plausible common support. Complete any body region visible in the target pose '
            'but hidden in image 1 with plausible anatomy consistent with her visible proportions; '
            'do not invent limbs outside the target frame or duplicate occluded limbs. '
            + ('Use only the INITIAL garment state in this sequence for the still image: '
               + garment_sequence + '. ' if garment_sequence else
               'Begin with clothing consistent with image 1. ') +
            ('The activity begins as follows: ' + action_description + '. ' if action_description else '') +
            'No extra person, duplicated identity, colored silhouette, panels, collage seams or text.')
        video_prompt = (
            f'A continuous photorealistic video of exactly {identity_count} distinct people in the newly '
            'generated scene and the environment of the reference photograph. The main woman has the face, '
            'hair and visible body proportions of the woman in the original photograph. Each companion '
            'has their own distinct appearance from the companion reference sheet. Their coordinated '
            'movement, relative spacing, timing, hand actions and interaction-object trajectories follow '
            'the motion example, beginning with its starting arm and hand positions. Handheld props '
            'are limited to the accepted source interaction objects at their demonstrated times; '
            'reference-only bags and grips are absent. All people share plausible common support, coherent lighting and shadows, '
            'with continuous natural body movement and interactions. Objects used by all participants appear '
            'at the demonstrated positions and times. The environment remains consistent with the reference '
            'photograph throughout, and the people retain stable, distinct identities. '
            'Visible limbs are connected and proportionally consistent, including through clothing and occlusion. '
            + ('Observed action description: ' + action_description + '. ' if action_description else '') +
            ('Garment states change continuously in this order: ' + garment_sequence + '. '
             if garment_sequence else
             'Garment handling follows the demonstrated action; reference clothing defines the starting '
             'appearance, not a requirement to freeze garment state during the action. '))
        mapped_corners = _apply_points([[trajectory[0], trajectory[1]], [trajectory[2], trajectory[3]]], matrix)
        cropped = {'reference_bottom_cropped': bool(ref_person[-2:].any()),
                   'source_bottom_cropped': bool(people[:, order, -2:, :].any())}
        initial_anchors = np.stack([_anchors(mask) for mask in initial_people])
        info.update(generation_mode='all people jointly regenerated in a new first scene',
                    primary_track=int(primary), identity_order=order, people=identity_count,
                    person_tracks=track_report, appearance_frames=appearance_frames,
                    source_props=prop_report, reference_props=ref_prop_report,
                    companion_sheet_panels=sheet_panels,
                    full_identity_sheet_panels=full_sheet_panels,
                    qwen_reference_order=['reference_photo', 'companion_and_object_sheet', 'layout_guide'],
                    explicit_action_description=action_description,
                    explicit_garment_sequence=garment_sequence,
                    action_captioner_implemented=False,
                    anatomy_fallback_authorized=True, anatomy_fallback_implemented=False,
                    prop_identity_policy='separate stable colors for interaction objects; never attach all props to main',
                    reference_identity_policy='face, hair, starting clothing and worn jewelry; '
                                              'source starting pose overrides reference arm and hand pose',
                    handheld_prop_policy='accepted source interaction tracks only, at their demonstrated times; '
                                         'no reference-only handheld props',
                    reference_accessory_policy='object masks remove accessories from the clean room but are not '
                                               'unioned into identity evidence; person overlap is preserved to protect hands and clothing',
                    reference_accessory_excluded_pixels=int((ref_accessory & ~ref_person).sum()),
                    reference_accessory_person_overlap_pixels=int((ref_accessory & ref_person).sum()),
                    reference_accessory_overlap_note='Overlapping object pixels can remain in the person reference; '
                                                     'semantic separation and the generated hand pose require visual review.',
                    clean_room_fill_fraction=float((ref_person | ref_accessory).mean()),
                    clean_room_method='CPU LaMa removes original reference subject and associated accessories; '
                                      'room reconstruction still requires visual review',
                    initial_source_props=initial_props, later_source_props=later_props,
                    excluded_later_source_props=[item['object_track'] for item in prop_report
                                                if item.get('initial_scene_excluded')],
                    source_props_policy='initially_visible_interaction_objects_only',
                    later_prop_note='Objects absent in frame 1 use isolated appearance and motion evidence only; '
                                    'later physical contact or successful entrance is not verified.',
                    prop_appearance_guards=guards, transform=matrix.tolist(),
                    transform_scope='one constant uniform scale and translation for all frames, people and props',
                    desired_body_scale=float(desired_scale), trajectory_bounds=list(trajectory),
                    mapped_trajectory_bounds=mapped_corners.ravel().tolist(),
                    cropped_feet=cropped, source_background_in_rgb_guide=False,
                    source_main_identity_in_rgb_guide=True,
                    identity_leakage='Source main face/body remain in RGB motion guidance and may affect generation; '
                                     'they are excluded from appearance references and layout pixels.',
                    overlap_fraction=overlap, prop_overlap_fraction=prop_overlap,
                    geometry='2D silhouettes and bottom anchors; no 3D support or depth measurement',
                    hand_contact='not verified physical contact; joint generation is not a guarantee',
                    automatic_quality_verified=False)
        plan = {'version': 1, 'width': width, 'height': height, 'frames': count,
                'people': identity_count, 'identity_order': order,
                'initial_anchors': initial_anchors.tolist(),
                'initial_props': initial_props,
                'mapped_trajectory_bounds': mapped_corners.ravel().tolist(),
                'source_to_layout': matrix.tolist(), 'analysis': info}
        return (_tensor(layout[None]), _tensor(sheet[None]), _tensor(motion_rgb), _tensor(motion_ids),
                _tensor(np.stack(views)), _tensor(np.stack(colors)), image_prompt, video_prompt,
                json.dumps(info, ensure_ascii=False), plan, _tensor(clean_room[None]), _tensor(full_identity_sheet[None]))


def _least_squares_similarity(source, target):
    """Upright similarity: least-squares uniform scale plus translation, no person shifts."""
    source, target = np.asarray(source).reshape(-1, 2), np.asarray(target).reshape(-1, 2)
    a, b = source-source.mean(axis=0), target-target.mean(axis=0)
    scale = float((a*b).sum()/max(1e-8, (a*a).sum()))
    delta = target.mean(axis=0)-scale*source.mean(axis=0)
    return np.array([[scale, 0., delta[0]], [0., scale, delta[1]]], np.float64)


def _match_generated(masks, plan):
    expected = int(plan['people'])
    if len(masks) != expected:
        raise ValueError(f'ฉากใหม่มีคน {len(masks)} คน แต่ต้องมี {expected} คน กรุณาเปลี่ยน seed แล้วสร้างฉากแรกใหม่ก่อนสร้างวิดีโอ')
    for i in range(len(masks)):
        for j in range(i):
            intersection = int((masks[i] & masks[j]).sum())
            smaller = min(int(masks[i].sum()), int(masks[j].sum()))
            if intersection/max(1, smaller) > .65:
                raise ValueError('หน้ากากคนในฉากใหม่ซ้ำหรือซ้อนกันมาก กรุณาเปลี่ยน seed แล้วสร้างฉากแรกใหม่')
    anchors = np.stack([_anchors(mask) for mask in masks])
    predicted = np.asarray(plan['initial_anchors'], np.float64)
    candidates = []
    for assignment in itertools.permutations(range(expected)):
        target = anchors[list(assignment)]
        matrix = _least_squares_similarity(predicted, target)
        if matrix[0, 0] <= 0:
            continue
        residual = float(np.sqrt(np.mean((_apply_points(predicted, matrix)-target)**2)))
        candidates.append((residual, assignment, matrix, target))
    candidates.sort(key=lambda item: (item[0], item[1]))
    if not candidates:
        raise ValueError('ตำแหน่งคนในฉากใหม่ไม่ตรงกับแผน กรุณาเปลี่ยน seed แล้วสร้างฉากแรกใหม่')
    _, assignment, matrix, target = candidates[0]
    typical_height = max(1., float(np.median(target[:, 2, 1]-target[:, 0, 1])))
    if len(candidates)>1 and candidates[1][0]-candidates[0][0] < .015*typical_height:
        raise ValueError('จับคู่คนในฉากใหม่ได้ไม่ชัดเจน กรุณาเปลี่ยน seed ให้ทุกคนอยู่ตามผังและเห็นแยกกัน')
    if not .4 <= matrix[0, 0] <= 2.5:
        raise ValueError('ขนาดคนในฉากใหม่ต่างจากผังมาก กรุณาเปลี่ยน seed แล้วสร้างฉากแรกใหม่')
    matrix = _fit_path(matrix[0, 0], matrix[:, 2], plan['mapped_trajectory_bounds'],
                       plan['width'], plan['height'])
    error = _apply_points(predicted, matrix)-target
    rms = float(np.sqrt(np.mean(error**2)))
    worst = float(np.max(np.linalg.norm(error, axis=-1)))
    if rms > .10*typical_height or worst > .20*typical_height:
        raise ValueError('สัดส่วนหรือตำแหน่งกลุ่มในฉากใหม่ไม่ตรงกับเส้นทางร่วม กรุณาเปลี่ยน seed แล้วสร้างฉากแรกใหม่ ห้ามเลื่อนคนแยกกัน')
    return list(assignment), matrix, {'rms_pixels': rms, 'worst_anchor_error_pixels': worst,
                                     'normalized_rms': rms/typical_height}


def _deduplicate_masks(masks):
    """Collapse only near-identical SAM proposals, retaining the largest region.

    This does not reconcile missing people or relax the required person count.
    Distinct overlapping people still reach the ambiguity validation below.
    """
    kept, rejected = [], []
    for index in sorted(range(len(masks)), key=lambda i: (-int(masks[i].sum()), i)):
        duplicate = False
        for prior in kept:
            intersection = int((masks[index] & masks[prior]).sum())
            union = int((masks[index] | masks[prior]).sum())
            if intersection/max(1, union) >= .85:
                duplicate = True
                rejected.append(index)
                break
        if not duplicate:
            kept.append(index)
    kept.sort()
    return masks[kept], rejected


def _generated_prop_correspondence(objects, people, plan, matrix):
    """Conservative 2-D object correspondence, without pretending to identify objects.

    Props must match predicted positions and sizes. Source-first-frame contact
    evidence additionally requires generated mask contact with its recorded participants.
    Ambiguous or missing object correspondence fails before video inference.
    """
    import cv2
    expected = plan.get('initial_props', [])
    output = np.zeros((plan['height'], plan['width'], 3), np.float32)
    if not expected:
        return output, []
    failure = ('อุปกรณ์ที่คนในฉากใช้ไม่ตรงกับแผน กรุณาเปลี่ยน seed แล้วสร้างฉากแรกใหม่ '
               'ให้เห็นอุปกรณ์และมือชัดก่อนสร้างวิดีโอ')
    if objects is None or len(expected) > len(PALETTE)-plan['people']:
        raise ValueError(failure)
    objects, _ = _deduplicate_masks(objects[objects.sum(axis=(1, 2)) >= 16])
    primary = people[0]
    primary_height = _anchors(primary)[2, 1]-_anchors(primary)[0, 1]
    touch_radius = max(2, round(.012*primary_height))
    nearby = [cv2.dilate(person.astype('uint8'),
                        np.ones((2*touch_radius+1, 2*touch_radius+1), np.uint8)) > 0
              for person in people]
    candidates = []
    for index, mask in enumerate(objects):
        area = int(mask.sum())
        if area >= .75*mask.size:
            continue
        if any((mask & person).sum()/max(1, person.sum()) > .65 for person in people):
            continue
        candidates.append((index, mask, np.asarray(bounds(mask), np.float64), area))
    choices = []
    for prop in expected:
        x0, y0, x1, y1 = prop['bounds']
        mapped = _apply_points([[x0, y0], [x1, y1]], matrix)
        box = np.r_[mapped[0], mapped[1]]
        center = (box[:2]+box[2:])/2
        expected_area = prop['area'] * matrix[0, 0]**2
        tolerance = max(6., .08*primary_height, .45*max(box[2:]-box[:2]))
        options = []
        for index, mask, candidate, area in candidates:
            ratio = area/max(1., expected_area)
            distance = float(np.linalg.norm((candidate[:2]+candidate[2:])/2-center))
            if not .3 <= ratio <= 3.3 or distance > tolerance:
                continue
            contacts = prop.get('contact_identity_indices', [0] if prop['contact_at_start'] else [])
            if any(person < 0 or person >= len(people) for person in contacts):
                raise ValueError('หมายเลขผู้ใช้อุปกรณ์ไม่ตรงกับแผนฉาก')
            if any((mask & nearby[person]).sum() < max(4, .002*people[person].sum())
                   for person in contacts):
                continue
            overlap = np.maximum(0., np.minimum(box[2:], candidate[2:])-np.maximum(box[:2], candidate[:2])).prod()
            union = (box[2:]-box[:2]).prod()+(candidate[2:]-candidate[:2]).prod()-overlap
            iou = overlap/max(1., union)
            if iou < .12:
                continue
            score = distance/tolerance + .2*abs(np.log(ratio)) + .25*(1-iou)
            options.append((score, index, mask))
        if not options:
            raise ValueError(failure)
        choices.append(sorted(options, key=lambda item: (item[0], item[1]))[:4])
    assignments = []
    for combination in itertools.product(*choices):
        if len({choice[1] for choice in combination}) == len(combination):
            assignments.append((sum(choice[0] for choice in combination), combination))
    assignments.sort(key=lambda item: item[0])
    if not assignments or (len(assignments)>1 and assignments[1][0]-assignments[0][0] < .08):
        raise ValueError(failure)
    report = []
    all_people = people.any(axis=0)
    for prop, (score, index, mask) in zip(expected, assignments[0][1]):
        visible = mask & ~all_people
        if visible.sum() < 16:
            raise ValueError(failure)
        color_index = int(prop.get('identity_color_index', 0))
        if not 0 <= color_index < len(PALETTE):
            raise ValueError('สีระบุอุปกรณ์ไม่ตรงกับแผนฉาก')
        output[visible] = PALETTE[color_index]
        report.append({'source_object_track': prop['object_track'], 'generated_mask': index,
                       'match_cost': float(score), 'identity_color_index': color_index,
                       'color': PALETTE[color_index].tolist(),
                       'contact_identity_indices': prop.get('contact_identity_indices', []),
                       'evidence': '2D position, size and mask contact when expected; not physical-contact proof'})
    return output, report


class MotionFullGenerationReference:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'generated': ('IMAGE',), 'generated_people': ('MASK',),
                'plan': ('MOTION_SCENE_PLAN',), 'motion_rgb': ('IMAGE',), 'motion_ids': ('IMAGE',),
                'identity_refs': ('IMAGE',), 'identity_masks': ('IMAGE',)},
                'optional': {'generated_objects': ('MASK',)}}

    RETURN_TYPES = ('IMAGE', 'IMAGE', 'IMAGE', 'IMAGE', 'STRING')
    RETURN_NAMES = ('reference_views', 'reference_masks', 'adjusted_motion_rgb',
                    'adjusted_motion_ids', 'analysis')
    FUNCTION = 'prepare'
    CATEGORY = 'Motion Studio / Full Generation'

    def prepare(self, generated, generated_people, plan, motion_rgb, motion_ids,
                identity_refs, identity_masks, generated_objects=None):
        height, width = plan['height'], plan['width']
        images = _array(generated)
        if images.shape != (1, height, width, 3):
            raise ValueError('ขนาดฉากใหม่ไม่ตรงกับแผน กรุณาสร้างภาพเดียวที่มีขนาดเดียวกับภาพอ้างอิง')
        raw_masks = _mask_batch(generated_people, width, height)
        masks = raw_masks[raw_masks.sum(axis=(1, 2)) >= 16]
        masks, duplicate_masks = _deduplicate_masks(masks)
        assignment, matrix, errors = _match_generated(masks, plan)
        rgb, ids = _array(motion_rgb), _array(motion_ids)
        refs, colors = _array(identity_refs), _array(identity_masks)
        if rgb.shape != (plan['frames'], height, width, 3) or ids.shape != rgb.shape:
            raise ValueError('เฟรมท่าทางไม่ตรงกับแผน กรุณาใช้ผลจากโหนดวางแผนชุดเดียวกัน')
        if refs.shape != colors.shape or refs.ndim != 4 or refs.shape[1:] != (height, width, 3):
            raise ValueError('ภาพอ้างอิงและสีระบุตัวบุคคลไม่ตรงกัน กรุณาใช้ข้อมูลวางแผนชุดเดียวกัน')
        arranged, overlap = resolve_visible_masks(masks[assignment][None])
        generated_colors = render_identities(arranged, list(range(plan['people'])), background=1)
        objects = _mask_batch(generated_objects, width, height) if generated_objects is not None else None
        prop_colors, prop_correspondence = _generated_prop_correspondence(objects, arranged[0], plan, matrix)
        prop_mask = prop_colors.any(axis=-1)
        generated_colors[0, prop_mask] = prop_colors[prop_mask]
        # The first view is EXACTLY the generated image. No source people are pasted.
        reference_views = np.concatenate([images, refs], axis=0)
        reference_masks = np.concatenate([generated_colors, colors], axis=0)
        adjusted_rgb = _warp_batch(rgb, matrix, width, height)
        adjusted_ids = _warp_batch(ids, matrix, width, height, nearest=True)
        composed = np.vstack([matrix, [0, 0, 1]]) @ np.vstack([plan['source_to_layout'], [0, 0, 1]])
        info = dict(plan['analysis'])
        info.update(generated_person_assignment=assignment, layout_to_generated=matrix.tolist(),
                    source_to_generated=composed[:2].tolist(), generated_layout_errors=errors,
                    generated_overlap_fraction=overlap,
                    generated_prop_correspondence=prop_correspondence,
                    duplicate_generated_proposals_removed=duplicate_masks,
                    generated_bottom_cropped=bool(masks[:, -2:].any()),
                    generated_first_view='unmodified newly generated image; no source-person compositing',
                    generated_correspondence_method='global layout permutation and upright least-squares similarity; no face gender inference',
                    geometry_validation='person count and 2D group correspondence only; not physical contact proof',
                    identity_appearance_verified=False, limb_pose_verified=False,
                    first_scene_visual_review='Required to assess faces, clothing, limb poses and natural contact; '
                                              'box correspondence does not verify these.',
                    automatic_quality_verified=False)
        return (_tensor(reference_views), _tensor(reference_masks), _tensor(adjusted_rgb),
                _tensor(adjusted_ids), json.dumps(info, ensure_ascii=False))


NODE_CLASS_MAPPINGS = {
    'MotionFullGenerationPlan': MotionFullGenerationPlan,
    'MotionFullGenerationReference': MotionFullGenerationReference,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    'MotionFullGenerationPlan': 'Motion: Plan Fully Generated Scene',
    'MotionFullGenerationReference': 'Motion: Validate Fully Generated Scene',
}
