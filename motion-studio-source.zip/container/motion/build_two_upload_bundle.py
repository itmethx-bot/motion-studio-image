"""Build a new explicit-allowlist web-service ZIP; never include credentials/outputs."""
import argparse
import json
from pathlib import Path
import zipfile

import install_two_upload as installer

ROOT = Path(__file__).resolve().parent
PREFIX = 'motion-studio-two-upload/'


def build(output, *, source=ROOT, fixtures=None):
    source = installer.safe_path(source)
    output = installer.safe_path(output)
    if output.exists():
        raise ValueError('Output exists; select a new ZIP filename')
    if output.suffix.lower() != '.zip':
        raise ValueError('Output must have .zip extension')
    files = installer.collect_files(source, fixtures)
    for name in ('install_two_upload.py', 'build_two_upload_bundle.py'):
        path = installer.safe_path(source/name)
        data = path.read_bytes()
        compile(data, str(path), 'exec')
        files[name] = data
    manifest = {'owner': installer.OWNER, 'system_version': 'motion-studio-7-manual-session',
                'generation_nodes_registered_by_web_extension': [],
                'models_included': False, 'credentials_included': False,
                'gpu_quality_verified': False, 'generic_quality_verified': False,
                'files': {name: installer.signature(data) for name, data in files.items()}}
    payload = json.dumps(manifest, ensure_ascii=False, indent=2).encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in files.items():
            archive.writestr(PREFIX+name, data)
        archive.writestr(PREFIX+installer.PACKAGE_MANIFEST, payload)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC verification failed')
        if len(archive.namelist()) != len(files)+1:
            raise ValueError('Unexpected archive members')
        for name, data in files.items():
            if installer.signature(archive.read(PREFIX+name)) != installer.signature(data):
                raise ValueError('Archive hash verification failed: '+name)
    result = {'path': str(output), **installer.signature(output.read_bytes()),
              'files': len(files)+1, 'gpu_quality_verified': False}
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--fixtures', type=Path,
                        help='Optional known-dance.json + approved-scene.png directory')
    args = parser.parse_args(argv)
    try:
        report = build(args.output, fixtures=args.fixtures)
    except (OSError, ValueError, SyntaxError, zipfile.BadZipFile) as error:
        parser.exit(1, 'Bundle creation stopped: '+str(error)+'\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    main()
