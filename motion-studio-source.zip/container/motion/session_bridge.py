"""Manual, reusable Pod connection. Contains no provider API or lease controller."""
import asyncio
import contextlib
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import time

from aiohttp import ClientError, ClientSession, ClientTimeout, CookieJar, web
from .service import Studio, OfflineBackend, SYSTEM_VERSION, ACTIVE_STATUSES, atomic_json, verify_result, validate_two_file_job, UID, PREFIX

POD_URL=re.compile(r'^https://[a-zA-Z0-9]+-8188\.proxy\.runpod\.net/?$')
IMAGE=re.compile(r'^[a-zA-Z0-9./_-]+@sha256:[a-f0-9]{64}$')


def keep_awake(enabled):
    if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | (1 if enabled else 0))


class RemoteError(ValueError):
    def __init__(self,status,message):
        super().__init__(message);self.status=status


class Remote:
    def __init__(self,settings):
        self.base=settings['url'].rstrip('/')+'/motion-studio/api'
        self.code=settings['access_code'];self.session=None

    async def open(self):
        self.session=ClientSession(cookie_jar=CookieJar(),timeout=ClientTimeout(total=120))
        await self.request('POST','/login',{'code':self.code})

    async def request(self,method,path,body=None,data=None):
        # Never replay a mutation, especially /jobs. Recovery reads the durable
        # client job ID instead of submitting another render.
        async with self.session.request(method,self.base+path,json=body if data is None else None,
                data=data,headers={'X-Requested-With':'MotionStudioAuto'},allow_redirects=False) as response:
            if response.status in (401,403):raise RemoteError(response.status,'รหัสเชื่อมต่อไม่ตรงกับ Template หรือ Pod ไม่อนุญาตให้เข้าถึง')
            if response.status>=400:raise RemoteError(response.status,f'ระบบบน Pod ตอบ HTTP {response.status} กรุณาตรวจ URL และการติดตั้ง')
            return await response.json()

    async def close(self):
        if self.session:await self.session.close()


def compatible(status):
    return (isinstance(status,dict) and status.get('system_version')==SYSTEM_VERSION
        and status.get('cleanup_owner')=='user' and status.get('session_mode')=='manual_session'
        and status.get('user_stop_only') is True)


class SessionBackend(OfflineBackend):
    def settings(self):
        path=self.data/'manual-session-connection.json'
        return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else None

    def template(self):
        path=self.data/'manual-session-template.json'
        if path.is_file():return json.loads(path.read_text(encoding='utf-8'))
        config=self.data/'runpod-automation.json'
        image=json.loads(config.read_text(encoding='utf-8')).get('image_name','') if config.is_file() else ''
        if not IMAGE.fullmatch(image):raise ValueError('ยังไม่ได้ติดตั้งชื่อ Docker image รุ่นปัจจุบันบน PC')
        value={'name':'motion-studio-manual','image_name':image,'container_gb':30,'volume_gb':100,
            'ports':'8188/http','env':{'MOTION_CLEANUP_OWNER':'user','MOTION_ACCESS_CODE':secrets.token_urlsafe(32),'MOTION_COMFY_PORT':'8188'}}
        atomic_json(path,value)
        with contextlib.suppress(OSError):path.chmod(0o600)
        return value

    async def ready(self):
        settings=self.settings()
        base={'pc_controller':True,'session_mode':'manual_session','user_stop_only':True,'automatic_stop_ready':False,
            'connected_url':settings['url'] if settings else '', 'connection_needed':not bool(settings)}
        if not settings:return {**base,'ready':False,'message':'เปิด Pod ด้วย Template ของเว็บ แล้วนำลิงก์ ComfyUI มาเชื่อม'}
        remote=Remote(settings)
        try:
            await remote.open();status=await remote.request('GET','/status')
            if not compatible(status):return {**base,'ready':False,'message':'Pod ต้องใช้ Docker image รุ่นเชื่อมเอง · สร้างต่อเนื่อง · หยุดเอง'}
            active=any(row.get('status') in ACTIVE_STATUSES for row in status.get('jobs',[]) if isinstance(row,dict))
            return {**base,'ready':bool(status.get('ready') and not active),
                'message':'พร้อมสร้างหลายคลิปบน Pod เดิม — คุณเป็นผู้ Stop และ Terminate เอง' if status.get('ready') and not active else
                    ('Pod กำลังทำงานหรือรอรับไฟล์ รอให้งานเดิมจบก่อนสร้างคลิปถัดไป' if active else status.get('message','กำลังเตรียมระบบบน Pod'))}
        except (ClientError,asyncio.TimeoutError,OSError,ValueError):
            return {**base,'ready':False,'message':'ติดต่อ Pod ไม่ได้ ตรวจว่าเครื่องเปิดอยู่ หรือเชื่อมลิงก์ของเครื่องใหม่'}
        finally:await remote.close()


class SessionStudio(Studio):
    def __init__(self,backend):
        super().__init__(backend)
        self.poll_seconds=3;self.runtime_limit_seconds=7500
        for job in self.jobs.values():
            if job.get('session_mode')=='manual_session' and job.get('status')=='interrupted':
                job.update(stop_confirmed=None,recoverable=True,message='PC เปิดใหม่ระหว่างงาน กดตรวจงานและกู้ผลเดิมก่อนส่งคลิปใหม่')
                self.persist(job)

    async def status(self,request):
        self.authorize(request)
        readiness=await self.backend.ready()
        jobs=[j for j in self.jobs.values() if j.get('session_mode')=='manual_session' or j.get('result')]
        return web.json_response({**readiness,'system_version':SYSTEM_VERSION,'duration_seconds':10,
            'duration_policy':'source_length_up_to_10s_no_loop_no_retime',
            'jobs':sorted(jobs,key=lambda j:j.get('created',0),reverse=True)[:30]},headers={'Cache-Control':'no-store'})

    async def read_template(self,request):
        self.authorize(request)
        try:value=self.backend.template()
        except ValueError as error:raise web.HTTPBadRequest(text=str(error))
        return web.json_response(value,headers={'Cache-Control':'no-store'})

    async def evidence(self,request):
        self.authorize(request)
        job=self.jobs.get(request.match_info['id'])
        if not job or not job.get('evidence_file'):raise web.HTTPNotFound()
        # New session results are stored beside their videos; prior bridge
        # jobs stored archives in the job folder. Both remain downloadable.
        for folder in (self.backend.outputs,self.job_dir):
            path=(folder/job['evidence_file']).resolve()
            if path.is_relative_to(folder.resolve()) and path.is_file():
                return web.FileResponse(path,headers={'Content-Type':'application/zip'})
        raise web.HTTPNotFound()

    async def connect(self,request):
        self.authorize(request,True);body=await self.body(request)
        if self.task and not self.task.done():raise web.HTTPConflict(text='รอให้งานและการรับไฟล์ปัจจุบันจบก่อนเปลี่ยน Pod')
        url=body.get('url','')
        if not isinstance(url,str):raise web.HTTPBadRequest(text='ลิงก์ Pod ไม่ถูกต้อง')
        url=url.strip()
        if not POD_URL.fullmatch(url):raise web.HTTPBadRequest(text='ใช้ลิงก์ https://รหัสPod-8188.proxy.runpod.net')
        settings={'url':url.rstrip('/'),'access_code':self.backend.template()['env']['MOTION_ACCESS_CODE']}
        remote=Remote(settings)
        try:
            await remote.open();status=await remote.request('GET','/status')
            if not compatible(status):raise ValueError('ใช้ Template และ Docker image รุ่นเชื่อมเอง · สร้างต่อเนื่อง · หยุดเองก่อน')
            atomic_json(self.data/'manual-session-connection.json',settings)
            return web.json_response({'ok':True,'message':'เชื่อมแล้ว ใช้ Pod เดิมสร้างหลายคลิปได้จนกว่าคุณจะหยุดเครื่องเอง'})
        except (ClientError,asyncio.TimeoutError,OSError,ValueError) as error:
            raise web.HTTPBadRequest(text=str(error) if isinstance(error,ValueError) else 'ยังเชื่อมไม่ได้ ตรวจว่า Pod เปิดและใช้ค่าจาก Template ของเว็บ')
        finally:await remote.close()

    async def create(self,request):
        self.authorize(request,True);body=await self.body(request)
        async with self.lock:
            if self.task and not self.task.done():raise web.HTTPConflict(text='รอให้งานก่อนหน้าเสร็จก่อน')
            settings=self.backend.settings()
            if not settings:raise web.HTTPConflict(text='เชื่อม Pod ที่เปิดเองก่อน')
            if any(j.get('recoverable') and j.get('remote_url')==settings['url'] and j.get('session_mode')=='manual_session' for j in self.jobs.values()):
                raise web.HTTPConflict(text='มีงานเดิมที่ต้องตรวจหรือกู้ผลก่อน เพื่อป้องกันการสร้างซ้ำ')
            try:
                image=self.input_record(body.get('image'),'image');video=self.input_record(body.get('video'),'video')
                duration=body.get('duration',10);timing=validate_two_file_job(image,video,duration)
            except (ValueError,KeyError,FileNotFoundError) as error:raise web.HTTPBadRequest(text=str(error))
            if not (await self.backend.ready()).get('ready'):raise web.HTTPConflict(text='Pod ยังไม่พร้อมหรือมีงานกำลังทำอยู่ กรุณาตรวจสถานะ')
            uid=secrets.token_hex(16)
            job={'id':uid,'created':time.time(),'status':'queued','stage':'analyzing','stop_confirmed':None,
                'session_mode':'manual_session','user_stop_only':True,'remote_url':settings['url'],
                'message':'กำลังส่งงานไปยัง Pod ที่คุณเปิดไว้','plan':{'frames':timing['final_frames'],'seconds':timing['final_seconds'],'fps':16}}
            self.jobs[uid]=job;self.persist(job)
            self.task=asyncio.create_task(self.run_remote(job,image,video,duration,settings))
            return web.json_response(job,status=202)

    async def recover(self,request):
        self.authorize(request,True)
        async with self.lock:
            if self.task and not self.task.done():raise web.HTTPConflict(text='กำลังทำงานหรือรับไฟล์อยู่')
            job=self.jobs.get(request.match_info['id']);settings=self.backend.settings()
            if not job or not job.get('recoverable') or job.get('session_mode')!='manual_session':raise web.HTTPConflict(text='งานนี้ไม่ต้องกู้ผล')
            if not settings or settings['url']!=job.get('remote_url'):raise web.HTTPConflict(text='เชื่อม Pod เดิมของงานนี้ก่อนกู้ผล')
            job.update(status='running',stage='downloading',message='กำลังอ่านสถานะและกู้ผลเดิม ไม่มีการส่งงานสร้างใหม่');self.persist(job)
            self.task=asyncio.create_task(self.run_remote(job,None,None,None,settings,recover=True))
            return web.json_response({'ok':True},status=202)

    async def download(self,remote,job,current,suffix,route,expected,max_bytes):
        if not isinstance(expected,str) or not re.fullmatch(r'[a-f0-9]{64}',expected):raise ValueError('Pod ไม่ส่ง SHA256 ของไฟล์ครบ')
        path=self.backend.outputs/(job['id']+suffix);temp=path.with_name(path.name+'.part')
        digest=hashlib.sha256();size=0
        try:
            async with remote.session.get(remote.base+'/jobs/'+job['remote_id']+'/'+route,allow_redirects=False) as response:
                if response.status!=200:raise ValueError('ดาวน์โหลด '+route+' ไม่สำเร็จ เก็บไฟล์ไว้บน Pod เพื่อกู้ใหม่')
                with temp.open('wb') as out:
                    async for chunk in response.content.iter_chunked(1024*1024):
                        size+=len(chunk)
                        if size>max_bytes:raise ValueError('ไฟล์ผลลัพธ์ใหญ่เกินกำหนด')
                        digest.update(chunk);out.write(chunk)
                    out.flush();os.fsync(out.fileno())
            if size<1 or digest.hexdigest()!=expected:raise ValueError('ไฟล์ที่รับมาไม่ตรงกับ SHA256 บน Pod')
            if route=='result':await asyncio.to_thread(verify_result,temp,current['plan'])
            elif size!=current.get('evidence_bytes'):raise ValueError('ขนาดหลักฐานไม่ตรงกับไฟล์บน Pod')
            os.replace(temp,path)
            return path.name,size
        finally:temp.unlink(missing_ok=True)

    async def run_remote(self,job,image,video,duration,settings,*,recover=False):
        remote=Remote(settings);submitted=bool(job.get('submission_attempted'));keep_awake(True)
        try:
            await remote.open();status=await remote.request('GET','/status')
            if not compatible(status) or not UID.fullmatch(str(status.get('instance_id',''))):raise ValueError('ระบบบน Pod ยังไม่พร้อมหรือไม่ใช่รุ่นหยุดเอง')
            if recover and status['instance_id']!=job.get('remote_instance_id'):raise ValueError('Pod เปิดระบบรอบใหม่ กู้ผลเดิมจากรอบเก่าไม่ได้ กรุณาตรวจไฟล์บน Pod')
            if not recover:
                job['remote_instance_id']=status['instance_id'];self.persist(job)
                for kind,record in (('image',image),('video',video)):
                    with (self.backend.inputs/record['file']).open('rb') as file:
                        value=await remote.request('POST','/upload/'+kind,data=file)
                    if not UID.fullmatch(str(value.get('id',''))):raise ValueError('Pod ไม่คืนหมายเลขไฟล์ที่ถูกต้อง')
                    job['remote_'+kind]=value['id']
                job.update(remote_id=job['id'],submission_attempted=True);submitted=True;self.persist(job)
                try:
                    value=await remote.request('POST','/jobs',{'image':job['remote_image'],'video':job['remote_video'],'duration':duration,'client_job_id':job['id']})
                    if value.get('id')!=job['id']:raise ValueError('หมายเลขงานบน Pod ไม่ตรงกับคำขอ')
                except RemoteError as error:
                    if error.status in (400,401,403,404,405,413,422):
                        submitted=False;job['submission_attempted']=False;raise
                    try:value=await remote.request('GET','/jobs/'+job['id'])
                    except RemoteError as lookup:
                        if error.status==409 and lookup.status==404:
                            submitted=False;job['submission_attempted']=False
                            raise ValueError('Pod ไม่รับงานเพราะคิวยังไม่ว่าง รอให้งานบน Pod จบแล้วส่งใหม่ได้') from error
                        raise
                except (ValueError,ClientError,asyncio.TimeoutError):
                    # An accepted POST may lose its response. Inspect its stable
                    # ID; never resend a render. If unreadable, leave recoverable.
                    value=await remote.request('GET','/jobs/'+job['id'])
                job.update(plan=value.get('plan',job['plan']),status='running');self.persist(job)
            deadline=time.monotonic()+self.runtime_limit_seconds
            while time.monotonic()<deadline:
                current=await remote.request('GET','/jobs/'+job['remote_id'])
                if current.get('id')!=job['remote_id'] or current.get('instance_id')!=job['remote_instance_id']:raise ValueError('งานหรือรอบระบบบน Pod ไม่ตรงกับที่ส่งไว้')
                for field in ('stage','message','plan','progress','generation_warnings','error_message','failure_stage'):
                    if field in current:job[field]=current[field]
                if current.get('result'):
                    job.update(stage='downloading',message='กำลังบันทึกวิดีโอและหลักฐานลง PC');self.persist(job)
                    name,size=await self.download(remote,job,current,'.mp4','result',current.get('output_sha256'),512*1024*1024)
                    job.update(result=name,output_sha256=current['output_sha256'],output_bytes=size);self.persist(job)
                    proof,proof_size=await self.download(remote,job,current,'.evidence.zip','evidence',current.get('evidence_sha256'),72*1024*1024)
                    job.update(evidence_file=proof,evidence_sha256=current['evidence_sha256'],evidence_bytes=proof_size,evidence_download_status='verified');self.persist(job)
                    # ACK only completes the service's transfer wait. The user
                    # owns all provider controls; ACK cannot stop the machine.
                    with contextlib.suppress(ValueError,ClientError,asyncio.TimeoutError):await remote.request('POST','/jobs/'+job['remote_id']+'/release',{})
                    job.update(status='completed',stage='completed',recoverable=False,stop_confirmed=None,
                        message='บันทึกวิดีโอและหลักฐานลง PC แล้ว สร้างคลิปถัดไปได้บน Pod เดิม เมื่อเลิกใช้ให้ Stop และ Terminate เอง')
                    job.pop('error_message',None)
                    self.persist(job);return
                if current.get('status') in ('failed','interrupted','cancelled'):
                    job.update(status='failed',stage='failed',recoverable=False,stop_confirmed=None,
                        message=current.get('error_message') or current.get('message','สร้างไม่สำเร็จ — Pod ยังเปิดอยู่'))
                    self.persist(job);return
                job.update(status='running');self.persist(job);await asyncio.sleep(self.poll_seconds)
            raise ValueError('หมดเวลาติดตาม งานบน Pod อาจยังทำอยู่ กดตรวจงานเดิมก่อนสร้างใหม่')
        except Exception as error:
            job.update(status='failed',stage='failed',recoverable=submitted,stop_confirmed=None,
                error_message=str(error) if isinstance(error,ValueError) else 'ติดต่อ Pod ขัดข้อง',
                message='ยังรับงานไม่ครบ กรุณาตรวจงานเดิมและกู้ผล — Pod ยังเปิดอยู่ ให้หยุดเองเมื่อเลิกใช้' if submitted else 'ยังส่งงานสร้างไม่สำเร็จ — Pod ยังเปิดอยู่ ให้หยุดเองเมื่อเลิกใช้')
            self.persist(job)
        finally:await remote.close();keep_awake(False)

    def routes(self):
        routes=list(super().routes())
        for method,path,handler in [('GET','/api/template',self.read_template),('POST','/api/connection',self.connect),('POST','/api/jobs/{id}/recover',self.recover)]:
            routes.append(web.route(method,PREFIX+path,handler))
        return routes
