"""Geometry and identity decisions, independently testable without a GPU."""
import math
import numpy as np

PALETTE = np.array([(0, 0, 1), (1, 0, 0), (0, 1, 0),
                    (1, 0, 1), (0, 1, 1), (1, 1, 0)], dtype=np.float32)


def bounds(mask):
    y, x = np.nonzero(np.asarray(mask) > .5)
    if len(x) < 16:
        raise ValueError('ตรวจไม่พบตัวละครชัดเจน กรุณาใช้ภาพหรือคลิปที่เห็นคนหลักชัดขึ้น')
    return int(x.min()), int(y.min()), int(x.max()+1), int(y.max()+1)


def choose_primary(masks, women, face_boxes=()):
    """Woman labels come from SAM3 text conditioning, never from face gender guesses.

    Score visible face area, body area, and lower silhouette as a foreground proxy.
    This is a heuristic, not a physical depth measurement. Fail closed on ambiguity.
    """
    masks = np.asarray(masks) > .5
    women = np.asarray(women) > .5
    if women.ndim == 3:
        women = women.any(axis=0)
    h, w = women.shape
    candidates = []
    for i, mask in enumerate(masks):
        area = int(mask.sum())
        if area < .002*h*w:
            continue
        overlap = float((mask & women).sum()) / area
        if overlap < .35:
            continue
        _, _, _, bottom = bounds(mask)
        face_area = 0
        for x, y, fw, fh in face_boxes:
            region = mask[max(0,y):min(h,y+fh), max(0,x):min(w,x+fw)]
            if region.size and region.mean() > .4:
                face_area = max(face_area, fw*fh)
        candidates.append((i, area, bottom/h, face_area, overlap))
    if not candidates:
        raise ValueError('ไม่พบผู้หญิงหลักที่ชัดเจนในช่วงต้นคลิป ระบบยังไม่สร้างเพื่อป้องกันการแทนผิดคน')
    max_area = max(v[1] for v in candidates)
    max_face = max(v[3] for v in candidates)
    scores = [(v[0], .45*v[1]/max_area + .20*v[2] +
               .35*(v[3]/max_face if max_face else 0)) for v in candidates]
    scores.sort(key=lambda v: (-v[1], v[0]))
    margin = scores[0][1]-scores[1][1] if len(scores)>1 else 1.
    if len(scores)>1 and margin < .06:
        raise ValueError('ผู้หญิงสองคนเด่นใกล้กันเกินไป กรุณาใช้ช่วงต้นคลิปที่คนเป้าหมายอยู่หน้าสุดและเห็นหน้าชัด')
    return scores[0][0], {'selection_margin': round(margin,4),
                         'visible_face_found': bool(max_face),
                         'selection_method': 'SAM3 woman mask + visible face + foreground proxy'}


def alignment(reference_mask, target_mask, reference_faces=(), target_faces=()):
    """Use matching visible heads when possible; otherwise uniform body-height scaling.
    Return a single affine transform used for BOTH appearance and identity mask.
    """
    rb, tb = bounds(reference_mask), bounds(target_mask)
    def eligible(faces, mask):
        valid = []
        for x,y,w,h in faces:
            patch = mask[max(0,y):y+h, max(0,x):x+w]
            if patch.size and patch.mean()>.4:
                valid.append((x,y,w,h))
        return max(valid, key=lambda v:v[2]*v[3]) if valid else None
    rf, tf = eligible(reference_faces, reference_mask), eligible(target_faces, target_mask)
    if rf and tf:
        scale = tf[2]/rf[2]
        ra = np.array([rf[0]+rf[2]/2, rf[1]+rf[3]/2])
        ta = np.array([tf[0]+tf[2]/2, tf[1]+tf[3]/2])
        method = 'face'
    else:
        scale = (tb[3]-tb[1])/(rb[3]-rb[1])
        ra = np.array([(rb[0]+rb[2])/2, rb[3]])
        ta = np.array([(tb[0]+tb[2])/2, tb[3]])
        method = 'body'
    if not .15 <= scale <= 5:
        raise ValueError('ขนาดคนในรูปกับคลิปต่างกันมากเกินไป กรุณาใช้ภาพที่เห็นร่างกายมากขึ้น')
    delta = ta-scale*ra
    return np.array([[scale,0,delta[0]],[0,scale,delta[1]]],dtype=np.float32), method


def identity_order(track_masks, primary):
    if track_masks.ndim != 4 or not 1 <= track_masks.shape[1] <= len(PALETTE):
        raise ValueError('รุ่นนี้รองรับคนพร้อมกันสูงสุด 6 คน')
    first = []
    for i in range(track_masks.shape[1]):
        times = np.flatnonzero((track_masks[:,i]>.5).sum(axis=(1,2))>=16)
        if len(times):
            first.append((i,int(times[0])))
    if primary not in [i for i,t in first]:
        raise ValueError('ไม่พบคนหลักในข้อมูลติดตาม')
    return [primary]+[i for i,t in sorted(first,key=lambda v:(v[1],v[0])) if i!=primary]


def render_identities(masks, order, background=0):
    """First identity wins overlap, exactly matching SCAIL's native renderer."""
    t, n, h, w = masks.shape
    out = np.full((t,h,w,3),background,dtype=np.float32)
    occupied = np.zeros((t,h,w),dtype=bool)
    for color_id, object_id in enumerate(order):
        active = (masks[:,object_id]>.5) & ~occupied
        out[active] = PALETTE[color_id]
        occupied |= active
    return out


def chunk_plan(frame_count, chunk=33, overlap=5):
    if frame_count < 5:
        raise ValueError('คลิปสั้นเกินไป ต้องมีอย่างน้อย 5 เฟรม')
    frame_count = (frame_count-1)//4*4+1
    result=[]
    start=0
    while start < frame_count:
        count=min(chunk,frame_count-start)
        count=(count-1)//4*4+1
        if count<=overlap and result:
            break
        result.append({'offset':start,'length':count,'trim':overlap if result else 0})
        if start+count>=frame_count:
            break
        start+=chunk-overlap
    return result


def size_for_video(width,height,long_edge=896,upscale=False):
    if min(width,height)<=0:
        raise ValueError('ขนาดวิดีโอไม่ถูกต้อง')
    scale=long_edge/max(width,height)
    if not upscale: scale=min(1,scale)
    return max(32,round(width*scale/32)*32), max(32,round(height*scale/32)*32)


def fit_image(image, width, height, edge_padding=False):
    """Fit the entire image using ONE scale; never crop or stretch its contents."""
    import cv2
    h,w=image.shape[:2]
    scale=min(width/w,height/h)
    nw,nh=max(1,round(w*scale)),max(1,round(h*scale))
    resized=cv2.resize(image,(nw,nh),interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_LANCZOS4)
    left,top=(width-nw)//2,(height-nh)//2
    return cv2.copyMakeBorder(resized,top,height-nh-top,left,width-nw-left,
                              cv2.BORDER_REPLICATE if edge_padding else cv2.BORDER_CONSTANT,value=0)


def filter_person_tracks(masks, faces_by_frame):
    """Reject unsupported segmentation fragments without renumbering identities.

    A tiny border sliver is not a third person. A small but complete background
    person can still qualify from sustained spatial extent, even without a face.
    This is a conservative shape check, not a learned person-quality classifier.
    """
    masks=np.asarray(masks)>0.5
    result=masks.copy()
    t,n,h,w=masks.shape
    min_height=max(12,round(.025*h));min_width=max(4,round(.006*w))
    # Persistence alone does not make a few hundred HD pixels a new person.
    # Unsupported narrow fragments in the failed job lasted 65 frames. Require
    # a modest spatial footprint for late body-only evidence. Keep smaller
    # complete people already present in frame one, and matched visible faces.
    min_body_area=max(16,round(.001*h*w))
    report=[]
    for i in range(n):
        support=[];face_frames=[];largest=0;strong_single=False
        for k in range(t):
            mask=masks[k,i];area=int(mask.sum());largest=max(largest,area)
            if area<16: continue
            x0,y0,x1,y1=bounds(mask)
            supported=(y1-y0>=min_height and x1-x0>=min_width)
            if supported: support.append(k)
            if supported and area>=.005*h*w and y1-y0>=.15*h:
                strong_single=True
            for x,y,fw,fh in faces_by_frame.get(k,()):
                patch=mask[max(0,y):min(h,y+fh),max(0,x):min(w,x+fw)]
                if patch.size and patch.mean()>.4:
                    face_frames.append(k);break
        repeated=any(b==a+1 for a,b in zip(support,support[1:]))
        initially_visible=int(masks[0,i].sum())>=16
        accepted=bool(face_frames or strong_single or
                      (repeated and (initially_visible or largest>=min_body_area)))
        if not accepted: result[:,i]=False
        report.append({'track_id':i,'accepted':accepted,'largest_mask_pixels':largest,
            'minimum_body_area_pixels':min_body_area,'minimum_body_height_pixels':min_height,
            'minimum_body_width_pixels':min_width,
            'initially_visible':initially_visible,
            'body_support_frames':len(support),'face_support_frames':face_frames,
            'reason':'visible_face_or_body_support' if accepted else 'unsupported_tiny_or_transient_fragment'})
    return result,report


def choose_primary_window(masks, women, faces_by_frame, indices):
    """Rank stable person tracks by visible-face/body prominence.

    SAM's first-frame woman query is soft support only: a missed segmentation
    must not exclude the clearest foreground performer. This does not infer
    gender from faces. Full-body visibility is a border-clearance heuristic.
    """
    masks=np.asarray(masks)>0.5
    women=np.asarray(women)>0.5
    if women.ndim==3: women=women.any(axis=0)
    h,w=women.shape
    eligible=[];woman_support={}
    for i,mask in enumerate(masks[0]):
        area=int(mask.sum())
        if area>=max(16,.002*h*w):
            eligible.append(i)
            woman_support[i]=float((mask & women).sum())/area
    if not eligible:
        raise ValueError('ไม่พบคนหลักในเฟรมเริ่มต้น กรุณาใช้ช่วงคลิปที่เห็นคนหลักชัด')
    records={i:[] for i in eligible}
    for t in indices:
        observations=[]
        for i in eligible:
            mask=masks[t,i];area=int(mask.sum())
            if area<max(16,.002*h*w): continue
            x0,y0,x1,y1=bounds(mask)
            face_area=0
            for x,y,fw,fh in faces_by_frame.get(t,()):
                region=mask[max(0,y):min(h,y+fh),max(0,x):min(w,x+fw)]
                if region.size and region.mean()>.4: face_area=max(face_area,fw*fh)
            full=float(x0>1 and y0>1 and x1<w-1 and y1<h-1)
            observations.append((i,area,face_area,y1/h,full))
        max_area=max((v[1] for v in observations),default=1)
        max_face=max((v[2] for v in observations),default=0)
        for i,area,face,bottom,full in observations:
            score=(.50*area/max_area+.35*(face/max_face if max_face else 0)+
                   .10*full+.05*woman_support[i])
            records[i].append((score,bool(face)))
    scores=[]
    for i,values in records.items():
        if values:
            visibility=len(values)/len(indices)
            scores.append((i,float(np.median([v[0] for v in values]))*visibility))
    scores.sort(key=lambda v:(-v[1],v[0]))
    if not scores: raise ValueError('ติดตามคนหลักในช่วงต้นคลิปไม่ได้')
    margin=scores[0][1]-scores[1][1] if len(scores)>1 else 1.
    if margin<.06:
        raise ValueError('คนหลักยังเด่นใกล้เคียงกัน กรุณาเริ่มคลิปในช่วงที่คนเป้าหมายเห็นชัดกว่า')
    return scores[0][0],{'selection_margin':round(margin,4),'selection_frames':list(indices),
        'visible_face_found':any(v[1] for v in records[scores[0][0]]),
        'selection_method':'temporal visible-face/body prominence; SAM3 woman overlap is soft support only',
        'woman_mask_support':{str(i):round(v,4) for i,v in woman_support.items()},
        'woman_mask_missed_selected':woman_support[scores[0][0]]<.35,
        'selection_scores':{str(i):round(score,4) for i,score in scores}}


def associate_props(people, objects):
    """Conservative geometric association, NOT object recognition or depth.

    Reject large/background detections, person-shaped false positives and ambiguous
    shared objects. Each object track is assigned one stable owner by consensus.
    An object handed to another person is left unassigned for joint RGB guidance.
    """
    import cv2
    people=np.asarray(people)>0.5;objects=np.asarray(objects)>0.5
    t,n,h,w=people.shape
    if objects.ndim!=4 or objects.shape[0]!=t or objects.shape[2:]!=(h,w):
        raise ValueError('จำนวนเฟรมหรือขนาดหน้ากากอุปกรณ์ไม่ตรงกับคน')
    assigned=np.zeros_like(people)
    report=[]
    samples=np.unique(np.linspace(0,t-1,min(t,16),dtype=int))
    radius=max(2,round(.025*max(h,w)))
    kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*radius+1,2*radius+1))
    # Compute neighbourhoods once for each sampled person, not once per object.
    nearby={int(k):[cv2.dilate(m.astype('uint8'),kernel)>0 for m in people[k]] for k in samples}
    for obj in range(objects.shape[1]):
        votes=[]
        visible=0
        for k in samples:
            mask=objects[k,obj];area=int(mask.sum())
            if area<16: continue
            visible+=1
            if area>.18*h*w: continue
            scores=[]
            for person in range(n):
                body=people[k,person];body_area=int(body.sum())
                if body_area<16 or area>.65*body_area: continue
                # A near-complete duplicate of a person must never be a prop.
                if (mask & body).sum()/max(1,body_area)>.65: continue
                proximity=float((mask & nearby[int(k)][person]).sum())/area
                if proximity>=.35: scores.append((person,proximity))
            scores.sort(key=lambda v:(-v[1],v[0]))
            if scores and (len(scores)==1 or scores[0][1]-scores[1][1]>=.20): votes.append(scores[0][0])
        winner=max(set(votes),key=votes.count) if votes else None
        confidence=votes.count(winner)/max(1,visible) if winner is not None else 0.
        # A brief but clear handoff still invalidates a single-owner region.
        accepted=winner is not None and confidence>=.70 and len(set(votes))==1
        if accepted:
            for k in range(t):
                mask=objects[k,obj]
                body=people[k,winner]
                # Do not attach a drifting or absent person's object merely by ID.
                if body.sum()<16 or mask.sum()<16 or mask.sum()>.18*h*w: continue
                near=cv2.dilate(body.astype('uint8'),kernel)>0
                if (mask & near).sum()/mask.sum()<.35: continue
                # Preserve objects crossing their holder's torso (e.g. a guitar).
                # Silhouettes of OTHER people still retain their own pixels.
                others=np.delete(people[k],winner,axis=0).any(axis=0)
                assigned[k,winner] |= mask & ~others
        report.append({'object_track':obj,'owner_track':int(winner) if accepted else None,
                       'confidence':round(confidence,4),'accepted':bool(accepted),
                       'reason':'stable_nearby_owner' if accepted else 'unassigned_or_ambiguous'})
    return assigned,report


def best_appearance_frame(frames, masks, person, limit=16):
    """Prefer a large, sharp and unoccluded observation; return a stable track view."""
    import cv2
    times=np.flatnonzero(masks[:,person].sum(axis=(1,2))>=16)
    if not len(times): raise ValueError('ไม่พบภาพตัวละครสำหรับใช้อ้างอิง')
    sample=times[np.unique(np.linspace(0,len(times)-1,min(limit,len(times)),dtype=int))]
    values=[]
    for k in sample:
        mask=masks[k,person]
        gray=cv2.cvtColor(np.uint8(np.clip(frames[k],0,1)*255),cv2.COLOR_RGB2GRAY)
        # Erode to avoid scoring a segmentation boundary as image sharpness.
        interior=cv2.erode(mask.astype('uint8'),np.ones((3,3),np.uint8))>0
        lap=cv2.Laplacian(gray,cv2.CV_32F)
        sharp=float(lap[interior].var()) if interior.sum()>=16 else 0.
        overlap=(mask & (np.delete(masks[k],person,axis=0).any(axis=0))).sum()/mask.sum()
        values.append((int(k),float(mask.sum()),sharp,float(overlap)))
    largest=max(v[1] for v in values)
    sharpest=max(1.,max(v[2] for v in values))
    return max(values,key=lambda v:(.55*v[1]/largest+.30*v[2]/sharpest-.4*v[3],-v[0]))[0]


def select_primary_interaction_props(people, objects, primary):
    """Select source-object tracks with repeated 2-D contact with the MAIN person.

    Nearness to a companion does not qualify. Selected tracks remain available
    before/after contact so placing or passing an object can be animated. Mask
    overlap/edge contact is evidence in image space, not proof of physical touch.
    """
    import cv2
    people=np.asarray(people)>0.5;objects=np.asarray(objects)>0.5
    t,n,h,w=people.shape
    if not 0<=primary<n: raise ValueError('ไม่พบหมายเลขคนหลัก')
    if objects.ndim!=4 or objects.shape[0]!=t or objects.shape[2:]!=(h,w):
        raise ValueError('จำนวนเฟรมหรือขนาดหน้ากากอุปกรณ์ไม่ตรงกับคน')
    selected=np.zeros_like(objects)
    report=[]
    if objects.shape[1]==0: return selected,report
    # Tight edge tolerance, unlike the old broad proximity neighbourhood.
    tolerance=max(1.,.003*max(h,w))
    distances=[cv2.distanceTransform(np.uint8(~frame[primary]),cv2.DIST_L2,3)
               if frame[primary].any() else np.full((h,w),np.inf) for frame in people]
    for obj in range(objects.shape[1]):
        contacts=[];valid=[];run=longest=0;head_only_frames=[]
        for k in range(t):
            mask=objects[k,obj];area=int(mask.sum());body=people[k,primary]
            valid_detection=16<=area<=.35*h*w
            if valid_detection:
                for person in people[k]:
                    person_area=int(person.sum())
                    if person_area>=16 and (mask & person).sum()/person_area>.65:
                        valid_detection=False;break
            # SAM's generic object query can return ceiling fixtures that only
            # overlap a person's hair in projection. Such head-only evidence is
            # insufficient to import source scenery. Deliberately conservative:
            # true overhead interactions need stronger evidence than this mask
            # heuristic can provide, so do not silently claim physical contact.
            if valid_detection and body.sum()>=16:
                body_y=np.flatnonzero(body.any(axis=1))
                head_limit=body_y[0]+.25*(body_y[-1]-body_y[0]+1)
                obj_y=np.nonzero(mask)[0]
                if np.mean(obj_y<head_limit)>.95:
                    valid_detection=False;head_only_frames.append(k)
            valid.append(valid_detection)
            if not valid_detection or body.sum()<16:
                run=0;continue
            edge_pixels=int((mask & (distances[k]<=tolerance)).sum())
            contact=edge_pixels>=max(4,round(.002*body.sum()))
            if contact:
                contacts.append(k);run+=1;longest=max(longest,run)
            else: run=0
        accepted=longest>=2
        if accepted:
            for k in range(t):
                if valid[k]: selected[k,obj]=objects[k,obj]
        report.append({'object_track':obj,'accepted':accepted,
            'owner_track':int(primary) if accepted else None,
            'contact_frames':contacts,'longest_contact_run':longest,
            'head_only_candidate_frames':head_only_frames,
            'contact_evidence':'2D mask overlap or near-touching boundaries; not verified physical contact',
            'reason':'main_person_contact' if accepted else
                     ('head_only_or_overhead_projection' if head_only_frames and not any(valid) else
                      'invalid_or_person_like_detection' if not any(valid) else 'no_repeated_main_person_contact')})
    return selected,report


def select_scene_interaction_props(people, objects, primary):
    """Select object tracks with repeated image-space contact with any person.

    Unlike the legacy main-only selector, this records each participant and can
    retain a companion's prop or a handoff. The supplied primary index is only
    reported; it does not bias acceptance or assign all props to that person.
    Large masks are considered support candidates only when contact is strong,
    vertically localized, and the object mostly extends below the contact.
    None of these mask heuristics establishes physical touch or ownership.

    Return bool masks shaped like objects [T, M, H, W] and one JSON-safe report
    per object. contact_by_track uses string person indices and nested evidence.
    """
    import cv2
    people = np.asarray(people) > .5
    objects = np.asarray(objects) > .5
    if people.ndim != 4 or min(people.shape[2:], default=0) < 1:
        raise ValueError('People masks must have shape [frames, people, height, width]')
    frames, person_count, height, width = people.shape
    if not isinstance(primary, (int, np.integer)) or not 0 <= primary < person_count:
        raise ValueError('Primary person index is outside the tracked people')
    if objects.ndim != 4 or objects.shape[0] != frames or objects.shape[2:] != (height, width):
        raise ValueError('Object and person mask frame counts and dimensions must match')
    selected = np.zeros_like(objects)
    reports = []
    object_count = objects.shape[1]
    if not object_count:
        return selected, reports
    minimum_area = 16
    frame_area = height * width
    tolerance = max(1., .003 * max(height, width))
    evidence = [{
        'valid_frames': [], 'large_frames': [], 'missing_frames': [], 'tiny_frames': [],
        'huge_or_background_frames': [], 'person_like_frames': [],
        'head_only_candidate_frames': [], 'unsupported_large_contact_frames': [],
        'contact_by_track': {str(person): {'contact_frames': [],
                            'strong_support_frames': [], 'head_only_candidate_frames': []}
                            for person in range(person_count)},
    } for _ in range(object_count)]

    # Keep only one frame's distance maps in memory, even for long clips.
    for frame in range(frames):
        body_info = []
        for person, body in enumerate(people[frame]):
            area = int(body.sum())
            if area < minimum_area:
                continue
            ys = np.flatnonzero(body.any(axis=1))
            body_height = int(ys[-1] - ys[0] + 1)
            distance = cv2.distanceTransform(np.uint8(~body), cv2.DIST_L2, 3)
            body_info.append((person, body, area, body_height,
                              float(ys[0] + .25 * body_height), distance <= tolerance))
        for obj in range(object_count):
            mask = objects[frame, obj]
            area = int(mask.sum())
            item = evidence[obj]
            if area == 0:
                item['missing_frames'].append(frame)
                continue
            if area < minimum_area:
                item['tiny_frames'].append(frame)
                continue
            large = area > .35 * frame_area
            # A surrounding room/background mask can have holes around people;
            # area alone would otherwise admit it as a large support surface.
            surrounds_frame = all((mask[0].any(), mask[-1].any(), mask[:, 0].any(), mask[:, -1].any()))
            if area >= .75 * frame_area or (large and surrounds_frame):
                item['huge_or_background_frames'].append(frame)
                continue
            if any((mask & body).sum() / body_area > .65
                   for _, body, body_area, _, _, _ in body_info):
                item['person_like_frames'].append(frame)
                continue
            frame_contacts = []
            head_only = False
            unsupported_large = False
            object_y = np.nonzero(mask)[0] if large else None
            for person, body, body_area, body_height, head_limit, nearby in body_info:
                touching_y = np.nonzero(mask & nearby)[0]
                ordinary_min = max(4, round(.002 * body_area))
                if len(touching_y) < ordinary_min:
                    continue
                below_head = touching_y[touching_y >= head_limit]
                track = item['contact_by_track'][str(person)]
                if len(below_head) < ordinary_min:
                    head_only = True
                    track['head_only_candidate_frames'].append(frame)
                    continue
                if large:
                    # A table can occupy much more than 35% of the image, but
                    # a wall/ring touching most of a person is not sufficient.
                    strong_min = max(8, round(.004 * body_area))
                    localized = (below_head.max() - below_head.min() + 1) <= .35 * body_height
                    extends_below = float(np.mean(object_y >= float(np.median(below_head)))) >= .60
                    if len(below_head) < strong_min or not localized or not extends_below:
                        unsupported_large = True
                        continue
                frame_contacts.append(person)
            if head_only:
                item['head_only_candidate_frames'].append(frame)
            # Another person's qualifying hand/foot contact can still validate
            # this object; head-only projection itself never supplies evidence.
            if not frame_contacts and (head_only or unsupported_large):
                if unsupported_large:
                    item['unsupported_large_contact_frames'].append(frame)
                continue
            item['valid_frames'].append(frame)
            if large:
                item['large_frames'].append(frame)
            selected[frame, obj] = mask
            for person in frame_contacts:
                track = item['contact_by_track'][str(person)]
                track['contact_frames'].append(frame)
                if large:
                    track['strong_support_frames'].append(frame)

    def longest_run(indices):
        longest = run = 0
        previous = None
        for index in indices:
            run = run + 1 if previous is not None and index == previous + 1 else 1
            longest = max(longest, run)
            previous = index
        return longest

    for obj, item in enumerate(evidence):
        participants = []
        contact_frames = set()
        for person, track in item['contact_by_track'].items():
            track['longest_contact_run'] = longest_run(track['contact_frames'])
            if track['contact_frames']:
                participants.append(int(person))
                contact_frames.update(track['contact_frames'])
        contact_frames = sorted(contact_frames)
        longest = longest_run(contact_frames)
        accepted = longest >= 2
        if not accepted:
            selected[:, obj] = False
        owner = participants[0] if accepted and len(participants) == 1 else None
        shared = accepted and len(participants) > 1
        reason = ('shared_or_handoff_contact' if shared else 'participant_contact') if accepted else (
            'head_only_or_overhead_projection' if item['head_only_candidate_frames'] and not item['valid_frames']
            else 'unsupported_large_contact' if item['unsupported_large_contact_frames'] and not item['valid_frames']
            else 'huge_or_background_detection' if item['huge_or_background_frames'] and not item['valid_frames']
            else 'person_like_detection' if item['person_like_frames'] and not item['valid_frames']
            else 'missing_or_tiny_detection' if not item['valid_frames']
            else 'no_repeated_participant_contact')
        reports.append({
            'object_track': obj, 'accepted': accepted, 'primary_track': int(primary),
            'owner_track': owner, 'participant_tracks': participants,
            'shared_or_handoff': shared, 'contact_frames': contact_frames,
            'longest_contact_run': longest,
            'contact_by_track': item.pop('contact_by_track'),
            **item, 'reason': reason,
            'contact_evidence': 'Repeated 2D mask overlap or near-touching boundaries with any valid participant; not physical contact or ownership proof',
            'large_support_evidence': 'Above 35% frame area requires stronger localized contact and most object pixels below it; masks covering 75% or surrounding all frame edges are rejected',
            'limitations': [
                'Small or fast balls below 16 pixels or with only isolated contact frames may be missed; no ballistic tracking is performed.',
                'Head-only or overhead projections are not sufficient evidence; genuine overhead interactions can be missed.',
                'Support geometry, depth, semantic object class and physical ownership are not verified.',
            ],
        })
    return selected, reports


def select_initial_scene_props(people, objects, primary):
    """Only seed supported first-scene props; retain exclusions as diagnostics.

    The generic SAM query can introduce background fragments after frame zero.
    Later candidates are not proof of real objects entering the scene. Neither
    these fragments nor genuine later-only objects can be reliably seeded in
    this first-image pipeline, so exclude them before appearance/layout creation.
    Never change the original mask arrays or legacy any-time selector.
    """
    selected, reports = select_scene_interaction_props(people, objects, primary)
    for item in reports:
        index = item['object_track']
        first_area = int(selected[0, index].sum()) if len(selected) else 0
        excluded = bool(item['accepted'] and first_area < 16)
        item.update(initial_mask_area=first_area, initial_scene_excluded=excluded,
                    initial_scene_policy='initially_visible_interaction_objects_only')
        if excluded:
            selected[:, index] = False
            item.update(accepted=False, owner_track=None,
                        reason='later_only_candidate_not_supported_in_initial_scene')
    return selected, reports


def motion_foreground(frames, people, selected_objects):
    """Only source people and selected interaction objects enter RGB guidance."""
    people=np.asarray(people)>0.5;selected_objects=np.asarray(selected_objects)>0.5
    keep=people.any(axis=1) | selected_objects.any(axis=1)
    return np.where(keep[...,None],frames,0).astype(np.float32)


def resolve_visible_masks(masks):
    """Resolve collisions using nearest exclusive support, independent of main ID.

    This estimates ownership, not true depth. Return the overlap fraction so the
    caller can flag contact/occlusion uncertainty rather than claim verification.
    """
    import cv2
    masks=np.asarray(masks)>0.5
    result=masks.copy();conflicts=0;foreground=0
    for t,frame in enumerate(masks):
        count=frame.sum(axis=0);ambiguous=count>1
        foreground+=int((count>0).sum());conflicts+=int(ambiguous.sum())
        if not ambiguous.any(): continue
        distances=[]
        for person,mask in enumerate(frame):
            unique=mask & (count==1)
            distance=cv2.distanceTransform(np.uint8(~unique),cv2.DIST_L2,3) if unique.any() else np.full(mask.shape,1e6)
            distances.append(np.where(mask,distance,np.inf))
        owner=np.argmin(np.stack(distances),axis=0)
        for person in range(len(frame)):
            result[t,person,ambiguous]=owner[ambiguous]==person
    return result,float(conflicts/max(1,foreground))


def safe_primary_prop_mask(mask, person_mask, faces):
    """Do not put the original main face into an object appearance reference.

    This guard is conservative when no face is visible. It does not certify that
    every remaining object pixel has been segmented correctly.
    """
    result=np.asarray(mask,dtype=bool).copy()
    person=np.asarray(person_mask,dtype=bool)
    h,w=result.shape
    visible=[]
    for x,y,fw,fh in faces:
        patch=person[max(0,y):min(h,y+fh),max(0,x):min(w,x+fw)]
        if patch.size and patch.mean()>.4: visible.append((x,y,fw,fh))
    if not visible:
        return result & ~person,'person_overlap_excluded_no_face'
    for x,y,fw,fh in visible:
        # Include hair/head margin in addition to the frontal facial rectangle.
        left=max(0,int(x-.4*fw));right=min(w,int(x+1.4*fw))
        top=max(0,int(y-.7*fh));bottom=min(h,int(y+1.3*fh))
        result[top:bottom,left:right]=False
    return result,'head_excluded'
