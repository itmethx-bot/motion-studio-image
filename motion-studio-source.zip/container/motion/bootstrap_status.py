"""Small authenticated boot-status endpoint; never accepts uploads or GPU jobs."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import os
import re
import secrets
import threading
import time


def safe_error(error):
    """Bounded diagnostics: never expose environment credentials or signed URLs."""
    message = str(error)
    for name, value in os.environ.items():
        if any(word in name.upper() for word in ('TOKEN', 'KEY', 'SECRET', 'PASSWORD', 'ACCESS_CODE')) and len(value) >= 4:
            message = message.replace(value, '[REDACTED]')
    message = re.sub(r'https?://[^\s]+', '[URL REDACTED]', message)
    message = re.sub(r'(?i)((?:access[_-]?code|password|token|api[_-]?key)\s*[=:]\s*)[^\s,;]+', r'\1[REDACTED]', message)
    message = ' '.join(message.split())[:500]
    # Only controlled installer messages are useful to users. Other exceptions
    # report their class/errno without arbitrary contents from a third party.
    if type(error).__name__ not in ('InstallError', 'ValueError'):
        message = 'Preparation stopped; inspect the exception type and storage/network settings.'
    record = {'type': type(error).__name__, 'message': message,
              'retryable': bool(getattr(error, 'retryable', False))}
    model = str(getattr(error, 'model', ''))
    if re.fullmatch(r'[A-Za-z0-9_.-]{1,64}', model): record['model'] = model
    cause = error.__cause__
    if cause is not None:
        record['cause_type'] = type(cause).__name__
        code = getattr(cause, 'code', None)
        if isinstance(code, int): record['http_status'] = code
        number = getattr(cause, 'errno', None)
        if isinstance(number, int): record['errno'] = number
    return record


class BootstrapStatus:
    def __init__(self,code,port=8188,host='0.0.0.0'):
        self.code=code;self.tokens=set();self.attempts=[];self.state={'phase':'preparing','failed':False}
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass # Never log credentials or request bodies.
            def reply(self,status,body,cookie=None):
                data=json.dumps(body).encode();self.send_response(status)
                self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)))
                self.send_header('Cache-Control','no-store')
                if cookie:self.send_header('Set-Cookie','motion_boot='+cookie+'; Path=/; HttpOnly; SameSite=Strict')
                self.end_headers();self.wfile.write(data)
            def do_POST(self):
                if self.path!='/motion-studio/api/login':return self.reply(404,{})
                if self.headers.get('X-Requested-With')!='MotionStudioAuto':return self.reply(403,{})
                now=time.time();owner.attempts=[t for t in owner.attempts if now-t<60]
                if len(owner.attempts)>=10:return self.reply(429,{})
                try:
                    count=int(self.headers.get('Content-Length','0'))
                    if not 0<count<=2048:raise ValueError()
                    body=json.loads(self.rfile.read(count));code=body.get('code','')
                except (ValueError,AttributeError):return self.reply(400,{})
                if not isinstance(code,str) or not secrets.compare_digest(code,owner.code):
                    owner.attempts.append(now);return self.reply(401,{})
                token=secrets.token_urlsafe(24);owner.tokens.add(token);self.reply(200,{'ok':True},token)
            def do_GET(self):
                if self.path!='/motion-studio/api/status':return self.reply(404,{})
                cookies=dict(part.strip().split('=',1) for part in self.headers.get('Cookie','').split(';') if '=' in part)
                if cookies.get('motion_boot') not in owner.tokens:return self.reply(401,{})
                self.reply(200,{'ready':False,'system_version':'motion-studio-9-scene-session','cleanup_owner':'user','session_mode':'manual_session','user_stop_only':True,
                    'bootstrap_phase':owner.state['phase'],'bootstrap_failed':owner.state['failed'],
                    'bootstrap_revision':'resume-diagnostics-20261008',
                    'bootstrap_error':owner.state.get('error'),
                    'message':('เตรียม Pod ล้มเหลว: '+owner.state.get('error',{}).get('message','กรุณาตรวจ Logs')) if owner.state['failed'] else 'กำลังเตรียม Pod และดาวน์โหลดโมเดลที่ตรวจ checksum'})
        self.server=ThreadingHTTPServer((host,port),Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
    def start(self):self.thread.start()
    def close(self):self.server.shutdown();self.server.server_close();self.thread.join(timeout=3)
