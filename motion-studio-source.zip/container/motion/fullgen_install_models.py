"""Verify bundled pinned Qwen weights; download only with --download-models."""
import argparse
import json
from pathlib import Path, PurePosixPath
import re
import urllib.parse

import install_on_pod as base
import install_fullgen_addon as addon

COMFY = addon.DEFAULT_COMFY
MANIFEST = Path(__file__).resolve().parent/'fullgen-model-manifest.json'
SPECS = [
    ('qwen', 'Comfy-Org/Qwen-Image-Edit_ComfyUI', 'split_files/diffusion_models/qwen_image_edit_2511_fp8mixed.safetensors', 'diffusion_models'),
    ('qwen_text', 'Comfy-Org/HunyuanVideo_1.5_repackaged', 'split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors', 'text_encoders'),
    ('qwen_vae', 'Comfy-Org/Qwen-Image_ComfyUI', 'split_files/vae/qwen_image_vae.safetensors', 'vae'),
    ('qwen_light', 'lightx2v/Qwen-Image-Edit-2511-Lightning', 'Qwen-Image-Edit-2511-Lightning-4steps-V1.0-bf16.safetensors', 'loras'),
]


def load_manifest(path=None, include_lightning=False):
    path = Path(path or MANIFEST)
    if not path.is_file():
        raise base.InstallError('Pinned fullgen-model-manifest.json is missing; obtain the complete package.')
    artifacts = json.loads(path.read_text(encoding='utf-8-sig')).get('models', [])
    specifications = {name: (repo, file, folder) for name, repo, file, folder in SPECS}
    if len(artifacts) != 4 or {item.get('id') for item in artifacts} != set(specifications):
        raise base.InstallError('Qwen manifest must contain the four distinct known artifact IDs.')
    for artifact in artifacts:
        repo, file, folder = specifications[artifact['id']]
        if artifact.get('path') != folder+'/'+PurePosixPath(file).name:
            raise base.InstallError('Unsafe or unexpected Qwen model destination: ' + str(artifact.get('path')))
        url = urllib.parse.urlsplit(artifact.get('url', ''))
        if (url.scheme != 'https' or url.netloc != 'huggingface.co' or url.query or url.fragment
                or not re.fullmatch('/'+re.escape(repo)+r'/resolve/[0-9a-f]{40}/'+re.escape(file), url.path)):
            raise base.InstallError('Qwen URLs must pin the expected publisher/file to an immutable commit.')
        if (artifact.get('checksum_algorithm') != 'sha256'
                or not re.fullmatch(r'[0-9a-f]{64}', artifact.get('checksum', ''))
                or type(artifact.get('bytes')) is not int or artifact['bytes'] <= 0):
            raise base.InstallError('Qwen models require SHA256 and a positive exact byte size.')
    return [item for item in artifacts if include_lightning or item['id'] != 'qwen_light']


def prepare_models(comfy=COMFY, *, download_models=False, manifest=None, include_lightning=False, port=8188):
    comfy = addon.check_comfy(comfy)
    runtime = addon.check_dependencies()
    artifacts = load_manifest(manifest, include_lightning)
    pending = base.pending_models(comfy/'models', artifacts)
    storage = base.storage_preflight(comfy, pending)
    report = {'comfy': str(comfy), 'runtime': runtime, 'storage': storage,
              'check_only': not download_models, 'missing_models': [item['path'] for item in pending],
              'pinned_model_count': len(artifacts), 'lightning_included': include_lightning,
              'downloaded': [], 'ready': runtime['ready'] and not pending}
    if download_models:
        if not runtime['ready']:
            raise base.InstallError('Use ComfyUI Python with required dependencies before downloading.')
        addon.require_idle(port)
        addon.check_live_nodes(port)
        for artifact in pending:
            addon.require_idle(port)
            base.download_artifact(comfy/'models', artifact)
            report['downloaded'].append(artifact['path'])
        report.update(missing_models=[], ready=True)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy', default=str(COMFY))
    parser.add_argument('--manifest', default=str(MANIFEST))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--download-models', action='store_true')
    mode.add_argument('--check-only', action='store_true', help='Read-only verification (default).')
    parser.add_argument('--include-lightning', action='store_true', help='Include the unused optional 4-step LoRA.')
    parser.add_argument('--port', type=int, default=8188)
    args = parser.parse_args(argv)
    try:
        report = prepare_models(args.comfy, download_models=args.download_models, manifest=args.manifest,
                                include_lightning=args.include_lightning, port=args.port)
    except (base.InstallError, ValueError, OSError) as exc:
        parser.exit(1, f'Model preparation stopped: {exc}\n')
    print(json.dumps(report, indent=2))
    return report


if __name__ == '__main__':
    main()
