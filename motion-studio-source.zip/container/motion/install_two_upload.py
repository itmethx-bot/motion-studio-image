"""Add the two-upload web service to an existing full-generation ComfyUI.

Default is read-only: compile/check package files and GET the loopback queue and
node registry. --install permits one owned extension write and an update backup.
No model downloads, pip, GPU jobs, provider calls, credentials or restarts.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parent
ADDON = 'motion_studio_web_v8'
OWNER = 'motion-studio-two-upload-v8'
MARKER = '.motion-studio-web-v8.json'
PACKAGE_MANIFEST = 'two-upload-package-manifest.json'
INIT_SOURCE = ('NODE_CLASS_MAPPINGS = {}\n'
               'from .service import register\n'
               'studio = register()\n')
CODE_FILES = (
    'service.py', 'session_bridge.py',
    'preview_server.py', 'fullgen_pipeline.py', 'fullgen_evidence.py', 'clip_duration.py',
    'fullgen_graph.py', 'graph.py', 'scene_core.py', 'fullgen_nodes.py', 'anatomy_reference.py', 'nodes.py',
    'fullgen_smoke.py', 'fullgen_preflight.py', 'fullgen_reuse.py',
    'finalize_video_duration.py', 'inspect_video_quality.py',
)
DATA_FILES = ('model-manifest.json', 'fullgen-model-manifest.json',
              'native_node_schemas.json', 'fullgen-schemas.json', 'fullgen-extra-schemas.json')
WEB_FILES = ('web/index.html', 'web/style.css', 'web/app.js')
DOC_FILES = ('README-two-upload.th.txt', 'requirements-pc.txt',
             'README-manual-pod.th.txt', 'start-studio.ps1', 'stop-studio.ps1')
DEPLOY_FILES = CODE_FILES + DATA_FILES + WEB_FILES + DOC_FILES
REQUIRED_NODES = (
    'SAM3_Detect', 'SAM3_VideoTrack', 'WanSCAILToVideo',
    'TextEncodeQwenImageEditPlus', 'FluxKontextImageScale',
    'FluxKontextMultiReferenceLatentMethod', 'CFGNorm',
    'MotionLoadClip', 'MotionFitImage', 'MotionCanvasSize', 'MotionSceneReport',
    'MotionFullGenerationPlan', 'MotionFullGenerationReference',
    'SaveVideo', 'CreateVideo',
)
FIXTURE_FILES = ('fullgen-fixtures/known-dance.json', 'fullgen-fixtures/approved-scene.png')


def safe_path(path):
    """Reject symlinks/junctions before resolving them, including parent links."""
    path = Path(path)
    if '..' in path.parts:
        raise ValueError('Parent traversal is not permitted: ' + str(path))
    path = Path(os.path.abspath(path))
    for entry in (path, *path.parents):
        if entry.is_symlink() or getattr(entry, 'is_junction', lambda: False)():
            raise ValueError('Linked paths are not permitted: ' + str(entry))
    return path.resolve()


def signature(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def check_fixture_json(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in {'api_key', 'access_code', 'password', 'token',
                                     'authorization', 'credentials', 'secret'}:
                raise ValueError('Credential fields cannot be packaged in fixtures')
            check_fixture_json(child)
    elif isinstance(value, list):
        for child in value:
            check_fixture_json(child)


def collect_files(source=ROOT, fixtures=None):
    """Snapshot only the explicit allowlist; never recurse through source outputs."""
    source = safe_path(source)
    files = {}
    for name in DEPLOY_FILES:
        path = safe_path(source/name)
        if not path.is_relative_to(source) or not path.is_file():
            raise ValueError('Package is incomplete: ' + name)
        data = path.read_bytes()
        if len(data) > 32*1024*1024:
            raise ValueError('Package component exceeds size limit: ' + name)
        if path.suffix == '.py':
            compile(data, str(path), 'exec')
        elif path.suffix == '.json':
            json.loads(data)
        files[name] = data
    fixture_root = safe_path(fixtures) if fixtures is not None else safe_path(source/'fullgen-fixtures')
    if fixtures is not None or fixture_root.exists():
        if not fixture_root.is_dir():
            raise ValueError('Fixture directory does not exist')
        # Both are required together. No video, credentials or arbitrary files.
        for name in FIXTURE_FILES:
            path = safe_path(fixture_root/Path(name).name)
            if not path.is_relative_to(fixture_root) or not path.is_file():
                raise ValueError('Fixture pair is incomplete: ' + name)
            data = path.read_bytes()
            if len(data) > 20*1024*1024:
                raise ValueError('Fixture exceeds size limit: ' + name)
            if name.endswith('.json'):
                check_fixture_json(json.loads(data))
            elif not data.startswith(b'\x89PNG\r\n\x1a\n'):
                raise ValueError('Approved fixture scene must be PNG')
            files[name] = data
    manifest_path = safe_path(source/PACKAGE_MANIFEST)
    if manifest_path.exists():
        package = json.loads(manifest_path.read_text(encoding='utf-8'))
        declared = package.get('files', {})
        if package.get('owner') != OWNER or not isinstance(declared, dict):
            raise ValueError('Invalid package ownership manifest')
        expected = set(files) | {'install_two_upload.py', 'build_two_upload_bundle.py'}
        if set(declared) != expected:
            raise ValueError('Package manifest does not match the explicit allowlist')
        for name in expected:
            data = files[name] if name in files else safe_path(source/name).read_bytes()
            if declared[name] != signature(data):
                raise ValueError('Package content differs from manifest: ' + name)
    return files


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('Loopback runtime checks do not follow redirects')


def read_runtime(endpoint, port=8188):
    if endpoint not in ('/queue', '/object_info') or type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('Only loopback queue and node-registry GET requests are allowed')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    request = urllib.request.Request(f'http://127.0.0.1:{port}{endpoint}', method='GET')
    with opener.open(request, timeout=15) as response:
        raw = response.read(64*1024*1024+1)
    if len(raw) > 64*1024*1024:
        raise ValueError('Runtime response exceeds size limit')
    return json.loads(raw)


def require_idle(port):
    queue = read_runtime('/queue', port)
    if (not isinstance(queue, dict) or any(not isinstance(queue.get(key), list)
            for key in ('queue_running', 'queue_pending'))):
        raise ValueError('Invalid queue response; installation blocked')
    if queue['queue_running'] or queue['queue_pending']:
        raise ValueError('ComfyUI queue is not empty; installation blocked')


def inspect_destination(comfy):
    dest = safe_path(comfy/'custom_nodes'/ADDON)
    if not dest.is_relative_to(comfy/'custom_nodes'):
        raise ValueError('Extension destination is outside custom_nodes')
    if not dest.exists():
        return dest
    if not dest.is_dir() or not (dest/MARKER).is_file():
        raise ValueError('Foreign extension destination; nothing overwritten')
    marker = json.loads(safe_path(dest/MARKER).read_text(encoding='utf-8'))
    owned = set(DEPLOY_FILES) | set(FIXTURE_FILES) | {'__init__.py'}
    if (marker.get('owner') != OWNER or not isinstance(marker.get('files'), dict)
            or not set(marker['files']).issubset(owned)
            or safe_path(dest/'__init__.py').read_text(encoding='utf-8') != INIT_SOURCE):
        raise ValueError('Foreign or changed extension ownership marker')
    for path in dest.rglob('*'):
        checked = safe_path(path)
        name = checked.relative_to(dest).as_posix()
        if checked.is_file() and name not in owned | {MARKER}:
            if not (checked.suffix == '.pyc' and '__pycache__' in checked.parts):
                raise ValueError('Unknown file in owned extension: ' + name)
        elif not checked.is_file() and not checked.is_dir():
            raise ValueError('Unsupported entry in extension')
    return dest


def install(comfy, *, source=ROOT, do_install=False, port=8188):
    comfy = safe_path(comfy)
    if not (safe_path(comfy/'main.py').is_file() and safe_path(comfy/'custom_nodes').is_dir()
            and safe_path(comfy/'input').is_dir() and safe_path(comfy/'output').is_dir()
            and safe_path(comfy/'models').is_dir()):
        raise ValueError('Pass the existing ComfyUI root with main.py/custom_nodes/input/output/models')
    files = collect_files(source)
    dest = inspect_destination(comfy)
    require_idle(port)
    info = read_runtime('/object_info', port)
    missing = [name for name in REQUIRED_NODES
               if not isinstance(info, dict) or not isinstance(info.get(name), dict)]
    if missing:
        raise ValueError('Required existing nodes are not loaded: ' + ', '.join(missing))
    files['__init__.py'] = INIT_SOURCE.encode()
    evidence = {'owner': OWNER, 'files': {name: signature(data) for name, data in files.items()}}
    report = {'comfy': str(comfy), 'destination': str(dest), 'check_only': not do_install,
              'queue_empty': True, 'required_nodes_loaded': True,
              'runtime_schema_model_validation': 'deferred to staged job preflight',
              'registered_generation_nodes': [], 'gpu_generation_tested': False,
              'files': evidence['files'], 'backup': None}
    if not do_install:
        return report
    token = uuid.uuid4().hex
    staging_root = safe_path(comfy/'motion-studio-web-staging')
    backup_root = safe_path(comfy/'motion-studio-backups')
    stage = safe_path(staging_root/token)
    backup = safe_path(backup_root/(ADDON+'-'+token))
    for path in (stage, backup):
        if not path.is_relative_to(comfy) or path.exists():
            raise ValueError('Unsafe staging/backup target')
    staging_root.mkdir(exist_ok=True)
    stage.mkdir()
    moved_old = False
    try:
        for name, data in files.items():
            path = stage/name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            if signature(path.read_bytes()) != evidence['files'][name]:
                raise ValueError('Staging verification failed: ' + name)
        (stage/MARKER).write_text(json.dumps(evidence, indent=2), encoding='utf-8')
        require_idle(port)
        inspect_destination(comfy)
        # Both resolved move targets were checked inside this exact Comfy root.
        if dest.exists():
            backup_root.mkdir(exist_ok=True)
            dest.rename(backup)
            moved_old = True
        try:
            stage.rename(dest)
        except Exception:
            if moved_old:
                backup.rename(dest)
            raise
    finally:
        # Delete only files created in this unique stage, never recurse via shell.
        if stage.exists():
            for path in sorted(stage.rglob('*'), key=lambda p: len(p.parts), reverse=True):
                safe = safe_path(path)
                if not safe.is_relative_to(stage):
                    raise ValueError('Unsafe staging cleanup path')
                if safe.is_dir():
                    safe.rmdir()
                else:
                    safe.unlink()
            stage.rmdir()
    report.update(installed=True, backup=str(backup) if moved_old else None,
                  next='Restart ComfyUI while idle, then verify service readiness. No render was submitted.')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy', type=Path, required=True)
    parser.add_argument('--port', type=int, default=8188)
    parser.add_argument('--install', action='store_true')
    args = parser.parse_args(argv)
    try:
        report = install(args.comfy, do_install=args.install, port=args.port)
    except (OSError, ValueError, SyntaxError) as error:
        parser.exit(1, 'Web installation stopped: '+str(error)+'\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    main()
