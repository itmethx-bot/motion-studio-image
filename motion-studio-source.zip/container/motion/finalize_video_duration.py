"""Trim decoded native-rate frames into a NEW H.264/AAC MP4; never retime or upscale.

This helper accepts constant-frame-rate, synchronized audio/video starting at
the same time. It re-encodes kept frames at their existing frame rate and size.
AAC may decode codec padding beyond its MP4 presentation duration; both are
reported separately. The input and any existing output/report are never changed.
"""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path


def fingerprint(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
    return dict(bytes=Path(path).stat().st_size,sha256=digest.hexdigest())


def probe(path):
    import av
    with av.open(str(path)) as container:
        if len(container.streams.video)!=1:raise ValueError('Expected exactly one video stream')
        stream=container.streams.video[0]
        fps=stream.average_rate
        if not fps or fps<=0:raise ValueError('Video has no valid native frame rate')
        first=None;count=0;size=None
        for frame in container.decode(video=0):
            if frame.pts is None or frame.time_base is None:raise ValueError('Video frame lacks timing')
            timestamp=Fraction(frame.pts)*frame.time_base
            if first is None:first=timestamp;size=(frame.width,frame.height)
            if (frame.width,frame.height)!=size:raise ValueError('Variable video dimensions are unsupported')
            if abs(timestamp-first-Fraction(count)/fps)>Fraction(1,1000):
                raise ValueError('Video is not constant-frame-rate; refusing to retime it')
            count+=1
        if not count:raise ValueError('Video contains no decoded frames')
        info=dict(frames=count,fps=float(fps),seconds=float(Fraction(count)/fps),
                  width=size[0],height=size[1],start_seconds=float(first),
                  codec=stream.codec_context.name,pixel_format=stream.codec_context.format.name,
                  stream_duration_seconds=float(stream.duration*stream.time_base) if stream.duration is not None else None,
                  container_duration_seconds=float(container.duration/av.time_base) if container.duration is not None else None)
    with av.open(str(path)) as container:
        if len(container.streams.audio)>1:raise ValueError('Multiple audio streams are unsupported')
        if container.streams.audio:
            audio=container.streams.audio[0]
            info['audio']=dict(codec=audio.codec_context.name,sample_rate=audio.codec_context.sample_rate,
                layout=audio.codec_context.layout.name,
                start_seconds=float(audio.start_time*audio.time_base) if audio.start_time is not None else None,
                stream_duration_seconds=float(audio.duration*audio.time_base) if audio.duration is not None else None,
                decoded_samples=sum(frame.samples for frame in container.decode(audio=0)))
        else:info['audio']=None
    return info,fps,first


def finalize(input_path,output_path,*,seconds=10,fps=16,crf=16,report_path=None):
    import av
    import numpy as np
    source=Path(input_path).resolve();output=Path(output_path).resolve()
    report=Path(report_path).resolve() if report_path else output.with_suffix(output.suffix+'.json')
    if not source.is_file():raise ValueError('Input video does not exist')
    if source==output or report in (source,output):raise ValueError('Input, output and report must be separate files')
    if output.exists() or report.exists():raise ValueError('Output or report already exists; choose new paths')
    if output.suffix.lower()!='.mp4':raise ValueError('Output must use the .mp4 extension')
    if crf not in (16,18):raise ValueError('Quality CRF must be 16 or 18')
    duration=Fraction(str(seconds));expected_fps=Fraction(str(fps))
    if duration<=0 or expected_fps<=0:raise ValueError('Duration and FPS must be positive')
    count_fraction=duration*expected_fps
    if count_fraction.denominator!=1:raise ValueError('Requested duration must contain an integer number of native frames')
    keep=int(count_fraction)
    before=fingerprint(source)
    input_info,native_fps,video_start=probe(source)
    if native_fps!=expected_fps:raise ValueError('Input FPS does not match requested native FPS; refusing to retime')
    if input_info['frames']<keep:raise ValueError('Insufficient decoded video frames for requested duration')
    if input_info['width']%2 or input_info['height']%2:raise ValueError('H.264 yuv420p requires even source dimensions')
    audio_data=None;sample_rate=None;layout=None;audio_samples=0
    if input_info['audio'] is not None:
        sample_rate=input_info['audio']['sample_rate'];layout=input_info['audio']['layout']
        available=input_info['audio']['stream_duration_seconds']
        if available is not None and available+1/sample_rate<float(duration):
            raise ValueError('Insufficient audio presentation duration; refusing to use codec padding as sound')
        wanted=duration*sample_rate
        if wanted.denominator!=1:raise ValueError('Requested duration is not an integer number of audio samples')
        audio_samples=int(wanted)
        parts=[];collected=0;first_audio=None;decoded_samples=0
        with av.open(str(source)) as container:
            resampler=av.AudioResampler(format='fltp',layout=layout,rate=sample_rate)
            for frame in container.decode(audio=0):
                if frame.pts is None or frame.time_base is None:raise ValueError('Audio lacks timing')
                if first_audio is None:
                    first_audio=Fraction(frame.pts)*frame.time_base
                    if abs(first_audio-video_start)>Fraction(1,sample_rate):
                        raise ValueError('Audio/video start offset is nonzero; refusing to shift audio')
                timestamp=Fraction(frame.pts)*frame.time_base
                if abs(timestamp-first_audio-Fraction(decoded_samples,sample_rate))>Fraction(1,sample_rate):
                    raise ValueError('Audio has gaps or overlapping timestamps; refusing to retime audio')
                decoded_samples+=frame.samples
                for converted in resampler.resample(frame):
                    data=converted.to_ndarray();remaining=audio_samples-collected
                    if remaining>0:parts.append(data[:,:remaining]);collected+=min(remaining,data.shape[1])
                if collected>=audio_samples:break
            if collected<audio_samples:
                for converted in resampler.resample(None):
                    data=converted.to_ndarray();remaining=audio_samples-collected
                    if remaining>0:parts.append(data[:,:remaining]);collected+=min(remaining,data.shape[1])
        if collected<audio_samples:raise ValueError('Insufficient audio samples; refusing to stretch or pad audio')
        audio_data=np.concatenate(parts,axis=1)
    output.parent.mkdir(parents=True,exist_ok=True)
    # Exclusive reservation prevents overwriting an existing user file.
    with output.open('xb'):pass
    try:
        with av.open(str(output),'w',format='mp4',options={'movflags':'+faststart'}) as destination:
            video=destination.add_stream('libx264',rate=native_fps)
            video.width=input_info['width'];video.height=input_info['height'];video.pix_fmt='yuv420p'
            video.options={'crf':str(crf),'preset':'medium'}
            audio=None
            if audio_data is not None:
                audio=destination.add_stream('aac',rate=sample_rate)
                audio.layout=layout;audio.bit_rate=192000
            with av.open(str(source)) as container:
                for index,frame in enumerate(container.decode(video=0)):
                    if index>=keep:break
                    frame=frame.reformat(format='yuv420p')
                    frame.pts=index;frame.time_base=Fraction(1)/native_fps;frame.pict_type=0
                    for packet in video.encode(frame):destination.mux(packet)
            for packet in video.encode(None):destination.mux(packet)
            if audio is not None:
                for offset in range(0,audio_samples,4096):
                    frame=av.AudioFrame.from_ndarray(np.ascontiguousarray(audio_data[:,offset:offset+4096]),
                                                    format='fltp',layout=layout)
                    frame.sample_rate=sample_rate;frame.pts=offset;frame.time_base=Fraction(1,sample_rate)
                    for packet in audio.encode(frame):destination.mux(packet)
                for packet in audio.encode(None):destination.mux(packet)
        result_info,output_fps,_=probe(output)
        if (result_info['frames']!=keep or output_fps!=native_fps
                or (result_info['width'],result_info['height'])!=(input_info['width'],input_info['height'])
                or result_info['codec']!='h264' or result_info['pixel_format']!='yuv420p'):
            raise RuntimeError('Output decoded video does not match the requested native-size trim')
        if abs(result_info['stream_duration_seconds']-float(duration))>1e-6:
            raise RuntimeError('Output video stream duration differs from requested trim')
        if result_info['audio'] is not None:
            measured=result_info['audio']['stream_duration_seconds']
            if measured is None or abs(measured-float(duration))>1/sample_rate:
                raise RuntimeError('Output audio presentation duration differs from requested trim')
        if fingerprint(source)!=before:raise RuntimeError('Input changed during finalization')
        result=dict(success=True,input_file=str(source),output_file=str(output),input_fingerprint=before,
                    output_fingerprint=fingerprint(output),input=input_info,output=result_info,
                    kept_frames=keep,trimmed_frames=input_info['frames']-keep,crf=crf,
                    retimed=False,interpolated=False,upscaled=False,source_unchanged=True,
                    audio_samples_submitted=audio_samples,
                    audio_codec_padding_note='AAC decoded sample count may include trailing codec padding; MP4 presentation duration is checked separately.',
                    visual_quality_verified=False)
        report.parent.mkdir(parents=True,exist_ok=True)
        with report.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2)
        return result
    except BaseException:
        output.unlink(missing_ok=True)
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--seconds',type=float,default=10)
    parser.add_argument('--fps',type=float,default=16,help='Must equal existing video FPS; never changes speed')
    parser.add_argument('--crf',type=int,choices=(16,18),default=16)
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    print(json.dumps(finalize(args.input,args.output,seconds=args.seconds,fps=args.fps,crf=args.crf,
                              report_path=args.report),ensure_ascii=False))


if __name__=='__main__':main()
