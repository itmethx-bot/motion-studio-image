"""One timing contract for admission, motion sampling and final encoding."""
import math

MIN_SECONDS=1.0
MAX_SECONDS=10.0
OUTPUT_FPS=16


def duration_contract(video,requested=MAX_SECONDS):
    if (isinstance(requested,bool) or not isinstance(requested,(int,float)) or
        not math.isfinite(requested) or not MIN_SECONDS<=requested<=MAX_SECONDS):
        raise ValueError('ความยาวที่ขอต้องอยู่ระหว่าง 1–10 วินาที')
    source=video.get('duration',0);fps=video.get('fps',0)
    if (isinstance(source,bool) or not isinstance(source,(int,float)) or
        not math.isfinite(source) or not MIN_SECONDS<=source<=120):
        raise ValueError('กรุณาใช้คลิปยาว 1–120 วินาที ระบบไม่ยืดหรือวนคลิป')
    if (isinstance(fps,bool) or not isinstance(fps,(int,float)) or
        not math.isfinite(fps) or not 16<=fps<=120):
        raise ValueError('กรุณาใช้คลิป 16–120 FPS สำหรับผลลัพธ์ 16 FPS')
    frames=math.floor(min(source,requested)*OUTPUT_FPS+1e-9)
    raw=((frames-1+3)//4)*4+1
    return dict(source_duration_seconds=source,requested_seconds=requested,
        source_seconds=frames/OUTPUT_FPS,final_seconds=frames/OUTPUT_FPS,
        fps=OUTPUT_FPS,frames=raw,final_frames=frames,tail_pad_frames=raw-frames,
        duration_policy='source_length_up_to_10s_no_loop_no_retime',
        timing_quantization_seconds=min(source,requested)-frames/OUTPUT_FPS)
