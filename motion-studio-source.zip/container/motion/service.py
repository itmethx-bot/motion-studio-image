"""Private web UI served by the existing ComfyUI process on the Pod.

This service generates and transfers results. Only the user controls Pod rental,
Stop and Terminate; no provider credentials or lifecycle commands are used.
"""
import asyncio
import contextlib
import hashlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import time
from urllib.parse import urlsplit

from aiohttp import web, ClientSession, ClientTimeout
from PIL import Image, ImageOps
from .graph import MODELS
from .fullgen_graph import build_fullgen_graph, QWEN_MODELS
from .finalize_video_duration import finalize
from .clip_duration import duration_contract

PREFIX='/motion-studio'
ROOT=Path(__file__).resolve().parent
UID=re.compile(r'^[a-f0-9]{32}$')
POD_ID=re.compile(r'^[a-zA-Z0-9]{8,40}$')
MIB=1024**2
SYSTEM_VERSION='motion-studio-8-anatomy-session'
ACTIVE_STATUSES={'queued','starting_gpu','running','analyzing','scene_generating',
                 'scene_validating','generating','finalizing','downloading','ready'}


def validate_two_file_job(image,video,duration=10):
    timing=duration_contract(video,duration)
    if min(image.get('width',0),image.get('height',0),video.get('width',0),video.get('height',0))<64:
        raise ValueError('ภาพและคลิปต้องมีขนาดอย่างน้อย 64 พิกเซลต่อด้าน')
    return timing


def atomic_json(path,value):
    tmp=path.with_name(path.name+'.'+secrets.token_hex(8)+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,path)


def metadata(path,kind):
    if kind=='image':
        with Image.open(path) as image:
            if image.width*image.height>32_000_000: raise ValueError('ภาพใหญ่เกินไป')
            original_format=image.format
            image.load()
            if (original_format in ('JPEG','PNG','WEBP') and image.mode=='RGB'
                    and max(image.size)<=2048 and image.getexif().get(274,1)==1):
                return {'width':image.width,'height':image.height,'preserve_original':True,
                        'extension':{'JPEG':'.jpg','PNG':'.png','WEBP':'.webp'}[original_format]}
            image=ImageOps.exif_transpose(image).convert('RGB')
            image.thumbnail((2048,2048))
            image.save(path.with_suffix('.png'))
            return {'width':image.width,'height':image.height}
    import av
    with av.open(str(path),format='mov',options={'protocol_whitelist':'file'}) as container:
        stream=container.streams.video[0]
        fps=float(stream.average_rate or 0)
        duration=float(stream.duration*stream.time_base) if stream.duration else float(container.duration or 0)/av.time_base
        first=next(container.decode(video=0),None)
        if first is None or not 1<=fps<=120 or not .2<=duration<=120: raise ValueError('คลิปต้องยาว 0.2–120 วินาที และอ่านเฟรมได้')
        width,height=first.width,first.height
        rotation=int(getattr(first,'rotation',0) or 0)%360
        if rotation in (90,270): width,height=height,width
        return {'width':width,'height':height,'fps':fps,'duration':duration}


def verify_result(path,plan):
    """Decode the whole downloaded result before accepting the local result."""
    info=metadata(path,'video')
    if (info['width'],info['height'])!=(plan['width'],plan['height']):
        raise ValueError('ขนาดวิดีโอผลลัพธ์ไม่ตรงกับงาน')
    if plan.get('fps') and abs(info['fps']-plan['fps'])>.001:
        raise ValueError('อัตราเฟรมวิดีโอผลลัพธ์ไม่ตรงกับงาน')
    if plan.get('seconds') and abs(info['duration']-plan['seconds'])>.025:
        raise ValueError('ความยาววิดีโอผลลัพธ์ไม่ตรงกับงาน')
    import av
    count=0
    with av.open(str(path),format='mov',options={'protocol_whitelist':'file'}) as container:
        for frame in container.decode(video=0):
            if (frame.width,frame.height)!=(plan['width'],plan['height']):
                raise ValueError('บางเฟรมของวิดีโอผลลัพธ์มีขนาดผิด')
            count+=1
    if count<1 or (plan.get('frames') and count!=plan['frames']):
        raise ValueError('จำนวนเฟรมวิดีโอผลลัพธ์ไม่ครบ')
    return info


class ComfyBackend:
    def __init__(self):
        import folder_paths
        self.inputs=Path(folder_paths.get_input_directory()).resolve()
        self.outputs=Path(folder_paths.get_output_directory()).resolve()
        self.data=self.inputs.parent/'motion-studio-private'
        self.base='http://127.0.0.1:'+str(os.environ.get('MOTION_COMFY_PORT','8188'))

    async def request(self,method,path,body=None):
        async with ClientSession(timeout=ClientTimeout(total=30)) as session:
            async with session.request(method,self.base+path,json=body) as response:
                payload=await response.json()
                if response.status>=400:
                    raise ValueError('ComfyUI ไม่รับงาน กรุณาตรวจโมเดลและโหนดให้ครบก่อน')
                return payload

    async def ready(self):
        import folder_paths
        from .nodes import lama_path
        missing=[]
        for category,name in [*MODELS.values(),*(v for k,v in QWEN_MODELS.items() if k!='light')]:
            if not folder_paths.get_full_path(category,name): missing.append(name)
        if not lama_path().is_file(): missing.append('big-lama.pt')
        info=await self.request('GET','/object_info')
        graph,_=build_fullgen_graph('readiness.png','readiness.mp4',
            {'width':720,'height':1280,'fps':30,'duration':15},duration=10.1,
            reference_size=(576,1024),long_edge=1280,upscale_canvas=True,target_fps=16,
            chunk_frames=65,single_scene_reference=True)
        required={node['class_type'] for node in graph.values()}
        missing+=sorted(required-set(info))
        manual=os.environ.get('MOTION_CLEANUP_OWNER')=='user'
        return {'ready':not missing and manual,'missing':missing,'automatic_stop_ready':False,
                'cleanup_owner':'user','session_mode':'manual_session','user_stop_only':True,
                'message':'พร้อมสร้างวิดีโอ' if not missing and manual else
                    ('ใช้ Template รุ่นเชื่อมเองและหยุดเองก่อน' if not manual else 'ยังติดตั้งโมเดลหรือโหนดไม่ครบ')}

    async def stop(self):
        raise RuntimeError('Manual session never stops or terminates a Pod')



class OfflineBackend:
    """Local UI preview. It cannot upload to a Pod, rent a GPU, or generate video."""
    def __init__(self,data):
        self.data=Path(data); self.inputs=self.data/'input'; self.outputs=self.data/'output'
        self.inputs.mkdir(parents=True,exist_ok=True); self.outputs.mkdir(parents=True,exist_ok=True)
    async def ready(self):
        return {'ready':False,'missing':[],'automatic_stop_ready':False,'preview':True,
                'message':'หน้าทดลองบน PC — ยังไม่ได้เชื่อมต่อ GPU'}


class Studio:
    def __init__(self,backend):
        self.backend=backend
        self.data=backend.data
        self.data.mkdir(parents=True,exist_ok=True)
        self.job_dir=self.data/'jobs'; self.job_dir.mkdir(exist_ok=True)
        pinfile=self.data/'access-code.txt'
        if not pinfile.is_file():
            pinfile.write_text(secrets.token_urlsafe(18),encoding='utf-8')
            with contextlib.suppress(OSError): pinfile.chmod(0o600)
        self.code_hash=hashlib.sha256(pinfile.read_text().strip().encode()).digest()
        self.sessions={}; self.attempts=[]; self.lock=asyncio.Lock(); self.task=None
        self.instance_id=secrets.token_hex(16)
        self.jobs={}
        self.releases={}
        for file in self.job_dir.glob('*.json'):
            # Watchdog receipts share this folder but are not job records.
            if not UID.fullmatch(file.stem):continue
            try:
                job=json.loads(file.read_text(encoding='utf-8'))
                if not isinstance(job,dict) or job.get('id')!=file.stem or not isinstance(job.get('status'),str):
                    raise ValueError('Invalid stored job record')
                if job['status'] in ACTIVE_STATUSES:
                    job.update(status='interrupted',message='ระบบเปิดใหม่ระหว่างทำงาน กรุณาตรวจ Pod ก่อนสร้างอีกครั้ง',stop_confirmed=False)
                    atomic_json(file,job)
                self.jobs[job['id']]=job
            except (OSError,ValueError):
                # Preserve damaged evidence and fail closed rather than lose an active lease.
                self.jobs[file.stem]={'id':file.stem,'status':'interrupted','stop_confirmed':False,
                    'stored_record_invalid':True,'message':'อ่านประวัติงานไม่ครบ กรุณาตรวจ Pod ก่อนเริ่มรอบใหม่'}

    def persist(self,job):
        atomic_json(self.job_dir/(job['id']+'.json'),job)

    def authorize(self,request,mutation=False):
        if self.sessions.get(request.cookies.get('motion_auto_session',''),0)<time.time():
            raise web.HTTPUnauthorized(text='กรุณาใส่รหัสเข้าใช้งาน')
        if mutation: self.check_origin(request)

    def check_origin(self,request):
        origin=request.headers.get('Origin')
        if origin and urlsplit(origin).netloc.lower()!=request.host.lower():
            raise web.HTTPForbidden(text='ไม่อนุญาตคำขอจากเว็บไซต์อื่น')
        if request.headers.get('X-Requested-With')!='MotionStudioAuto':
            raise web.HTTPForbidden(text='คำขอไม่ถูกต้อง')

    async def body(self,request):
        if request.content_length and request.content_length>4096:
            raise web.HTTPBadRequest(text='คำขอใหญ่เกินไป')
        raw=await request.content.read(4097)
        if len(raw)>4096: raise web.HTTPBadRequest(text='คำขอใหญ่เกินไป')
        try:
            value=json.loads(raw)
            if not isinstance(value,dict): raise ValueError()
            return value
        except (ValueError,UnicodeError): raise web.HTTPBadRequest(text='ข้อมูลไม่ถูกต้อง')

    async def login(self,request):
        self.check_origin(request)
        now=time.time(); self.attempts=[t for t in self.attempts if now-t<60]
        if len(self.attempts)>=10: raise web.HTTPTooManyRequests(text='กรุณารอ 1 นาทีแล้วลองใหม่')
        body=await self.body(request)
        code=body.get('code','')
        if not isinstance(code,str) or not secrets.compare_digest(hashlib.sha256(code.encode()).digest(),self.code_hash):
            self.attempts.append(now); raise web.HTTPUnauthorized(text='รหัสไม่ถูกต้อง')
        token=secrets.token_urlsafe(32); self.sessions[token]=now+86400
        result=web.json_response({'ok':True})
        result.set_cookie('motion_auto_session',token,httponly=True,samesite='Strict',max_age=86400,
                          secure=request.secure or request.headers.get('X-Forwarded-Proto')=='https')
        return result

    async def status(self,request):
        self.authorize(request)
        try: readiness=await self.backend.ready()
        except Exception: readiness={'ready':False,'message':'ติดต่อ ComfyUI ไม่ได้ กรุณาตรวจว่า Pod ยังเปิดอยู่','automatic_stop_ready':False}
        return web.json_response({**readiness,'system_version':SYSTEM_VERSION,'instance_id':self.instance_id,
                                  'anatomy_policy':'source-primary-geometry-template-v1','anatomy_fallback_implemented':True,
                                  'anatomy_quality_verified':False,
                                  'generation_mode':'full_generation_two_stage','session_mode':'manual_session','user_stop_only':True,'cleanup_owner':'user','duration_seconds':10,
                                  'duration_policy':'source_length_up_to_10s_no_loop_no_retime',
                                  'input_limits':{'min_video_seconds':1.0,'max_video_seconds':120,'min_video_fps':16,'max_people':3},
                                  'jobs':sorted(self.jobs.values(),key=lambda j:j.get('created',0),reverse=True)[:20]})

    async def upload(self,request):
        self.authorize(request,True)
        kind=request.match_info['kind']
        if kind not in ('image','video'): raise web.HTTPNotFound()
        limit=(20 if kind=='image' else 200)*MIB
        folder=self.backend.inputs/'motion-studio'; folder.mkdir(exist_ok=True)
        uid=secrets.token_hex(16); temp=folder/(uid+'.upload')
        final=folder/(uid+('.png' if kind=='image' else '.mp4'))
        # Raw upload body avoids multipart library limits and handles iPhone files.
        try:
            count=0
            with temp.open('wb') as output:
                async for chunk in request.content.iter_chunked(256*1024):
                    count+=len(chunk)
                    if count>limit: raise ValueError('ไฟล์ใหญ่เกินกำหนด: ภาพ 20 MB / คลิป 200 MB')
                    output.write(chunk)
            info=await asyncio.to_thread(metadata,temp,kind)
            if kind=='image' and info.pop('preserve_original',False):
                final=folder/(uid+info.pop('extension'))
                os.replace(temp,final)
            elif kind=='image': os.replace(temp.with_suffix('.png'),final)
            else: os.replace(temp,final)
            record={'id':uid,'kind':kind,'file':str(final.relative_to(self.backend.inputs)).replace('\\','/'),**info}
            atomic_json(folder/(uid+'.json'),record)
            return web.json_response(record)
        except Exception as error:
            final.unlink(missing_ok=True)
            raise web.HTTPBadRequest(text=str(error) if isinstance(error,ValueError) else 'อ่านไฟล์ไม่ได้ กรุณาใช้ JPG/PNG หรือ MP4 ที่เล่นได้')
        finally:
            temp.unlink(missing_ok=True)
            if temp.with_suffix('.png')!=final:
                temp.with_suffix('.png').unlink(missing_ok=True)

    def input_record(self,uid,kind):
        if not isinstance(uid,str) or not UID.fullmatch(uid): raise ValueError('ไฟล์นำเข้าไม่ถูกต้อง')
        path=self.backend.inputs/'motion-studio'/(uid+'.json')
        record=json.loads(path.read_text(encoding='utf-8'))
        if record.get('kind')!=kind: raise ValueError('ประเภทไฟล์ไม่ถูกต้อง')
        selected=(self.backend.inputs/record.get('file','')).resolve()
        if not selected.is_relative_to(self.backend.inputs.resolve()) or not selected.is_file():
            raise ValueError('ไฟล์นำเข้าไม่อยู่ในพื้นที่ของระบบ')
        return record

    async def create(self,request):
        self.authorize(request,True)
        body=await self.body(request)
        async with self.lock:
            if self.task and not self.task.done(): raise web.HTTPConflict(text='กำลังสร้างงานก่อนหน้าอยู่')
            ready=await self.backend.ready()
            if not ready.get('ready'): raise web.HTTPConflict(text=ready['message'])
            queue=await self.backend.request('GET','/queue')
            if not isinstance(queue,dict) or not all(isinstance(queue.get(k),list) for k in ('queue_running','queue_pending')):
                raise web.HTTPConflict(text='ยังอ่านคิว ComfyUI ไม่ครบ กรุณาตรวจสถานะก่อนส่งงาน')
            if queue.get('queue_running') or queue.get('queue_pending'):
                raise web.HTTPConflict(text='ComfyUI มีงานอื่นอยู่ กรุณารอให้เสร็จก่อน')
            try:
                image=self.input_record(body.get('image'),'image'); video=self.input_record(body.get('video'),'video')
                duration=body.get('duration',10)
                timing=validate_two_file_job(image,video,duration)
                runtime_limit=body.get('runtime_limit_seconds',7200)
                if isinstance(runtime_limit,bool) or not isinstance(runtime_limit,(int,float)) or not 600<=runtime_limit<=7200:
                    raise ValueError('เวลาประมวลผลที่เหลือไม่เพียงพอหรือไม่ถูกต้อง')
                uid=body.get('client_job_id',secrets.token_hex(16))
                if not isinstance(uid,str) or not UID.fullmatch(uid) or uid in self.jobs:
                    raise ValueError('หมายเลขงานไม่ถูกต้องหรือส่งงานนี้ไปแล้ว ระบบไม่สร้างซ้ำ')
                from .fullgen_pipeline import canvas_for_reference
                canvas=canvas_for_reference(image['width'],image['height'])
                _,plan=build_fullgen_graph(image['file'],video['file'],video,duration=timing['source_seconds'],job_id=uid,
                    reference_size=canvas,long_edge=max(canvas),upscale_canvas=True,
                    target_fps=16,chunk_frames=65,single_scene_reference=True,tail_pad_frames=timing['tail_pad_frames'])
                plan.update(raw_frames=plan['frames'],frames=timing['final_frames'],seconds=timing['final_seconds'],
                    duration_policy=timing['duration_policy'],quality_review_pending=True)
            except ValueError as error: raise web.HTTPBadRequest(text=str(error))
            except (FileNotFoundError,KeyError): raise web.HTTPBadRequest(text='ตรวจไฟล์และความยาวอีกครั้ง')
            job={'id':uid,'prompt_id':None,'status':'queued','stage':'analyzing','created':time.time(),
                 'message':'กำลังวิเคราะห์คนและเตรียมฉากใหม่อัตโนมัติ','plan':plan,'stop_confirmed':None,
                 'requested_duration':duration,'runtime_limit_seconds':runtime_limit,'generation_mode':'full_generation_two_stage',
                 'quality_review_pending':True,'visual_quality_verified':False,'session_mode':'manual_session','user_stop_only':True}
            job['instance_id']=self.instance_id
            self.jobs[uid]=job; self.persist(job)
            self.task=asyncio.create_task(self.watch_fullgen(job,image,video))
            return web.json_response(job,status=202)

    async def watch_fullgen(self,job,image,video):
        from .fullgen_pipeline import FullGenerationPipeline
        try:
            runtime_limit=job['runtime_limit_seconds']
            async def update(values):
                # The raw renderer result must never become downloadable before
                # finalization; PC controllers treat `result` as the release signal.
                stage_names={'prepare':'analyzing','scene':'scene_generating','scene_reused':'scene_validating',
                             'validate':'scene_validating','video':'generating','render_complete':'finalizing'}
                values={k:v for k,v in values.items() if k not in ('result','plan')}
                values['stage']=stage_names.get(values.get('stage'),values.get('stage'))
                job.update(values,status='running');self.persist(job)
            pipeline=FullGenerationPipeline(request=self.backend.request,inputs=self.backend.inputs,
                outputs=self.backend.outputs,evidence_dir=self.data/'evidence'/job['id'],
                fixtures=ROOT/'fullgen-fixtures',on_update=update,timeout_seconds=runtime_limit)
            result=await pipeline.run(image,video,job_id=job['id'],seconds=job.get('requested_duration',10))
            raw=(self.backend.outputs/result['result']).resolve()
            if not raw.is_relative_to(self.backend.outputs.resolve()) or not raw.is_file():
                raise ValueError('ไม่พบไฟล์วิดีโอในพื้นที่ผลลัพธ์')
            final_seconds=result.get('final_seconds',10.)
            final_frames=result.get('final_frames',round(final_seconds*16))
            job.update(stage='finalizing',message=f'กำลังตรวจวิดีโอและบันทึกความยาว {final_seconds:g} วินาที',raw_result=result['result'])
            self.persist(job)
            destination=self.backend.outputs/'motion-studio'/(job['id']+f'-{final_seconds:g}s.mp4')
            destination.parent.mkdir(exist_ok=True)
            report=await asyncio.to_thread(finalize,raw,destination,seconds=final_seconds,fps=16,crf=16)
            final_plan={**result['plan'],'raw_frames':result['plan']['frames'],'frames':final_frames,'seconds':final_seconds}
            await asyncio.to_thread(verify_result,destination,final_plan)
            if result.get('first_scene'):
                from .fullgen_evidence import package_job_evidence
                proof=await asyncio.to_thread(package_job_evidence,self.data/'evidence'/job['id'],
                    result['first_scene']['file'],report,self.job_dir/(job['id']+'.evidence.zip'))
                job.update(evidence_file=Path(proof['path']).name,evidence_sha256=proof['sha256'],evidence_bytes=proof['bytes'])
            job.update(plan=final_plan,scene_analysis=result.get('scene_analysis',{}),
                reference_analysis=result.get('reference_analysis',{}),
                result=str(destination.relative_to(self.backend.outputs)).replace('\\','/'),
                render_status='completed',status='ready',stage='downloading',
                message=f'สร้างครบ {final_seconds:g} วินาทีแล้ว กำลังส่งไฟล์ไปบันทึกบน PC',
                output_sha256=report['output_fingerprint']['sha256'],quality_review_pending=True,
                visual_quality_verified=False)
            event=asyncio.Event();self.releases[job['id']]=event;self.persist(job)
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(event.wait(),timeout=180)
        except Exception as error:
            job.update(render_status='failed',error_stage=job.get('failure_stage') or job.get('stage'),
                error_message=str(error) if isinstance(error,ValueError) else type(error).__name__,
                message=str(error) if isinstance(error,ValueError) else 'ระบบสร้างวิดีโอขัดข้อง กรุณาตรวจ Pod ที่เปิดไว้')
        finally:
            self.releases.pop(job['id'],None)
            state=job.get('render_status','failed')
            job.update(status=state,stage=state,stop_confirmed=None,cleanup_owner='user',user_stop_only=True)
            if job.get('result'):job['message']='วิดีโอพร้อมดาวน์โหลด เครื่องยังเปิดอยู่ ให้ผู้ใช้ Stop และ Terminate เองหลังเก็บผลครบ'
            self.persist(job)

    async def read_job(self,request):
        self.authorize(request)
        job=self.jobs.get(request.match_info['id'])
        if not job:raise web.HTTPNotFound()
        return web.json_response(job,headers={'Cache-Control':'no-store'})

    async def result(self,request):
        self.authorize(request)
        job=self.jobs.get(request.match_info['id'])
        if not job or not job.get('result'): raise web.HTTPNotFound()
        path=(self.backend.outputs/job['result']).resolve()
        if not path.is_relative_to(self.backend.outputs) or not path.is_file(): raise web.HTTPNotFound()
        return web.FileResponse(path,headers={'Content-Type':'video/mp4'})

    async def release(self,request):
        self.authorize(request,True)
        event=self.releases.get(request.match_info['id'])
        if event: event.set()
        return web.json_response({'ok':bool(event)})

    async def evidence(self,request):
        self.authorize(request)
        job=self.jobs.get(request.match_info['id'])
        if not job or not job.get('evidence_file'):raise web.HTTPNotFound()
        path=(self.job_dir/job['evidence_file']).resolve()
        if not path.is_relative_to(self.job_dir.resolve()) or not path.is_file():raise web.HTTPNotFound()
        return web.FileResponse(path,headers={'Content-Type':'application/zip'})

    async def asset(self,request):
        name=request.match_info.get('name','index.html')
        if name not in ('index.html','style.css','app.js'): raise web.HTTPNotFound()
        return web.FileResponse(ROOT/'web'/name,headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',
            'Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob:; media-src 'self' blob:; frame-ancestors 'none'"})

    def routes(self):
        routes=web.RouteTableDef()
        for method,path,handler in [('GET','/',self.asset),('GET','/assets/{name}',self.asset),
            ('POST','/api/login',self.login),('GET','/api/status',self.status),
            ('POST','/api/upload/{kind}',self.upload),('POST','/api/jobs',self.create),
            ('POST','/api/jobs/{id}/release',self.release),
            ('GET','/api/jobs/{id}/evidence',self.evidence),
            ('GET','/api/jobs/{id}',self.read_job),
            ('GET','/api/jobs/{id}/result',self.result)]:
            routes.route(method,PREFIX+path)(handler)
        return routes


def register():
    from server import PromptServer
    studio=Studio(ComfyBackend())
    PromptServer.instance.app.add_routes(studio.routes())
    return studio
