"""Durable Runpod lifecycle: legacy resume/stop or fresh create/terminate.

The fresh lifecycle lives in fresh_pod.py. No allocation mutation is retried,
no network volume is used, and the account key remains encrypted on the PC.
"""
import asyncio
from contextlib import asynccontextmanager
import ctypes
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from aiohttp import ClientSession,ClientTimeout
from .service import atomic_json
from .fresh_pod import FreshPodLifecycle
from .manual_pod import ManualPodLifecycle

POD_ID=re.compile(r'^[a-zA-Z0-9]{8,40}$')
REST='https://rest.runpod.io/v1'


def protect(raw,decrypt=False):
    if os.name!='nt':raise ValueError('การเก็บ API key รองรับบัญชี Windows ของเจ้าของ PC เท่านั้น')
    class Blob(ctypes.Structure):
        _fields_=[('size',ctypes.c_ulong),('data',ctypes.POINTER(ctypes.c_ubyte))]
    buffer=ctypes.create_string_buffer(raw)
    source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));output=Blob()
    function=ctypes.windll.crypt32.CryptUnprotectData if decrypt else ctypes.windll.crypt32.CryptProtectData
    function.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,
                      ctypes.c_void_p,ctypes.c_ulong,ctypes.POINTER(Blob)]
    function.restype=ctypes.c_int
    if not function(ctypes.byref(source),None,None,None,None,1,ctypes.byref(output)):
        raise ValueError('อ่านกุญแจที่เข้ารหัสด้วยบัญชี Windows ไม่สำเร็จ')
    try:return ctypes.string_at(output.data,output.size)
    finally:
        free=ctypes.windll.kernel32.LocalFree;free.argtypes=[ctypes.c_void_p];free.restype=ctypes.c_void_p
        free(output.data)


class ProviderError(ValueError):
    def __init__(self,status,operation):
        self.status=status;self.operation=operation
        if status==403:
            message='RunPod HTTP 403: API key ไม่มีสิทธิ์สำหรับ '+operation+'; ใช้กุญแจบัญชีที่อนุญาตอ่าน/สร้าง/หยุด/ลบ Pods บน PC และตรวจข้อจำกัดบัญชี'
        elif status==401:message='RunPod HTTP 401: API key ไม่ถูกต้องหรือถูกยกเลิก'
        else:message=f'RunPod HTTP {status}: {operation} ไม่สำเร็จ'
        super().__init__(message)


class Provider(FreshPodLifecycle,ManualPodLifecycle):
    def __init__(self,data):
        self.data=Path(data);self.key_path=self.data/'runpod-key.dpapi'
        self.config_path=self.data/'runpod-automation.json';self.ledger_path=self.data/'runpod-lease.json'
        self.lock=asyncio.Lock()

    @asynccontextmanager
    async def lifecycle_lock(self):
        """Serialize the controller and independent guard across OS processes.

        Without this, an old guard's delayed stop could kill a newly started job.
        The operating system releases this lock if the holder crashes.
        """
        async with self.lock:
            path=self.data/'runpod-lifecycle.lock'
            if not path.exists():
                try:
                    with path.open('xb') as initial:initial.write(b'0')
                except FileExistsError:pass
            file=path.open('r+b');locked=False
            if os.name=='nt':import msvcrt
            else:import fcntl
            deadline=time.monotonic()+600
            try:
                while not locked:
                    try:
                        file.seek(0)
                        if os.name=='nt':msvcrt.locking(file.fileno(),msvcrt.LK_NBLCK,1)
                        else:fcntl.flock(file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                        locked=True
                    except OSError:
                        if time.monotonic()>deadline:raise ValueError('รอการตรวจหยุด GPU ของรอบเดิมนานเกินไป')
                        await asyncio.sleep(.25)
                yield
            finally:
                if locked:
                    file.seek(0)
                    if os.name=='nt':msvcrt.locking(file.fileno(),msvcrt.LK_UNLCK,1)
                    else:fcntl.flock(file.fileno(),fcntl.LOCK_UN)
                file.close()

    def config(self):
        return json.loads(self.config_path.read_text(encoding='utf-8')) if self.config_path.is_file() else {}

    def save_account_key(self,api_key):
        """Store only. Never contact Runpod, arm rental, or expose the key."""
        if self.lease().get('cleanup_pending'):raise ValueError('ต้องจัดการ Pod ของงานเดิมก่อนเปลี่ยน API key')
        if not isinstance(api_key,str) or not 16<=len(api_key)<=512 or any(c.isspace() for c in api_key):
            raise ValueError('กรุณาใส่ API key ของบัญชี RunPod ที่ถูกต้อง')
        encrypted=protect(api_key.encode())
        temp=self.key_path.with_suffix('.tmp');temp.write_bytes(encrypted);os.replace(temp,self.key_path)

    def lease(self):
        return json.loads(self.ledger_path.read_text(encoding='utf-8')) if self.ledger_path.is_file() else {}

    def public(self):
        if self.config().get('mode')=='manual_owned':return self.manual_public()
        if self.config().get('mode')=='fresh':return self.fresh_public()
        config=self.config();pending=self.lease().get('cleanup_pending',False)
        enabled=bool(config.get('enabled') and self.key_path.is_file() and POD_ID.fullmatch(config.get('pod_id','')))
        return {'auto_lease':enabled,'cleanup_pending':pending,'ready':enabled and not pending,
                'connection_needed':not enabled,'automatic_stop_ready':enabled,
                'message':'รอการยืนยันหยุด GPU ของงานก่อนหน้า' if pending else
                    'พร้อมเริ่ม GPU บน RunPod อัตโนมัติเมื่อกดสร้าง' if enabled else
                    'ตั้งค่า RunPod ครั้งเดียว แล้วระบบจะเปิดและหยุด GPU ให้ทุกงาน'}

    def configure(self,pod_id,api_key):
        if self.lease().get('cleanup_pending'):raise ValueError('ยังมี GPU ที่ต้องตรวจและหยุดก่อนเปลี่ยนการตั้งค่า')
        if not POD_ID.fullmatch(pod_id):raise ValueError('รหัส Pod ไม่ถูกต้อง')
        if api_key:
            if not isinstance(api_key,str) or not 16<=len(api_key)<=512 or any(c.isspace() for c in api_key):
                raise ValueError('API key ไม่ถูกต้อง')
            encrypted=protect(api_key.encode())
            temp=self.key_path.with_suffix('.tmp');temp.write_bytes(encrypted);os.replace(temp,self.key_path)
        if not self.key_path.is_file():raise ValueError('กรุณาระบุ API key ครั้งแรก')
        atomic_json(self.config_path,{'enabled':True,'pod_id':pod_id,'max_runtime_seconds':7200})

    def start_guard(self,job_id):
        return subprocess.Popen([sys.executable,str(Path(__file__).with_name('pc_lease_guard.py')),
            '--data',str(self.data),'--job',job_id],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))

    async def call(self,method,path,body=None):
        key=protect(self.key_path.read_bytes(),decrypt=True).decode()
        url='https://api.runpod.io/graphql' if path=='graphql' else REST+path
        try:
            async with ClientSession(trust_env=False,timeout=ClientTimeout(total=35)) as session:
                async with session.request(method,url,json=body,allow_redirects=False,
                                           headers={'Authorization':'Bearer '+key}) as response:
                    if response.status>=300:raise ProviderError(response.status,method+' '+path.split('?')[0])
                    raw=await response.content.read(1024*1024+1)
                    if len(raw)>1024*1024:raise ValueError('RunPod ส่งข้อมูลใหญ่เกินกำหนด')
                    return json.loads(raw) if raw else {}
        except (OSError,asyncio.TimeoutError):
            raise ValueError('ติดต่อ RunPod ไม่สำเร็จ ระบบต้องตรวจการหยุด GPU ก่อนเริ่มงานใหม่') from None

    async def acquire(self,job_id,persist):
        if self.config().get('mode')=='manual_owned':return await self.acquire_manual(job_id,persist)
        if self.config().get('mode')=='fresh':return await self.acquire_fresh(job_id,persist)
        async with self.lifecycle_lock():
            config=self.config()
            if not self.public()['ready']:raise ValueError(self.public()['message'])
            pod_id=config['pod_id']
            # Inspect the specifically configured Pod; never adopt another running job.
            pod=await self.call('GET','/pods/'+pod_id)
            if pod.get('id')!=pod_id or pod.get('desiredStatus') not in ('EXITED','STOPPED'):
                raise ValueError('Pod ที่ตั้งไว้ยังเปิดอยู่หรือไม่พร้อม กรุณาหยุด Pod ก่อนใช้ระบบอัตโนมัติครั้งแรก')
            balance=await self.call('POST','graphql',{'query':'query { myself { clientBalance isAutoPayEnabled } }'})
            account=balance.get('data',{}).get('myself',{})
            if account.get('isAutoPayEnabled') is not False:
                raise ValueError('กรุณาปิดการเติมเงินอัตโนมัติใน RunPod ก่อนเริ่มงาน')
            credits=account.get('clientBalance')
            hourly=pod.get('adjustedCostPerHr') or pod.get('costPerHr')
            if isinstance(credits,bool) or not isinstance(credits,(int,float)) or not math.isfinite(credits) or credits<=0:
                raise ValueError('เครดิต RunPod ไม่พอ ระบบยังไม่เริ่มเช่า')
            try:
                if isinstance(hourly,bool):raise ValueError()
                hourly=float(hourly)
            except (TypeError,ValueError):hourly=0
            if not math.isfinite(hourly) or hourly<=0:
                raise ValueError('ยังตรวจค่าเช่า GPU ไม่ได้ ระบบยังไม่เริ่มเช่า')
            # Conservative runtime allowance from remaining credit, without the old $1 cap.
            max_seconds=min(config.get('max_runtime_seconds',7200),int(credits*.70/hourly*3600))
            if max_seconds<3600:raise ValueError('เครดิตไม่พอเผื่อเปิดเครื่องและงานคุณภาพ 10 วินาทีอย่างน้อย 1 ชั่วโมง จึงยังไม่เริ่มเช่า')
            row={'job_id':job_id,'pod_id':pod_id,'cleanup_pending':True,'started_at':time.time(),
                 'deadline':time.time()+max_seconds,'hourly_usd':hourly,'state':'starting'}
            # Save BEFORE the mutation: an HTTP timeout can mean GPU start succeeded.
            atomic_json(self.ledger_path,row);persist(row)
            self.start_guard(job_id)
            await self.call('POST','/pods/'+pod_id+'/start')
            row['state']='running';atomic_json(self.ledger_path,row);persist(row)
            return row

    async def stop_owned(self,job_id):
        if self.lease().get('mode')=='fresh':return await self.cleanup_fresh(job_id)
        async with self.lifecycle_lock():
            row=self.lease()
            if row.get('job_id')!=job_id or not row.get('cleanup_pending'):
                return not row.get('cleanup_pending',False)
            pod_id=row.get('pod_id','')
            if not POD_ID.fullmatch(pod_id):return False
            try:
                state=await self.call('GET','/pods/'+pod_id)
                if state.get('id')!=pod_id:return False
                if state.get('desiredStatus') not in ('EXITED','STOPPED'):
                    await self.call('POST','/pods/'+pod_id+'/stop')
                # Confirm through the provider API, independently of the Pod web server.
                for i in range(12):
                    state=await self.call('GET','/pods/'+pod_id)
                    if state.get('id')==pod_id and state.get('desiredStatus') in ('EXITED','STOPPED'):
                        row.update(cleanup_pending=False,state='stopped',stopped_at=time.time())
                        if self.lease().get('job_id')!=job_id:return False
                        atomic_json(self.ledger_path,row);return True
                    await asyncio.sleep(2)
            except Exception:pass
            row['state']='stop_unconfirmed'
            if self.lease().get('job_id')==job_id:atomic_json(self.ledger_path,row)
            return False

    async def reconcile(self):
        row=self.lease()
        if row.get('cleanup_pending'):return await self.stop_owned(row['job_id'])
        return True
