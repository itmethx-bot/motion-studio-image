"""PC cleanup process survives a crash of the web controller while PC stays on."""
import argparse
import asyncio
from pathlib import Path
import sys
import time
import types

ROOT=Path(__file__).resolve().parent
pkg=types.ModuleType('motion_studio_auto');pkg.__path__=[str(ROOT)]
sys.modules['motion_studio_auto']=pkg
from motion_studio_auto.provider import Provider


async def guard(data,job_id):
    provider=Provider(data)
    while True:
        row=provider.lease()
        if row.get('job_id')!=job_id or not row.get('cleanup_pending'):return
        path=Path(data)/'jobs'/(job_id+'.json')
        heartbeat=path.stat().st_mtime if path.is_file() else row.get('heartbeat_at',row['started_at'])
        if time.time()>row['deadline'] or time.time()-heartbeat>300:
            if await provider.stop_owned(job_id):return
        await asyncio.sleep(15)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--job',required=True)
    args=p.parse_args();asyncio.run(guard(args.data,args.job))
