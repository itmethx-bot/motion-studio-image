"""Build a fresh SCAIL-2 graph per job: no copied photo-specific parameters."""
from .scene_core import chunk_plan, size_for_video
import math

MODELS = {
    'sam': ('checkpoints','sam3.1_multiplex_fp16.safetensors'),
    'unet': ('diffusion_models','wan2.1_14B_SCAIL_2_int8_convrot.safetensors'),
    'dpo': ('loras','wan2.1_SCAIL_2_DPO_lora_bf16.safetensors'),
    'light': ('loras','lightx2v_I2V_14B_480p_cfg_step_distill_rank64_bf16.safetensors'),
    'text': ('text_encoders','umt5_xxl_fp8_e4m3fn_scaled.safetensors'),
    'vision': ('clip_vision','clip_vision_h.safetensors'),
    'vae': ('vae','Wan2_1_VAE_bf16.safetensors'),
}
SOURCE_OBJECT_QUERY = 'object'


def merge_short_tail(plan):
    """Avoid a 9/13-frame continuation with almost all latents anchored.

    A real 149-frame run showed corruption in its final 9-frame window. Extend
    the preceding 33-frame window to 37/41 using actual remaining guide frames;
    do not request a longer latent while silently leaving its guide unpadded.
    This preserves all output frames, offsets and earlier cached windows.
    """
    parts=[dict(part) for part in plan]
    if len(parts)>1 and parts[-1]['length']<=13:
        tail=parts.pop()
        parts[-1]['length']+=tail['length']-tail['trim']
    return parts


def build_graph(image,video,meta,duration=5,seed=32139832,job_id='test',reference_size=None,*,
                long_edge=704,upscale_canvas=False,target_fps=None,chunk_frames=33,
                video_steps=8,video_cfg=1.,video_shift=1.,use_lightx=True,video_sampler='euler',lightx_lora=None,
                no_source_props=False):
    if isinstance(long_edge,bool) or not isinstance(long_edge,int) or not 256<=long_edge<=1280 or long_edge%32:
        raise ValueError('long_edge must be a multiple of 32 between 256 and 1280')
    if type(upscale_canvas) is not bool or type(use_lightx) is not bool:
        raise ValueError('upscale_canvas and use_lightx must be booleans')
    if type(no_source_props) is not bool:
        raise ValueError('no_source_props must be a boolean')
    if chunk_frames not in (33,49,65,81) or isinstance(chunk_frames,bool):
        raise ValueError('chunk_frames must be 33, 49, 65 or 81')
    source_fps=float(meta['fps'])
    fps=min(30,source_fps)
    if target_fps is not None:
        fps=float(target_fps)
        if not math.isfinite(fps) or not 12<=fps<=30 or fps>source_fps+1e-6:
            raise ValueError('target_fps must be between 12 and 30 and not exceed source FPS')
    if isinstance(video_steps,bool) or not isinstance(video_steps,int) or video_steps<1:
        raise ValueError('video_steps must be a positive integer')
    if not math.isfinite(float(video_cfg)) or video_cfg<0:
        raise ValueError('video_cfg must be finite and nonnegative')
    if not math.isfinite(float(video_shift)) or video_shift<=0:
        raise ValueError('video_shift must be finite and positive')
    if video_sampler not in ('euler','uni_pc','dpmpp_2m'):
        raise ValueError('video_sampler must be euler, uni_pc or dpmpp_2m')
    if lightx_lora is not None:
        if (not isinstance(lightx_lora,str) or not lightx_lora.endswith('.safetensors')
                or lightx_lora.strip()!=lightx_lora or lightx_lora.startswith('.')
                or any(char in lightx_lora for char in '/\\:*?"<>|')
                or any(ord(char)<32 for char in lightx_lora)):
            raise ValueError('lightx_lora must be a plain .safetensors basename with no directory or drive')
        if not use_lightx:
            raise ValueError('lightx_lora cannot be supplied when use_lightx is false')
    # The destination scene sets the canvas. The source video is fitted into it
    # without stretching by MotionLoadClip; person positions remain relative.
    width,height=size_for_video(*(reference_size or (meta['width'],meta['height'])),
                                long_edge=long_edge,upscale=upscale_canvas)
    frames=int(min(duration,meta['duration'])*fps)
    plan=merge_short_tail(chunk_plan(frames,chunk=chunk_frames))
    frame_count=sum(part['length']-part['trim'] for part in plan)
    p={}
    def add(id,kind,**inputs):
        p[str(id)]={'class_type':kind,'inputs':inputs}
        return [str(id),0]
    ref=add('reference','LoadImage',image=image)
    vid=add('video','MotionLoadClip',file=video,seconds=min(duration,meta['duration']),
            fps=fps,width=width,height=height,expected_frames=frame_count)
    sam=add('sam','CheckpointLoaderSimple',ckpt_name=MODELS['sam'][1])
    person=add('people_text','CLIPTextEncode',clip=['sam',1],text='person')
    woman=add('women_text','CLIPTextEncode',clip=['sam',1],text='woman')
    reference_objects_text=add('reference_objects_text','CLIPTextEncode',clip=['sam',1],text='handheld object')
    # Broad candidates include contact with objects that are not held (e.g. a
    # chair). Scene preparation still admits ONLY main-person contact candidates.
    # SAM's generic "object" query does not guarantee detection of every prop.
    if not no_source_props:
        source_objects_text=add('source_objects_text','CLIPTextEncode',clip=['sam',1],text=SOURCE_OBJECT_QUERY)
    first=add('first','ImageFromBatch',image=vid,batch_index=0,length=1)
    track=add('tracking','SAM3_VideoTrack',images=vid,model=sam,conditioning=person,
              detection_threshold=.30,max_objects=6,detect_interval=8)
    women=add('women','SAM3_Detect',model=sam,image=first,conditioning=woman,
              threshold=.30,refine_iterations=2,individual_masks=False)
    resized=add('reference_size','MotionFitImage',image=ref,width=width,height=height)
    refmask=add('reference_person','SAM3_Detect',model=sam,image=resized,conditioning=woman,
                threshold=.30,refine_iterations=2,individual_masks=True)
    reference_objects=add('reference_objects','SAM3_Detect',model=sam,image=resized,
                conditioning=reference_objects_text,threshold=.35,refine_iterations=2,individual_masks=True)
    source_prop_inputs={}
    if not no_source_props:
        source_objects=add('source_objects','SAM3_VideoTrack',images=vid,model=sam,
                    conditioning=source_objects_text,detection_threshold=.35,max_objects=6,detect_interval=8)
        source_prop_inputs['source_object_tracks']=source_objects
    scene=add('scene','MotionPrepareScene',reference=resized,reference_mask=refmask,
              source_frames=vid,track_data=track,women_mask=women,
              reference_objects=reference_objects,**source_prop_inputs,fps=['video',2])
    add('analysis_report','MotionSceneReport',analysis=['scene',4])
    text=add('text','CLIPLoader',clip_name=MODELS['text'][1],type='wan',device='default')
    pos=add('positive','CLIPTextEncode',clip=text,text=['scene',3])
    neg=add('negative','CLIPTextEncode',clip=text,text='extra person, duplicate character, identity swap, '
            'original main character face, frozen character, malformed hands, disconnected hands, '
            'extra fingers, extra limbs, flickering face, distorted anatomy, watermark, text')
    base=add('unet','UNETLoader',unet_name=MODELS['unet'][1],weight_dtype='default')
    dpo=add('dpo','LoraLoaderModelOnly',model=base,lora_name=MODELS['dpo'][1],strength_model=1.)
    # SCAIL-2's official Lightx recipe uses strength=1, 8 steps, shift=1 and cfg=1.
    # This is a documented starting point, not evidence of GPU-tested quality.
    light=add('light','LoraLoaderModelOnly',model=dpo,lora_name=lightx_lora or MODELS['light'][1],strength_model=1.) if use_lightx else dpo
    model=add('model','ModelSamplingSD3',model=light,shift=video_shift)
    vae=add('vae','VAELoader',vae_name=MODELS['vae'][1])
    vision=add('vision','CLIPVisionLoader',clip_name=MODELS['vision'][1])
    main_view=add('main_reference','ImageFromBatch',image=scene,batch_index=0,length=1)
    features=add('features','CLIPVisionEncode',clip_vision=vision,image=main_view,crop='none')
    sampler=add('sampler','KSamplerSelect',sampler_name=video_sampler)
    sigmas=add('sigmas','BasicScheduler',model=model,scheduler='simple',steps=video_steps,denoise=1.)
    previous=None
    assembled=None
    for i,part in enumerate(plan):
        # WanSCAILToVideo slices the FULL filtered driving tensors using the
        # cumulative offset. Raw source RGB never goes into the generator:
        # only people and main-person contact candidates survive scene filtering.
        opts=dict(positive=pos,negative=neg,vae=vae,width=width,height=height,
                  length=part['length'],batch_size=1,pose_strength=1.,pose_start=0.,pose_end=1.,
                  video_frame_offset=part['offset']+(5 if i else 0),previous_frame_count=5,
                  replacement_mode=False,pose_video=['scene',5],pose_video_mask=['scene',2],
                  reference_image=scene,reference_image_mask=['scene',1],clip_vision_output=features)
        if previous:
            opts['previous_frames']=previous
        cond=add(f'condition_{i}','WanSCAILToVideo',**opts)
        latent=add(f'sample_{i}','SamplerCustom',model=model,add_noise=True,noise_seed=seed,
                   cfg=video_cfg,positive=cond,negative=[cond[0],1],latent_image=[cond[0],2],
                   sampler=sampler,sigmas=sigmas)
        decoded=add(f'decode_{i}','VAEDecode',samples=[latent[0],1],vae=vae)
        previous=decoded
        if i:
            trimmed=add(f'trim_{i}','ImageFromBatch',image=decoded,batch_index=5,length=4096)
            assembled=add(f'join_{i}','ImageBatch',image1=assembled,image2=trimmed)
        else:
            assembled=decoded
    video_out=add('create','CreateVideo',images=assembled,fps=['video',2],audio=['video',1],bit_depth=8)
    add('save','SaveVideo',video=video_out,filename_prefix=f'motion-studio/{job_id}',format='mp4',codec='h264')
    return p,{'frames':frame_count,'fps':fps,'seconds':frame_count/fps,
              'width':width,'height':height,'chunks':len(plan),
              'generation_mode':'joint_reference_scene',
              'props':('disabled by explicit no_source_props policy; no source object candidates'
                       if no_source_props else 'primary-contact candidates only; 2D association is not physical contact proof'),
              'source_scene':'filtered out before generation; destination scene from reference',
              'gpu_quality_verified':False}
