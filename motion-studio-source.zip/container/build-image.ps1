param(
    [Parameter(Mandatory=$true)][string]$BaseImage,
    [Parameter(Mandatory=$true)][string]$ImageTag
)
$ErrorActionPreference = 'Stop'
if ($BaseImage -notmatch '^[a-z0-9][a-z0-9./_:-]{1,240}@sha256:[a-f0-9]{64}$') {
    throw 'Use a reviewed CUDA/PyTorch base image pinned with @sha256:digest.'
}
if ($ImageTag -notmatch '^[a-z0-9][a-z0-9./_-]{1,200}:[a-zA-Z0-9._-]{1,100}$') {
    throw 'Use an image repository and version tag.'
}
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Docker is not installed. Nothing built or published.' }
# This command builds locally only. Publishing requires a registry account and
# a separate docker push; it never publishes personal files or provider keys.
& docker build --build-arg ('BASE_IMAGE=' + $BaseImage) --tag $ImageTag $PSScriptRoot
if ($LASTEXITCODE -ne 0) { throw 'Docker build failed. Do not use this image on a billable Pod.' }
Write-Host 'Local image built. Publish separately, then use its registry @sha256:digest in Motion Studio.'
