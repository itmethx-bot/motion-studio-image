"""Container paths, protected Comfy proxy and readiness; no rental or model fetch."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from urllib.request import ProxyHandler, build_opener

# การรอ ComfyUI ภายใน Pod ไม่ผ่าน HTTP proxy จาก env
urlopen = build_opener(ProxyHandler({})).open


def port(name, default):
    value = os.environ.get(name, str(default))
    if not value.isdecimal() or not 1024 <= int(value) <= 65535:
        raise ValueError(name + ' ต้องเป็นพอร์ต 1024–65535')
    return int(value)


def mounted_workspace(path=Path('/workspace')):
    """ตรวจ mount จริง เพื่อไม่ให้เผลอเก็บโมเดลลง container disk."""
    wanted = str(path.resolve())
    info = Path('/proc/self/mountinfo')
    if not info.is_file():
        return False
    return any(len(parts := line.split()) > 4 and parts[4] == wanted
               for line in info.read_text(encoding='utf-8').splitlines())


def safe_root(value, workspace=Path('/workspace')):
    path = Path(value)
    if not path.is_absolute() or path.is_symlink() or not path.resolve().is_relative_to(workspace.resolve()):
        raise ValueError('MODELS_ROOT และ DATA_ROOT ต้องอยู่ภายใน Network Volume /workspace')
    if path.resolve() == workspace.resolve():
        raise ValueError('ใช้โฟลเดอร์ย่อย /workspace/models และ /workspace/image-studio-data')
    return path.resolve()


def link(path, target):
    """สร้างเฉพาะ symlink ที่ระบุ ไม่ย้าย/ลบไฟล์โมเดลหรือโฟลเดอร์เดิม."""
    path, target = Path(path), Path(target)
    if path.is_symlink():
        if path.resolve() != target.resolve():
            raise ValueError('symlink เดิมไม่ตรงกับ MODELS_ROOT: ' + path.name)
        return
    if path.exists():
        # directory ว่างจาก source ComfyUI ไม่มีน้ำหนัก; rmdir ลบได้เฉพาะที่ว่างจริง
        if not path.is_dir() or any(path.iterdir()):
            raise ValueError('พบข้อมูลเดิมที่ตำแหน่งโมเดล จึงไม่แก้ทับ: ' + path.name)
        path.rmdir()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.symlink_to(target, target_is_directory=True)


def proxy_config(external, internal, credentials):
    return f'''user www-data;
worker_processes 1;
pid /run/image-studio/nginx.pid;
error_log /dev/stderr warn;
events {{ worker_connections 256; }}
http {{
    include /etc/nginx/mime.types;
    access_log off;
    map $http_upgrade $connection_upgrade {{ default upgrade; '' close; }}
    server {{
        listen {external};
        client_max_body_size 64m;
        auth_basic "Image Studio ComfyUI";
        auth_basic_user_file {credentials};
        location / {{
            proxy_pass http://127.0.0.1:{internal};
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection $connection_upgrade;
            proxy_set_header Authorization "";
            proxy_set_header X-Forwarded-Proto $http_x_forwarded_proto;
            proxy_read_timeout 3600s;
            proxy_send_timeout 3600s;
        }}
    }}
}}
'''


def prepare():
    if not mounted_workspace():
        raise ValueError('ไม่พบ mount /workspace ให้แนบ Network Volume และตั้ง Volume mount path เป็น /workspace')
    models = safe_root(os.environ.get('MODELS_ROOT', '/workspace/models'))
    data = safe_root(os.environ.get('DATA_ROOT', '/workspace/image-studio-data'))
    if models == data or models.is_relative_to(data) or data.is_relative_to(models):
        raise ValueError('MODELS_ROOT และ DATA_ROOT ต้องแยกโฟลเดอร์กัน')
    code = os.environ.get('IMAGE_STUDIO_CODE', '')
    if not re.fullmatch(r'[A-Za-z0-9_-]{24,128}', code):
        raise ValueError('ตั้ง IMAGE_STUDIO_CODE เป็นรหัส A–Z/a–z/0–9/_/- ความยาว 24–128 ตัว')
    ports = [port('APP_PORT', 5000), port('COMFY_PORT', 8188), port('COMFY_INTERNAL_PORT', 8189)]
    if len(set(ports)) != 3:
        raise ValueError('APP_PORT, COMFY_PORT และ COMFY_INTERNAL_PORT ต้องต่างกัน')
    models.mkdir(parents=True, exist_ok=True)
    for name in ('comfy-input', 'comfy-output', 'comfy-user'):
        (data / name).mkdir(parents=True, exist_ok=True)
    # custom nodes บางตัวอ่าน models_dir โดยตรง จึงต้องมี symlink นอกจาก YAML
    comfy = Path('/opt/ComfyUI')
    # Git source มี .gitkeep ใน models; สร้าง models location ใหม่ใน Docker build ก่อนขั้นนี้
    link(comfy / 'models', models)
    for alias, target in {'sams': 'sam', 'grounding-dino': 'groundingdino'}.items():
        (models / target).mkdir(exist_ok=True)
        link(models / alias, models / target)
    yaml = f'''network_volume:
  base_path: {json.dumps(str(models))}
  is_default: true
  checkpoints: checkpoints
  diffusion_models: diffusion_models
  text_encoders: text_encoders
  clip: text_encoders
  clip_vision: clip_vision
  vae: vae
  controlnet: controlnet
  loras: loras
  ipadapter: ipadapter
  instantid: instantid
  insightface: insightface
  sams: sam
  grounding-dino: groundingdino
  facerestore_models: facerestore_models
'''
    run = Path('/run/image-studio')
    run.mkdir(mode=0o750, parents=True, exist_ok=True)
    (run / 'extra_model_paths.yaml').write_text(yaml, encoding='utf-8')
    # ส่งรหัสผ่าน stdin ไม่ใส่ใน command line หรือ log
    result = subprocess.run(['openssl', 'passwd', '-6', '-stdin'], input=code + '\n',
                            text=True, capture_output=True, check=True)
    digest = result.stdout.strip()
    if not digest.startswith('$6$') or '\n' in digest:
        raise ValueError('สร้างรหัสป้องกัน ComfyUI ไม่สำเร็จ')
    credentials = run / 'comfy.htpasswd'
    credentials.write_text('image-studio:' + digest + '\n', encoding='utf-8')
    import pwd
    gid = pwd.getpwnam('www-data').pw_gid
    os.chown(run, 0, gid)
    os.chown(credentials, 0, gid)
    credentials.chmod(0o640)
    (run / 'nginx.conf').write_text(proxy_config(ports[1], ports[2], credentials), encoding='utf-8')
    # Manager ไม่อัปเดต/ติดตั้ง dependency ระหว่างเปิด Pod ปกติ
    manager = data / 'comfy-user/__manager'
    manager.mkdir(parents=True, exist_ok=True)
    (manager / 'config.ini').write_text('[default]\nnetwork_mode = offline\nsecurity_level = strong\nupdate_policy = never\nuse_uv = false\n', encoding='utf-8')
    print('เตรียม Network Volume และพอร์ตแอปแล้ว; ไม่มีการดาวน์โหลดโมเดล')


def preflight():
    """ตรวจ assets ที่ node ใช้ตอน import ด้วยขนาดเท่านั้น; SHA ตรวจตอน install/เลือกโมเดล."""
    from install_models import InstallError, destination, effective_entry
    from model_catalog import select_models
    models = Path(os.environ.get('MODELS_ROOT', '/workspace/models'))
    failures = []
    for entry in select_models(['character', 'pose', 'segmentation']):
        try:
            effective = effective_entry(models, entry)
            path = destination(models, entry['path'])
            if not path.is_file() or path.stat().st_size != effective['bytes']:
                failures.append(entry['id'])
        except (InstallError, ValueError, OSError):
            failures.append(entry['id'])
    if failures:
        raise ValueError('โมเดลสำหรับ custom nodes ยังไม่ครบ: ' + ', '.join(failures[:8])
                         + ' — ตั้ง BOOTSTRAP_MODELS=1 ครั้งแรก หรือรัน install_models.py ก่อน')


def wait_comfy():
    internal = port('COMFY_INTERNAL_PORT', 8189)
    limit = int(os.environ.get('COMFY_STARTUP_TIMEOUT_SECONDS', '600'))
    if not 30 <= limit <= 1800:
        raise ValueError('COMFY_STARTUP_TIMEOUT_SECONDS ต้องเป็น 30–1800')
    deadline = time.monotonic() + limit
    required = {'CheckpointLoaderSimple', 'KSampler', 'CLIPTextEncode', 'EmptyLatentImage',
                'VAEDecode', 'SaveImage', 'InstantIDModelLoader', 'InstantIDFaceAnalysis',
                'FaceKeypointsPreprocessor', 'ApplyInstantID', 'ApplyInstantIDAdvanced',
                'ControlNetLoader', 'IPAdapterUnifiedLoader', 'IPAdapter', 'ReActorFaceSwap',
                'SAMModelLoader (segment anything)', 'GroundingDinoModelLoader (segment anything)',
                'GroundingDinoSAMSegment (segment anything)', 'OpenposePreprocessor'}
    missing = None
    while time.monotonic() < deadline:
        try:
            with urlopen(f'http://127.0.0.1:{internal}/object_info', timeout=3) as response:
                nodes = json.load(response)
            missing = sorted(required.difference(nodes))
            if missing:
                raise ValueError('custom nodes ไม่พร้อม: ' + ', '.join(missing))
            print('ComfyUI และโหนดพร้อมแล้ว กำลังเปิดหน้าแอป')
            return
        except (OSError, ValueError):
            time.sleep(2)
    raise ValueError('ComfyUI เริ่มไม่สำเร็จภายในเวลาที่กำหนด'
                     + ('; โหนดที่ขาด: ' + ', '.join(missing) if missing else '')
                     + ' — อ่าน log ของ Pod')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('prepare', 'preflight', 'wait'))
    args = parser.parse_args()
    try:
        {'prepare': prepare, 'preflight': preflight, 'wait': wait_comfy}[args.action]()
    except (ValueError, OSError, RuntimeError, subprocess.SubprocessError) as error:
        print('เปิดระบบไม่สำเร็จ: ' + (str(error) if isinstance(error, ValueError) else type(error).__name__), file=sys.stderr)
        raise SystemExit(1)
