@echo off
setlocal
set "PYTHONUTF8=1"
chcp 65001 >nul
cd /d "%~dp0"
py -3 -c "import sys;sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto use_py
python -c "import sys;sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto use_python
echo ไม่พบ Python 3.10 ขึ้นไป
echo ติดตั้งจาก https://www.python.org/downloads/windows/ และเลือก Add Python to PATH
pause
exit /b 2

:use_py
py -3 -c "import requests" >nul 2>&1
if errorlevel 1 (
  echo ยังไม่มี requests ให้รัน: py -3 -m pip install requests
  pause
  exit /b 2
)
py -3 "%~dp0launcher.py" %*
set "launcher_exit=%errorlevel%"
if not "%launcher_exit%"=="0" pause
exit /b %launcher_exit%

:use_python
python -c "import requests" >nul 2>&1
if errorlevel 1 (
  echo ยังไม่มี requests ให้รัน: python -m pip install requests
  pause
  exit /b 2
)
python "%~dp0launcher.py" %*
set "launcher_exit=%errorlevel%"
if not "%launcher_exit%"=="0" pause
exit /b %launcher_exit%
