"""Text-to-image and local Character Reference graphs; no provider lifecycle API."""
import json
import math
import re
import secrets
from pathlib import Path, PurePosixPath

VERSION = 'image-studio-1'
COMFY_COMMIT = 'f1072eb0350638a3390ddb6afbcaa8c6b237c6fd'
RATIOS = {'portrait': (832,1216), 'square': (1024,1024), 'landscape': (1216,832)}
LOCAL_RATIOS = {'portrait': (640,896), 'square': (768,768), 'landscape': (896,640)}
# เก็บขนาดเดิมเป็นโหมดเร็ว และเพิ่มขนาดใกล้ native สำหรับ PC
LOCAL_FAST_RATIOS = dict(LOCAL_RATIOS)
LOCAL_RATIOS = {'portrait': (768,1152), 'square': (1024,1024), 'landscape': (1152,768)}
NEGATIVE = 'low quality, blurry, distorted anatomy, extra fingers, extra limbs, fused fingers, mutated hands, plastic skin, oversmooth skin, cgi, 3d render, doll, waxy, airbrushed, bad proportions, watermark'
POSITIVE_PREFIX = 'photorealistic, RAW photo, natural skin texture, film grain, sharp focus, '
LOCAL_MODELS = ('sdxl','juggernaut_x','realvisxl')
POD_MODELS = ('qwen','flux1_dev')
FEATURES = ['realism-presets','realvisxl','flux1_dev','character-reference','character-dataset-guidance','character-lora']
STYLE_SUFFIX = 'photorealistic, natural skin texture, soft daylight, amateur photo'
CHARACTER_SIZE = (832, 1216)
CHARACTER_OOM_SIZE = (768, 1152)
# เพิ่มหลังฝึกและตรวจไฟล์จริงเท่านั้น ไม่เปิดรับ path/ไฟล์ LoRA จากคำขอเว็บ
CHARACTER_LORAS = {}

def _lora_entry(lora_id):
    if not isinstance(lora_id,str) or lora_id not in CHARACTER_LORAS:
        raise ValueError('ไม่พบตัวละคร LoRA ที่ฝึกและตรวจสอบแล้ว')
    entry=CHARACTER_LORAS[lora_id]
    if not isinstance(entry,dict) or entry.get('id')!=lora_id:
        raise ValueError('รายการตัวละคร LoRA ไม่ถูกต้อง')
    relative=entry.get('path',''); digest=entry.get('checksum')
    parts=PurePosixPath(relative).parts if isinstance(relative,str) else ()
    if (len(parts)<2 or parts[0]!='loras' or relative!='/'.join(parts)
            or any(part in ('.','..') or not re.fullmatch(r'[A-Za-z0-9_.-]+',part) for part in parts)
            or not relative.endswith('.safetensors')):
        raise ValueError('ไฟล์ตัวละคร LoRA ต้องอยู่ใน models/loras และเป็น safetensors')
    if (type(entry.get('bytes')) is not int or entry['bytes']<=0
            or entry.get('checksum_algorithm')!='sha256'
            or not isinstance(digest,str) or not re.fullmatch(r'[a-f0-9]{64}',digest)
            or entry.get('url') is not None):
        raise ValueError('ตัวละคร LoRA ต้องมีขนาดและ SHA256 ของไฟล์ที่ตรวจแล้ว')
    if entry.get('base_model') not in LOCAL_MODELS or entry.get('strength_clip')!=0:
        raise ValueError('ตัวละคร LoRA รุ่นนี้ต้องใช้โมเดล PC และฝึกเฉพาะ UNet')
    if (not isinstance(entry.get('trigger'),str) or not 1<=len(entry['trigger'].strip())<=200
            or not isinstance(entry.get('label'),str) or not 1<=len(entry['label'].strip())<=100):
        raise ValueError('ชื่อตัวละครหรือคำเรียก LoRA ไม่ถูกต้อง')
    return dict(entry)

def available_characters():
    """คืนเฉพาะชื่อที่เลือกได้ ไม่เผย path/hash ของไฟล์บน PC"""
    return [dict(id=item['id'],label=item['label'],base_model=item['base_model'],
                 trigger=item['trigger'],default_strength=0.8)
            for item in (_lora_entry(key) for key in CHARACTER_LORAS)]

def _lora_options(body,target,model,is_character=False):
    lora_id=body.get('lora_id','')
    if lora_id is None:lora_id=''
    if not isinstance(lora_id,str):raise ValueError('เลือกตัวละคร LoRA จากรายการ')
    strength=body.get('lora_strength',0.8)
    if type(strength) not in (int,float) or not 0<=strength<=1.2 or not math.isfinite(strength):
        raise ValueError('น้ำหนัก LoRA ต้องเป็นตัวเลข 0–1.2 ที่มีค่าจำกัด')
    if not lora_id:return None
    if target!='local':raise ValueError('ตัวละคร LoRA ใช้ได้เฉพาะ PC ในรุ่นนี้')
    if is_character:raise ValueError('เลือก LoRA หรือรูปอ้างอิงอย่างใดอย่างหนึ่งก่อนสร้างภาพ')
    entry=_lora_entry(lora_id)
    if model!=entry['base_model']:raise ValueError('ตัวละคร LoRA ต้องใช้โมเดล '+entry['base_model'])
    return dict(lora_id=lora_id,lora_sha256=entry['checksum'],lora_strength=float(strength),
                lora_trigger=entry['trigger'].strip(),lora_label=entry['label'].strip())

def lora_artifact(plan):
    """ใช้ registry เป็นแหล่ง path และป้องกันงานเก่าโหลดน้ำหนักคนละรุ่น"""
    options=_lora_options(plan,plan.get('target'),plan.get('model'),plan.get('mode')=='character')
    if options is None:return None
    if any(plan.get(key)!=options[key] for key in ('lora_sha256','lora_trigger','lora_label')):
        raise ValueError('ตัวละคร LoRA ถูกเปลี่ยนรุ่น กรุณาสร้างงานใหม่จากรายการปัจจุบัน')
    return _lora_entry(options['lora_id'])

def character_prompt(description, scene):
    # เก็บลักษณะตัวละครไว้ก่อนฉากเสมอ และตัดช่องว่าง/comma ที่ซ้ำ
    return ', '.join(part.strip() for text in (description, scene, STYLE_SUFFIX)
                     for part in re.sub(r'\s+', ' ', text).split(',') if part.strip())

def _character_options(body, target):
    if target != 'local':
        raise ValueError('Character Reference ใช้ได้เฉพาะ PC ในรุ่นนี้')
    description=body.get('character_description','')
    if not isinstance(description,str) or not 3<=len(description.strip())<=2000:
        raise ValueError('ตรวจหรือกรอกลักษณะตัวละคร 3–2,000 ตัวอักษรก่อนสร้างภาพ')
    name=body.get('reference_name',''); digest=body.get('reference_sha256','')
    if not isinstance(digest,str) or not re.fullmatch(r'[a-f0-9]{64}',digest) or name!='character_'+digest+'.png':
        raise ValueError('อัปโหลดรูปอ้างอิงให้สมบูรณ์ก่อนสร้างภาพ')
    flags={}
    # เริ่มด้วย InstantID อย่างเดียวสำหรับ PC 6GB; ค่างานเดิมที่ระบุไว้ยังใช้เหมือนเดิม
    for key,default in (('use_instantid',True),('use_ipadapter',False),('use_reactor',False)):
        value=body.get(key,default)
        if type(value) is not bool: raise ValueError(key+' ต้องเป็น true หรือ false')
        flags[key]=value
    options=dict(mode='character',reference_name=name,reference_sha256=digest,
                 character_description=description.strip(),**flags)
    # แยกแรงคุมตำแหน่งจากความเหมือนใบหน้าสำหรับชุดภาพหลายท่า; งานเดิมไม่เพิ่มค่านี้
    if 'instantid_controlnet_strength' in body:
        strength=body['instantid_controlnet_strength']
        if type(strength) not in (int,float) or not 0<=strength<=1 or not math.isfinite(strength):
            raise ValueError('instantid_controlnet_strength ต้องเป็นตัวเลข 0–1 ที่มีค่าจำกัด')
        if not flags['use_instantid']:
            raise ValueError('instantid_controlnet_strength ต้องเปิด InstantID ก่อน')
        options['instantid_controlnet_strength']=strength
    return options

def atomic(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.'+secrets.token_hex(8)+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def validate(body, pod=False):
    target='runpod' if pod else body.get('target','local')
    if target not in ('local','runpod'): raise ValueError('เลือก PC หรือ RunPod')
    is_character=bool(body.get('reference_image') or body.get('reference_name') or body.get('mode')=='character')
    if 'instantid_controlnet_strength' in body and not is_character:
        raise ValueError('instantid_controlnet_strength ใช้เฉพาะ Character Reference')
    character=_character_options(body,target) if is_character else None
    prompt=body.get('prompt','')
    if not isinstance(prompt,str) or not 3<=len(prompt.strip())<=3000: raise ValueError('ใส่คำบรรยายภาพ 3–3,000 ตัวอักษร')
    negative=body.get('negative',NEGATIVE)
    if not isinstance(negative,str) or len(negative)>1000: raise ValueError('ข้อความสิ่งที่ไม่ต้องการยาวเกินไป')
    ratio=body.get('ratio','portrait')
    if ratio not in RATIOS: raise ValueError('สัดส่วนภาพไม่ถูกต้อง')
    seed=body.get('seed')
    if seed in (None,''): seed=secrets.randbelow(2**53)
    elif isinstance(seed,bool) or not isinstance(seed,int) or not 0<=seed<2**53: raise ValueError('Seed ต้องเป็นจำนวนเต็ม 0–9007199254740991')
    quality=body.get('quality','standard')
    if quality not in ('draft','standard','high'): raise ValueError('ระดับคุณภาพไม่ถูกต้อง')
    model=body.get('model','qwen' if target=='runpod' else 'juggernaut_x')
    if model not in (LOCAL_MODELS if target=='local' else POD_MODELS): raise ValueError('โมเดลไม่ตรงกับโหมด PC / RunPod ที่เลือก')
    lora=_lora_options(body,target,model,is_character)
    resolution=body.get('resolution','native')
    if resolution not in ('native','fast'): raise ValueError('เลือกขนาดภาพแบบมาตรฐานหรือเร็ว')
    # FLUX ใช้ guidance ใน conditioning แยกจาก CFG ของ KSampler
    steps=({'draft':24,'standard':40,'high':48} if target=='local' else
           {'draft':20,'standard':24,'high':28} if model=='flux1_dev' else {'draft':20,'standard':32,'high':40})[quality]
    w,h=(LOCAL_FAST_RATIOS if target=='local' and resolution=='fast' else LOCAL_RATIOS if target=='local' else RATIOS)[ratio]
    result=dict(prompt=prompt.strip(),negative=negative.strip(),target=target,ratio=ratio,seed=seed,
                quality=quality,steps=steps,width=w,height=h,model=model,resolution=resolution,
                positive_prompt=POSITIVE_PREFIX+prompt.strip(),
                cfg=1.0 if model=='flux1_dev' else 5.0 if model in ('juggernaut_x','realvisxl') else 6.0 if model=='sdxl' else 4.0,
                sampler='dpmpp_2m' if target=='local' else 'euler',
                scheduler='karras' if target=='local' else 'simple',
                **({'guidance':3.5} if model=='flux1_dev' else {}))
    if character:
        # ค่าเฉพาะตัวละครไม่เปลี่ยน text2img และไม่เก็บภาพ base64 ในแผนงาน
        result.update(character)
        result.update(width=CHARACTER_SIZE[0],height=CHARACTER_SIZE[1],ratio='portrait',
                      steps=35,cfg=5.0,sampler='dpmpp_2m',scheduler='karras',resolution='native',
                      positive_prompt=character_prompt(character['character_description'],prompt.strip()))
    if lora:
        # คำเรียกตัวละครมาก่อนฉาก แต่เก็บ prompt ดิบไว้สำหรับนำงานเดิมกลับมาใช้
        result.update(lora)
        result['positive_prompt']=POSITIVE_PREFIX+lora['lora_trigger']+', '+prompt.strip()
    return result

def graph(plan, job_id):
    lora=lora_artifact(plan) if plan.get('lora_id') else None
    if plan.get('mode')=='character': return character_graph(plan,job_id)
    def node(cls, **inputs): return {'class_type':cls,'inputs':inputs}
    if plan['model'] in LOCAL_MODELS:
        checkpoint={'sdxl':SDXL,'juggernaut_x':JUGGERNAUT,'realvisxl':REALVIS}[plan['model']]
        g={'1':node('CheckpointLoaderSimple',ckpt_name=Path(checkpoint['path']).name)}
        model=['1',0]; clip=['1',1]; vae=['1',2]; empty='EmptyLatentImage'
        if lora:
            # UNet-only LoRA ไม่เปลี่ยน VAE และไม่โหลด text encoder เพิ่มบน PC 6GB
            g['12']=node('LoraLoader',model=model,clip=clip,
                         lora_name='/'.join(PurePosixPath(lora['path']).parts[1:]),
                         strength_model=plan['lora_strength'],strength_clip=0.0)
            model=['12',0];clip=['12',1]
    elif plan['model']=='qwen':
        g={'1':node('UNETLoader',unet_name='qwen_image_fp8_e4m3fn.safetensors',weight_dtype='default'),
           '2':node('CLIPLoader',clip_name='qwen_2.5_vl_7b_fp8_scaled.safetensors',type='qwen_image',device='default'),
           '3':node('VAELoader',vae_name='qwen_image_vae.safetensors'),
           '4':node('ModelSamplingAuraFlow',model=['1',0],shift=3.1)}
        model=['4',0];clip=['2',0];vae=['3',0];empty='EmptySD3LatentImage'
    elif plan['model']=='flux1_dev':
        # เส้นทางใหม่ใช้ diffusion + T5/CLIP-L + AE ไม่ใช้ checkpoint SDXL
        g={'1':node('UNETLoader',unet_name='flux1-dev.safetensors',weight_dtype='default'),
           '2':node('DualCLIPLoader',clip_name1='t5xxl_fp16.safetensors',clip_name2='clip_l.safetensors',type='flux',device='default'),
           '3':node('VAELoader',vae_name='ae.safetensors'),
           '4':node('ModelSamplingFlux',model=['1',0],max_shift=1.15,base_shift=0.5,width=plan['width'],height=plan['height']),
           '11':node('FluxGuidance',conditioning=['5',0],guidance=plan.get('guidance',3.5))}
        model=['4',0];clip=['2',0];vae=['3',0];empty='EmptySD3LatentImage'
    else: raise ValueError('ไม่รู้จักโมเดลสร้างภาพ')
    # งานเก่าที่ไม่มี positive_prompt ยังคงใช้ข้อความเดิมทุกตัวอักษร
    positive=POSITIVE_PREFIX+lora['trigger'].strip()+', '+plan['prompt'] if lora else plan.get('positive_prompt',plan['prompt'])
    g.update({'5':node('CLIPTextEncode',text=positive,clip=clip),
      '6':node('CLIPTextEncode',text=plan['negative'],clip=clip),
      '7':node(empty,width=plan['width'],height=plan['height'],batch_size=1),
      '8':node('KSampler',model=model,positive=['11',0] if plan['model']=='flux1_dev' else ['5',0],negative=['6',0],latent_image=['7',0],
          seed=plan['seed'],steps=plan['steps'],cfg=plan.get('cfg',1.0 if plan['model']=='flux1_dev' else 6.0 if plan['model']=='sdxl' else 5.0 if plan['model'] in LOCAL_MODELS else 4.0),
          sampler_name=plan.get('sampler','euler' if plan['model'] in POD_MODELS else 'dpmpp_2m'),
          scheduler=plan.get('scheduler','simple' if plan['model'] in POD_MODELS else 'karras'),denoise=1.0),
      '9':node('VAEDecode',samples=['8',0],vae=vae),
      '10':node('SaveImage',images=['9',0],filename_prefix='image-studio/'+job_id)})
    return g

def character_graph(plan, job_id):
    """สร้างกราฟใหม่แยกจากกราฟ text2img เดิม"""
    options=_character_options(plan,plan.get('target'))
    if plan.get('model') not in LOCAL_MODELS: raise ValueError('Character Reference ต้องใช้โมเดล SDXL บน PC')
    if (plan['width'],plan['height']) not in (CHARACTER_SIZE,CHARACTER_OOM_SIZE):
        raise ValueError('ขนาดภาพ Character Reference ไม่ถูกต้อง')
    def node(cls,**inputs): return {'class_type':cls,'inputs':inputs}
    checkpoint={'sdxl':SDXL,'juggernaut_x':JUGGERNAUT,'realvisxl':REALVIS}[plan['model']]
    g={'1':node('CheckpointLoaderSimple',ckpt_name=Path(checkpoint['path']).name),
       '2':node('LoadImage',image=options['reference_name']),
       '5':node('CLIPTextEncode',text=character_prompt(options['character_description'],plan['prompt']),clip=['1',1]),
       '6':node('CLIPTextEncode',text=plan['negative'],clip=['1',1]),
       '7':node('EmptyLatentImage',width=plan['width'],height=plan['height'],batch_size=1)}
    model=['1',0]; positive=['5',0]; negative=['6',0]
    if options['use_instantid']:
        g.update({'20':node('InstantIDModelLoader',instantid_file='ip-adapter.bin'),
                  '21':node('InstantIDFaceAnalysis',provider='CPU'),
                  '22':node('FaceKeypointsPreprocessor',faceanalysis=['21',0],image=['2',0]),
                  '23':node('ControlNetLoader',control_net_name=str(Path('instantid')/'diffusion_pytorch_model.safetensors'))})
        instantid_inputs=dict(instantid=['20',0],insightface=['21',0],control_net=['23',0],
                             image=['2',0],image_kps=['22',0],model=model,positive=positive,negative=negative,
                             start_at=0.0,end_at=0.8)
        if 'instantid_controlnet_strength' in options:
            # Advanced ลดแรงล็อกท่าต้นแบบได้โดยคงน้ำหนักรูปลักษณ์เดิม
            g['24']=node('ApplyInstantIDAdvanced',**instantid_inputs,ip_weight=0.8,
                         cn_strength=options['instantid_controlnet_strength'],noise=0.35,combine_embeds='average')
        else:
            g['24']=node('ApplyInstantID',**instantid_inputs,weight=0.8)
        model=['24',0]; positive=['24',1]; negative=['24',2]
    if options['use_ipadapter']:
        # PLUS FACE ต้องใช้ไฟล์ plus-face; PLUS ธรรมดาใช้แทนกันไม่ได้
        g.update({'30':node('IPAdapterUnifiedLoader',model=model,preset='PLUS FACE (portraits)'),
                  '31':node('IPAdapter',model=['30',0],ipadapter=['30',1],image=['2',0],
                            weight=0.6,start_at=0.0,end_at=0.7,weight_type='standard')})
        model=['31',0]
    g.update({'8':node('KSampler',model=model,positive=positive,negative=negative,latent_image=['7',0],
                      seed=plan['seed'],steps=35,cfg=5.0,sampler_name='dpmpp_2m',scheduler='karras',denoise=1.0),
              '9':node('VAEDecode',samples=['8',0],vae=['1',2])})
    images=['9',0]
    if options['use_reactor']:
        g['40']=node('ReActorFaceSwap',enabled=True,input_image=images,source_image=['2',0],
                     swap_model='inswapper_128.onnx',facedetection='retinaface_resnet50',
                     face_restore_model='codeformer-v0.1.0.pth',face_restore_visibility=1.0,
                     codeformer_weight=0.7,detect_gender_input='no',detect_gender_source='no',
                     input_faces_index='0',source_faces_index='0',console_log_level=0)
        images=['40',0]
    g['10']=node('SaveImage',images=images,filename_prefix='image-studio/'+job_id)
    return g

def character_artifacts(plan):
    """คืนเฉพาะโมเดลเสริมที่เปิดใช้ และไม่ยอมให้โหลดบน RunPod"""
    options=_character_options(plan,plan.get('target'))
    if plan.get('model') not in LOCAL_MODELS: raise ValueError('Character Reference ต้องใช้โมเดล SDXL บน PC')
    entries=[]
    if options['use_instantid']: entries.extend(INSTANTID+ANTELOPE)
    if options['use_ipadapter']: entries.extend([IPADAPTER_FACE,CLIP_VISION])
    if options['use_reactor']: entries.extend(REACTOR)
    return [dict(item) for item in entries]

def model_artifacts(model, target):
    """แยกไฟล์ของ PC และ Pod ก่อนดาวน์โหลดทุกครั้ง"""
    allowed=LOCAL_MODELS if target=='local' else POD_MODELS if target=='runpod' else ()
    if model not in allowed: raise ValueError('ห้ามโหลดโมเดลข้ามโหมด PC / RunPod')
    items={'sdxl':[SDXL],'juggernaut_x':[JUGGERNAUT],'realvisxl':[REALVIS],'qwen':QWEN,'flux1_dev':FLUX}[model]
    result=[]
    for entry in items:
        item=dict(entry)
        # checksum ว่างให้ตัวติดตั้งบันทึกครั้งแรก แต่ขนาดต้องทราบก่อนเช็กพื้นที่
        digest=item.get('checksum')
        if type(item['bytes']) is not int or item['bytes']<=0 or item['checksum_algorithm']!='sha256':
            raise ValueError('รัน tools/model_info.py เพื่อเติมขนาดจริงก่อนติดตั้ง '+item['id'])
        if digest not in (None,'') and (not isinstance(digest,str) or not re.fullmatch(r'[a-f0-9]{64}',digest)):
            raise ValueError('SHA256 ของโมเดลไม่ถูกต้อง: '+item['id'])
        result.append(item)
    return result

SDXL={'id':'sdxl','path':'checkpoints/sd_xl_base_1.0.safetensors','bytes':6938078334,
  'checksum_algorithm':'sha256','checksum':'31e35c80fc4829d14f90153f4c74cd59c90b779f6afe05a74cd6120b893f7e5b',
  'url':'https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/f298da3c058bd8f1f1c62f3ecfa775244a243897/sd_xl_base_1.0.safetensors'}
JUGGERNAUT={'id':'juggernaut_x','path':'checkpoints/Juggernaut-X-RunDiffusion-NSFW.safetensors','bytes':7105348672,
  'checksum_algorithm':'sha256','checksum':'d91d35736d8f2be038f760a9b0009a771ecf0a417e9b38c244a84ea4cb9c0c45',
  'url':'https://huggingface.co/RunDiffusion/Juggernaut-X-v10/resolve/35e4f3ccbe745c3e1221715d04a452aaa1ee5761/Juggernaut-X-RunDiffusion-NSFW.safetensors'}
# เติมค่าจริงจาก tools/model_info.py และ pin commit ให้ขนาด/hash ตรงไฟล์รุ่นเดียวกัน
REALVIS={'id':'realvisxl','path':'checkpoints/RealVisXL_V5.0_fp16.safetensors','bytes':6938065488,
  'checksum_algorithm':'sha256','checksum':'6a35a7855770ae9820a3c931d4964c3817b6d9e3c6f9c4dabb5b3a94e5643b80',
  'url':'https://huggingface.co/SG161222/RealVisXL_V5.0/resolve/ac93e0dda1f6d448cae19bbfab8c5e720a5e48bc/RealVisXL_V5.0_fp16.safetensors'}
# FLUX มี 4 ไฟล์จริง: diffusion, T5, CLIP-L และ VAE — ใช้เฉพาะ RunPod
# HF ซ่อน lfs.oid ของ gated repo เมื่อไม่มีสิทธิ์: คง SHA256 รุ่นที่ pin ไว้เดิม
# รัน tools/model_info.py เพื่อเติม/ตรวจซ้ำด้วย HF_TOKEN ที่ยอมรับเงื่อนไขแล้ว
FLUX=[{'id':'flux1_dev','path':'diffusion_models/flux1-dev.safetensors','bytes':23802932552,
  'checksum_algorithm':'sha256','checksum':'4610115bb0c89560703c892c59ac2742fa821e60ef5871b33493ba544683abd7',
  'url':'https://huggingface.co/black-forest-labs/FLUX.1-dev/resolve/3de623fc3c33e44ffbe2bad470d0f45bccf2eb21/flux1-dev.safetensors'},
 {'id':'flux_t5','path':'text_encoders/t5xxl_fp16.safetensors','bytes':9787841024,
  'checksum_algorithm':'sha256','checksum':'6e480b09fae049a72d2a8c5fbccb8d3e92febeb233bbe9dfe7256958a9167635',
  'url':'https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/6af2a98e3f615bdfa612fbd85da93d1ed5f69ef5/t5xxl_fp16.safetensors'},
 {'id':'flux_clip','path':'text_encoders/clip_l.safetensors','bytes':246144152,
  'checksum_algorithm':'sha256','checksum':'660c6f5b1abae9dc498ac2d21e1347d2abdb0cf6c0c0c8576cd796491d9a6cdd',
  'url':'https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/6af2a98e3f615bdfa612fbd85da93d1ed5f69ef5/clip_l.safetensors'},
 {'id':'flux_vae','path':'vae/ae.safetensors','bytes':335304388,
  'checksum_algorithm':'sha256','checksum':'afc8e28272cd15db3919bacdb6918ce9c1ed22e96cb12c4d5ed0fba823529e38',
  'url':'https://huggingface.co/black-forest-labs/FLUX.1-dev/resolve/3de623fc3c33e44ffbe2bad470d0f45bccf2eb21/ae.safetensors'}]
QWEN=[{'id':'qwen','path':'diffusion_models/qwen_image_fp8_e4m3fn.safetensors','bytes':20430635136,
  'checksum_algorithm':'sha256','checksum':'98763a127701eb6fb59096f7742cb3aa7d64ed510b9f4e882d8351f8176e3ce3',
  'url':'https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/a4875863818e93fdb65f366d1d7a201581d05eeb/split_files/diffusion_models/qwen_image_fp8_e4m3fn.safetensors'},
 {'id':'qwen_text','path':'text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors','bytes':9384670680,
  'checksum_algorithm':'sha256','checksum':'cb5636d852a0ea6a9075ab1bef496c0db7aef13c02350571e388aea959c5c0b4',
  'url':'https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/1405a2b738c29b890cf6d03fc038d8d3e92eeed7/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors'},
 {'id':'qwen_vae','path':'vae/qwen_image_vae.safetensors','bytes':253806246,
  'checksum_algorithm':'sha256','checksum':'a70580f0213e67967ee9c95f05bb400e8fb08307e017a924bf3441223e023d1f',
  'url':'https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/1f12b17be14c89b026c51a91d67c32f84bb047bc/split_files/vae/qwen_image_vae.safetensors'}]

# Character Reference เฉพาะ PC: ขนาด/hash จาก HF API และตรึงรุ่นทุกไฟล์
INSTANTID=[{'id':'instantid','path':'instantid/ip-adapter.bin','bytes':1691134141,
  'checksum_algorithm':'sha256','checksum':'02b3618e36d803784166660520098089a81388e61a93ef8002aa79a5b1c546e1',
  'url':'https://huggingface.co/InstantX/InstantID/resolve/57b32dfee076092ad2930c71fd6d439c2c3b1820/ip-adapter.bin'},
 {'id':'instantid_controlnet','path':'controlnet/instantid/diffusion_pytorch_model.safetensors','bytes':2502139136,
  'checksum_algorithm':'sha256','checksum':'c8127be9f174101ebdafee9964d856b49b634435cf6daa396d3f593cf0bbbb05',
  'url':'https://huggingface.co/InstantX/InstantID/resolve/57b32dfee076092ad2930c71fd6d439c2c3b1820/ControlNetModel/diffusion_pytorch_model.safetensors'}]

# ใช้ mirror ที่ README ผู้พัฒนา InstantID อ้างอิง แยกไฟล์เพื่อไม่ต้องแตก ZIP
ANTELOPE=[{'id':'antelope_1k3d68','path':'insightface/models/antelopev2/1k3d68.onnx','bytes':143607619,
  'checksum_algorithm':'sha256','checksum':'df5c06b8a0c12e422b2ed8947b8869faa4105387f199c477af038aa01f9a45cc',
  'url':'https://huggingface.co/MonsterMMORPG/tools/resolve/2cc250d767e22019bef3ae1aefaa1ad8a73ef64c/1k3d68.onnx'},
 {'id':'antelope_2d106det','path':'insightface/models/antelopev2/2d106det.onnx','bytes':5030888,
  'checksum_algorithm':'sha256','checksum':'f001b856447c413801ef5c42091ed0cd516fcd21f2d6b79635b1e733a7109dbf',
  'url':'https://huggingface.co/MonsterMMORPG/tools/resolve/2cc250d767e22019bef3ae1aefaa1ad8a73ef64c/2d106det.onnx'},
 {'id':'antelope_genderage','path':'insightface/models/antelopev2/genderage.onnx','bytes':1322532,
  'checksum_algorithm':'sha256','checksum':'4fde69b1c810857b88c64a335084f1c3fe8f01246c9a191b48c7bb756d6652fb',
  'url':'https://huggingface.co/MonsterMMORPG/tools/resolve/2cc250d767e22019bef3ae1aefaa1ad8a73ef64c/genderage.onnx'},
 {'id':'antelope_glintr100','path':'insightface/models/antelopev2/glintr100.onnx','bytes':260665334,
  'checksum_algorithm':'sha256','checksum':'4ab1d6435d639628a6f3e5008dd4f929edf4c4124b1a7169e1048f9fef534cdf',
  'url':'https://huggingface.co/MonsterMMORPG/tools/resolve/2cc250d767e22019bef3ae1aefaa1ad8a73ef64c/glintr100.onnx'},
 {'id':'antelope_scrfd','path':'insightface/models/antelopev2/scrfd_10g_bnkps.onnx','bytes':16923827,
  'checksum_algorithm':'sha256','checksum':'5838f7fe053675b1c7a08b633df49e7af5495cee0493c7dcf6697200b85b5b91',
  'url':'https://huggingface.co/MonsterMMORPG/tools/resolve/2cc250d767e22019bef3ae1aefaa1ad8a73ef64c/scrfd_10g_bnkps.onnx'}]

# เก็บ PLUS ตามคำขอไว้ใน registry แต่ดาวน์โหลด PLUS FACE ที่ preset ใช้จริงเท่านั้น
IPADAPTER_PLUS={'id':'ipadapter_plus_sdxl','path':'ipadapter/ip-adapter-plus_sdxl_vit-h.safetensors','bytes':847517512,
  'checksum_algorithm':'sha256','checksum':'3f5062b8400c94b7159665b21ba5c62acdcd7682262743d7f2aefedef00e6581',
  'url':'https://huggingface.co/h94/IP-Adapter/resolve/018e402774aeeddd60609b4ecdb7e298259dc729/sdxl_models/ip-adapter-plus_sdxl_vit-h.safetensors'}
IPADAPTER_FACE={'id':'ipadapter_plus_face_sdxl','path':'ipadapter/ip-adapter-plus-face_sdxl_vit-h.safetensors','bytes':847517512,
  'checksum_algorithm':'sha256','checksum':'677ad8860204f7d0bfba12d29e6c31ded9beefdf3e4bbd102518357d31a292c1',
  'url':'https://huggingface.co/h94/IP-Adapter/resolve/018e402774aeeddd60609b4ecdb7e298259dc729/sdxl_models/ip-adapter-plus-face_sdxl_vit-h.safetensors'}
CLIP_VISION={'id':'clip_vision_vit_h','path':'clip_vision/CLIP-ViT-H-14-laion2B-s32B-b79K.safetensors','bytes':2528373448,
  'checksum_algorithm':'sha256','checksum':'6ca9667da1ca9e0b0f75e46bb030f7e011f44f86cbfb8d5a36590fcd7507b030',
  'url':'https://huggingface.co/h94/IP-Adapter/resolve/018e402774aeeddd60609b4ecdb7e298259dc729/models/image_encoder/model.safetensors'}

# ReActor ใช้ path ของตัวเองจริง (insightface/facerestore_models) และไม่โหลดเมื่อปิด
REACTOR=[{'id':'reactor_inswapper','path':'insightface/inswapper_128.onnx','bytes':554253681,
  'checksum_algorithm':'sha256','checksum':'e4a3f08c753cb72d04e10aa0f7dbe3deebbf39567d4ead6dce08e98aa49e16af',
  'url':'https://huggingface.co/datasets/Gourieff/ReActor/resolve/41ea28532966db7d4cb8658475d080f9d6f873e8/models/inswapper_128.onnx'},
 {'id':'reactor_codeformer','path':'facerestore_models/codeformer-v0.1.0.pth','bytes':376637898,
  'checksum_algorithm':'sha256','checksum':'1009e537e0c2a07d4cabce6355f53cb66767cd4b4297ec7a4a64ca4b8a5684b7',
  'url':'https://huggingface.co/datasets/Gourieff/ReActor/resolve/41ea28532966db7d4cb8658475d080f9d6f873e8/models/facerestore_models/codeformer-v0.1.0.pth'},
 # เก็บ archive นอก path ที่ ReActor ลบอัตโนมัติ เพื่อไม่ต้องโหลดซ้ำทุกภาพ
 {'id':'reactor_buffalo_l','path':'reactor/archives/buffalo_l.zip','bytes':288621354,
  'checksum_algorithm':'sha256','checksum':'80ffe37d8a5940d59a7384c201a2a38d4741f2f3c51eef46ebb28218a7b0ca2f',
  'url':'https://huggingface.co/datasets/Gourieff/ReActor/resolve/41ea28532966db7d4cb8658475d080f9d6f873e8/models/buffalo_l.zip'},
 # GitHub release ไม่ให้ SHA256: บันทึก checksum ครั้งแรกด้วย sidecar ตามระบบเดิม
 {'id':'reactor_detection','path':'facedetection/detection_Resnet50_Final.pth','bytes':109497761,
  'checksum_algorithm':'sha256','checksum':None,
  'url':'https://github.com/xinntao/facexlib/releases/download/v0.1.0/detection_Resnet50_Final.pth'},
 {'id':'reactor_parsing','path':'facedetection/parsing_parsenet.pth','bytes':85331193,
  'checksum_algorithm':'sha256','checksum':None,
  'url':'https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/parsing_parsenet.pth'},
 # เตรียมไฟล์ที่ ReActor เรียกใช้อัตโนมัติไว้ล่วงหน้า โดยคงพฤติกรรมส่วนเสริมเดิม
 {'id':'reactor_detector_config','path':'nsfw_detector/vit-base-nsfw-detector/config.json','bytes':715,
  'checksum_algorithm':'sha256','checksum':'604d1da5e3cc8b6dc3f2768a911ed61a44a331cfcee9ecde2ce2cba9a1e7972b',
  'url':'https://huggingface.co/AdamCodd/vit-base-nsfw-detector/resolve/8587de998f441aac03fdd57a85d2e4cb808c7d64/config.json'},
 {'id':'reactor_detector','path':'nsfw_detector/vit-base-nsfw-detector/model.safetensors','bytes':344391328,
  'checksum_algorithm':'sha256','checksum':'266efb8bf67c1e865a577222fbbd6ddb149b9e00ba0d2b50466a034837f026a4',
  'url':'https://huggingface.co/AdamCodd/vit-base-nsfw-detector/resolve/8587de998f441aac03fdd57a85d2e4cb808c7d64/model.safetensors'},
 {'id':'reactor_detector_preprocessor','path':'nsfw_detector/vit-base-nsfw-detector/preprocessor_config.json','bytes':232,
  'checksum_algorithm':'sha256','checksum':'f2ca775909d2237bd31440280cefcaceb3ac66753c19f7a344e385e68982a9b2',
  'url':'https://huggingface.co/AdamCodd/vit-base-nsfw-detector/resolve/8587de998f441aac03fdd57a85d2e4cb808c7d64/preprocessor_config.json'}]
