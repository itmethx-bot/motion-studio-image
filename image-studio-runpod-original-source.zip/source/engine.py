"""External ComfyUI worker. No model downloads, Pod control, or generation retries."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import struct
import threading
import time
import zlib

import requests
import core

ACTIVE = {"queued", "running", "downloading", "unknown"}
JOB_ID = re.compile(r"[a-f0-9]{32}\Z")
MAX_IMAGE_BYTES = 30 * 1024**2


class EngineError(ValueError):
    pass


class UncertainSubmission(EngineError):
    pass


class RejectedSubmission(EngineError):
    pass


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + secrets.token_hex(8) + ".tmp")
    try:
        with temporary.open("x", encoding="utf-8") as output:
            json.dump(value, output, ensure_ascii=False, indent=2)
            output.flush()
            os.fsync(output.fileno())
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def png_dimensions(raw):
    # ตรวจ chunk/CRC และ zlib แบบจำกัดขนาด ไม่ยอมรับไฟล์ที่มีแค่ PNG header
    if (len(raw) < 33 or len(raw) > MAX_IMAGE_BYTES or raw[:8] != b"\x89PNG\r\n\x1a\n"
            or raw[8:12] != b"\x00\x00\x00\r" or raw[12:16] != b"IHDR"):
        raise EngineError("ComfyUI ไม่ได้คืนไฟล์ PNG ที่สมบูรณ์")
    width, height, depth, color, compression, filtering, interlace = struct.unpack(">IIBBBBB", raw[16:29])
    if not 1 <= width <= 4096 or not 1 <= height <= 4096 or depth not in (8, 16) or color not in (0, 2, 4, 6) or (compression, filtering, interlace) != (0, 0, 0):
        raise EngineError("รูปแบบ PNG ผลลัพธ์ไม่รองรับหรือขนาดไม่ปลอดภัย")
    position = 8
    idat = []
    ended = False
    while position < len(raw):
        if position + 12 > len(raw):
            raise EngineError("PNG ส่งมาไม่ครบ")
        length = struct.unpack(">I", raw[position:position + 4])[0]
        kind = raw[position + 4:position + 8]
        end = position + 12 + length
        if end > len(raw) or length > MAX_IMAGE_BYTES:
            raise EngineError("PNG มี chunk ที่ไม่สมบูรณ์")
        payload = raw[position + 8:position + 8 + length]
        expected = struct.unpack(">I", raw[position + 8 + length:end])[0]
        if zlib.crc32(kind + payload) & 0xffffffff != expected:
            raise EngineError("CRC ของ PNG ไม่ถูกต้อง")
        if kind == b"IHDR" and position != 8:
            raise EngineError("PNG มี IHDR ซ้ำ")
        if kind == b"IDAT":
            idat.append(payload)
        if kind == b"IEND":
            if length or end != len(raw):
                raise EngineError("ปลายไฟล์ PNG ไม่ถูกต้อง")
            ended = True
            break
        position = end
    if not ended or not idat:
        raise EngineError("PNG ไม่มีข้อมูลภาพหรือ IEND")
    channels = {0: 1, 2: 3, 4: 2, 6: 4}[color]
    stride = width * channels * (depth // 8) + 1
    maximum = stride * height
    try:
        decoder = zlib.decompressobj()
        decoded = decoder.decompress(b"".join(idat), maximum + 1)
        if len(decoded) != maximum or not decoder.eof or decoder.unconsumed_tail or decoder.unused_data:
            raise EngineError("ข้อมูลพิกเซล PNG ไม่ครบหรือเกินขนาด")
        if any(decoded[offset] > 4 for offset in range(0, maximum, stride)):
            raise EngineError("PNG ใช้ filter ที่ไม่ถูกต้อง")
    except zlib.error:
        raise EngineError("ข้อมูล PNG เสียหาย") from None
    return width, height


class Engine:
    def __init__(self, data_root, models_root, port=8189):
        self.data = Path(data_root).resolve()
        self.models = Path(models_root).resolve()
        self.port = int(port)
        if not 1024 <= self.port <= 65535:
            raise EngineError("COMFY_INTERNAL_PORT ต้องเป็นพอร์ต 1024–65535")
        self.base = "http://127.0.0.1:" + str(self.port)
        for name in ("jobs", "outputs"):
            (self.data / name).mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.jobs = {}
        self.workers = {}
        self.signatures = {}
        self.probe_lock = threading.Lock()
        self.ready_cache = {"ready": False, "message": "กำลังตรวจ ComfyUI", "vram_gib": 0}
        self.next_probe = 0.0
        self.closed = threading.Event()
        self.instance_id = secrets.token_hex(16)
        self.pod_id = os.environ.get("RUNPOD_POD_ID", "")
        if self.pod_id and not re.fullmatch(r"[A-Za-z0-9]{8,40}", self.pod_id):
            raise EngineError("RUNPOD_POD_ID มีรูปแบบไม่ถูกต้อง")
        # ห้าม restart แล้วส่ง prompt เดิมซ้ำ: งานที่ยังไม่จบต้องกู้ผลแบบอ่านอย่างเดียว
        for path in (self.data / "jobs").glob("*.json"):
            if not JOB_ID.fullmatch(path.stem) or path.is_symlink() or path.stat().st_size > 128 * 1024:
                continue
            try:
                job = json.loads(path.read_text(encoding="utf-8"))
                if job.get("id") != path.stem or not isinstance(job.get("plan"), dict):
                    continue
                if job.get("prompt_id") and (not isinstance(job["prompt_id"], str) or not re.fullmatch(r"[a-f0-9-]{32,36}", job["prompt_id"])):
                    raise EngineError("รหัสงาน GPU ที่บันทึกไว้ไม่ถูกต้อง")
                if job.get("status") in ACTIVE:
                    if self.pod_id and job.get("pod_id") and self.pod_id != job["pod_id"]:
                        job.update(status="failed", message="งานนี้มาจาก Pod คนละเครื่อง จึงกู้คิว GPU จากเครื่องนี้ไม่ได้; ตรวจเครื่องเดิมและไฟล์ที่บันทึกไว้")
                    else:
                        job.update(status="unknown", message="ระบบเริ่มใหม่ กรุณากู้ผลเดิมก่อนสร้างงานต่อ")
                    self.persist(job)
                self.jobs[job["id"]] = job
            except (OSError, ValueError, AttributeError):
                raise EngineError("อ่านข้อมูลคำขอเดิมไม่ได้ กรุณาตรวจไฟล์งานก่อนสร้างใหม่") from None

    def persist(self, job):
        atomic_json(self.data / "jobs" / (job["id"] + ".json"), job)

    def _json(self, method, path, body=None, limit=8 * 1024**2):
        with requests.Session() as session:
            session.trust_env = False
            with session.request(method, self.base + path, json=body, timeout=(3, 20),
                                 allow_redirects=False, stream=True) as response:
                data = bytearray()
                started = time.monotonic()
                for chunk in response.iter_content(128 * 1024):
                    data.extend(chunk)
                    if len(data) > limit or time.monotonic() - started > 40:
                        raise EngineError("ผลตอบกลับ ComfyUI ใหญ่เกินกำหนดหรือใช้เวลานานเกินไป")
                try:
                    result = json.loads(data)
                except (ValueError, UnicodeError):
                    if method == "POST" and path == "/prompt":
                        raise UncertainSubmission("ผลส่งงานยังไม่ชัดเจน ห้ามสร้างซ้ำ ให้กดกู้ผลเดิม") from None
                    raise EngineError("ComfyUI คืนข้อมูลไม่ถูกต้อง") from None
                if response.status_code != 200:
                    if method == "POST" and path == "/prompt" and response.status_code >= 500:
                        raise UncertainSubmission("ComfyUI ตอบผิดพลาดหลังส่งงาน ให้กู้ผลเดิมก่อน")
                    if method == "POST" and path == "/prompt":
                        raise RejectedSubmission("ComfyUI ปฏิเสธ workflow (HTTP " + str(response.status_code) + ") ตรวจชื่อโมเดลและโหนด")
                    raise EngineError("ComfyUI ตอบ HTTP " + str(response.status_code) + " กรุณาตรวจ log ของ Pod")
                if not isinstance(result, dict):
                    raise EngineError("โครงสร้างผลตอบกลับ ComfyUI ไม่ถูกต้อง")
                return result

    def readiness(self, force=False):
        if self.closed.is_set():
            return {"ready": False, "message": "บริการกำลังปิด", "vram_gib": 0}
        if force or time.monotonic() >= self.next_probe:
            if self.probe_lock.acquire(blocking=False):
                try:
                    self.next_probe = time.monotonic() + 5
                    stats = self._json("GET", "/system_stats", limit=1024**2)
                    schema = self._json("GET", "/object_info", limit=32 * 1024**2)
                    gpu = next((device for device in stats.get("devices", [])
                                if isinstance(device, dict) and device.get("type") == "cuda"), None)
                    if not gpu or not isinstance(gpu.get("vram_total"), (int, float)) or gpu["vram_total"] < 23 * 1024**3:
                        raise EngineError("ต้องใช้ NVIDIA GPU VRAM อย่างน้อย 24 GB สำหรับชุด Deploy นี้")
                    missing = set()
                    for model in core.LOCAL_MODELS + core.POD_MODELS:
                        target = "local" if model in core.LOCAL_MODELS else "runpod"
                        plan = core.validate({"prompt": "a landscape", "target": target, "model": model, "seed": 0})
                        missing.update(node["class_type"] for node in core.graph(plan, "a" * 32).values() if node["class_type"] not in schema)
                    if missing:
                        raise EngineError("ComfyUI ขาดโหนด " + ", ".join(sorted(missing)))
                    self.ready_cache = {"ready": True, "message": "พร้อมสร้างภาพบน RunPod",
                                        "gpu": str(gpu.get("name", "NVIDIA CUDA")), "vram_gib": gpu["vram_total"] / 1024**3}
                except (EngineError, requests.RequestException, OSError, ValueError, TypeError) as error:
                    self.ready_cache = {"ready": False, "message": str(error)[:400] if isinstance(error, EngineError)
                                        else "ComfyUI ยังไม่พร้อม ตรวจ Logs ของ Pod และสถานะ GPU", "vram_gib": 0}
                finally:
                    self.probe_lock.release()
        return dict(self.ready_cache)

    def status(self):
        ready = self.readiness()
        with self.lock:
            jobs = sorted(self.jobs.values(), key=lambda job: job.get("created", 0), reverse=True)[:18]
            return {**ready, "busy": any(job["status"] in ACTIVE for job in self.jobs.values()),
                    "jobs": json.loads(json.dumps(jobs))}

    def _artifacts(self, plan):
        return core.model_artifacts(plan["model"], plan["target"])

    def verify_models(self, plan, progress=None):
        sidecar = None
        for source in self._artifacts(plan):
            item = dict(source)
            relative = PurePosixPath(item["path"])
            if relative.is_absolute() or ".." in relative.parts or "\\" in item["path"]:
                raise EngineError("พาธโมเดลใน registry ไม่ถูกต้อง")
            path = self.models.joinpath(*relative.parts)
            if path.is_symlink() or not path.resolve().is_relative_to(self.models) or not path.is_file():
                raise EngineError("ไม่พบโมเดล " + item["id"] + " บน Volume — รัน install_models.py ก่อน")
            if not item.get("checksum"):
                if sidecar is None:
                    marker = self.models / ".checksums.json"
                    if marker.is_symlink() or not marker.is_file() or marker.stat().st_size > 4 * 1024**2:
                        raise EngineError("ยังไม่มี checksum ที่เชื่อถือได้ — รัน install_models.py ก่อน")
                    sidecar = json.loads(marker.read_text(encoding="utf-8"))
                    if sidecar.get("version") != 1 or not isinstance(sidecar.get("artifacts"), dict):
                        raise EngineError("ไฟล์ checksum บน Volume ไม่ถูกต้อง")
                record = sidecar["artifacts"].get(item["path"], {})
                identity = ("id", "url", "bytes", "checksum_algorithm")
                if any(record.get(key) != item[key] for key in identity):
                    raise EngineError("checksum บน Volume เป็นโมเดลคนละรุ่น")
                item["checksum"] = record.get("checksum")
            if not isinstance(item.get("checksum"), str) or not re.fullmatch("[a-f0-9]{64}", item["checksum"]):
                raise EngineError("ยังไม่มี SHA256 ที่ถูกต้องสำหรับ " + item["id"])
            before = path.stat()
            signature = (str(path.resolve()), before.st_size, before.st_mtime_ns, item["checksum"])
            if self.signatures.get(item["id"]) == signature:
                continue
            if before.st_size != item["bytes"]:
                raise EngineError("ขนาดโมเดลไม่ตรง: " + item["id"] + " — ตรวจด้วย install_models.py")
            if progress:
                progress("กำลังตรวจ SHA256: " + item["id"])
            digest = hashlib.sha256()
            with path.open("rb") as file:
                for chunk in iter(lambda: file.read(4 * 1024**2), b""):
                    if self.closed.is_set():
                        raise EngineError("บริการกำลังปิดก่อนตรวจโมเดลเสร็จ")
                    digest.update(chunk)
            after = path.stat()
            if digest.hexdigest() != item["checksum"] or (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise EngineError("SHA256 โมเดลไม่ตรงหรือไฟล์ถูกแก้: " + item["id"])
            self.signatures[item["id"]] = signature
            print(json.dumps({"model": item["id"], "status": "verified", "bytes": after.st_size}), flush=True)

    def submit(self, body):
        if not isinstance(body, dict):
            raise EngineError("ข้อมูลสร้างภาพไม่ถูกต้อง")
        allowed = {"id", "prompt", "model", "negative", "ratio", "quality", "seed", "resolution"}
        if set(body) - allowed:
            raise EngineError("ระบบนี้รับข้อความสร้างภาพเท่านั้น ไม่รับไฟล์หรือพาธโมเดลจากเว็บ")
        job_id = body.get("id", "")
        if not isinstance(job_id, str) or not JOB_ID.fullmatch(job_id):
            raise EngineError("รหัสงานไม่ถูกต้อง")
        model = body.get("model", "juggernaut_x")
        values = dict(body, model=model, target="local" if model in core.LOCAL_MODELS else "runpod")
        plan = core.validate(values)
        with self.lock:
            if job_id in self.jobs:
                old = self.jobs[job_id]
                comparable = ("prompt", "negative", "model", "ratio", "quality", "resolution")
                if any(old["plan"].get(key) != plan.get(key) for key in comparable) or (body.get("seed") not in (None, "") and old["plan"].get("seed") != plan["seed"]):
                    raise EngineError("รหัสงานนี้ใช้กับค่าชุดอื่นแล้ว กรุณาเริ่มงานใหม่")
                return json.loads(json.dumps(old))
            if any(job["status"] in ACTIVE for job in self.jobs.values()):
                raise EngineError("มีงานเดิมที่ต้องรอหรือกู้ผลก่อน ห้ามกดสร้างซ้ำ")
            ready = self.readiness()
            if not ready.get("ready"):
                raise EngineError(ready["message"])
            if model in core.POD_MODELS and ready.get("vram_gib", 0) < 40:
                raise EngineError("Qwen / FLUX รุ่นนี้ต้องใช้ GPU VRAM อย่างน้อย 48 GB; 4090 ใช้ SDXL ได้")
            job = {"id": job_id, "created": time.time(), "status": "queued", "message": "กำลังตรวจโมเดล", "plan": plan,
                   "pod_id": self.pod_id, "instance_id": self.instance_id}
            # บันทึกรหัสงานก่อนสร้าง thread และก่อน POST ไป GPU ทุกครั้ง
            self.persist(job)
            self.jobs[job_id] = job
            self._start_worker(job, False)
            return json.loads(json.dumps(job))

    def _start_worker(self, job, recover):
        worker = threading.Thread(target=self._work, args=(job, recover), daemon=True)
        self.workers[job["id"]] = worker
        worker.start()

    def _update(self, job, **changes):
        with self.lock:
            job.update(changes)
            self.persist(job)

    def get_job(self, job_id):
        if not isinstance(job_id, str) or not JOB_ID.fullmatch(job_id) or job_id not in self.jobs:
            raise EngineError("ไม่พบงานนี้")
        with self.lock:
            return json.loads(json.dumps(self.jobs[job_id]))

    def recover(self, job_id):
        with self.lock:
            self.get_job(job_id)
            job = self.jobs[job_id]
            if job["status"] not in ACTIVE:
                return json.loads(json.dumps(job))
            worker = self.workers.get(job_id)
            if worker and worker.is_alive():
                return json.loads(json.dumps(job))
            self._start_worker(job, True)
            return json.loads(json.dumps(job))

    def _find_prompt(self, job):
        queue = self._json("GET", "/queue")
        history = self._json("GET", "/history?max_items=200")
        rows = list(queue.get("queue_running", [])) + list(queue.get("queue_pending", []))
        rows += [entry.get("prompt", []) for entry in history.values() if isinstance(entry, dict)]
        found = set()
        for row in rows:
            if (isinstance(row, (list, tuple)) and len(row) > 3 and isinstance(row[3], dict)
                    and row[3].get("image_studio_job") == job["id"]
                    and (not job.get("instance_id") or row[3].get("image_studio_instance") == job["instance_id"])):
                found.add(row[1])
        if len(found) > 1:
            raise EngineError("พบงานเดิมมากกว่าหนึ่งงาน กรุณาตรวจคิวก่อนดำเนินการต่อ")
        prompt_id = next(iter(found), None)
        if prompt_id is not None and (not isinstance(prompt_id, str) or not re.fullmatch(r"[a-f0-9-]{32,36}", prompt_id)):
            raise EngineError("ComfyUI คืนรหัสงานเดิมที่ไม่ถูกต้อง")
        return prompt_id

    def _image(self, item):
        if (not isinstance(item, dict) or item.get("type") != "output" or item.get("subfolder") != "image-studio"
                or not re.fullmatch(r"[A-Za-z0-9_.-]+\.png", item.get("filename", ""))):
            raise EngineError("ปลายทางภาพผลลัพธ์ไม่ตรงกับงาน")
        with requests.Session() as session:
            session.trust_env = False
            with session.get(self.base + "/view", params=item, timeout=(3, 30), stream=True, allow_redirects=False) as response:
                if response.status_code != 200:
                    raise EngineError("อ่านภาพผลลัพธ์จาก ComfyUI ไม่ได้")
                data = bytearray()
                for chunk in response.iter_content(128 * 1024):
                    data.extend(chunk)
                    if len(data) > MAX_IMAGE_BYTES:
                        raise EngineError("ภาพผลลัพธ์ใหญ่เกิน 30 MB")
                return bytes(data)

    def _work(self, job, recover):
        submitted = bool(job.get("prompt_id")) or recover
        try:
            if not recover:
                self.verify_models(job["plan"], lambda message: self._update(job, status="running", message=message))
                queue = self._json("GET", "/queue")
                if (not isinstance(queue.get("queue_running"), list) or not isinstance(queue.get("queue_pending"), list)
                        or queue["queue_running"] or queue["queue_pending"]):
                    raise EngineError("ComfyUI มีงานอื่นอยู่ รอให้คิวว่างก่อน")
                self._update(job, status="unknown", message="กำลังส่งงาน ตรวจผลก่อนส่งซ้ำ", submitted_at=time.time())
                submitted = True
                try:
                    result = self._json("POST", "/prompt", {"prompt": core.graph(job["plan"], job["id"]),
                                                               "client_id": job["id"], "extra_data": {"image_studio_job": job["id"],
                                                                                                         "image_studio_instance": job["instance_id"]}})
                except RejectedSubmission:
                    submitted = False
                    raise
                except requests.RequestException:
                    raise UncertainSubmission("ติดต่อ GPU ขาดหายระหว่างส่งงาน กดกู้ผลเดิม ห้ามสร้างซ้ำ") from None
                if result.get("node_errors"):
                    submitted = False
                    raise EngineError("ComfyUI ไม่รับ workflow กรุณาตรวจชื่อโมเดลและโหนดใน Logs")
                if not isinstance(result.get("prompt_id"), str) or not re.fullmatch(r"[a-f0-9-]{32,36}", result["prompt_id"]):
                    raise UncertainSubmission("ComfyUI ไม่คืนรหัสงานที่ถูกต้อง ให้ตรวจและกู้ผลเดิมก่อน")
                self._update(job, prompt_id=result["prompt_id"], status="running", message="GPU กำลังสร้างภาพ")
            elif not job.get("prompt_id"):
                prompt_id = self._find_prompt(job)
                if not prompt_id:
                    raise UncertainSubmission("ยังไม่พบงานเดิมในคิวหรือประวัติ GPU ระบบไม่ส่งงานใหม่ซ้ำ")
                self._update(job, prompt_id=prompt_id, status="running", message="พบงานเดิม กำลังกู้ผล")
            deadline = time.monotonic() + 2 * 60 * 60
            while time.monotonic() < deadline and not self.closed.is_set():
                row = self._json("GET", "/history/" + job["prompt_id"]).get(job["prompt_id"])
                if row:
                    status = row.get("status", {})
                    errors = [message for message in status.get("messages", [])
                              if isinstance(message, (list, tuple)) and message and message[0] in ("execution_error", "execution_interrupted")]
                    if errors:
                        submitted = False
                        details = errors[-1][1] if len(errors[-1]) > 1 and isinstance(errors[-1][1], dict) else {}
                        node = str(details.get("node_type", "ไม่ทราบโหนด"))[:100]
                        cause = str(details.get("exception_message", "งานถูกหยุดก่อนเสร็จ"))[:300]
                        raise EngineError("GPU สร้างภาพล้มเหลวที่ " + node + ": " + cause)
                    images = row.get("outputs", {}).get("10", {}).get("images", [])
                    if images:
                        self._update(job, status="downloading", message="กำลังตรวจและบันทึก PNG ลง Volume")
                        image = self._image(images[0])
                        if png_dimensions(image) != (job["plan"]["width"], job["plan"]["height"]):
                            submitted = False
                            raise EngineError("ขนาด PNG ผลลัพธ์ไม่ตรงกับคำขอ")
                        target = self.data / "outputs" / (job["id"] + ".png")
                        temporary = target.with_suffix(".png.tmp")
                        try:
                            with temporary.open("wb") as output:
                                output.write(image)
                                output.flush()
                                os.fsync(output.fileno())
                            temporary.replace(target)
                        finally:
                            temporary.unlink(missing_ok=True)
                        atomic_json(target.with_suffix(".json"), {"version": core.VERSION, "plan": job["plan"],
                                                                    "workflow": core.graph(job["plan"], job["id"]),
                                                                    "sha256": hashlib.sha256(image).hexdigest()})
                        self._update(job, status="succeeded", message="บันทึก PNG และค่าการสร้างลง Network Volume แล้ว")
                        return
                    if status.get("completed"):
                        submitted = False
                        raise EngineError("งานจบแต่ไม่พบ PNG จากโหนด SaveImage")
                self.closed.wait(2)
            raise UncertainSubmission("งานยังไม่จบหรือติดต่อขาดหาย กู้ผลเดิมเมื่อ GPU พร้อม ห้ามส่งซ้ำ")
        except Exception as error:
            unknown = submitted or isinstance(error, UncertainSubmission)
            safe = str(error)[:500] if isinstance(error, EngineError) else "ติดต่อ GPU หรือบันทึกผลไม่ได้ ตรวจสถานะก่อนกู้ผลเดิม"
            self._update(job, status="unknown" if unknown else "failed", message=safe)

    def output_path(self, job_id, extension):
        job = self.get_job(job_id)
        if job["status"] != "succeeded" or extension not in ("png", "json"):
            raise EngineError("ภาพงานนี้ยังไม่พร้อมดาวน์โหลด")
        path = self.data / "outputs" / (job_id + "." + extension)
        if path.is_symlink() or not path.resolve().is_relative_to(self.data / "outputs") or not path.is_file():
            raise EngineError("ไม่พบไฟล์ผลลัพธ์")
        return path

    def close(self):
        # หยุดเฉพาะ worker แอป ไม่ interrupt GPU/หยุด Pod/ลบ Volume
        self.closed.set()
