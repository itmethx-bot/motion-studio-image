#!/usr/bin/env bash
set -euo pipefail
cd /opt/image-studio
export MODELS_ROOT="${MODELS_ROOT:-/workspace/models}"
export DATA_ROOT="${DATA_ROOT:-/workspace/image-studio-data}"
export STUDIO_DATA_ROOT="$DATA_ROOT"
export APP_PORT="${APP_PORT:-5000}" COMFY_PORT="${COMFY_PORT:-8188}"
export COMFY_INTERNAL_PORT="${COMFY_INTERNAL_PORT:-8189}"
export AUX_ANNOTATOR_CKPTS_PATH="$MODELS_ROOT/annotators"
export HF_HOME="$DATA_ROOT/huggingface-cache"
export TORCH_HOME="$DATA_ROOT/torch-cache"
export HF_HUB_DISABLE_TELEMETRY=1 DO_NOT_TRACK=1
python runtime_init.py prepare

# สามารถสั่งติดตั้งอย่างเดียวได้ ไม่เปิด GPU inference เอง
if [[ "${1:-}" == "install-models" ]]; then
    shift
    exec python install_models.py --root "$MODELS_ROOT" "$@"
fi
if [[ "$#" -gt 0 ]]; then
    echo 'Start command ไม่รู้จัก: เว้นว่าง หรือใช้ install-models' >&2
    exit 2
fi
case "${BOOTSTRAP_MODELS:-0}" in
    1) python install_models.py --root "$MODELS_ROOT" --groups "${MODEL_GROUPS:-sdxl,character,pose,segmentation}" ;;
    0) ;;
    *) echo 'BOOTSTRAP_MODELS ต้องเป็น 0 หรือ 1' >&2; exit 2 ;;
esac
python runtime_init.py preflight
# ห้าม Hub ดึงโมเดลอัตโนมัติ; node ที่ใช้ torch.hub ต้องเลือกเฉพาะรุ่นที่ติดตั้งไว้
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
owned=()
cleanup() {
    trap - EXIT INT TERM
    for child in "${owned[@]}"; do kill -TERM "$child" 2>/dev/null || true; done
    # จำกัดช่วงปิด process ไม่ให้ entrypoint รอ child ที่ค้างอย่างไม่สิ้นสุด
    for ((round=0; round<30; round++)); do
        alive=0
        for child in "${owned[@]}"; do kill -0 "$child" 2>/dev/null && alive=1 || true; done
        [[ "$alive" == 0 ]] && break
        sleep 1
    done
    for child in "${owned[@]}"; do kill -KILL "$child" 2>/dev/null || true; done
    for child in "${owned[@]}"; do wait "$child" 2>/dev/null || true; done
}
trap cleanup EXIT INT TERM
python -u /opt/ComfyUI/main.py --listen 127.0.0.1 --port "$COMFY_INTERNAL_PORT" \
    --disable-auto-launch --disable-api-nodes --fp32-vae \
    --extra-model-paths-config /run/image-studio/extra_model_paths.yaml \
    --input-directory "$DATA_ROOT/comfy-input" --output-directory "$DATA_ROOT/comfy-output" \
    --user-directory "$DATA_ROOT/comfy-user" &
owned+=("$!")
python runtime_init.py wait
nginx -c /run/image-studio/nginx.conf -g 'daemon off;' &
owned+=("$!")
python -u app.py &
owned+=("$!")
# service ใดหยุดให้ปิดเฉพาะลูกที่ entrypoint สร้างไว้ ไม่ทิ้ง GPU process ค้าง
set +e
wait -n "${owned[@]}"
result=$?
set -e
exit "$result"
