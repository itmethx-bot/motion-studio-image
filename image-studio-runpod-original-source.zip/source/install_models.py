"""Install pinned models to a persistent Network Volume; stdlib + requests only."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import stat
import sys
import time
from urllib.parse import quote, urljoin, urlsplit
import zipfile

import requests
from model_catalog import select_models

GIB = 1024 ** 3
CHUNK = 1024 ** 2
BUFFER_BYTES = 2 * GIB
BUF_FILES = {'det_10g.onnx', 'w600k_r50.onnx', 'genderage.onnx', '2d106det.onnx', '1k3d68.onnx'}
INITIAL_HOSTS = {'huggingface.co', 'github.com', 'dl.fbaipublicfiles.com'}
REDIRECT_HOSTS = INITIAL_HOSTS | {'release-assets.githubusercontent.com', 'objects.githubusercontent.com',
    'cdn-lfs.huggingface.co', 'cdn-lfs-us-1.huggingface.co', 'cdn-lfs-eu-1.huggingface.co',
    'cas-bridge.xethub.hf.co', 'cdn-lfs.hf.co'}


class InstallError(RuntimeError):
    def __init__(self, message, retryable=False):
        super().__init__(message)
        self.retryable = retryable


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(4 * CHUNK), b''):
            value.update(chunk)
    return value.hexdigest()


def destination(root, relative):
    # ไม่ยอมให้ชื่อไฟล์หรือ symlink เขียนออกนอก volume ที่ตั้งไว้
    root = Path(root).resolve()
    if (not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative
            or any(p in ('', '.', '..') for p in relative.split('/'))
            or PurePosixPath(relative).is_absolute()):
        raise InstallError('path โมเดลไม่ถูกต้อง')
    path = root.joinpath(*PurePosixPath(relative).parts)
    if path.is_symlink() or not path.resolve().is_relative_to(root):
        raise InstallError('ปลายทางต้องอยู่ใน MODELS_ROOT และต้องไม่เป็น symlink')
    return path


def atomic_json(path, data):
    path = Path(path)
    if path.is_symlink():
        raise InstallError('ไม่เขียนทับไฟล์ metadata ที่เป็น symlink')
    temporary = path.with_name(path.name + '.' + secrets.token_hex(8) + '.tmp')
    try:
        with temporary.open('x', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def read_sidecar(root):
    path = destination(root, '.checksums.json')
    if not path.exists():
        return {'version': 1, 'artifacts': {}}
    try:
        if not path.is_file() or path.stat().st_size > 4 * CHUNK:
            raise ValueError()
        data = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data, dict) or data.get('version') != 1 or not isinstance(data.get('artifacts'), dict):
            raise ValueError()
        return data
    except (OSError, ValueError):
        raise InstallError('.checksums.json เสียหาย กรุณาสำรองและตรวจไฟล์ก่อนลองใหม่') from None


def effective_entry(root, entry):
    result = dict(entry)
    if result.get('checksum'):
        return result
    record = read_sidecar(root)['artifacts'].get(result['path'])
    if record is not None:
        identity = {k: result[k] for k in ('id', 'url', 'bytes', 'checksum_algorithm')}
        if (not isinstance(record, dict) or any(record.get(k) != v for k, v in identity.items())
                or not isinstance(record.get('checksum'), str)
                or not re.fullmatch(r'[a-f0-9]{64}', record['checksum'])):
            raise InstallError('checksum ที่บันทึกไว้เป็นคนละรุ่น/แหล่งดาวน์โหลด: ' + result['id'])
        result['checksum'] = record['checksum']
    return result


def record_checksum(root, entry, digest):
    # schema ตรงกับ download_model.py เดิม: TOFU ไม่ใช่การรับรองจากผู้เผยแพร่
    data = read_sidecar(root)
    record = {key: entry[key] for key in ('id', 'url', 'bytes', 'checksum_algorithm')}
    record.update(checksum=digest, source='first_download')
    old = data['artifacts'].get(entry['path'])
    if old is not None and old != record:
        raise InstallError('ไม่เขียนทับ checksum ที่เคยบันทึกคนละค่า: ' + entry['id'])
    data['artifacts'][entry['path']] = record
    atomic_json(destination(root, '.checksums.json'), data)


def allowed_url(url, initial=False):
    parsed = urlsplit(url)
    hosts = INITIAL_HOSTS if initial else REDIRECT_HOSTS
    if (parsed.scheme != 'https' or parsed.hostname not in hosts or parsed.username or parsed.password
            or parsed.port not in (None, 443)):
        raise InstallError('ปฏิเสธ URL/redirect ที่ไม่ใช่ HTTPS ของผู้เผยแพร่ที่อนุญาต')
    return parsed


def http_stream(session, url, headers=None, token=None, method='GET'):
    allowed_url(url, initial=True)
    for _ in range(8):
        parsed = allowed_url(url)
        outgoing = dict(headers or {})
        outgoing.update({'User-Agent': 'ImageStudioVolumeInstaller/1', 'Accept-Encoding': 'identity'})
        # ไม่ส่ง HF token ต่อไปยัง CDN, GitHub หรือ host อื่น แม้ redirect ถูกต้อง
        if token and parsed.hostname == 'huggingface.co':
            outgoing['Authorization'] = 'Bearer ' + token
        try:
            response = session.request(method, url, headers=outgoing, timeout=(20, 120),
                                       stream=True, allow_redirects=False)
        except requests.RequestException:
            raise InstallError('เชื่อมต่อดาวน์โหลดไม่ได้หรือหมดเวลา', retryable=True) from None
        if response.status_code in (301, 302, 303, 307, 308):
            new_url = urljoin(url, response.headers.get('Location', ''))
            response.close()
            if not new_url or new_url == url:
                raise InstallError('redirect ไม่สมบูรณ์หรือวนซ้ำ')
            allowed_url(new_url)
            url = new_url
            continue
        if response.status_code in (401, 403):
            response.close()
            raise InstallError('ไม่มีสิทธิ์ดาวน์โหลด: ตรวจ HF_TOKEN และยอมรับเงื่อนไขโมเดลใน Hugging Face')
        if response.status_code not in (200, 206, 416):
            status = response.status_code
            response.close()
            raise InstallError('ดาวน์โหลดตอบ HTTP ' + str(status) + ' กรุณาตรวจแหล่งโมเดล/เครือข่าย',
                               retryable=status in (408, 429, 500, 502, 503, 504))
        return response
    raise InstallError('redirect มากเกินไป')


def fill_metadata(entry, session, token=None):
    """อ่าน size/LFS SHA256 ของ HF รุ่นที่ pin ไว้เมื่อ catalog ยังไม่ครบ"""
    result = dict(entry)
    if type(result.get('bytes')) is int and result['bytes'] > 0 and result.get('checksum'):
        return result
    parsed = allowed_url(result['url'], initial=True)
    match = re.fullmatch(r'/(datasets/)?([^/]+/[^/]+)/resolve/([^/]+)/(.+)', parsed.path)
    if parsed.hostname != 'huggingface.co' or not match:
        return result
    kind, repo, revision, filename = match.groups()
    if not re.fullmatch(r'[a-f0-9]{40}', revision):
        raise InstallError('metadata ต้องใช้ HF commit ที่ pin แล้ว: ' + result['id'])
    parent = str(PurePosixPath(filename).parent)
    path = '/api/' + ('datasets/' if kind else 'models/') + repo + '/tree/' + revision
    if parent != '.':
        path += '/' + quote(parent, safe='/')
    url = 'https://huggingface.co' + path + '?limit=1000'
    response = http_stream(session, url, token=token)
    try:
        raw = response.raw.read(8 * CHUNK + 1)
        if len(raw) > 8 * CHUNK:
            raise InstallError('HF metadata ใหญ่เกินขอบเขต')
        items = json.loads(raw)
        item = next(item for item in items if item.get('path') == filename and item.get('type') == 'file')
        size = item.get('size')
        if type(size) is not int or size <= 0:
            raise ValueError()
        if result.get('bytes') not in (None, 0, size):
            raise InstallError('ขนาด catalog ไม่ตรงกับ HF รุ่นที่ pin: ' + result['id'])
        result['bytes'] = size
        oid = (item.get('lfs') or {}).get('oid')
        if isinstance(oid, str):
            oid = oid.removeprefix('sha256:').lower()
            if re.fullmatch(r'[a-f0-9]{64}', oid):
                result['checksum'] = oid
        return result
    except (ValueError, TypeError, AttributeError, StopIteration, requests.RequestException):
        raise InstallError('อ่าน size/checksum ของ HF ไม่สำเร็จ: ' + result['id']) from None
    finally:
        response.close()


def validate_entry(root, entry):
    destination(root, entry.get('path'))
    if not isinstance(entry.get('id'), str) or not re.fullmatch(r'[a-z0-9_]+', entry['id']):
        raise InstallError('id โมเดลไม่ถูกต้อง')
    if type(entry.get('bytes')) is not int or entry['bytes'] <= 0:
        raise InstallError('ไม่ทราบขนาดโมเดล จึงไม่เริ่มดาวน์โหลด: ' + entry['id'])
    if entry.get('checksum_algorithm') != 'sha256' or (entry.get('checksum') not in (None, '')
            and not re.fullmatch(r'[a-f0-9]{64}', str(entry['checksum']))):
        raise InstallError('checksum ของโมเดลไม่ถูกต้อง: ' + entry['id'])
    allowed_url(entry['url'], initial=True)


def file_valid(path, entry):
    return (path.is_file() and path.stat().st_size == entry['bytes']
            and bool(entry.get('checksum')) and sha256(path) == entry['checksum'])


def part_identity(entry):
    return {k: entry.get(k) or None for k in ('url', 'bytes', 'checksum_algorithm', 'checksum')}


def part_paths(root, entry):
    return destination(root, entry['path'] + '.part'), destination(root, entry['path'] + '.part.json')


def partial_size(root, entry):
    partial, metadata = part_paths(root, entry)
    if not partial.exists():
        return 0
    try:
        saved = json.loads(metadata.read_text(encoding='utf-8'))
        identity = part_identity(entry)
        compatible = (isinstance(saved, dict) and saved.get('checksum') is None and identity['checksum']
                      and all(saved.get(k) == v for k, v in identity.items() if k != 'checksum')
                      and set(saved) == set(identity))
        if saved != identity and not compatible:
            raise ValueError()
        if not partial.is_file() or not 0 <= partial.stat().st_size <= entry['bytes']:
            raise ValueError()
        return partial.stat().st_size
    except (ValueError, OSError):
        raise InstallError('ไฟล์ .part ไม่ตรงกับโมเดลรุ่นนี้ กรุณาสำรอง/ย้าย .part และ .part.json: ' + entry['id']) from None


def progress_printer(ident):
    last = [-1, 0.0]
    def emit(done, total):
        percent = min(100, int(done * 100 / total))
        now = time.monotonic()
        if percent == 100 or percent >= last[0] + 5 or now - last[1] >= 5:
            print(f'{ident}: {percent:3d}% ({done / GIB:.2f}/{total / GIB:.2f} GiB)', flush=True)
            last[:] = [percent, now]
    return emit


def download_one(root, entry, session, token=None, progress=None):
    entry = effective_entry(root, entry)
    validate_entry(root, entry)
    target = destination(root, entry['path'])
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and file_valid(target, entry):
        print(entry['id'] + ': verified — มีไฟล์ครบแล้ว ข้ามดาวน์โหลด', flush=True)
        return 'skipped'
    partial, metadata = part_paths(root, entry)
    offset = partial_size(root, entry)
    progress = progress or progress_printer(entry['id'])
    if offset < entry['bytes']:
        headers = {'Range': f'bytes={offset}-'} if offset else {}
        response = http_stream(session, entry['url'], headers=headers, token=token)
        try:
            if response.headers.get('Content-Encoding') not in (None, '', 'identity'):
                raise InstallError('server ส่งไฟล์แบบบีบอัด ไม่สามารถตรวจขนาด/ต่อดาวน์โหลดได้')
            if response.status_code == 416:
                raise InstallError('server ปฏิเสธช่วง .part กรุณาย้าย .part ก่อนลองใหม่')
            if response.status_code == 206:
                match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
                if (not match or int(match[1]) != offset or int(match[3]) != entry['bytes']
                        or int(match[2]) != entry['bytes'] - 1):
                    raise InstallError('Content-Range ไม่ตรงกับรุ่น/ขนาดโมเดล')
            elif response.status_code == 200:
                offset = 0  # server ไม่รองรับ Range จึงเริ่มไฟล์ใหม่ ไม่ต่อซ้ำ
            length = response.headers.get('Content-Length')
            if length is not None and (not length.isdigit() or int(length) != entry['bytes'] - offset):
                raise InstallError('Content-Length ไม่ตรงกับขนาดโมเดล')
            atomic_json(metadata, part_identity(entry))
            progress(offset, entry['bytes'])
            try:
                with partial.open('ab' if offset else 'wb') as handle:
                    for chunk in response.iter_content(chunk_size=CHUNK):
                        if not chunk:
                            continue
                        if offset + len(chunk) > entry['bytes']:
                            raise InstallError('ไฟล์ดาวน์โหลดใหญ่เกิน catalog')
                        handle.write(chunk)
                        offset += len(chunk)
                        progress(offset, entry['bytes'])
                    handle.flush()
                    os.fsync(handle.fileno())
            except requests.RequestException:
                raise InstallError('ดาวน์โหลดขาดช่วง เก็บ .part ไว้เพื่อต่อใหม่', retryable=True) from None
        finally:
            response.close()
    if not partial.is_file() or partial.stat().st_size != entry['bytes']:
        raise InstallError('ดาวน์โหลดไม่ครบขนาด เก็บ .part ไว้เพื่อต่อใหม่', retryable=True)
    digest = sha256(partial)
    if entry.get('checksum') and digest != entry['checksum']:
        # ลบเฉพาะไฟล์ชั่วคราวของรุ่นที่มี metadata ตรงกัน ไม่ทับไฟล์จริงที่มีอยู่
        partial.unlink()
        metadata.unlink(missing_ok=True)
        raise InstallError('SHA256 ไม่ตรง ไฟล์ชั่วคราวถูกลบเพื่อดาวน์โหลดใหม่', retryable=True)
    first = not entry.get('checksum')
    if first:
        record_checksum(root, entry, digest)
    partial.replace(target)
    metadata.unlink(missing_ok=True)
    print(entry['id'] + (': checksum recorded (first download) — บันทึก SHA256 ครั้งแรก; ไม่ใช่ hash จากผู้เผยแพร่'
                        if first else ': verified — ขนาดและ SHA256 ตรงกัน'), flush=True)
    return 'installed'


def prepare_buffalo(root, entry, validate_only=False):
    archive = destination(root, entry['path'])
    if not file_valid(archive, entry):
        raise InstallError('ต้องมี Buffalo archive ที่ตรวจ SHA256 แล้วก่อนแตกไฟล์')
    with zipfile.ZipFile(archive) as bundle:
        members = {}
        for item in bundle.infolist():
            path = PurePosixPath(item.filename)
            mode = item.external_attr >> 16
            if ('\\' in item.filename or ':' in item.filename or '\x00' in item.filename
                    or '..' in path.parts or path.is_absolute() or stat.S_ISLNK(mode) or item.flag_bits & 1):
                raise InstallError('Buffalo ZIP มีชื่อ/ชนิดไฟล์ไม่ปลอดภัย')
            if item.is_dir():
                continue
            if (path.name not in BUF_FILES or path.parts not in ((path.name,), ('buffalo_l', path.name))
                    or path.name in members or not 0 < item.file_size < 400 * CHUNK):
                raise InstallError('Buffalo ZIP มีไฟล์นอกชุดที่กำหนด')
            members[path.name] = item
        if set(members) != BUF_FILES or sum(x.file_size for x in members.values()) > GIB:
            raise InstallError('Buffalo ZIP ต้องมีโมเดลครบ 5 ไฟล์')
        for name, info in members.items():
            target = destination(root, 'insightface/models/buffalo_l/' + name)
            value = hashlib.sha256()
            with bundle.open(info) as source:
                for chunk in iter(lambda: source.read(CHUNK), b''):
                    value.update(chunk)
            if target.is_file() and target.stat().st_size == info.file_size and sha256(target) == value.hexdigest():
                continue
            if validate_only:
                raise InstallError('Buffalo ONNX ยังไม่ครบหรือ SHA256 ไม่ตรง: ' + name)
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(name + '.' + secrets.token_hex(8) + '.tmp')
            try:
                with bundle.open(info) as source, temporary.open('xb') as out:
                    shutil.copyfileobj(source, out, CHUNK)
                    out.flush()
                    os.fsync(out.fileno())
                if temporary.stat().st_size != info.file_size or sha256(temporary) != value.hexdigest():
                    raise InstallError('แตก Buffalo ไม่ครบ')
                temporary.replace(target)
            finally:
                temporary.unlink(missing_ok=True)
    print('reactor_buffalo_l: แตกและตรวจ ONNX ครบ 5 ไฟล์แล้ว', flush=True)


@contextmanager
def install_lock(root):
    path = destination(root, '.install-models.lock')
    try:
        handle = path.open('x', encoding='utf-8')
    except FileExistsError:
        raise InstallError('มีการติดตั้งอื่นหรือ lock จากครั้งก่อน: ตรวจ process แล้วค่อยลบ .install-models.lock') from None
    try:
        with handle:
            json.dump({'pid': os.getpid(), 'started': time.time()}, handle)
        yield
    finally:
        path.unlink(missing_ok=True)


def install_all(root, entries, session=None, retries=3, dry_run=False, validate_only=False,
                token=None, reserve_bytes=BUFFER_BYTES, sleep=time.sleep):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    owned = session is None
    if owned:
        session = requests.Session()
        session.trust_env = False
    results = {}
    try:
        with install_lock(root):
            prepared = []
            for item in entries:
                try:
                    # --dry-run และ --validate ไม่ใช้เครือข่าย/ไม่เติม checksum
                    entry = dict(item) if dry_run or validate_only else fill_metadata(item, session, token)
                    validate_entry(root, entry)
                    entry = effective_entry(root, entry)
                    target = destination(root, entry['path'])
                    valid = file_valid(target, entry)
                    if valid:
                        print(entry['id'] + ': verified — มีไฟล์ครบแล้ว', flush=True)
                        results[entry['id']] = 'skipped'
                    elif validate_only:
                        results[entry['id']] = 'failed'
                        print(entry['id'] + ': ยังไม่มีไฟล์ที่ตรวจผ่าน', file=sys.stderr)
                    else:
                        prepared.append(entry)
                except (InstallError, OSError) as exc:
                    results[item['id']] = 'failed'
                    message = str(exc) if isinstance(exc, InstallError) else 'ตรวจไฟล์/สิทธิ์พื้นที่จัดเก็บไม่ได้'
                    print(item['id'] + ': ' + message, file=sys.stderr)
            checked = []
            for entry in prepared:
                try:
                    partial_size(root, entry)
                    checked.append(entry)
                except (InstallError, OSError) as exc:
                    results[entry['id']] = 'failed'
                    print(entry['id'] + ': ' + (str(exc) if isinstance(exc, InstallError)
                                              else 'ตรวจ .part ไม่สำเร็จ'), file=sys.stderr)
            prepared = checked
            required = reserve_bytes + sum(entry['bytes'] - partial_size(root, entry) for entry in prepared)
            if any(item['id'] == 'reactor_buffalo_l' for item in entries):
                required += GIB  # เผื่อพื้นที่ ONNX ที่แตกแล้ว
            free = shutil.disk_usage(root).free
            print(f'พื้นที่: ต้องว่างอย่างน้อย {required / GIB:.1f} GiB; มี {free / GIB:.1f} GiB', flush=True)
            if dry_run:
                for entry in prepared:
                    print(entry['id'] + ': จะติดตั้ง ' + entry['path'])
                    results[entry['id']] = 'planned'
            elif not validate_only:
                if free < required:
                    print('พื้นที่ไม่พอ จึงไม่เริ่มดาวน์โหลด เพิ่มขนาด Network Volume ก่อน', file=sys.stderr)
                    for entry in prepared:
                        results[entry['id']] = 'failed'
                    prepared = []
                for entry in prepared:
                    for attempt in range(retries):
                        try:
                            results[entry['id']] = download_one(root, entry, session, token)
                            break
                        except (InstallError, OSError) as exc:
                            retryable = isinstance(exc, InstallError) and exc.retryable
                            message = str(exc) if isinstance(exc, InstallError) else 'เขียนไฟล์ไม่ได้/พื้นที่เต็ม'
                            print(f"{entry['id']}: ครั้งที่ {attempt + 1}/{retries} — {message}", file=sys.stderr)
                            if retryable and attempt < retries - 1:
                                sleep(2 * (attempt + 1))
                                continue
                            results[entry['id']] = 'failed'
                            break
            buffalo = next((e for e in entries if e['id'] == 'reactor_buffalo_l'), None)
            if buffalo and not dry_run and results.get(buffalo['id']) != 'failed':
                try:
                    prepare_buffalo(root, buffalo, validate_only=validate_only)
                except (InstallError, OSError, zipfile.BadZipFile) as exc:
                    results[buffalo['id']] = 'failed'
                    print('Buffalo: ' + (str(exc) if isinstance(exc, InstallError) else 'แตก ZIP ไม่สำเร็จ'), file=sys.stderr)
    finally:
        if owned:
            session.close()
    print('สรุป: ' + ', '.join(f"{label} {sum(v == value for v in results.values())}"
          for value, label in (('installed', 'ติดตั้ง'), ('skipped', 'ตรวจผ่าน/ข้าม'),
                               ('planned', 'เตรียมแผน'), ('failed', 'ล้มเหลว'))), flush=True)
    return results


def main(argv=None):
    # PowerShell/pipe อาจใช้ cp1252; บังคับ UTF-8 เฉพาะ stream จริง ไม่แตะ StringIO ของ tests
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, 'reconfigure', None)
        if callable(reconfigure):
            try:
                reconfigure(encoding='utf-8', errors='backslashreplace')
            except (OSError, ValueError):
                pass  # stream ปิดอยู่หรือ wrapper ไม่รองรับการเปลี่ยน encoding
    parser = argparse.ArgumentParser(description='ติดตั้งโมเดลครั้งเดียวลง Network Volume; รันซ้ำได้')
    parser.add_argument('--root', default=os.environ.get('MODELS_ROOT', '/workspace/models'))
    parser.add_argument('--groups', help='sdxl,character,pose,segmentation,cloud; ไม่ระบุหมายถึงทั้งหมด')
    parser.add_argument('--all', action='store_true', help='ติดตั้งทุกชุด (ประมาณ 94 GiB ไม่รวม outputs/cache)')
    parser.add_argument('--dry-run', action='store_true', help='แสดงแผน/พื้นที่ ไม่ใช้เครือข่ายและไม่ดาวน์โหลด')
    parser.add_argument('--validate', action='store_true', help='ตรวจไฟล์เดิมทั้งหมด ไม่ดาวน์โหลด')
    parser.add_argument('--list', action='store_true', help='แสดงรายการโมเดล โดยไม่ตรวจ/ดาวน์โหลด')
    parser.add_argument('--retries', type=int, default=3, help='จำนวนครั้งรวมเมื่อเครือข่ายล้มเหลว (ค่าเริ่มต้น 3)')
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(argv)
    try:
        if args.groups and args.all:
            raise InstallError('เลือก --groups หรือ --all อย่างเดียว')
        if not 1 <= args.retries <= 10:
            raise InstallError('--retries ต้องเป็น 1–10')
        groups = [x.strip() for x in args.groups.split(',') if x.strip()] if args.groups else None
        entries = select_models(groups)
        if args.list:
            for entry in entries:
                print(f"{entry['id']}: {entry['bytes'] / GIB:.2f} GiB — {entry['path']}")
            print(f"รวม {sum(entry['bytes'] for entry in entries) / GIB:.1f} GiB")
            return 0
        token = os.environ.get('HF_TOKEN') or os.environ.get('HUGGING_FACE_HUB_TOKEN')
        result = install_all(args.root, entries, retries=args.retries, dry_run=args.dry_run,
                             validate_only=args.validate, token=token)
        return 1 if 'failed' in result.values() else 0
    except KeyboardInterrupt:
        print('หยุดติดตั้งแล้ว .part ที่มี metadata ถูกเก็บไว้เพื่อต่อครั้งหน้า', file=sys.stderr)
        return 130
    except (InstallError, OSError, ValueError) as exc:
        print('ติดตั้งไม่สำเร็จ: ' + (str(exc) if isinstance(exc, (InstallError, ValueError)) else 'ตรวจ path/สิทธิ์เขียน/พื้นที่'),
              file=sys.stderr)
        if args.debug:
            # traceback ของเครือข่ายอาจมี signed URL จึงแสดงชนิดข้อผิดพลาดแทน token/URL
            print('debug: ' + type(exc).__name__, file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
