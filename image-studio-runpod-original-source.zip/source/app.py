"""หน้า Text-to-Image บน RunPod; ใช้ Python มาตรฐาน + requests เท่านั้น"""
from __future__ import annotations

from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import threading
import time
from urllib.parse import urlsplit

from engine import Engine, EngineError, JOB_ID

ROOT = Path(__file__).resolve().parent
MAX_BODY = 16 * 1024


class Application:
    def __init__(self, engine, code, index_path=ROOT / "index.html"):
        if not isinstance(code, str) or not re.fullmatch(r"[A-Za-z0-9_-]{24,128}", code):
            raise ValueError("ตั้ง IMAGE_STUDIO_CODE เป็นรหัส 24–128 ตัวอักษร (ตัวอักษร ตัวเลข _ หรือ -)")
        self.engine = engine
        self.code = code
        self.index_path = Path(index_path)
        self.sessions = {}
        self.attempts = {}
        self.lock = threading.Lock()

    def authenticated(self, cookie):
        if not isinstance(cookie, str) or len(cookie) > 4096:
            return False
        try:
            parsed = SimpleCookie()
            parsed.load(cookie)
            token = parsed.get("image_session")
            with self.lock:
                return bool(token and self.sessions.get(token.value, 0) > time.time())
        except Exception:
            return False

    def login(self, code, peer):
        now = time.time()
        with self.lock:
            previous = [timestamp for timestamp in self.attempts.get(peer, []) if now - timestamp < 60]
            self.attempts[peer] = previous
            if len(previous) >= 10:
                return None, 429
            if not isinstance(code, str) or not secrets.compare_digest(code.encode("utf-8"), self.code.encode("utf-8")):
                previous.append(now)
                return None, 401
            self.attempts.pop(peer, None)
            self.sessions = {token: expiry for token, expiry in self.sessions.items() if expiry > now}
            token = secrets.token_urlsafe(32)
            self.sessions[token] = now + 86400
            return token, 200

    def handler(self):
        application = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "ImageStudio"

            def log_message(self, format, *args):
                # ไม่พิมพ์ URL/query/body/cookie ที่อาจมีรหัสหรือ prompt ลง access log
                return

            def respond(self, status, body, content_type="application/json; charset=utf-8", headers=None):
                raw = json.dumps(body, ensure_ascii=False).replace(application.code, "[ปกปิดรหัส]").encode("utf-8") if isinstance(body, dict) else body
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'")
                for key, value in (headers or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(raw)

            def error(self, status, message):
                # ข้อความจาก ComfyUI อาจมีข้อมูลที่ตั้งไว้ใน environment: ลบรหัสก่อนส่ง
                self.respond(status, {"error": str(message).replace(application.code, "[ปกปิดรหัส]")[:700]})

            def protected(self):
                if not application.authenticated(self.headers.get("Cookie", "")):
                    self.error(401, "กรุณาใส่รหัสเข้าใช้งาน")
                    return False
                return True

            def mutation(self):
                if self.headers.get("X-Requested-With") != "ImageStudio":
                    self.error(403, "คำขอไม่ถูกต้อง กรุณาใช้หน้าแอปนี้")
                    return False
                origin = self.headers.get("Origin")
                if origin and urlsplit(origin).netloc.lower() != self.headers.get("Host", "").lower():
                    self.error(403, "ไม่อนุญาตคำขอจากเว็บไซต์อื่น")
                    return False
                return True

            def body(self):
                if self.headers.get("Transfer-Encoding"):
                    raise ValueError("รูปแบบคำขอไม่รองรับ")
                length = self.headers.get("Content-Length", "")
                if not length.isdecimal() or not 0 < int(length) <= MAX_BODY:
                    raise ValueError("ข้อมูลคำขอว่างหรือใหญ่เกิน 16 KB")
                if self.headers.get("Content-Type", "").split(";", 1)[0].strip() != "application/json":
                    raise ValueError("ข้อมูลต้องเป็น JSON")
                self.connection.settimeout(10)
                raw = self.rfile.read(int(length))
                if len(raw) != int(length):
                    raise ValueError("ส่งข้อมูลมาไม่ครบ")
                value = json.loads(raw)
                if not isinstance(value, dict):
                    raise ValueError("ข้อมูลคำขอไม่ถูกต้อง")
                return value

            def do_GET(self):
                try:
                    path = urlsplit(self.path).path
                    if path in ("/", "/image-studio/"):
                        self.respond(200, application.index_path.read_bytes(), "text/html; charset=utf-8")
                        return
                    if path == "/healthz":
                        status = application.engine.readiness()
                        self.respond(200 if status.get("ready") else 503,
                                     {"ready": bool(status.get("ready")), "service": "image-studio"})
                        return
                    if not self.protected():
                        return
                    if path == "/api/status":
                        self.respond(200, application.engine.status())
                        return
                    match = re.fullmatch(r"/api/jobs/([a-f0-9]{32})(?:/(image|settings))?", path)
                    if match:
                        job_id, output = match.groups()
                        if not output:
                            self.respond(200, application.engine.get_job(job_id))
                        else:
                            extension = "png" if output == "image" else "json"
                            file = application.engine.output_path(job_id, extension)
                            if file.stat().st_size > 30 * 1024**2:
                                raise EngineError("ผลลัพธ์ใหญ่เกินขนาดที่รองรับ")
                            self.respond(200, file.read_bytes(), "image/png" if output == "image" else "application/json; charset=utf-8",
                                         {"Content-Disposition": ('inline' if output == "image" else 'attachment') + '; filename="image-' + job_id[:8] + '.' + extension + '"'})
                        return
                    self.error(404, "ไม่พบหน้านี้")
                except (BrokenPipeError, ConnectionResetError):
                    return
                except (ValueError, OSError):
                    self.error(400, "อ่านสถานะหรือไฟล์ผลลัพธ์ไม่ได้ กรุณาตรวจงานเดิม")
                except Exception:
                    self.error(500, "ระบบอ่านผลลัพธ์ไม่สำเร็จ กรุณาตรวจ Logs ของ Pod")

            def do_POST(self):
                try:
                    if not self.mutation():
                        return
                    path = urlsplit(self.path).path
                    if path == "/api/login":
                        body = self.body()
                        token, status = application.login(body.get("code"), self.client_address[0])
                        if not token:
                            self.error(status, "รอ 1 นาทีแล้วลองใหม่" if status == 429 else "รหัสไม่ถูกต้อง")
                            return
                        cookie = "image_session=" + token + "; Path=/; HttpOnly; SameSite=Strict; Max-Age=86400"
                        if self.headers.get("X-Forwarded-Proto", "").lower() == "https":
                            cookie += "; Secure"
                        self.respond(200, {"ok": True}, headers={"Set-Cookie": cookie})
                        return
                    if not self.protected():
                        return
                    body = self.body()
                    if path in ("/api/generate", "/api/jobs"):
                        self.respond(200, application.engine.submit(body))
                        return
                    match = re.fullmatch(r"/api/jobs/([a-f0-9]{32})/recover", path)
                    if match:
                        if body:
                            raise ValueError("คำขอกู้ผลต้องไม่แก้ค่าของงานเดิม")
                        self.respond(200, application.engine.recover(match.group(1)))
                        return
                    self.error(404, "ไม่พบคำสั่งนี้")
                except EngineError as error:
                    self.error(409, error)
                except ValueError as error:
                    self.error(400, error)
                except (OSError, TimeoutError):
                    self.error(503, "ติดต่อ GPU หรือบันทึกคำขอไม่ได้ ตรวจงานเดิมก่อนกดสร้างซ้ำ")
                except Exception:
                    self.error(500, "ระบบสร้างภาพขัดข้อง ตรวจสถานะก่อนกดสร้างซ้ำ")

        return Handler


def main():
    server = None
    engine = None
    try:
        port = int(os.environ.get("APP_PORT", "5000"))
        if not 1024 <= port <= 65535:
            raise ValueError("APP_PORT ต้องเป็นพอร์ต 1024–65535")
        engine = Engine(os.environ.get("STUDIO_DATA_ROOT", "/workspace/image-studio-data"),
                        os.environ.get("MODELS_ROOT", "/workspace/models"),
                        os.environ.get("COMFY_INTERNAL_PORT", "8189"))
        application = Application(engine, os.environ.get("IMAGE_STUDIO_CODE", ""))
        server = ThreadingHTTPServer(("0.0.0.0", port), application.handler())
        print("IMAGE_STUDIO_APP_STARTED", flush=True)
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    except Exception as error:
        print("IMAGE_STUDIO_APP_FAILED: " + (str(error)[:400] if isinstance(error, ValueError)
                                              else "ตรวจ Logs ของ Pod และค่า Deploy"), flush=True)
        raise SystemExit(1)
    finally:
        if engine:
            engine.close()
        if server:
            server.server_close()


if __name__ == "__main__":
    main()
