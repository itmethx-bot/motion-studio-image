"""Install pinned code/dependencies during Docker build; never fetch model weights."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import sys


def clone(entry, path):
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', entry['repo']):
        raise ValueError('ชื่อ repository ไม่ถูกต้อง')
    if not re.fullmatch(r'[a-f0-9]{40}', entry['commit']):
        raise ValueError('ต้องระบุ commit เต็มเพื่อทำซ้ำได้')
    # ใช้ source จากเจ้าของโครงการ ไม่รัน install.py ที่อาจดึงโมเดลระหว่าง build
    subprocess.run(['git', 'init', str(path)], check=True)
    subprocess.run(['git', '-C', str(path), 'remote', 'add', 'origin', 'https://github.com/' + entry['repo'] + '.git'], check=True)
    subprocess.run(['git', '-C', str(path), 'fetch', '--depth', '1', 'origin', entry['commit']], check=True)
    subprocess.run(['git', '-C', str(path), 'checkout', '--detach', 'FETCH_HEAD'], check=True)
    actual = subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != entry['commit']:
        raise ValueError('commit ที่ติดตั้งไม่ตรงกับ lock')


def install_requirements(path, constraints):
    requirements = path / 'requirements.txt'
    if requirements.is_file():
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-c', str(constraints), '-r', str(requirements)], check=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--lock', type=Path, required=True)
    p.add_argument('--constraints', type=Path, required=True)
    args = p.parse_args()
    lock = json.loads(args.lock.read_text(encoding='utf-8'))
    clone(lock['comfy'], args.root)
    install_requirements(args.root, args.constraints)
    for entry in lock['nodes']:
        if not re.fullmatch(r'[A-Za-z0-9_.-]+', entry['directory']):
            raise ValueError('ชื่อโฟลเดอร์ node ไม่ถูกต้อง')
        path = args.root / 'custom_nodes' / entry['directory']
        clone(entry, path)
        install_requirements(path, args.constraints)
    # ย้ายเพียงโครง placeholder ที่มากับ Git ภายใน image ไม่แตะ Network Volume
    models = args.root / 'models'
    if models.exists():
        for file in models.rglob('*'):
            if file.is_file() and file.suffix.lower() in ('.safetensors', '.ckpt', '.pt', '.pth', '.onnx', '.bin'):
                raise ValueError('พบโมเดลใน source ระหว่าง build จึงหยุดก่อนแพ็ก image')
        models.rename(args.root / 'model-path-reference')


if __name__ == '__main__':
    main()
