#!/usr/bin/env python3
"""เปิด/ลบ Image Studio Pod จากเครื่องผู้ใช้ โดยไม่ลบ Network Volume."""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
import traceback
import uuid
import webbrowser

try:
    import requests
except ImportError:
    requests = None

API_ROOT = "https://rest.runpod.io/v1"
HERE = Path(__file__).resolve().parent
DEFAULTS = {
    "RUNPOD_GPU_TYPE_IDS": "NVIDIA GeForce RTX 4090",
    "CONTAINER_DISK_GB": "40",
    "APP_PORT": "5000",
    "COMFY_PORT": "8188",
    "STARTUP_TIMEOUT_SECONDS": "1800",
    "BOOTSTRAP_MODELS": "0",
    "MODEL_GROUPS": "sdxl,character,pose,segmentation",
}
STATE_FIELDS = {
    "version", "phase", "request_name", "attempt", "created_at", "pod_id",
    "template_id", "network_volume_id", "data_center_id", "gpu_type_ids",
    "app_port", "comfy_port", "container_disk_gb", "last_status", "app_ready",
}
ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,100}$")


class LauncherError(Exception):
    """ข้อผิดพลาดที่อธิบายให้ผู้ใช้ได้ โดยไม่มีข้อมูลลับ."""


class ApiError(LauncherError):
    def __init__(self, method, status, gpu_unavailable=False):
        self.method = method
        self.status = status
        self.gpu_unavailable = gpu_unavailable
        messages = {
            401: "API key ไม่ถูกต้องหรือหมดอายุ ให้แก้ RUNPOD_API_KEY ใน config.env",
            403: "API key ไม่มีสิทธิ์สำหรับคำสั่งนี้ ให้ตรวจสิทธิ์ Pods และ Network Volumes",
            404: "ไม่พบรายการนี้ในบัญชี RunPod ที่ใช้ API key นี้",
            429: "ส่งคำขอถี่เกินไป กรุณารอสักครู่แล้วเลือกตรวจสถานะ",
        }
        text = messages.get(status, f"RunPod ตอบ HTTP {status} ขณะ {method}; ให้ตรวจสถานะก่อนลองใหม่")
        if gpu_unavailable:
            text = "GPU ที่เลือกยังไม่ว่างในศูนย์ข้อมูลของ Network Volume"
        super().__init__(text)


class TransportError(LauncherError):
    pass


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def _unquote_env(value, line_number):
    value = value.strip()
    if value.startswith(("'", '"')):
        quote = value[0]
        closing = value.rfind(quote)
        tail = value[closing + 1:].strip()
        if closing == 0 or (tail and not tail.startswith("#")):
            raise LauncherError(f"config.env บรรทัด {line_number}: เครื่องหมายคำพูดปิดไม่ถูกต้อง")
        return value[1:closing]
    # รองรับ comment ต่อท้าย แต่ไม่ตีความ shell หรือแทนค่า $VARIABLE
    return re.split(r"\s+#", value, maxsplit=1)[0].strip()


def read_config(path, environ=None):
    values = dict(DEFAULTS)
    path = Path(path)
    if path.exists():
        try:
            lines = path.read_text(encoding="utf-8-sig").splitlines()
        except OSError as exc:
            raise LauncherError("อ่าน config.env ไม่ได้ กรุณาตรวจสิทธิ์อ่านไฟล์") from exc
        for number, raw in enumerate(lines, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].lstrip()
            if "=" not in line:
                raise LauncherError(f"config.env บรรทัด {number}: ต้องเขียน ชื่อตัวแปร=ค่า")
            key, value = line.split("=", 1)
            key = key.strip()
            if not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
                raise LauncherError(f"config.env บรรทัด {number}: ชื่อตัวแปรไม่ถูกต้อง")
            values[key] = _unquote_env(value, number)
    env = os.environ if environ is None else environ
    allowed = set(DEFAULTS) | {
        "RUNPOD_API_KEY", "RUNPOD_TEMPLATE_ID", "RUNPOD_NETWORK_VOLUME_ID",
        "RUNPOD_DATACENTER_IDS", "APP_ACCESS_CODE",
    }
    values.update({key: str(env[key]) for key in allowed if key in env})
    return values


def require(values, *keys):
    missing = [key for key in keys if not values.get(key, "").strip()]
    if missing:
        raise LauncherError("ยังไม่ได้ตั้งค่า " + ", ".join(missing)
                            + " — เปิด config.env แล้วใส่ค่า ชื่อตัวแปร=ค่า ตาม config.example.env")


def parse_list(value, name):
    value = value.strip()
    try:
        result = json.loads(value) if value.startswith("[") else value.split(",")
    except json.JSONDecodeError as exc:
        raise LauncherError(f"{name} ต้องเป็นชื่อคั่นด้วย comma หรือ JSON list") from exc
    if not isinstance(result, list) or not result or any(not isinstance(x, str) or not x.strip() for x in result):
        raise LauncherError(f"{name} ต้องมีชื่ออย่างน้อยหนึ่งรายการ เช่น [\"EU-RO-1\"]")
    result = [item.strip() for item in result]
    if any("\n" in item or len(item) > 160 for item in result):
        raise LauncherError(f"{name} มีค่าที่ไม่ถูกต้อง")
    return list(dict.fromkeys(result))


def integer(values, key, minimum, maximum):
    try:
        value = int(values[key])
    except (KeyError, TypeError, ValueError) as exc:
        raise LauncherError(f"{key} ต้องเป็นจำนวนเต็ม") from exc
    if not minimum <= value <= maximum:
        raise LauncherError(f"{key} ต้องอยู่ระหว่าง {minimum}–{maximum}")
    return value


def validate_start(values):
    require(values, "RUNPOD_API_KEY", "RUNPOD_TEMPLATE_ID", "RUNPOD_NETWORK_VOLUME_ID",
            "RUNPOD_DATACENTER_IDS", "RUNPOD_GPU_TYPE_IDS", "APP_ACCESS_CODE")
    for key in ("RUNPOD_TEMPLATE_ID", "RUNPOD_NETWORK_VOLUME_ID"):
        if not ID_PATTERN.fullmatch(values[key]):
            raise LauncherError(f"{key} ต้องเป็น ID จาก RunPod ไม่ใช่ URL หรือชื่อที่ตั้งเอง")
    if len(values["APP_ACCESS_CODE"]) < 12:
        raise LauncherError("APP_ACCESS_CODE ต้องยาวอย่างน้อย 12 ตัวอักษร เพื่อป้องกันหน้าแอปบนอินเทอร์เน็ต")
    bootstrap = values.get("BOOTSTRAP_MODELS", "0").strip()
    if bootstrap not in ("0", "1"):
        raise LauncherError("BOOTSTRAP_MODELS ต้องเป็น 0 (ใช้โมเดลเดิม) หรือ 1 (ติดตั้งโมเดลครั้งแรก)")
    groups = parse_list(values.get("MODEL_GROUPS", "sdxl,character,pose,segmentation"), "MODEL_GROUPS")
    if set(groups) - {"sdxl", "character", "pose", "segmentation", "cloud"}:
        raise LauncherError("MODEL_GROUPS ใช้ได้เฉพาะ sdxl,character,pose,segmentation,cloud คั่นด้วย comma")
    result = {
        "gpu_type_ids": parse_list(values["RUNPOD_GPU_TYPE_IDS"], "RUNPOD_GPU_TYPE_IDS"),
        "data_center_ids": parse_list(values["RUNPOD_DATACENTER_IDS"], "RUNPOD_DATACENTER_IDS"),
        "container_disk_gb": integer(values, "CONTAINER_DISK_GB", 20, 2000),
        "app_port": integer(values, "APP_PORT", 1, 65535),
        "comfy_port": integer(values, "COMFY_PORT", 1, 65535),
        "startup_timeout": integer(values, "STARTUP_TIMEOUT_SECONDS", 60, 7200),
        "bootstrap_models": bootstrap,
        "model_groups": ",".join(groups),
    }
    if result["app_port"] == result["comfy_port"]:
        raise LauncherError("APP_PORT และ COMFY_PORT ต้องไม่ซ้ำกัน")
    return result


class Redactor:
    def __init__(self, values):
        self.secrets = [values[key] for key in ("RUNPOD_API_KEY", "APP_ACCESS_CODE") if values.get(key)]

    def __call__(self, message):
        text = str(message)
        for secret in sorted(self.secrets, key=len, reverse=True):
            text = text.replace(secret, "[ปิดบังข้อมูลลับ]")
        text = re.sub(r"(?i)(Bearer\s+)[^\s\"']+", r"\1[REDACTED]", text)
        return text


class StateStore:
    def __init__(self, path):
        self.path = Path(path)
        self.lock_path = self.path.with_name(self.path.name + ".lock")

    @contextlib.contextmanager
    def locked(self):
        """ล็อกข้าม process จริง ป้องกันเปิด launcher สองหน้าต่างแล้วเช่าซ้ำ."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.lock_path.open("a+b")
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            handle.close()
            raise LauncherError("มี launcher อีกหน้าต่างกำลังทำงาน ให้รอหรือปิดหน้าต่างนั้นก่อน") from exc
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()

    def load(self):
        if not self.path.exists():
            return {}
        try:
            state = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise LauncherError("อ่าน state.json ไม่ได้ ห้ามลบไฟล์นี้ก่อนตรวจ Pods ใน RunPod เพราะอาจมีเครื่องเช่าอยู่") from exc
        if not isinstance(state, dict) or set(state) - STATE_FIELDS:
            raise LauncherError("state.json มีรูปแบบไม่ถูกต้อง ให้สำรองไฟล์และตรวจ Pods ก่อนแก้")
        for field in ("pod_id", "template_id", "network_volume_id"):
            if state.get(field) and not ID_PATTERN.fullmatch(str(state[field])):
                raise LauncherError("state.json มี ID ไม่ถูกต้อง จึงยังไม่ส่งคำสั่งไป RunPod")
        if state and state.get("version") != 1:
            raise LauncherError("state.json เป็นรุ่นที่ไม่รองรับ กรุณาตรวจ Pods ก่อนเปลี่ยนไฟล์")
        return state

    def save(self, state):
        if set(state) - STATE_FIELDS:
            raise LauncherError("ปฏิเสธการบันทึกข้อมูลที่ไม่ใช่สถานะ Pod")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=".state-", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(state, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.chmod(name, 0o600)
            except OSError:
                pass
            os.replace(name, self.path)
        finally:
            if os.path.exists(name):
                os.unlink(name)


class RunPodAPI:
    def __init__(self, key, session=None):
        if requests is None:
            raise LauncherError("ยังไม่มี requests ให้รัน python -m pip install requests")
        self.session = session or requests.Session()
        self.session.trust_env = False
        self.session.headers.update({"Authorization": f"Bearer {key}", "Content-Type": "application/json"})

    def call(self, method, path, payload=None, params=None, allow_404=False):
        # API key อยู่เฉพาะ header นี้ ไม่ใส่ใน state, URL หรือ env ของ Pod
        try:
            response = self.session.request(method, API_ROOT + path, json=payload, params=params,
                                            timeout=(10, 60), allow_redirects=False)
        except requests.RequestException as exc:
            raise TransportError("เชื่อมต่อ RunPod ไม่สำเร็จหรือหมดเวลารอ; ไม่ยืนยันว่าคำสั่งมีผลหรือไม่") from exc
        if response.status_code == 404 and allow_404:
            return None
        if not 200 <= response.status_code < 300:
            raw = response.text[:10000].lower()
            capacity = response.status_code in (400, 409) and bool(re.search(
                r"(gpu|machine|instance|capacity).{0,100}(not available|unavailable|no available|insufficient|out of stock|not enough)|"
                r"(no available|insufficient|not enough).{0,100}(gpu|machine|instance|capacity)", raw))
            raise ApiError(method, response.status_code, capacity)
        if response.status_code == 204 or not response.content:
            return {}
        try:
            return response.json()
        except ValueError as exc:
            raise TransportError("RunPod ส่งข้อมูลที่อ่านไม่ได้; ให้ตรวจสถานะก่อนลองคำสั่งเดิม") from exc

    def get_pod(self, pod_id):
        return self.call("GET", f"/pods/{pod_id}", allow_404=True,
                         params={"includeNetworkVolume": "true"})

    def find_created(self, name):
        result = self.call("GET", "/pods", params={"name": name, "includeNetworkVolume": "true"})
        if not isinstance(result, list):
            raise LauncherError("RunPod ส่งรายการ Pod ที่อ่านไม่ได้ จึงยังไม่สร้างเครื่องเพิ่ม")
        return [item for item in result if isinstance(item, dict) and item.get("name") == name]


class Launcher:
    def __init__(self, values, store, api=None, printer=print, ask=input,
                 sleep=time.sleep, clock=time.monotonic, opener=webbrowser.open, health_session=None):
        self.values = values
        self.store = store
        require(values, "RUNPOD_API_KEY")
        self.api = api or RunPodAPI(values["RUNPOD_API_KEY"])
        self.print = printer
        self.ask = ask
        self.sleep = sleep
        self.clock = clock
        self.opener = opener
        self.health_session = health_session

    def _owned(self, state, pod):
        if not isinstance(pod, dict) or not ID_PATTERN.fullmatch(str(pod.get("id", ""))):
            raise LauncherError("RunPod ส่ง ID ที่อ่านไม่ได้ จึงไม่เปลี่ยนสถานะเครื่อง")
        if state.get("pod_id") and pod["id"] != state["pod_id"]:
            raise LauncherError("Pod ID ไม่ตรงกับ state.json จึงไม่ส่งคำสั่งลบ")
        if not state.get("request_name") or pod.get("name") != state["request_name"]:
            raise LauncherError("ชื่อ Pod ไม่ตรงกับเครื่องที่ launcher สร้าง จึงไม่ส่งคำสั่งลบหรือใช้แทน")
        volume = pod.get("networkVolumeId") or (pod.get("networkVolume") or {}).get("id")
        if volume and volume != state.get("network_volume_id"):
            raise LauncherError("Network Volume ไม่ตรงกับสถานะที่บันทึกไว้ จึงยังไม่ใช้เครื่องนี้")
        return pod

    def _remember_pod(self, state, pod):
        self._owned(state, pod)
        state.update(pod_id=pod["id"], phase="active", last_status=pod.get("desiredStatus", "UNKNOWN"), app_ready=False)
        self.store.save(state)
        return state

    def _resolve(self, state):
        if not state:
            return None
        if state.get("pod_id"):
            pod = self.api.get_pod(state["pod_id"])
            if pod is None:
                self.store.save({})
                self.print("ยืนยันแล้วว่า Pod เดิมไม่อยู่ในบัญชีนี้; Network Volume ไม่ถูกลบ")
                return None
            return self._owned(state, pod)
        if state.get("phase") in ("creating", "unknown"):
            pods = self.api.find_created(state["request_name"])
            if len(pods) != 1:
                detail = "ยังไม่พบ" if not pods else "พบมากกว่าหนึ่งเครื่อง"
                raise LauncherError(f"คำขอสร้างเดิมยังไม่ยืนยัน ({detail}): {state['request_name']}\n"
                                    "ไม่สร้างซ้ำเพื่อป้องกันค่าเช่าซ้ำ ให้ตรวจ Pods/Logs แล้วเลือก Status อีกครั้ง; อย่าลบ state.json")
            self._remember_pod(state, pods[0])
            self.print(f"พบเครื่องจากคำขอเดิมแล้ว: {state['pod_id']}; ไม่สร้างซ้ำ")
            return pods[0]
        raise LauncherError("สถานะคำขอเดิมไม่ถูกต้อง จึงยังไม่สร้าง Pod เพิ่ม")

    def _url(self, state):
        port = int(state.get("app_port", self.values.get("APP_PORT", "5000")))
        if not 1 <= port <= 65535:
            raise LauncherError("พอร์ตแอปใน state.json ไม่ถูกต้อง")
        return f"https://{state['pod_id']}-{port}.proxy.runpod.net"

    def _ready(self, url):
        if requests is None:
            return False
        if self.health_session is None:
            self.health_session = requests.Session()
            self.health_session.trust_env = False
        try:
            response = self.health_session.get(url + "/healthz", timeout=(5, 10), allow_redirects=False)
            if response.status_code != 200:
                return False
            payload = response.json()
            return isinstance(payload, dict) and payload.get("ready") is True
        except (requests.RequestException, ValueError):
            return False

    def _wait(self, state, open_browser=True):
        timeout = integer(self.values, "STARTUP_TIMEOUT_SECONDS", 60, 7200)
        deadline = self.clock() + timeout
        self.print("รอ Pod และ ComfyUI พร้อมใช้งาน อาจใช้เวลาหลายนาที; Ctrl+C หยุดรอได้ แต่ไม่หยุดค่าเช่า")
        previous = None
        while self.clock() < deadline:
            try:
                pod = self.api.get_pod(state["pod_id"])
            except (TransportError, ApiError) as exc:
                if isinstance(exc, ApiError) and exc.status in (401, 403):
                    raise
                self.sleep(10)
                continue
            if pod is None:
                self.store.save({})
                raise LauncherError("Pod ถูกลบระหว่างรอ ให้ตรวจ RunPod ก่อนเริ่มใหม่")
            self._owned(state, pod)
            status = pod.get("desiredStatus", "UNKNOWN")
            if status != previous:
                self.print(f"สถานะ Pod: {status}")
                previous = status
            state.update(last_status=status)
            self.store.save(state)
            if status in ("EXITED", "TERMINATED"):
                raise LauncherError("Pod หยุดแล้ว ให้เปิด Logs ใน RunPod ตรวจสาเหตุ หรือเลือก Terminate ก่อนสร้างใหม่")
            url = self._url(state)
            # RUNNING เป็น desiredStatus; ต้องตรวจ HTTP health จริงก่อนประกาศว่าใช้งานได้
            if status == "RUNNING" and self._ready(url):
                state.update(app_ready=True)
                self.store.save(state)
                self.print(f"พร้อมใช้งาน: {url}")
                if open_browser:
                    try:
                        self.opener(url)
                    except Exception:
                        self.print("เปิดเบราว์เซอร์อัตโนมัติไม่ได้ ให้คัดลอก URL ด้านบน")
                return url
            self.sleep(10)
        raise LauncherError(f"ยังไม่พร้อมหลังรอ {timeout // 60} นาที เครื่องอาจยังคิดค่าเช่าอยู่\n"
                            "ตรวจ Logs ใน RunPod หรือเลือก [4] Terminate; โปรแกรมไม่ได้ลบเครื่องอัตโนมัติ")

    def start(self):
        # ถ้า config ที่ใช้สร้างเปลี่ยนไป ก็ยังจัดการเครื่องเดิมได้โดยไม่สร้างซ้ำ
        state = self.store.load()
        pod = self._resolve(state)
        if pod:
            self.print(f"มี Pod เดิม: {pod['id']} ({pod.get('desiredStatus', 'UNKNOWN')})")
            if self.ask("ใช้เครื่องเดิมไหม? พิมพ์ y เพื่อใช้: ").strip().lower() != "y":
                self.print("ยังไม่สร้างเครื่องเพิ่ม ให้เลือก [4] ปิดและลบ Pod เดิมก่อน")
                return None
            return self._wait(state)
        state = {}
        settings = validate_start(self.values)
        volume = self.api.call("GET", f"/networkvolumes/{self.values['RUNPOD_NETWORK_VOLUME_ID']}")
        if not isinstance(volume, dict) or volume.get("id") != self.values["RUNPOD_NETWORK_VOLUME_ID"]:
            raise LauncherError("ข้อมูล Network Volume ไม่ถูกต้อง จึงไม่เริ่มเช่า")
        data_center = volume.get("dataCenterId")
        if data_center not in settings["data_center_ids"]:
            raise LauncherError("ศูนย์ข้อมูลใน RUNPOD_DATACENTER_IDS ไม่ตรงกับ Network Volume\n"
                                f"ให้ใส่ RUNPOD_DATACENTER_IDS={data_center or 'ID จากหน้า Volume'} ใน config.env")
        name = "image-studio-" + uuid.uuid4().hex[:24]
        state = {
            "version": 1, "phase": "creating", "request_name": name, "attempt": 0,
            "created_at": utc_now(), "template_id": self.values["RUNPOD_TEMPLATE_ID"],
            "network_volume_id": self.values["RUNPOD_NETWORK_VOLUME_ID"], "data_center_id": data_center,
            "gpu_type_ids": settings["gpu_type_ids"], "app_port": settings["app_port"],
            "comfy_port": settings["comfy_port"], "container_disk_gb": settings["container_disk_gb"],
        }
        payload = {
            "name": name, "templateId": state["template_id"], "computeType": "GPU",
            "cloudType": "SECURE", "gpuCount": 1, "gpuTypeIds": settings["gpu_type_ids"],
            "dataCenterIds": [data_center], "networkVolumeId": state["network_volume_id"],
            "containerDiskInGb": settings["container_disk_gb"], "volumeInGb": 0,
            "volumeMountPath": "/workspace", "interruptible": False,
            "allowedCudaVersions": ["12.8", "12.9", "13.0"],
            "ports": [f"{settings['app_port']}/http", f"{settings['comfy_port']}/http"],
            "env": {"MODELS_ROOT": "/workspace/models", "APP_PORT": str(settings["app_port"]),
                    "COMFY_PORT": str(settings["comfy_port"]), "COMFY_INTERNAL_PORT": "8189",
                    "BOOTSTRAP_MODELS": settings["bootstrap_models"], "MODEL_GROUPS": settings["model_groups"],
                    "IMAGE_STUDIO_CODE": self.values["APP_ACCESS_CODE"]},
        }
        self.print("กำลังสร้าง Pod; จะเริ่มมีค่าเช่าเมื่อ RunPod จัดสรรเครื่อง และ Volume มีค่าเก็บข้อมูลแยก")
        for attempt in range(1, 4):
            # บันทึกก่อน POST ทุกครั้ง แม้โปรแกรมปิดกะทันหันก็ไม่ทำคำขอซ้ำโดยไม่ตรวจ
            state.update(attempt=attempt, phase="creating")
            self.store.save(state)
            try:
                created = self.api.call("POST", "/pods", payload=payload)
                self._remember_pod(state, created)
            except ApiError as exc:
                if exc.gpu_unavailable:
                    if attempt < 3:
                        self.print(f"GPU ยังไม่ว่าง (ครั้งที่ {attempt}/3) ลองใหม่ใน 10 วินาที")
                        self.sleep(10)
                        continue
                    self.store.save({})
                    raise LauncherError("GPU ยังไม่ว่างหลังลอง 3 ครั้ง ไม่มี Pod ที่สร้างสำเร็จจากคำขอเหล่านี้\n"
                                        "ลองภายหลัง หรือเลือก GPU อื่นที่รองรับในศูนย์ข้อมูลเดียวกับ Volume") from exc
                if exc.status < 500 and exc.status not in (408, 429):
                    self.store.save({})
                    raise
                state["phase"] = "unknown"
                self.store.save(state)
                return self._reconcile_then_wait(state)
            except (TransportError, LauncherError) as exc:
                # timeout / 5xx / malformed response อาจสร้างจริงแล้ว ห้าม POST ซ้ำ
                state["phase"] = "unknown"
                self.store.save(state)
                return self._reconcile_then_wait(state)
            # ความผิดพลาดระหว่างรอแอปไม่ใช่คำขอสร้างที่คลุมเครือ และไม่ส่ง POST ใหม่
            return self._wait(state)
        return None

    def _reconcile_then_wait(self, state):
        self.print("ยังยืนยันคำขอสร้างไม่ได้ กำลังค้นหาชื่อเครื่องเดิม โดยไม่สร้างซ้ำ")
        self._resolve(state)
        return self._wait(state)

    def status(self):
        state = self.store.load()
        pod = self._resolve(state)
        if not pod:
            self.print("ไม่มี Pod ที่ launcher นี้กำลังจัดการ")
            return None
        status = pod.get("desiredStatus", "UNKNOWN")
        ready = status == "RUNNING" and self._ready(self._url(state))
        state.update(last_status=status, app_ready=ready)
        self.store.save(state)
        self.print(f"Pod: {pod['id']} | สถานะ: {status} | แอป: {'พร้อม' if ready else 'ยังไม่พร้อม'}")
        price = pod.get("adjustedCostPerHr", pod.get("costPerHr"))
        if isinstance(price, (str, int, float)) and re.fullmatch(r"\d+(\.\d+)?", str(price)):
            self.print(f"ค่า Pod ประมาณ ${price}/ชั่วโมง (ไม่รวมค่าเก็บ Network Volume)")
        self.print(f"URL: {self._url(state)}")
        self.print("ออกจาก launcher หรือปิดแท็บไม่หยุดค่าเช่า ให้เลือก [4] เมื่อเลิกใช้")
        return pod

    def open(self):
        state = self.store.load()
        pod = self._resolve(state)
        if not pod:
            raise LauncherError("ยังไม่มี Pod ให้เลือก [1] เริ่มใช้งานก่อน")
        return self._wait(state)

    def terminate(self, yes=False):
        state = self.store.load()
        pod = self._resolve(state)
        if not pod:
            self.print("ไม่มี Pod ที่ต้องลบ")
            return False
        self.print(f"กำลังจะปิดและลบ Pod {pod['id']} ({state['request_name']})")
        self.print("Network Volume ไม่หาย โมเดลไม่ต้องโหลดใหม่; ข้อมูลบน container disk จะหาย\n"
                   "ดาวน์โหลดผลงานสำคัญก่อนลบ และ Volume ยังมีค่าเก็บข้อมูลจนกว่าจะลบเอง")
        if not yes and self.ask("ยืนยัน Terminate? พิมพ์ y: ").strip().lower() != "y":
            self.print("ยกเลิกการลบ Pod; ถ้าเครื่องยังทำงานอยู่ ค่าเช่ายังเดิน")
            return False
        # ห้ามมี DELETE networkvolumes ใน launcher นี้
        try:
            self.api.call("DELETE", f"/pods/{pod['id']}", allow_404=True)
        except (ApiError, TransportError):
            current = self.api.get_pod(pod["id"])
            if current is not None:
                raise LauncherError("ยังยืนยันการลบ Pod ไม่ได้ สถานะเดิมถูกเก็บไว้ ให้เลือก Status แล้วตรวจ Console")
        for attempt in range(6):
            current = self.api.get_pod(pod["id"])
            if current is None:
                self.store.save({})
                self.print("ยืนยันแล้วว่า Pod ถูกลบ; Network Volume และโมเดลยังอยู่")
                return True
            self._owned(state, current)
            if attempt < 5:
                self.sleep(2)
        raise LauncherError("ส่งคำขอลบแล้ว แต่ยังยืนยันว่า Pod หายไม่ได้; state.json ยังอยู่ ให้เลือก Status เพื่อตรวจอีกครั้ง")


def parser():
    result = argparse.ArgumentParser(description="Image Studio — เปิด Pod ใช้ เสร็จแล้วลบเครื่อง")
    action = result.add_mutually_exclusive_group()
    action.add_argument("--start", action="store_true", help="เริ่ม Pod แล้วเปิดแอป")
    action.add_argument("--stop", action="store_true", help="ยืนยันและ Terminate Pod (ไม่ลบ Volume)")
    action.add_argument("--status", action="store_true", help="ตรวจสถานะเครื่องเดิม")
    result.add_argument("--yes", action="store_true", help="ยืนยัน Terminate สำหรับ --stop โดยไม่ถามซ้ำ")
    result.add_argument("--debug", action="store_true", help="แสดง traceback ที่ปิดบัง key และรหัสแล้ว")
    result.add_argument("--config", type=Path, default=HERE / "config.env")
    result.add_argument("--state", type=Path, default=HERE / "state.json")
    return result


def configure_cli_encoding():
    """บังคับ UTF-8 สำหรับข้อความไทย แม้ PowerShell pipe ตั้ง locale เป็น cp1252."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="backslashreplace")
            except (OSError, ValueError, AttributeError):
                # StringIO หรือ stream ของโปรแกรมเรียกใช้อาจไม่รองรับ ห้ามปิด/แทน stream
                pass


def main(argv=None):
    configure_cli_encoding()
    options = parser().parse_args(argv)
    if options.yes and not options.stop:
        parser().error("--yes ใช้ได้กับ --stop เท่านั้น")
    if requests is None:
        print("ยังไม่มี requests ให้รัน python -m pip install requests แล้วเปิด launcher ใหม่")
        return 2
    redact = Redactor({})
    try:
        def invoke(action):
            nonlocal redact
            # อ่าน config ใหม่ทุกคำสั่ง เพื่อแก้ค่าในไฟล์แล้วใช้งานต่อได้
            values = read_config(options.config)
            redact = Redactor(values)
            require(values, "RUNPOD_API_KEY")
            store = StateStore(options.state)
            app = Launcher(values, store, printer=lambda message: print(redact(message)))
            with store.locked():
                if action == "start":
                    app.start()
                elif action == "open":
                    app.open()
                elif action == "stop":
                    app.terminate(yes=options.yes)
                else:
                    app.status()

        if options.start or options.stop or options.status:
            invoke("start" if options.start else "stop" if options.stop else "status")
            return 0
        # แสดง state ในเครื่องก่อนส่ง HTTP โดยไม่เผย API key
        saved = StateStore(options.state).load()
        if saved:
            print(f"สถานะเดิม: Pod {saved.get('pod_id', 'ยังไม่ยืนยัน')} | คำขอ {saved.get('request_name', '-')} | {saved.get('phase', '-')}")
        while True:
            print("\nImage Studio บน RunPod\n[1] เริ่มใช้งาน (Start pod)\n[2] เปิดหน้าแอป (Open)\n[3] ตรวจสถานะ (Status)\n[4] ปิดและลบ pod (Terminate)\n[5] ออกจากโปรแกรม")
            choice = input("เลือกหมายเลข: ").strip()
            if choice == "5":
                if StateStore(options.state).load():
                    print("ออกจากโปรแกรมแล้ว แต่ Pod อาจยังคิดค่าเช่าอยู่ เปิด launcher แล้วเลือก [4] เมื่อเลิกใช้")
                return 0
            if choice not in ("1", "2", "3", "4"):
                print("กรุณาเลือกหมายเลข 1–5")
                continue
            try:
                invoke({"1": "start", "2": "open", "3": "status", "4": "stop"}[choice])
            except Exception as exc:
                print(redact("ทำรายการไม่สำเร็จ: " + (str(exc) if isinstance(exc, LauncherError) else "พบข้อผิดพลาดในเครื่อง ให้ลอง --debug เพื่อตรวจ")))
                if options.debug:
                    print(redact(traceback.format_exc()))
    except (KeyboardInterrupt, EOFError):
        print("\nหยุดโปรแกรมแล้ว; ไม่ได้ลบ Pod อัตโนมัติ ให้ตรวจสถานะและ Terminate เมื่อเลิกใช้")
        return 130
    except Exception as exc:
        print(redact("ทำรายการไม่สำเร็จ: " + (str(exc) if isinstance(exc, LauncherError) else "พบข้อผิดพลาดในเครื่อง ให้ใช้ --debug เพื่อตรวจ")))
        if options.debug:
            print(redact(traceback.format_exc()))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
