// DOM regression checks without browser, npm packages, network, or GPU.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
let createdImages = 0, assignedSources = 0;
class Element {
  constructor(tag='div') { this.tagName=tag;this.children=[];this.parentNode=null;this.className='';this.value='';this._text='';this.disabled=false;this.hidden=false; }
  get classList() { return {contains: name => this.className.split(/\s+/).includes(name)}; }
  set textContent(value) { this._text=String(value);this.children.forEach(child=>child.parentNode=null);this.children=[]; }
  get textContent() { return this._text; }
  set src(value) { this._src=value;assignedSources++; }
  get src() { return this._src; }
  append(...children) { for(const child of children)this.insertBefore(child,null); }
  insertBefore(child, before) { if(child.parentNode)child.remove();const index=before===null?this.children.length:this.children.indexOf(before);assert(index>=0);this.children.splice(index,0,child);child.parentNode=this; }
  remove() { if(this.parentNode){const index=this.parentNode.children.indexOf(this);this.parentNode.children.splice(index,1);this.parentNode=null;} }
  replaceChildren(...children) { this.children.forEach(child=>child.parentNode=null);this.children=[];this.append(...children); }
  querySelectorAll(selector) { const found=[];for(const child of this.children){if(selector.startsWith('.')&&child.classList.contains(selector.slice(1)))found.push(child);found.push(...child.querySelectorAll(selector));}return found; }
  querySelector(selector) { return this.querySelectorAll(selector)[0]||null; }
  addEventListener() {}
}
const elements = new Map();
const document = {
  getElementById(id) { if(!elements.has(id))elements.set(id,new Element());return elements.get(id); },
  createElement(tag) { if(tag==='img')createdImages++;return new Element(tag); },
};
document.getElementById('model').value='juggernaut_x';
document.getElementById('prompt').value='a garden';
const context=vm.createContext({document,console,Date,Map,Set,JSON,Number,Error,crypto:{randomUUID:()=> 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'},setInterval:()=>1,clearInterval:()=>{},fetch:()=>{throw new Error('UI tests must not fetch');}});
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
let script=html.match(/<script>([\s\S]*?)<\/script>/)[1].replace(/\nrefresh\(\);\s*$/,'');
vm.runInContext(script,context);
function render(jobs){context.rows=jobs;vm.runInContext('renderJobs(rows)',context);}
function job(id,status='succeeded',message='ready'){return {id,created:1,status,message,plan:{model:'juggernaut_x',width:768,height:1152}};}
function image(card){return card.children.find(child=>child.tagName==='img');}
const container=document.getElementById('jobs');

const a=job('a'.repeat(32));
render([a]);
const firstCard=container.children[0], firstImage=image(firstCard);
assert(firstImage);
assert.equal(createdImages,1);
assert.equal(assignedSources,1);
for(let index=0;index<30;index++)render([structuredClone(a)]);
assert.equal(container.children[0],firstCard,'unchanged card must remain in DOM');
assert.equal(image(firstCard),firstImage,'unchanged PNG must retain its image node');
assert.equal(createdImages,1,'polling must not create another image');
assert.equal(assignedSources,1,'polling must not reassign image src');

render([{...a,message:'saved and verified'}]);
assert.equal(firstCard.children[2].textContent,'saved and verified');
assert.equal(image(firstCard),firstImage,'message updates must not reload completed PNG');

const b=job('b'.repeat(32),'running','step 1');
render([b,a]);
const secondCard=container.children[0];
assert.equal(container.children[1],firstCard,'newest job must be first');
render([{...b,message:'step 7'},a]);
assert.equal(container.children[0],secondCard,'same-status progress should update existing card');
assert.equal(secondCard.children[2].textContent,'step 7');
assert.equal(assignedSources,1);

render([{...b,status:'unknown',message:'response lost'},a]);
assert(secondCard.children.find(child=>child.tagName==='button').textContent.includes('กู้ผลเดิม'));
render([{...b,status:'succeeded'},a]);
const secondImage=image(secondCard);
assert(secondImage);
assert.equal(createdImages,2);
render([a,{...b,status:'succeeded'}]);
assert.equal(container.children[0],firstCard);
assert.equal(container.children[1],secondCard);
assert.equal(image(secondCard),secondImage);
assert.equal(assignedSources,2,'reordering must preserve image source');

render([{...a,message:'<img src=x onerror=alert(1)>'}]);
assert.equal(container.children.length,1,'removed job should be removed from DOM and cache');
assert.equal(firstCard.children[2].textContent,'<img src=x onerror=alert(1)>','server messages are plain text');
assert.equal(image(firstCard),firstImage);
render([]);render([]);
assert.equal(container.children.length,1,'empty state should be stable');
assert(container.children[0].classList.contains('empty-jobs'));
console.log('UI regression checks passed: PNG caching, order, progress, recover, removal, text safety.');
