import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import install_models as installer
from model_catalog import MODELS, select_models
import requests

URL = 'https://huggingface.co/test/model/resolve/' + 'a' * 40 + '/model.bin'


def entry(data=b'abcdef', ident='sample', digest=True):
    return dict(id=ident, path='checkpoints/' + ident + '.bin', bytes=len(data),
                checksum_algorithm='sha256', checksum=hashlib.sha256(data).hexdigest() if digest else None,
                url=URL)


class Response:
    def __init__(self, body=b'abcdef', status=200, headers=None, chunks=None):
        self.status_code = status
        self.headers = headers or {'Content-Length': str(len(body))}
        self.body = body
        self.raw = io.BytesIO(body)
        self.chunks = chunks
        self.closed = False

    def iter_content(self, chunk_size=None):
        if self.chunks is None:
            yield self.body
        else:
            for value in self.chunks:
                if isinstance(value, BaseException):
                    raise value
                yield value

    def close(self):
        self.closed = True


class Session:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []
        self.trust_env = False

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        value = self.responses.pop(0)
        if isinstance(value, BaseException):
            raise value
        return value


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.output = io.StringIO()
        self.errors = io.StringIO()
        self.stdout = contextlib.redirect_stdout(self.output)
        self.stderr = contextlib.redirect_stderr(self.errors)
        self.stdout.__enter__()
        self.stderr.__enter__()

    def tearDown(self):
        self.stderr.__exit__(None, None, None)
        self.stdout.__exit__(None, None, None)
        self.temp.cleanup()

    def install(self, items, session, **kwargs):
        return installer.install_all(self.root, items, session, reserve_bytes=0, sleep=lambda _: None, **kwargs)

    def target(self, item):
        path = self.root / item['path']
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def partial(self, item, data):
        path = self.target(item)
        Path(str(path) + '.part').write_bytes(data)
        Path(str(path) + '.part.json').write_text(json.dumps(installer.part_identity(item)))
        return path

    def test_catalog_complete_pinned_and_groups_disjoint(self):
        self.assertEqual(len(MODELS), 43)
        self.assertEqual(len({x['id'] for x in MODELS}), len(MODELS))
        self.assertEqual(len({x['path'] for x in MODELS}), len(MODELS))
        for item in MODELS:
            installer.validate_entry(self.root, item)
            if item['url'].startswith('https://huggingface.co/'):
                self.assertRegex(item['url'], '/resolve/[a-f0-9]{40}/')
        self.assertEqual({x['id'] for x in select_models(['sdxl'])}, {'sdxl', 'juggernaut_x', 'realvisxl'})
        self.assertIn('flux1_dev', {x['id'] for x in select_models(['cloud'])})
        with self.assertRaises(ValueError):
            select_models(['not_a_group'])

    def test_good_download_then_idempotent_skip(self):
        item = entry()
        session = Session(Response())
        self.assertEqual(self.install([item], session), {'sample': 'installed'})
        self.assertEqual(self.target(item).read_bytes(), b'abcdef')
        self.assertEqual(self.install([item], session), {'sample': 'skipped'})
        self.assertEqual(len(session.calls), 1)
        self.assertIn('100%', self.output.getvalue())
        self.assertIn('verified', self.output.getvalue())
        self.assertFalse(Path(str(self.target(item)) + '.part').exists())

    def test_first_download_sidecar_exact_original_schema(self):
        item = entry(digest=False)
        session = Session(Response(json.dumps([{'path': 'model.bin', 'type': 'file', 'size': 6,
                                                'oid': 'git_blob_hash_is_not_sha256'}]).encode()), Response())
        self.install([item], session)
        sidecar = json.loads((self.root / '.checksums.json').read_text())
        record = sidecar['artifacts'][item['path']]
        self.assertEqual(sidecar['version'], 1)
        self.assertEqual(record['source'], 'first_download')
        self.assertEqual(record['id'], item['id'])
        self.assertEqual(record['checksum'], hashlib.sha256(b'abcdef').hexdigest())
        self.assertIn('checksum recorded (first download)', self.output.getvalue())
        # อ้างอิง publisher ไม่มี hash แต่ครั้งต่อไปตรวจ sidecar ที่บันทึกได้
        self.assertTrue(installer.file_valid(self.target(item), installer.effective_entry(self.root, item)))

    def test_corrupt_existing_not_blindly_skipped(self):
        item = entry()
        self.target(item).write_bytes(b'badbad')
        session = Session(Response())
        self.assertEqual(self.install([item], session), {'sample': 'installed'})
        self.assertEqual(self.target(item).read_bytes(), b'abcdef')

    def test_resume_strict_range(self):
        item = entry()
        target = self.partial(item, b'ab')
        session = Session(Response(b'cdef', 206, {'Content-Length': '4', 'Content-Range': 'bytes 2-5/6'}))
        self.install([item], session)
        self.assertEqual(target.read_bytes(), b'abcdef')
        self.assertEqual(session.calls[0][2]['headers']['Range'], 'bytes=2-')

    def test_server_ignoring_range_restarts_not_appends(self):
        item = entry()
        target = self.partial(item, b'ab')
        self.install([item], Session(Response()))
        self.assertEqual(target.read_bytes(), b'abcdef')

    def test_incorrect_range_preserves_partial_and_fails(self):
        item = entry()
        target = self.partial(item, b'ab')
        session = Session(Response(b'cdef', 206, {'Content-Range': 'bytes 1-4/6'}))
        result = self.install([item], session)
        self.assertEqual(result['sample'], 'failed')
        self.assertEqual(Path(str(target) + '.part').read_bytes(), b'ab')
        self.assertFalse(target.exists())

    def test_connection_break_retries_and_resumes_once(self):
        item = entry()
        session = Session(Response(chunks=[b'ab', requests.ConnectionError('secret URL')]),
                          Response(b'cdef', 206, {'Content-Length': '4', 'Content-Range': 'bytes 2-5/6'}))
        self.assertEqual(self.install([item], session)['sample'], 'installed')
        self.assertEqual(len(session.calls), 2)
        self.assertEqual(session.calls[1][2]['headers']['Range'], 'bytes=2-')
        self.assertNotIn('secret URL', self.errors.getvalue())

    def test_checksum_mismatch_retries_three_no_bad_output(self):
        item = entry()
        session = Session(Response(b'badbad'), Response(b'badbad'), Response(b'badbad'))
        self.assertEqual(self.install([item], session)['sample'], 'failed')
        self.assertEqual(len(session.calls), 3)
        self.assertFalse(self.target(item).exists())
        self.assertFalse(Path(str(self.target(item)) + '.part').exists())

    def test_token_not_forwarded_to_cdn_redirect(self):
        session = Session(Response(status=302, headers={'Location': 'https://cas-bridge.xethub.hf.co/path?secret=xyz'}),
                          Response())
        response = installer.http_stream(session, URL, token='do-not-log-token')
        response.close()
        self.assertEqual(session.calls[0][2]['headers']['Authorization'], 'Bearer do-not-log-token')
        self.assertNotIn('Authorization', session.calls[1][2]['headers'])
        self.assertFalse(session.calls[0][2]['allow_redirects'])
        self.assertNotIn('do-not-log-token', self.output.getvalue() + self.errors.getvalue())

    def test_insecure_redirect_blocked(self):
        session = Session(Response(status=302, headers={'Location': 'http://huggingface.co/model.bin'}))
        with self.assertRaises(installer.InstallError):
            installer.http_stream(session, URL)
        self.assertEqual(len(session.calls), 1)

    def test_unapproved_host_and_credentials_blocked(self):
        for url in ('https://huggingface.co.evil.example/file', 'https://huggingface.co@evil.example/file',
                    'https://huggingface.co:80/file', 'https://localhost/file'):
            with self.assertRaises(installer.InstallError):
                installer.http_stream(Session(), url)

    def test_auth_failure_not_retried_and_other_file_continues(self):
        session = Session(Response(status=403), Response())
        items = [entry(ident='first'), entry(ident='second')]
        self.assertEqual(self.install(items, session), {'first': 'failed', 'second': 'installed'})
        self.assertEqual(len(session.calls), 2)
        self.assertIn('HF_TOKEN', self.errors.getvalue())
        self.assertIn('ล้มเหลว 1', self.output.getvalue())

    def test_disk_preflight_no_download_and_summary(self):
        session = Session()
        with patch.object(installer.shutil, 'disk_usage', return_value=type('Disk', (), {'free': 0})()):
            result = self.install([entry()], session)
        self.assertEqual(result['sample'], 'failed')
        self.assertEqual(session.calls, [])
        self.assertIn('พื้นที่ไม่พอ', self.errors.getvalue())
        self.assertIn('ล้มเหลว 1', self.output.getvalue())

    def test_metadata_size_and_lfs_sha256_filled(self):
        item = entry(digest=False)
        item['bytes'] = None
        digest = hashlib.sha256(b'abcdef').hexdigest()
        response = Response(json.dumps([dict(type='file', path='model.bin', size=6, lfs={'oid': digest})]).encode())
        actual = installer.fill_metadata(item, Session(response))
        self.assertEqual(actual['checksum'], digest)
        self.assertEqual(actual['bytes'], 6)
        self.assertTrue(response.closed)

    def test_metadata_git_blob_not_used_as_sha256(self):
        item = entry(digest=False)
        response = Response(json.dumps([dict(type='file', path='model.bin', size=6, oid='a' * 40)]).encode())
        actual = installer.fill_metadata(item, Session(response))
        self.assertIsNone(actual['checksum'])

    def test_dry_run_and_validate_never_network(self):
        item = entry()
        session = Session()
        self.assertEqual(self.install([item], session, dry_run=True)['sample'], 'planned')
        self.assertEqual(self.install([item], session, validate_only=True)['sample'], 'failed')
        self.assertEqual(session.calls, [])
        self.assertFalse(self.target(item).exists())

    def test_unknown_partial_ownership_no_download(self):
        item = entry()
        target = self.partial(item, b'ab')
        Path(str(target) + '.part.json').write_text('{bad')
        session = Session()
        self.assertEqual(self.install([item], session)['sample'], 'failed')
        self.assertEqual(session.calls, [])
        self.assertEqual(Path(str(target) + '.part').read_bytes(), b'ab')

    def test_sidecar_malformed_not_overwritten(self):
        (self.root / '.checksums.json').write_text('{broken')
        item = entry(digest=False)
        with self.assertRaises(installer.InstallError):
            installer.effective_entry(self.root, item)
        self.assertEqual((self.root / '.checksums.json').read_text(), '{broken')

    def test_sidecar_same_path_wrong_source_blocked(self):
        item = entry(digest=False)
        installer.record_checksum(self.root, item, hashlib.sha256(b'abcdef').hexdigest())
        other = dict(item, url=URL.replace('test/model', 'other/model'))
        with self.assertRaises(installer.InstallError):
            installer.effective_entry(self.root, other)

    def test_path_escape_blocked(self):
        for path in ('../escape', '/escape', 'dir//file', 'C:/escape', 'dir\\escape'):
            with self.assertRaises(installer.InstallError):
                installer.destination(self.root, path)

    def test_concurrent_lock_not_deleted(self):
        lock = self.root / '.install-models.lock'
        lock.write_text('other owner')
        with self.assertRaises(installer.InstallError):
            with installer.install_lock(self.root):
                self.fail('must not acquire lock')
        self.assertEqual(lock.read_text(), 'other owner')

    def make_buffalo(self, extra=None):
        path = self.root / 'reactor/archives/buffalo_l.zip'
        path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path, 'w') as archive:
            for name in installer.BUF_FILES:
                archive.writestr('buffalo_l/' + name, name.encode())
            if extra:
                archive.writestr(extra, b'bad')
        item = entry(path.read_bytes(), ident='reactor_buffalo_l')
        item['path'] = 'reactor/archives/buffalo_l.zip'
        return item

    def test_buffalo_extraction_repeat_and_validation(self):
        item = self.make_buffalo()
        installer.prepare_buffalo(self.root, item)
        installer.prepare_buffalo(self.root, item)
        installer.prepare_buffalo(self.root, item, validate_only=True)
        for name in installer.BUF_FILES:
            self.assertEqual((self.root / 'insightface/models/buffalo_l' / name).read_bytes(), name.encode())
        path = self.root / 'insightface/models/buffalo_l/genderage.onnx'
        path.write_bytes(b'bad')
        with self.assertRaises(installer.InstallError):
            installer.prepare_buffalo(self.root, item, validate_only=True)
        self.assertEqual(path.read_bytes(), b'bad')

    def test_zip_path_traversal_rejected(self):
        item = self.make_buffalo(extra='../escape.onnx')
        with self.assertRaises(installer.InstallError):
            installer.prepare_buffalo(self.root, item)
        self.assertFalse((self.root / 'insightface').exists())

    def test_list_cli_does_not_construct_session(self):
        with patch.object(installer.requests, 'Session', side_effect=AssertionError('no network')):
            self.assertEqual(installer.main(['--list', '--groups', 'sdxl']), 0)

    def test_list_subprocess_cp1252_streams_are_utf8(self):
        environment = dict(os.environ, PYTHONIOENCODING='cp1252', PYTHONUTF8='0', PYTHONDONTWRITEBYTECODE='1')
        result = subprocess.run([sys.executable, '-B', str(Path(installer.__file__)), '--list'],
                                env=environment, capture_output=True, timeout=30, check=False)
        self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', errors='replace'))
        stdout = result.stdout.decode('utf-8')
        self.assertIn('รวม 93.6 GiB', stdout)
        self.assertIn('reactor_buffalo_l', stdout)
        self.assertEqual(result.stderr, b'')


if __name__ == '__main__':
    unittest.main()
