"""Deployment path/proxy/startup checks without Docker, GPU, downloads, or mount changes."""
import io
import os
from pathlib import Path, PurePosixPath
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import runtime_init
import install_models


class RuntimeTests(unittest.TestCase):
    def test_paths_must_be_separate_subdirectories_of_volume(self):
        with tempfile.TemporaryDirectory() as folder:
            workspace = Path(folder)
            self.assertEqual(runtime_init.safe_root(workspace / "models", workspace), (workspace / "models").resolve())
            with self.assertRaises(ValueError):
                runtime_init.safe_root(workspace, workspace)
            with self.assertRaises(ValueError):
                runtime_init.safe_root(workspace.parent / "outside", workspace)
            with self.assertRaises(ValueError):
                runtime_init.safe_root("relative/models", workspace)

    def test_link_never_overwrites_nonempty_existing_data(self):
        with tempfile.TemporaryDirectory() as folder:
            destination = Path(folder) / "models"
            destination.mkdir()
            existing = destination / "user-model.safetensors"
            existing.write_bytes(b"keep these bytes")
            with self.assertRaises(ValueError):
                runtime_init.link(destination, Path(folder) / "new-models")
            self.assertEqual(existing.read_bytes(), b"keep these bytes")

    def test_invalid_ports_fail_before_opening_any_service(self):
        for value in ("0", "65536", "8188; rm -rf /", "http://example", "-10"):
            with patch.dict(os.environ, {"APP_PORT": value}):
                with self.assertRaises(ValueError):
                    runtime_init.port("APP_PORT", 5000)
        with patch.dict(os.environ, {"COMFY_INTERNAL_PORT": "8189"}):
            self.assertEqual(runtime_init.port("COMFY_INTERNAL_PORT", 0), 8189)

    def test_comfy_proxy_protects_all_paths_and_websocket_headers(self):
        config = runtime_init.proxy_config(8188, 8189, PurePosixPath("/run/image-studio/comfy.htpasswd"))
        self.assertIn("listen 8188;", config)
        self.assertIn("proxy_pass http://127.0.0.1:8189;", config)
        self.assertIn('auth_basic "Image Studio ComfyUI";', config)
        self.assertIn("auth_basic_user_file /run/image-studio/comfy.htpasswd;", config)
        self.assertIn('proxy_set_header Authorization "";', config)
        self.assertIn("proxy_set_header Upgrade $http_upgrade;", config)
        self.assertIn("access_log off;", config)

    def test_missing_import_time_assets_fail_without_download(self):
        with tempfile.TemporaryDirectory() as folder:
            entry = {"id": "missing-import-asset", "path": "instantid/example.bin", "bytes": 10}
            with patch.dict(os.environ, {"MODELS_ROOT": folder}), patch("model_catalog.select_models", return_value=[entry]), \
                    patch.object(install_models, "effective_entry", return_value=entry), \
                    patch.object(install_models, "download_one", side_effect=AssertionError("runtime must not download")) as download:
                with self.assertRaisesRegex(ValueError, "missing-import-asset"):
                    runtime_init.preflight()
                download.assert_not_called()

    def test_wait_reports_missing_nodes_after_bounded_timeout(self):
        clock = iter([0, 0, 31])
        with patch.dict(os.environ, {"COMFY_STARTUP_TIMEOUT_SECONDS": "30", "COMFY_INTERNAL_PORT": "8189"}), \
                patch.object(runtime_init.time, "monotonic", side_effect=lambda: next(clock)), \
                patch.object(runtime_init.time, "sleep"), \
                patch.object(runtime_init, "urlopen", return_value=io.BytesIO(b'{"KSampler":{}}')):
            with self.assertRaisesRegex(ValueError, "InstantIDModelLoader"):
                runtime_init.wait_comfy()


if __name__ == "__main__":
    unittest.main()
