"""Offline API/worker tests. No GPU, downloads, or RunPod calls."""
import hashlib
from http.server import ThreadingHTTPServer
import json
import os
from pathlib import Path
import struct
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
import zlib

import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import app
import core
import engine


def png(width, height):
    def chunk(kind, payload):
        return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress((b"\x00" + b"\x80\x80\x80" * width) * height)) + chunk(b"IEND", b""))


class FakeEngine(engine.Engine):
    def __init__(self, root):
        super().__init__(Path(root) / "data", Path(root) / "models")
        self.models.mkdir()
        raw = b"test model weights"
        (self.models / "weights.bin").write_bytes(raw)
        self.artifact = {"id": "test", "path": "weights.bin", "bytes": len(raw), "checksum_algorithm": "sha256",
                         "checksum": hashlib.sha256(raw).hexdigest(), "url": "https://example.test/model"}
        self.native = {}
        self.posts = []
        self.mode = "success"
        self.vram = 48
        self.schema = {node["class_type"]: {} for model in core.LOCAL_MODELS + core.POD_MODELS
                       for node in core.graph(core.validate({"prompt": "a landscape", "model": model,
                                                            "target": "local" if model in core.LOCAL_MODELS else "runpod"}), "a" * 32).values()}

    def _artifacts(self, plan):
        return [dict(self.artifact)]

    def _json(self, method, path, body=None, **kwargs):
        if path == "/system_stats":
            return {"devices": [{"type": "cuda", "name": "Fake CUDA", "vram_total": self.vram * 1024**3}]}
        if path == "/object_info":
            return self.schema
        if path == "/queue":
            return {"queue_running": [], "queue_pending": []}
        if path.startswith("/history?"):
            return self.native
        if path.startswith("/history/"):
            prompt_id = path.rsplit("/", 1)[1]
            return {prompt_id: self.native[prompt_id]} if prompt_id in self.native else {}
        if method == "POST" and path == "/prompt":
            marker = body["extra_data"]["image_studio_job"]
            stored = json.loads((self.data / "jobs" / (marker + ".json")).read_text(encoding="utf-8"))
            assert stored["status"] == "unknown", "job must be durable before GPU POST"
            self.posts.append(body)
            if self.mode == "reject":
                raise engine.RejectedSubmission("ComfyUI ปฏิเสธ workflow")
            prompt_id = "b" * 32
            row = {"prompt": [0, prompt_id, body["prompt"], body["extra_data"], []],
                   "status": {"completed": True, "messages": []},
                   "outputs": {"10": {"images": [{"type": "output", "subfolder": "image-studio", "filename": "test.png"}]}}}
            if self.mode == "gpu_error":
                row["status"]["messages"] = [["execution_error", {"node_type": "KSampler", "exception_message": "CUDA out of memory"}]]
                row["outputs"] = {}
            self.native[prompt_id] = row
            if self.mode == "uncertain":
                raise requests.Timeout("simulated lost POST response")
            return {"prompt_id": prompt_id}
        raise AssertionError((method, path))

    def _image(self, item):
        plan = next(reversed(self.jobs.values()))["plan"]
        return png(plan["width"], plan["height"])


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = FakeEngine(self.temp.name)
        self.engine.readiness(force=True)

    def tearDown(self):
        self.engine.close()
        for worker in self.engine.workers.values():
            worker.join(2)
        self.temp.cleanup()

    def submit(self, job_id="a" * 32, model="juggernaut_x"):
        return self.engine.submit({"id": job_id, "prompt": "A garden in daylight", "model": model, "seed": 42})

    def wait(self, job_id="a" * 32):
        self.engine.workers[job_id].join(3)
        self.assertFalse(self.engine.workers[job_id].is_alive())
        return self.engine.get_job(job_id)

    def test_each_native_graph_preserved_and_outputs_saved(self):
        for index, model in enumerate(core.LOCAL_MODELS + core.POD_MODELS):
            job_id = format(index + 1, "032x")
            self.submit(job_id, model)
            job = self.wait(job_id)
            self.assertEqual(job["status"], "succeeded")
            self.assertEqual(self.engine.posts[-1]["prompt"], core.graph(job["plan"], job_id))
            settings = json.loads(self.engine.output_path(job_id, "json").read_text(encoding="utf-8"))
            self.assertEqual(settings["workflow"], core.graph(job["plan"], job_id))
            self.assertEqual(engine.png_dimensions(self.engine.output_path(job_id, "png").read_bytes()),
                             (job["plan"]["width"], job["plan"]["height"]))

    def test_post_timeout_never_resubmits_recover_reads_existing_job(self):
        self.engine.mode = "uncertain"
        self.submit()
        self.assertEqual(self.wait()["status"], "unknown")
        self.assertEqual(len(self.engine.posts), 1)
        with self.assertRaises(engine.EngineError):
            self.submit("c" * 32)
        self.engine.recover("a" * 32)
        self.assertEqual(self.wait()["status"], "succeeded")
        self.assertEqual(len(self.engine.posts), 1)

    def test_unknown_recovery_without_history_stays_unknown_no_post(self):
        self.engine.mode = "uncertain"
        self.submit()
        self.wait()
        self.engine.native.clear()
        self.engine.recover("a" * 32)
        self.assertEqual(self.wait()["status"], "unknown")
        self.assertEqual(len(self.engine.posts), 1)

    def test_parallel_generate_only_one_is_admitted(self):
        started = threading.Event()
        release = threading.Event()
        original = self.engine.verify_models
        def blocked(*args, **kwargs):
            started.set()
            release.wait(2)
            return original(*args, **kwargs)
        self.engine.verify_models = blocked
        self.submit()
        self.assertTrue(started.wait(1))
        with self.assertRaises(engine.EngineError):
            self.submit("c" * 32)
        release.set()
        self.assertEqual(self.wait()["status"], "succeeded")
        self.assertEqual(len(self.engine.posts), 1)

    def test_model_tamper_fails_before_gpu_post(self):
        (self.engine.models / "weights.bin").write_bytes(b"bad")
        self.submit()
        self.assertEqual(self.wait()["status"], "failed")
        self.assertEqual(self.engine.posts, [])

    def test_missing_registry_checksum_requires_matching_installer_sidecar(self):
        digest = self.engine.artifact["checksum"]
        self.engine.artifact["checksum"] = None
        with self.assertRaises(engine.EngineError):
            self.engine.verify_models({})
        record = {key: self.engine.artifact[key] for key in ("id", "url", "bytes", "checksum_algorithm")}
        record.update(checksum=digest, source="first_download")
        marker = self.engine.models / ".checksums.json"
        marker.write_text(json.dumps({"version": 1, "artifacts": {"weights.bin": record}}), encoding="utf-8")
        self.engine.verify_models({})
        self.engine.signatures.clear()
        record["url"] = "https://different.example/model"
        marker.write_text(json.dumps({"version": 1, "artifacts": {"weights.bin": record}}), encoding="utf-8")
        with self.assertRaises(engine.EngineError):
            self.engine.verify_models({})

    def test_recovery_ignores_job_with_different_instance_marker(self):
        self.engine.mode = "uncertain"
        self.submit()
        self.wait()
        self.engine.native["b" * 32]["prompt"][3]["image_studio_instance"] = "c" * 32
        self.engine.recover("a" * 32)
        self.assertEqual(self.wait()["status"], "unknown")
        self.assertEqual(len(self.engine.posts), 1)

    def test_actual_http_prompt_400_rejected_and_500_uncertain(self):
        class Response:
            status_code = 400
            def __enter__(self):
                return self
            def __exit__(self, *args):
                return False
            def iter_content(self, size):
                yield b'{"error":"simulated"}'
        class Session:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                return False
            def request(self, *args, **kwargs):
                return Response()
        with patch.object(engine.requests, "Session", Session):
            with self.assertRaises(engine.RejectedSubmission):
                engine.Engine._json(self.engine, "POST", "/prompt", {})
            Response.status_code = 500
            with self.assertRaises(engine.UncertainSubmission):
                engine.Engine._json(self.engine, "POST", "/prompt", {})

    def test_large_models_rejected_on_4090_before_job_saved(self):
        self.engine.vram = 24
        self.engine.readiness(force=True)
        self.assertTrue(self.engine.ready_cache["ready"])
        with self.assertRaisesRegex(engine.EngineError, "48 GB"):
            self.submit(model="flux1_dev")
        self.assertEqual(self.engine.jobs, {})
        self.assertEqual(self.engine.posts, [])

    def test_native_gpu_error_is_failed_and_does_not_retry(self):
        self.engine.mode = "gpu_error"
        self.submit()
        job = self.wait()
        self.assertEqual(job["status"], "failed")
        self.assertIn("KSampler", job["message"])
        self.assertEqual(len(self.engine.posts), 1)

    def test_definite_prompt_rejection_is_failed(self):
        self.engine.mode = "reject"
        self.submit()
        self.assertEqual(self.wait()["status"], "failed")

    def test_job_id_idempotency_and_user_paths_rejected(self):
        self.submit()
        self.wait()
        again = self.submit()
        self.assertEqual(again["status"], "succeeded")
        self.assertEqual(len(self.engine.posts), 1)
        with self.assertRaises(engine.EngineError):
            self.engine.submit({"id": "a" * 32, "prompt": "another scene"})
        with self.assertRaises(engine.EngineError):
            self.engine.submit({"id": "c" * 32, "prompt": "a garden", "model_path": "/etc/passwd"})

    def test_restart_unknown_requires_readonly_recovery(self):
        self.engine.mode = "uncertain"
        self.submit()
        self.wait()
        resumed = engine.Engine(self.engine.data, self.engine.models)
        self.assertEqual(resumed.get_job("a" * 32)["status"], "unknown")
        self.assertFalse(resumed.workers)
        resumed.close()

    def test_new_pod_marks_previous_pod_unfinished_job_unrecoverable(self):
        self.engine.pod_id = "oldpod123456"
        self.engine.mode = "uncertain"
        self.submit()
        self.wait()
        with patch.dict(os.environ, {"RUNPOD_POD_ID": "newpod123456"}):
            resumed = engine.Engine(self.engine.data, self.engine.models)
        self.assertEqual(resumed.get_job("a" * 32)["status"], "failed")
        self.assertIn("คนละเครื่อง", resumed.get_job("a" * 32)["message"])
        resumed.close()

    def test_png_corruption_truncation_and_bomb_rejected(self):
        good = png(2, 3)
        self.assertEqual(engine.png_dimensions(good), (2, 3))
        with self.assertRaises(engine.EngineError):
            engine.png_dimensions(good[:33])
        damaged = bytearray(good)
        damaged[-15] ^= 1
        with self.assertRaises(engine.EngineError):
            engine.png_dimensions(damaged)
        with self.assertRaises(engine.EngineError):
            engine.png_dimensions(good + b"trailing data")

    def test_readiness_does_not_download_or_post(self):
        self.assertTrue(self.engine.readiness(force=True)["ready"])
        self.assertEqual(self.engine.posts, [])
        self.engine.close()
        self.assertFalse(self.engine.readiness()["ready"])


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = FakeEngine(self.temp.name)
        self.engine.readiness(force=True)
        self.code = "safecode_for_test_1234567890"
        self.application = app.Application(self.engine, self.code)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), self.application.handler())
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = "http://127.0.0.1:" + str(self.server.server_port)
        self.client = requests.Session()
        self.client.trust_env = False
        self.client.headers["X-Requested-With"] = "ImageStudio"

    def tearDown(self):
        self.engine.close()
        for worker in self.engine.workers.values():
            worker.join(2)
        self.server.shutdown()
        self.server.server_close()
        self.client.close()
        self.temp.cleanup()

    def login(self, **headers):
        return self.client.post(self.base + "/api/login", json={"code": self.code}, headers=headers, timeout=5)

    def test_protected_routes_login_cookie_and_https(self):
        self.assertEqual(self.client.get(self.base + "/api/status", timeout=5).status_code, 401)
        self.assertTrue(self.client.get(self.base + "/healthz", timeout=5).json()["ready"])
        logged = self.login(**{"X-Forwarded-Proto": "https"})
        self.assertEqual(logged.status_code, 200)
        cookie = logged.headers["Set-Cookie"]
        for word in ("HttpOnly", "SameSite=Strict", "Secure"):
            self.assertIn(word, cookie)
        self.client.cookies.clear()
        self.assertEqual(self.login().status_code, 200)
        self.assertEqual(self.client.get(self.base + "/api/status", timeout=5).status_code, 200)

    def test_cross_origin_mutation_and_missing_marker_blocked(self):
        bad = self.login(Origin="https://attacker.example")
        self.assertEqual(bad.status_code, 403)
        bad = self.client.post(self.base + "/api/login", json={"code": self.code}, headers={"X-Requested-With": "bad"}, timeout=5)
        self.assertEqual(bad.status_code, 403)
        self.assertEqual(self.login().status_code, 200)
        bad = self.client.post(self.base + "/api/jobs", json={"id": "a" * 32, "prompt": "a garden"}, headers={"Origin": "https://attacker.example"}, timeout=5)
        self.assertEqual(bad.status_code, 403)
        self.assertFalse(self.engine.jobs)

    def test_new_page_preserves_all_form_controls_and_has_no_pc_routing(self):
        text = self.client.get(self.base + "/", timeout=5).text
        for control in ("model", "prompt", "negative", "ratio", "quality", "seed", "generate", "code"):
            self.assertIn('id="' + control + '"', text)
        self.assertNotIn('name="target"', text)
        self.assertNotIn("pod-url", text)
        self.assertNotIn(self.code, text)

    def test_generate_then_download_authenticated_png_and_settings(self):
        self.login()
        result = self.client.post(self.base + "/api/jobs", json={"id": "a" * 32, "prompt": "a garden", "seed": 42}, timeout=5)
        self.assertEqual(result.status_code, 200)
        self.engine.workers["a" * 32].join(3)
        image = self.client.get(self.base + "/api/jobs/" + "a" * 32 + "/image", timeout=5)
        self.assertEqual(image.status_code, 200)
        self.assertEqual(engine.png_dimensions(image.content), (768, 1152))
        settings = self.client.get(self.base + "/api/jobs/" + "a" * 32 + "/settings", timeout=5)
        self.assertEqual(settings.status_code, 200)
        self.assertEqual(settings.json()["plan"]["seed"], 42)
        self.client.cookies.clear()
        self.assertEqual(self.client.get(self.base + "/api/jobs/" + "a" * 32 + "/image", timeout=5).status_code, 401)

    def test_wrong_unicode_login_denied_and_code_redacted_from_status(self):
        response = self.client.post(self.base + "/api/login", json={"code": "ภาษาไทย"}, timeout=5)
        self.assertEqual(response.status_code, 401)
        self.login()
        self.engine.jobs["a" * 32] = {"id": "a" * 32, "created": 1, "status": "failed", "message": self.code, "plan": {}}
        response = self.client.get(self.base + "/api/status", timeout=5)
        self.assertNotIn(self.code, response.text)


if __name__ == "__main__":
    unittest.main()
