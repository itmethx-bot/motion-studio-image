"""ทดสอบ launcher แบบจำลองเท่านั้น ไม่เรียกบัญชี RunPod หรือเริ่มค่าเช่า."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

SPEC = importlib.util.spec_from_file_location("deploy_launcher", Path(__file__).resolve().parents[1] / "launcher.py")
L = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(L)


def config():
    return {
        **L.DEFAULTS, "RUNPOD_API_KEY": "private-test-key-0123456789",
        "RUNPOD_TEMPLATE_ID": "template123", "RUNPOD_NETWORK_VOLUME_ID": "volume123",
        "RUNPOD_DATACENTER_IDS": '["EU-RO-1"]', "APP_ACCESS_CODE": "secret-app-code-123456",
    }


class Response:
    def __init__(self, data=None, status=200, text=""):
        self.status_code = status
        self.data = data
        self.text = text
        self.content = b"json" if data is not None else b""

    def json(self):
        if self.data is None:
            raise ValueError("not json")
        return self.data


class Health:
    def __init__(self, ready=True):
        self.ready = ready
        self.urls = []

    def get(self, url, **kwargs):
        self.urls.append((url, kwargs))
        return Response({"ready": self.ready})


class FakeAPI:
    def __init__(self, store):
        self.store = store
        self.calls = []
        self.posts = []
        self.post_results = []
        self.pod = None
        self.reconciled = None
        self.volume = {"id": "volume123", "dataCenterId": "EU-RO-1"}
        self.delete_error = None
        self.delete_sticks = False

    def call(self, method, path, payload=None, **kwargs):
        self.calls.append((method, path))
        if method == "GET" and path.startswith("/networkvolumes/"):
            return self.volume
        if method == "POST":
            # บันทึกคำขอก่อน POST และไฟล์สถานะไม่บรรจุ key หรือ access code
            before = self.store.load()
            assert before["phase"] == "creating"
            assert before["request_name"] == payload["name"]
            assert before["attempt"] == len(self.posts) + 1
            assert "private-test-key" not in json.dumps(before)
            assert "secret-app-code" not in json.dumps(before)
            self.posts.append(payload)
            result = self.post_results.pop(0) if self.post_results else None
            if isinstance(result, Exception):
                raise result
            if result is not None:
                return result
            self.pod = {"id": "pod123", "name": payload["name"], "desiredStatus": "RUNNING",
                        "networkVolume": {"id": "volume123"}, "costPerHr": "0.5"}
            return self.pod
        if method == "DELETE":
            if self.delete_error:
                raise self.delete_error
            if not self.delete_sticks:
                self.pod = None
            return {}
        raise AssertionError((method, path))

    def get_pod(self, pod_id):
        self.calls.append(("GET", f"/pods/{pod_id}"))
        return self.pod

    def find_created(self, name):
        self.calls.append(("GET", "/pods?name"))
        if self.reconciled is True:
            self.pod = {"id": "pod123", "name": name, "desiredStatus": "RUNNING",
                        "networkVolume": {"id": "volume123"}}
            return [self.pod]
        return self.reconciled or []


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = L.StateStore(Path(self.temp.name) / "state.json")
        self.api = FakeAPI(self.store)
        self.messages = []
        self.sleeps = []
        self.now = 0
        self.opened = []
        self.health = Health()
        self.values = config()

    def sleep(self, seconds):
        self.sleeps.append(seconds)
        self.now += seconds

    def app(self, answer="y", values=None):
        return L.Launcher(values or self.values, self.store, api=self.api, printer=self.messages.append,
                          ask=lambda text: answer, sleep=self.sleep, clock=lambda: self.now,
                          opener=self.opened.append, health_session=self.health)

    def existing(self):
        state = {"version": 1, "phase": "active", "request_name": "image-studio-owned",
                 "pod_id": "pod123", "network_volume_id": "volume123", "app_port": 5000}
        self.store.save(state)
        self.api.pod = {"id": "pod123", "name": state["request_name"], "desiredStatus": "RUNNING",
                        "networkVolume": {"id": "volume123"}}
        return state

    def test_config_quotes_lists_spaces_env_precedence(self):
        path = Path(self.temp.name) / "config.env"
        path.write_text('RUNPOD_GPU_TYPE_IDS="NVIDIA GeForce RTX 4090" # valid\n'
                        'RUNPOD_DATACENTER_IDS=["EU-RO-1", "US-TX-3"]\n'
                        "APP_ACCESS_CODE='a#quoted space secret'\n", encoding="utf-8")
        values = L.read_config(path, {"APP_PORT": "5010"})
        self.assertEqual(L.parse_list(values["RUNPOD_GPU_TYPE_IDS"], "gpu"), ["NVIDIA GeForce RTX 4090"])
        self.assertEqual(L.parse_list(values["RUNPOD_DATACENTER_IDS"], "dc"), ["EU-RO-1", "US-TX-3"])
        self.assertEqual(values["APP_ACCESS_CODE"], "a#quoted space secret")
        self.assertEqual(values["APP_PORT"], "5010")

    def test_missing_values_actionable_and_no_network(self):
        with self.assertRaisesRegex(L.LauncherError, "APP_ACCESS_CODE"):
            self.app(values={**self.values, "APP_ACCESS_CODE": ""}).start()
        self.assertEqual(self.api.calls, [])
        with self.assertRaisesRegex(L.LauncherError, "12"):
            L.validate_start({**self.values, "APP_ACCESS_CODE": "short"})

    def test_start_payload_persistence_and_health_before_open(self):
        url = self.app().start()
        self.assertEqual(url, "https://pod123-5000.proxy.runpod.net")
        self.assertEqual(self.opened, [url])
        sent = self.api.posts[0]
        self.assertEqual(sent["gpuTypeIds"], ["NVIDIA GeForce RTX 4090"])
        self.assertEqual(sent["containerDiskInGb"], 40)
        self.assertEqual(sent["networkVolumeId"], "volume123")
        self.assertEqual(sent["dataCenterIds"], ["EU-RO-1"])
        self.assertEqual(sent["volumeMountPath"], "/workspace")
        self.assertEqual(sent["ports"], ["5000/http", "8188/http"])
        self.assertEqual(sent["env"]["COMFY_INTERNAL_PORT"], "8189")
        self.assertEqual(sent["env"]["BOOTSTRAP_MODELS"], "0")
        self.assertEqual(sent["env"]["MODEL_GROUPS"], "sdxl,character,pose,segmentation")
        self.assertNotIn("HF_TOKEN", sent["env"])
        self.assertEqual(sent["env"]["IMAGE_STUDIO_CODE"], self.values["APP_ACCESS_CODE"])
        self.assertNotIn(self.values["RUNPOD_API_KEY"], json.dumps(sent))
        self.assertTrue(self.store.load()["app_ready"])
        self.assertTrue(self.health.urls[0][0].endswith("/healthz"))
        self.assertFalse(self.health.urls[0][1]["allow_redirects"])

    def test_explicit_bootstrap_and_groups_in_payload(self):
        self.values.update(BOOTSTRAP_MODELS="1", MODEL_GROUPS='["sdxl", "character", "cloud"]')
        self.app().start()
        self.assertEqual(self.api.posts[0]["env"]["BOOTSTRAP_MODELS"], "1")
        self.assertEqual(self.api.posts[0]["env"]["MODEL_GROUPS"], "sdxl,character,cloud")
        self.assertNotIn("HF_TOKEN", self.api.posts[0]["env"])
        self.assertNotIn("BOOTSTRAP_MODELS", self.store.load())

    def test_invalid_bootstrap_or_groups_prevents_api_request(self):
        for invalid in ({"BOOTSTRAP_MODELS": "true"}, {"BOOTSTRAP_MODELS": ""},
                        {"MODEL_GROUPS": ""}, {"MODEL_GROUPS": "sdxl,unknown"}, {"MODEL_GROUPS": "[]"}):
            with self.subTest(invalid=invalid), self.assertRaises(L.LauncherError):
                self.app(values={**self.values, **invalid}).start()
        self.assertEqual(self.api.calls, [])

    def test_volume_location_mismatch_no_post(self):
        self.api.volume["dataCenterId"] = "US-TX-3"
        with self.assertRaisesRegex(L.LauncherError, "US-TX-3"):
            self.app().start()
        self.assertEqual(self.api.posts, [])
        self.assertFalse(self.store.load())

    def test_gpu_unavailable_retries_only_three(self):
        self.api.post_results = [L.ApiError("POST", 400, True), L.ApiError("POST", 409, True)]
        self.app().start()
        self.assertEqual(len(self.api.posts), 3)
        self.assertEqual(self.sleeps, [10, 10])
        self.assertEqual(len(set(x["name"] for x in self.api.posts)), 1)

    def test_exhausted_gpu_retries_clear_safe_failure(self):
        self.api.post_results = [L.ApiError("POST", 400, True)] * 3
        with self.assertRaisesRegex(L.LauncherError, "3"):
            self.app().start()
        self.assertEqual(len(self.api.posts), 3)
        self.assertEqual(self.sleeps, [10, 10])
        self.assertEqual(self.store.load(), {})

    def test_bad_template_400_never_retry(self):
        self.api.post_results = [L.ApiError("POST", 400)]
        with self.assertRaises(L.ApiError):
            self.app().start()
        self.assertEqual(len(self.api.posts), 1)
        self.assertEqual(self.store.load(), {})

    def test_ambiguous_timeout_reconciles_without_duplicate(self):
        self.api.post_results = [L.TransportError("timeout")]
        self.api.reconciled = True
        self.app().start()
        self.assertEqual(len(self.api.posts), 1)
        self.assertEqual(self.store.load()["pod_id"], "pod123")

    def test_500_absent_reconcile_blocks_future_start(self):
        self.api.post_results = [L.ApiError("POST", 500)]
        for attempt in range(2):
            with self.assertRaisesRegex(L.LauncherError, "ไม่สร้างซ้ำ"):
                self.app().start()
        self.assertEqual(len(self.api.posts), 1)
        self.assertEqual(self.store.load()["phase"], "unknown")
        self.assertTrue(self.store.load()["request_name"].startswith("image-studio-"))

    def test_success_response_with_bad_pod_does_not_resubmit(self):
        self.api.post_results = [{"no_id": True}]
        with self.assertRaisesRegex(L.LauncherError, "ไม่สร้างซ้ำ"):
            self.app().start()
        self.assertEqual(len(self.api.posts), 1)
        self.assertEqual(self.store.load()["phase"], "unknown")

    def test_app_timeout_preserves_active_and_no_new_post(self):
        self.values["STARTUP_TIMEOUT_SECONDS"] = "60"
        self.health.ready = False
        with self.assertRaisesRegex(L.LauncherError, "1 นาที"):
            self.app().start()
        self.assertEqual(len(self.api.posts), 1)
        self.assertEqual(self.store.load()["phase"], "active")
        self.assertEqual(self.opened, [])
        self.assertEqual(self.now, 60)

    def test_existing_declined_never_duplicate(self):
        self.existing()
        self.assertIsNone(self.app(answer="n").start())
        self.assertEqual(self.api.posts, [])
        self.assertEqual(self.store.load()["pod_id"], "pod123")

    def test_existing_reused_no_start_config_required(self):
        self.existing()
        values = {**L.DEFAULTS, "RUNPOD_API_KEY": self.values["RUNPOD_API_KEY"]}
        self.app(values=values).start()
        self.assertEqual(self.api.posts, [])
        self.assertEqual(self.opened, ["https://pod123-5000.proxy.runpod.net"])

    def test_delete_requires_confirmation_and_never_deletes_volume(self):
        self.existing()
        self.assertFalse(self.app(answer="n").terminate())
        self.assertFalse(any(x[0] == "DELETE" for x in self.api.calls))
        self.assertTrue(self.app().terminate())
        self.assertEqual(self.store.load(), {})
        self.assertEqual([x for x in self.api.calls if x[0] == "DELETE"], [("DELETE", "/pods/pod123")])
        self.assertIn("Network Volume ไม่หาย", "\n".join(self.messages))

    def test_delete_ambiguous_preserves_state(self):
        self.existing()
        self.api.delete_error = L.TransportError("timeout")
        with self.assertRaisesRegex(L.LauncherError, "ยังยืนยัน"):
            self.app().terminate(yes=True)
        self.assertEqual(self.store.load()["pod_id"], "pod123")

    def test_delete_success_unconfirmed_preserves_state(self):
        self.existing()
        self.api.delete_sticks = True
        with self.assertRaisesRegex(L.LauncherError, "ยังยืนยัน"):
            self.app().terminate(yes=True)
        self.assertEqual(self.store.load()["pod_id"], "pod123")
        self.assertEqual(len([x for x in self.api.calls if x[0] == "DELETE"]), 1)

    def test_pod_name_or_volume_mismatch_blocks_delete(self):
        self.existing()
        self.api.pod["name"] = "different-project"
        with self.assertRaisesRegex(L.LauncherError, "ชื่อ Pod"):
            self.app().terminate(yes=True)
        self.assertFalse(any(x[0] == "DELETE" for x in self.api.calls))
        self.api.pod["name"] = "image-studio-owned"
        self.api.pod["networkVolume"]["id"] = "different-volume"
        with self.assertRaisesRegex(L.LauncherError, "Network Volume"):
            self.app().terminate(yes=True)

    def test_status_does_not_require_template_or_access_code(self):
        self.existing()
        values = {**L.DEFAULTS, "RUNPOD_API_KEY": self.values["RUNPOD_API_KEY"]}
        self.app(values=values).status()
        self.assertEqual(self.api.posts, [])
        self.assertTrue(self.store.load()["app_ready"])

    def test_file_lock_prevents_simultaneous_launcher(self):
        with self.store.locked():
            with self.assertRaisesRegex(L.LauncherError, "อีกหน้าต่าง"):
                with L.StateStore(self.store.path).locked():
                    pass
        with self.store.locked():
            self.store.save({})

    def test_corrupt_state_blocks_before_api(self):
        self.store.path.write_text("not json", encoding="utf-8")
        with self.assertRaisesRegex(L.LauncherError, "state.json"):
            self.app().start()
        self.assertEqual(self.api.calls, [])

    def test_redacts_known_secrets_and_bearer(self):
        result = L.Redactor(self.values)(f"Bearer other-token {self.values['RUNPOD_API_KEY']} {self.values['APP_ACCESS_CODE']}")
        self.assertNotIn("other-token", result)
        self.assertNotIn(self.values["RUNPOD_API_KEY"], result)
        self.assertNotIn(self.values["APP_ACCESS_CODE"], result)

    def test_main_debug_redacts_exception(self):
        path = Path(self.temp.name) / "config.env"
        path.write_text("\n".join(f"{key}={value}" for key, value in self.values.items()), encoding="utf-8")
        captured = io.StringIO()
        with mock.patch.object(L.Launcher, "status", side_effect=L.LauncherError(self.values["RUNPOD_API_KEY"] + self.values["APP_ACCESS_CODE"])), mock.patch.dict(L.os.environ, {}, clear=True), contextlib.redirect_stdout(captured):
            code = L.main(["--status", "--debug", "--config", str(path), "--state", str(self.store.path)])
        self.assertEqual(code, 1)
        self.assertNotIn(self.values["RUNPOD_API_KEY"], captured.getvalue())
        self.assertNotIn(self.values["APP_ACCESS_CODE"], captured.getvalue())

    def test_cli_cp1252_pipe_missing_key_emits_thai_without_traceback(self):
        path = Path(self.temp.name) / "empty.env"
        path.write_text("# ไม่มี API key — ทดสอบ error ก่อนเชื่อมต่อเท่านั้น\n", encoding="utf-8")
        environment = dict(os.environ)
        environment.pop("RUNPOD_API_KEY", None)
        environment.update(PYTHONIOENCODING="cp1252", PYTHONUTF8="0")
        completed = subprocess.run(
            [sys.executable, "-B", str(Path(SPEC.origin)), "--status", "--config", str(path),
             "--state", str(self.store.path)],
            env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20,
        )
        output = (completed.stdout + completed.stderr).decode("utf-8")
        self.assertEqual(completed.returncode, 1)
        self.assertIn("ยังไม่ได้ตั้งค่า RUNPOD_API_KEY", output)
        self.assertNotIn("Traceback", output)
        self.assertNotIn("UnicodeEncodeError", output)


class APIClientTests(unittest.TestCase):
    def test_gpu_classification_not_generic_bad_request(self):
        session = mock.Mock()
        session.headers = {}
        api = L.RunPodAPI("hidden-key", session=session)
        session.request.return_value = Response(status=400, text="GPU is not available in this data center")
        with self.assertRaises(L.ApiError) as result:
            api.call("POST", "/pods")
        self.assertTrue(result.exception.gpu_unavailable)
        session.request.return_value = Response(status=400, text="containerDiskInGb is invalid hidden-key")
        with self.assertRaises(L.ApiError) as result:
            api.call("POST", "/pods")
        self.assertFalse(result.exception.gpu_unavailable)
        self.assertNotIn("hidden-key", str(result.exception))
        self.assertFalse(session.request.call_args.kwargs["allow_redirects"])
        self.assertFalse(session.trust_env)

    def test_404_is_missing_only_when_explicitly_allowed(self):
        session = mock.Mock()
        session.headers = {}
        session.request.return_value = Response(status=404)
        api = L.RunPodAPI("hidden-key", session=session)
        self.assertIsNone(api.get_pod("pod123"))
        with self.assertRaises(L.ApiError):
            api.call("GET", "/networkvolumes/volume123")


if __name__ == "__main__":
    unittest.main()
